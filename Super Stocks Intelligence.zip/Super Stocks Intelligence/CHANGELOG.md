# Changelog

Riwayat ringkas perubahan besar (dirangkum dari folder `plans/` lama, yang akan dihapus). Hanya yang membantu memahami kode saat ini; keputusan yang berlaku ada di `ROADMAP.md`.

## Belum dirilis (2026-10-03)
- Laporan bulanan tahun berjalan (YTD) di Perbandingan Emiten:
  - Periode baru `M01`..`M12` (`financial.ts`), diunggah hanya untuk tahun kalender berjalan; nama file ("Januari", "Feb", dst.) dikenali oleh `suggestIdentity`.
  - `validateMonthly` (`yearWindow.ts`): bila ada emiten dengan laporan bulanan, minimal 2 emiten harus punya set bulan identik (berurutan dari Januari, jumlah sama), contoh FY2021-2025 + Jan 2026. Selain itu perbandingan diblokir dengan alasan per emiten.
  - Bulanan hanya tampil sebagai rasio YTD mentah (`MonthlyPanel`), tanpa anualisasi dan tanpa Skor Model; Skor dan ranking tetap FY saja. `MODEL_VERSION` tidak berubah.
  - PDF bulanan memvalidasi bulan akhir periode (`detectPeriodMonth`); ketidakcocokan membekukan alur tarik via `YearMismatchError` (field `months`).
- Halaman "Daftar Emiten" (`DaftarEmitenPage.tsx`) ditambahkan ke navigasi utama:
  - Menggabungkan registri tetap bank IDX (`ALL_BANKS`/`registryWith`) dengan emiten dari dokumen pengguna.
  - Menampilkan skor Mamdani per tahun fiskal hanya dari analisis terverifikasi; bank tanpa laporan tidak diberi skor buatan.
  - Menyediakan pencarian, filter kategori, tahun akhir, jendela 2-5 tahun, harga FY, perubahan skor, dan perubahan harga.
  - Bank syariah (BRIS, BTPS, PNBS) dihapus dari registri dan kartu contoh Simulasi; hanya ditolak saat unggah. Registri ditambah bank umum AGRS, BBSI, BSWD, INPC.
- Modul konteks valuasi `src/domain/valuation.ts`:
  - BVPS diturunkan dari ekuitas dan estimasi jumlah saham (`laba bersih / EPS`); PBV dan PER memakai harga analisis.
  - PBV wajar memakai formula ilustratif `(ROE - g) / (r - g)` dengan default `g = 6%` dan `r = 12%`.
  - Kuadran "Kualitas vs Valuasi" membandingkan persentil skor dan PBV antarbank yang memiliki data pada tahun akhir.
  - Seluruh metrik valuasi tetap konteks dan tidak mengubah skor Mamdani.
- Halaman "Simulasi End-to-End" (Koleksi Laporan, `SimulasiPage.tsx` + `domain/simulation.ts`). Walkthrough 7 tahap untuk data ilustratif BBRI FY2020-2025 dan BMRI FY2021-2025:
  - Alur: Perpustakaan → PDF→TXT → DeepSeek → dialog 9 akun + verifikasi → Mamdani → skor → komparasi.
  - Elemen pendukung: toast, disclaimer, autoplay yang berhenti di gerbang verifikasi.
  - Skor dihitung oleh `computeFuzzy` asli. Komparasi memakai `validateComparison`.
  - BMRI FY2025 sengaja dibuat sebagai dokumen jebakan tahun.
  - Tidak ada panggilan AI atau backend sungguhan.
- Kebijakan key: DeepSeek ditampilkan sebagai secret backend yang hanya bisa dibaca (Akun Saya). Entri Anthropic dihapus dari `PROVIDERS`. `setKey` menolak non-admin, dan input key open-source dinonaktifkan untuk viewer.
- Komparasi N tahun (2-10) apple-to-apple: `yearWindow.ts` `validateComparison`, `YearDisclaimer`. Skor/ranking disembunyikan bila jendela tidak identik.
- Pembekuan saat tahun tidak cocok: `YearMismatchError` di `pullFromCollection`, `usePull`/`YearMismatchDialog` di `PullFlow.tsx`, kunci verifikasi untuk `columnYear` salah.
- Halaman "Folder Laporan" (`FolderLibraryPage.tsx`) di submenu Koleksi Laporan: per bank, per tahun, termasuk tahun kosong.
- Koreksi label 23 rule menjadi 24 (Metodologi + i18n).
- Dokumentasi dikonsolidasi menjadi 6 file `.md`.
- Fitur "Data & Cadangan" (ekspor/impor/hapus data, `backup.ts`) dihapus dari Akun Saya.
- Metodologi > Flowchart: panel "Flowchart SIA" di bawah "Input, konversi & verifikasi" (`SiaFlow` di `MetodologiPage.tsx`): swimlane Admin/Sistem/Pengguna/Penyedia AI dengan simbol dokumen SIA (terminator, input manual, proses, keputusan, dokumen, basis data, operasi manual, proses terdefinisi, konektor antarhalaman) dan legenda. Belum dicek visual di browser.
- Code-splitting: 8 halaman di `App.tsx` memakai `React.lazy` + `Suspense`; chunk utama ~1,43 MB menjadi ~1,10 MB. `CollectionsPages` dan `MarketPages` tetap statis karena diimpor `WorkspacePages`.
- Dokumentasi historis dikonsolidasikan kembali ke enam file resmi; empat berkas `plans/*.md` lama dihapus setelah keputusan relevannya dipindahkan.
- Terjemahan Inggris untuk Daftar Emiten dan Simulasi End-to-End ditambahkan melalui `src/i18n/extra/simulasi.ts`, termasuk teks dinamis untuk toast, mismatch tahun, alasan komparasi, istilah fuzzy/rule, dan konteks valuasi.
- `PerbandinganPage` mendapat grafik skor vs harga berbentuk small-multiple per emiten:
  - Skor dan harga manual dinormalisasi ke indeks 100 pada FY awal agar arah perubahan dapat dibandingkan meskipun satuannya berbeda.
  - Garis tanpa area fill mengikuti gaya terminal; tooltip menampilkan nilai asli dan indeks, serta ringkasan menampilkan Δ skor dan Δ harga.
  - Harga yang tidak lengkap menghasilkan empty state, bukan garis nol yang menyesatkan.
  - Disclaimer menegaskan harga bukan feed real-time, kesearahan bukan kausalitas, dan grafik bukan rekomendasi beli/jual.
- Verifikasi otomatis terbaru berhasil: `pnpm exec tsc --noEmit -p .` dan `pnpm build`. Build hanya memberi peringatan chunk utama sekitar 1,09 MB (> 500 kB).

### Catatan keputusan dan alasan tingkat tinggi
- **Simulasi dipisahkan dari data nyata** agar alur TA dapat didemonstrasikan lengkap tanpa mengklaim telah memanggil PDF, DeepSeek, atau backend sungguhan. Engine skor dan validator perbandingan tetap memakai implementasi produksi sehingga perilaku model yang ditampilkan deterministik.
- **Registri emiten dibuat tetap, tetapi skor tidak dipraisi**. Pemisahan ini memungkinkan daftar cakupan bank terlihat sejak awal tanpa menciptakan angka fiktif; analisis tetap bergantung pada laporan FY yang diunggah dan diverifikasi.
- **Valuasi dipisahkan dari kualitas fundamental**. Skor Mamdani menjawab kualitas berbasis sembilan rasio, sedangkan PBV/PER/kuadran membantu membaca murah-mahal relatif. Mencampurkan keduanya ke satu skor ditolak karena akan mengubah metodologi dan versi model.
- **Syariah tetap ditampilkan namun tidak dianalisis** agar daftar emiten transparan sekaligus menjaga perbandingan apple-to-apple untuk bank konvensional.
- **DeepSeek harus server-side** karena key berbayar tidak boleh berada di bundle atau localStorage. UI sudah mencerminkan kebijakan tersebut, tetapi integrasi teknis lama Anthropic di `aiExtract.ts` masih menjadi utang yang harus dihapus setelah proxy backend tersedia.
- **Alternatif harga real-time belum diaktifkan pada Daftar Emiten**. Implementasi saat ini memakai harga yang tersimpan bersama analisis FY agar label periodenya konsisten dan tidak mencampur harga terkini dengan laporan historis.
- **Grafik skor vs harga ditunda ke `PerbandinganPage`** agar Daftar Emiten tetap menjadi tabel pemindaian lintas bank, sedangkan analisis deret waktu ditempatkan pada halaman komparasi.

## Riwayat sebelumnya (urut kasar)
1. **Template awal** dashboard fintech/asuransi generik (Overview, Payment, dll.) dengan token tema kartu 20px, glow, emoji. Diganti total.
2. **Re-tema ke saham tambang emas** BEI (model lama `mamdani-v1.0`, ~40-45 emiten, IDR). Kemudian **dikonversi ke perbankan** IDX-IC sektor G: model `mamdani-bank-v1.0`, 9 akun, 9 rasio, 24 rule, data demo, banner profil, teks ID/EN. Sisa berita bertema tambang masih ada di `news.ts` (backlog).
3. **Struktur navigasi** Main / Features / Support dengan alur koleksi -> analisis -> insight -> advisory; kemudian header full-width bergaya Aniq-ui.
4. **Redesign formal terminal keuangan** (gaya Bloomberg/Refinitiv): teal hanya untuk aksi/indikator/skor, kosakata radius 10/8/6/4, tanpa glow/blur/gradien/emoji, hover lewat border/background.
5. **Kloter 0 data contract** (`financial.ts`): `ALLOWED_STATEMENT_TYPES`, `isAllowedSource`, `RATIO_DEFINITIONS`, `MODEL_VERSION`; hanya Laba Rugi + Posisi Keuangan konsolidasian.
6. **Pipeline PDF hemat token**: pdf.js ke teks di browser, `accountMatcher` berbasis aturan, AI (Anthropic) hanya untuk akun yang gagal; verifikasi manusia wajib.
7. **Panel skor & defuzzifikasi** di `FuzzyMamdani.tsx` didesain ulang agar mudah dipahami awam (`ScoreGauge`), fuzzifikasi terkunci, mode kumulatif.
8. **Overview & pasar**: World Bank + Frankfurter tanpa key, opsional FMP/Twelve Data/Finnhub (`market.ts`); hanya konteks, bukan input model.
9. **Rebrand** menjadi SSI / Stock Intelligence (`Logo.tsx`, wordmark monoline), hero login didesain ulang.
10. **News role-based** (admin publish, viewer komentar) dan **Data Analytics** admin-only (`usage.ts`, data demo berlabel).
11. **Responsivitas** 320-480px: drawer mobile, `h-dvh`, tabel scroll horizontal.
12. **Rencana backend Laravel** di Hostinger shared hosting (belum dibangun; detail di `ROADMAP.md`).
