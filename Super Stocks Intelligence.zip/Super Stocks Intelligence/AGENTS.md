# figma-make-app (SSI / Aurevia Intelligence)

React + Vite + Tailwind CSS project running inside Figma Make. Product: Super Stocks Intelligence (SSI), a fuzzy-logic scoring tool for Indonesian conventional banks. See `README.md` for methodology and data contract, `ROADMAP.md` for decisions and the open backlog, `HANDOFF.md` for current status and the next-step checklist (read first), `CHANGELOG.md` for history. Keep documentation to these 6 `.md` files (incl. `CLAUDE.md`, `AGENTS.md`); do not add new ones.

## Development Server

A Vite development server is **already running** on `$PORT` (default 8443). You don't need to start it manually.

- Preview URL: The user can access the running app through the preview panel
- Hot reload: Changes to source files are reflected immediately

## Project Structure

This is the canonical project structure. Start with task-relevant files below. Only follow imports or inspect other files when required, when a documented path is missing, or when the repository contradicts this guide.

Scaffold:
- `src/main.tsx` - React entrypoint; imports `src/index.css` and mounts `src/App.tsx` into `#root`
- `src/index.css` - Global CSS, Tailwind v4 import, and the dark/light CSS-variable palette (`[data-theme="light"]` overrides)
- `index.html`, `package.json`, `vite.config.ts` (React, Tailwind v4, Figma Make plugins, `@` alias for `src`), `.mise.toml`

App shell (state-based navigation, no router):
- `src/App.tsx` - shell, `NAV` (with the Koleksi Laporan submenu incl. "Folder Laporan" and "Simulasi End-to-End"), `parentMap`, `PAGE_DESC`, and the render switch `{active === "..." && <Page />}`. A new page needs all four.
- `src/Auth.tsx` - login/register (dev bypass = admin); `src/FuzzyMamdani.tsx` - interactive engine page
- `src/ui.tsx` - primitives: Panel, Btn, Badge, Notice (requires an `icon` prop), EmptyState, Stat, Table, Row, Field, Select. Reuse these before writing custom UI.
- `src/theme.ts` - palette `T`/`palette` (CSS variables), the single source for colours

Domain (`src/domain/`, no JSX except `store.tsx`):
- `engine.ts` (membership functions, `RULES`, `RULE_COUNT`, `computeFuzzy`), `financial.ts` (canonical accounts, `RATIO_DEFINITIONS`, `MODEL_VERSION`), `accountMatcher.ts`
- `store.tsx` (workspace store, `pullFromCollection`, `YearMismatchError`), `issuers.ts` (`WINDOW_YEARS = 5`, `coverageWindow`, `isSharia`, `bankSegmentOf`, `ALL_BANKS`, `registryWith`), `yearWindow.ts` (N-year comparison validation)
- `pdfScan.ts` / `pdfText.ts` (pdf.js), `aiExtract.ts` (Anthropic call), `apiKeys.ts`, `blobStore.ts` (IndexedDB `ssi-files`)
- `valuation.ts` (BVPS/PBV/PER/fair PBV and quality-vs-valuation quadrant; context only), `simulation.ts` (illustrative BBRI/BMRI walkthrough data)
- `news.ts` (roles), `usage.ts`, `profile.ts`, `preferences.ts`, `market.ts` (World Bank, Frankfurter, optional FMP/Twelve Data/Finnhub), `narrative.ts`, `exporters.ts`, `glossary.ts`, `demo.ts`

UI: `src/pages/` (Workspace, Emiten, DaftarEmiten, Collections, FolderLibrary, Simulasi, Market, Metodologi, News, HelpCenter, Akun, UserAmounts) and `src/components/` (PullFlow, YearDisclaimer, ScoreGauge, WhatIfPanel, Term, Logo, CommandPalette, ...). `src/assets/` holds only the two logos.

i18n: Indonesian strings are the keys. English lives in `src/i18n/en.ts` and `src/i18n/extra/*.ts`. Never add a duplicate key within one map (it breaks the build); search before adding.

## Dependencies

- Runtime: React 19 and React DOM 19
- Styling: Tailwind CSS v4 with the `@tailwindcss/vite` plugin
- Build tooling: Vite 8, TypeScript 5.7, and `@vitejs/plugin-react`
- Formatting: oxfmt

## Styling

This project uses **Tailwind CSS v4** through the `@tailwindcss/vite` plugin configured in `vite.config.ts`. `src/index.css` imports Tailwind with `@import 'tailwindcss';`. Use Tailwind utility classes directly in JSX and put global CSS or Tailwind v4 theme customization in `src/index.css`. This scaffold does not need a Tailwind config file or PostCSS config.

`src/main.tsx` imports `src/index.css`, so global font wiring belongs in `src/index.css`. Keep CSS `@import` statements first, then add any `@font-face` rules and font-family defaults there.

## Design system (formal financial terminal)

- Dark default, light via `[data-theme="light"]`; always use palette tokens, never hard-coded hex.
- Teal is reserved for primary action fills, the active nav indicator, and key numeric scores. Icons, links, labels and hovers use text/sub tokens.
- Radius vocabulary: cards 10px, inner panels and stat cards 8px, inputs and buttons 6px, badges and chips 4px. `rounded-full` only for real circles (avatar, legend dots, progress tracks).
- No decorative effects (glow, blur, gradient stripes, chart area fills). Lucide icons only, no emoji or pictographs.
- Hover changes border colour or background, never `brightness`. Type scale 10/11/12/13/14/18 px (22/24/28 for stat values and titles).
- Responsive: mobile drawer navigation, `h-dvh` shell, tables scroll horizontally.

## Code quality

- Use double quotes for strings containing apostrophes (`"We're here to help"`), or escape them in single-quoted strings. An unescaped apostrophe in a single-quoted string breaks the build.
- Ensure JSX tags are closed and braces are balanced.
- Export components as default exports.
- Verify with `pnpm exec tsc --noEmit -p .` and `pnpm build`. The sandbox shell sometimes denies these (and `sed -i`); if so, say so and ask the user to run them.

## Domain rules

- Scope: conventional commercial banks on IDX (sector G Financials). Sharia banks (BRIS, BTPS, PNBS) are not in the registry and `isSharia` only rejects them at upload because revenue structure and ratios (FDR, NPF, NOM) are not comparable.
- Inputs: consolidated Profit & Loss and Statement of Financial Position only (cash flow, equity changes, notes and highlights are forbidden sources). 9 canonical accounts feed 9 ratios (ROE, ROA, NIM proxy, NPM, BOPO, LDR, EQA, LTA, PER) and 24 Mamdani rules, model `mamdani-bank-v1.0`. Market data is context only and never a model input; PER's share price is the one manual external input.
- AI only proposes numbers. The user must verify every row before the score is computed; the engine is deterministic.
- DeepSeek is the target AI provider and its key must exist only in a backend secret such as `DEEPSEEK_API_KEY`; never expose it through `VITE_*`, browser storage, account settings, logs, or UI. The current `aiExtract.ts` Anthropic browser call is legacy technical debt, not the target architecture.
- `ALL_BANKS` is a display registry, not a source of scores. Only verified FY analyses may produce score/valuation rows. `valuation.ts` outputs are context and must never feed the Mamdani engine.
- `WINDOW_YEARS = 5` applies to Emiten profile coverage. Comparison uses a user-chosen N-year window (2-10) validated by `validateComparison` in `yearWindow.ts`: all compared issuers must have every year of the identical window, otherwise scores and ranking are hidden and the user is told which years are missing (apple-to-apple rule). Do not add a "common years only" fallback.
- Year mismatch: `pullFromCollection` throws `YearMismatchError` when the PDF's detected year (`scan.years[0]`, a heuristic) or an AI column year differs from the document's fiscal year. `usePull`/`YearMismatchDialog` (`components/PullFlow.tsx`) freeze the flow with no continue button, and `VerifikasiPage` locks verification while any extraction has a wrong `columnYear`.

## News access model

- The role is session-derived (`getRole()`; dev-bypass login and emails in `ADMIN_EMAILS` are **admin**, everyone else is viewer). Only admins can publish or delete News (text + image blocks, cover image). There is intentionally no Viewer/Admin switcher in the UI.
- Non-admin (viewer) accounts can only read News and post comments under an article. Comments are open to everyone.
- Implementation: `src/domain/news.ts` (store, `getRole`, `canPublishNews`, `canManageCollection`) and `src/pages/NewsPage.tsx`. Data is localStorage-only until a backend exists; News never affects the Model Score.
- Collection access: only admins (`canManageCollection`) upload/delete reports in Koleksi Laporan (Upload Laporan, Perpustakaan, Folder Laporan delete) and edit optional FMP/Twelve Data/Finnhub keys; normal users only pull existing PDFs (`pullFromCollection` in `src/domain/store.tsx`) and verify their own copy. DeepSeek is never editable in the frontend. PDFs live in IndexedDB (`src/domain/blobStore.ts`), per browser, and are not part of JSON backups.

## Usage analytics access model

- The "Data Analytics" page (`src/pages/UserAmountsPage.tsx`) is reachable only from the profile menu, below "Akun Saya", and only for admins (`canViewUserAmounts` in `src/domain/news.ts`).
- Events are tracked by `track()` in `src/domain/usage.ts` and stored in localStorage (`aurevia.usage.v1`). Demo events are flagged `demo: true` and can be loaded or removed from the page. Real cross-user analytics need a backend.

## Storage keys

localStorage: `aurevia.workspace.v1`, `aurevia.usage.v1`, `aurevia.theme.v1`, `aurevia.lang.v1`, `aurevia.onboarding.v1`, `aurevia.advisor.v1`, `aurevia.profile.v1:<email>`, `ssi.apikeys`. IndexedDB: `ssi-files`.
