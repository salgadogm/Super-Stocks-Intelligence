// Step 2 tests (T2/T3): validators. SINTETIS fixture, not real bank data.
import { describe, it, expect } from "vitest";
import { toMiliar, validateAll, validateCritical, validateWarnings, type Accounts } from "../../src/domain/v3/validators";

const meta = { ticker: "SINT", period: "FY2024", consolidated: true };
// SINTETIS: balanced fixture. Assets 1000 = 100+50+200+10+550+0+40+10+40; L 850 + E 150.
const base: Accounts = {
  CASH_BI: 100, DUE_FROM_BANKS: 50, SECURITIES: 200, ACCEPTANCE_DERIV_ASSET: 10, LOANS_NET: 550,
  FIXED_ASSETS: 40, DEFERRED_TAX_ASSET: 10, OTHER_ASSETS: 40, TOTAL_ASSETS_REPORTED: 1000,
  TOTAL_LIABILITIES_REPORTED: 850, TOTAL_EQUITY_REPORTED: 150,
  INTEREST_INCOME: 80, INTEREST_EXPENSE: 30, NET_INTEREST_INCOME_REPORTED: 50,
  OTHER_OP_INCOME: 20, OTHER_OP_EXPENSE: 30, CKPN_EXPENSE: 5, OPERATING_PROFIT_REPORTED: 35,
  NON_OP: 1, PRE_TAX_PROFIT_REPORTED: 36, TAX: 6, NET_INCOME_TOTAL: 30, NET_INCOME_PARENT: 29, NET_INCOME_NCI: 1,
};
const run = (a: Accounts, unit: "miliar" | "juta" | "ambigu" | null = "miliar", m = meta) =>
  validateCritical({ accounts: a, unit, meta: m, expectedMeta: meta });
const codes = (a: Accounts, unit: "miliar" | "juta" | "ambigu" | null = "miliar", m = meta) => run(a, unit, m).map((i) => i.code);

describe("T2/T3 critical validators", () => {
  it("passes a consistent fixture", () => expect(run(base)).toEqual([]));
  it("V1 blocks a component sum mismatch and reports value/expected/diff", () => {
    const i = run({ ...base, SECURITIES: 150 }).find((x) => x.code === "V1")!;
    expect(i).toMatchObject({ value: 1000, expected: 950, diff: 50 });
  });
  it("V1 tolerates 0.1%", () => expect(codes({ ...base, TOTAL_ASSETS_REPORTED: 1000.9, TOTAL_LIABILITIES_REPORTED: 850.9 })).toEqual([]));
  it("V2 blocks an unbalanced balance sheet", () => expect(codes({ ...base, TOTAL_EQUITY_REPORTED: 120 })).toContain("V2"));
  it("V3 blocks wrong net interest income", () => expect(codes({ ...base, NET_INTEREST_INCOME_REPORTED: 60 })).toContain("V3"));
  it("V4 blocks each broken link of the P&L chain", () => {
    expect(codes({ ...base, OPERATING_PROFIT_REPORTED: 40 })).toContain("V4");
    expect(codes({ ...base, PRE_TAX_PROFIT_REPORTED: 40 })).toContain("V4");
    expect(codes({ ...base, NET_INCOME_TOTAL: 33 })).toContain("V4");
    expect(codes({ ...base, NET_INCOME_PARENT: 25 })).toContain("V4");
  });
  it("V5 blocks negative assets and negative expenses", () => {
    expect(codes({ ...base, OTHER_ASSETS: -40, TOTAL_ASSETS_REPORTED: 920, TOTAL_LIABILITIES_REPORTED: 770 })).toContain("V5");
    expect(codes({ ...base, CKPN_EXPENSE: -5 })).toContain("V5");
  });
  it("V6 rejects ambiguous or unknown units", () => {
    expect(codes(base, "ambigu")).toContain("V6");
    expect(codes(base, null)).toContain("V6");
  });
  it("V6 converts units to Rp miliar", () => {
    expect(toMiliar(2_000_000, "juta")).toBe(2000);
    expect(toMiliar(3, "triliun")).toBe(3000);
    expect(toMiliar(5, "ambigu")).toBeNull();
  });
  it("V7 blocks wrong entity, period or non-consolidated", () => {
    expect(codes(base, "miliar", { ...meta, ticker: "LAIN" })).toContain("V7");
    expect(codes(base, "miliar", { ...meta, period: "FY2023" })).toContain("V7");
    expect(codes(base, "miliar", { ...meta, consolidated: false })).toContain("V7");
  });
  it("missing totals fail safe instead of passing silently (P4)", () => {
    const a = { ...base }; delete a.TOTAL_LIABILITIES_REPORTED;
    expect(codes(a)).toContain("V2");
  });
  it("null optional component counts as zero", () => expect(codes({ ...base, SHARIAH_FINANCING: null })).toEqual([]));
});

describe("warnings W1-W4", () => {
  const w = (extra: Partial<Parameters<typeof validateWarnings>[0]>) => validateWarnings({ accounts: base, ocr: false, ...extra }).map((i) => i.code);
  it("W1 flags >40% change on large accounts only", () => {
    expect(w({ previous: { ...base, LOANS_NET: 300 } })).toContain("W1");
    expect(w({ previous: { ...base, LOANS_NET: 500 } })).not.toContain("W1");
  });
  it("W2 shows restatement difference", () => {
    const r = validateWarnings({ accounts: base, ocr: false, comparative: { TOTAL_ASSETS_REPORTED: 900 }, previousClosing: { TOTAL_ASSETS_REPORTED: 950 } });
    expect(r[0]).toMatchObject({ code: "W2", diff: -50 });
  });
  it("W3 flags implausible ratios", () => {
    expect(w({ ratios: { roe: 45 } })).toContain("W3");
    expect(w({ ratios: { bopo: 25 } })).toContain("W3");
    expect(w({ ratios: { growth: 50 } })).toContain("W3");
    expect(w({ ratios: { roe: 15, bopo: 70, growth: 10 } })).not.toContain("W3");
  });
  it("W4 flags OCR", () => expect(w({ ocr: true })).toContain("W4"));
  it("validateAll is ok only without critical issues; warnings do not block", () => {
    const r = validateAll({ accounts: base, unit: "miliar", meta, expectedMeta: meta }, { accounts: base, ocr: true });
    expect(r.ok).toBe(true);
    expect(r.warnings).toHaveLength(1);
  });
});
