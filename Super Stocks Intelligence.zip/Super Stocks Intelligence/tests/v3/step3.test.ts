// Step 3 tests (T2): Stage A formulas on SINTETIS numbers, hand-calculated.
import { describe, it, expect } from "vitest";
import { computeStageA, roeValuasi, ttm, parentEquity, type StageAInput } from "../../src/domain/v3/stageA";
import { DEFAULT_CONFIG } from "../../src/domain/v3/config";

const cur = {
  CASH_BI: 100, DUE_FROM_BANKS: 50, SECURITIES: 200, LOANS_NET: 550, TOTAL_ASSETS_REPORTED: 1000, DEPOSITS: 800,
  TOTAL_EQUITY_REPORTED: 150, EQUITY_PARENT: 120, NCI: 30,
  INTEREST_INCOME: 80, INTEREST_EXPENSE: 30, NET_INTEREST_INCOME_REPORTED: 50, OTHER_OP_INCOME: 20, OTHER_OP_EXPENSE: 30,
  CKPN_EXPENSE: 5, NET_INCOME_TOTAL: 30, NET_INCOME_PARENT: 30,
};
const start = { CASH_BI: 90, DUE_FROM_BANKS: 40, SECURITIES: 170, LOANS_NET: 450, TOTAL_ASSETS_REPORTED: 900, EQUITY_PARENT: 100 };
const annual: StageAInput = { isFullYear: true, months: 12, cur, start };
const r = computeStageA(annual);

describe("inference ratios (annual)", () => {
  it("A1 ROE_kinerja = 30 / avg(120,100) = 27.2727", () => expect(r.inference.ROE_KINERJA.value).toBeCloseTo(27.272727, 5));
  it("A2 BOPO = (30+30+5)/(80+20) = 65", () => expect(r.inference.BOPO.value).toBeCloseTo(65, 9));
  it("A3 CoC = 5 / avg(550,450) = 1.0 and flagged PROKSI", () => {
    expect(r.inference.COC.value).toBeCloseTo(1.0, 9);
    expect(r.inference.COC.flags).toContain("PROKSI");
  });
  it("A4 Ekuitas/Aset = 150/1000 = 15 and flagged PROKSI", () => {
    expect(r.inference.EA.value).toBeCloseTo(15, 9);
    expect(r.inference.EA.flags).toContain("PROKSI");
  });
  it("A5 growth = 550/450 - 1 = 22.2222", () => expect(r.inference.GROWTH.value).toBeCloseTo(22.222222, 5));
  it("no blocking reasons when complete", () => expect(r.blocked).toEqual([]));
});

describe("display ratios", () => {
  it("D1..D6", () => {
    expect(r.display.ROA.value).toBeCloseTo(30 / 950 * 100, 6);
    expect(r.display.CIR.value).toBeCloseTo(30 / 70 * 100, 6);
    expect(r.display.LDR.value).toBeCloseTo(550 / 800 * 100, 6);
    expect(r.display.NIM.value).toBeCloseTo(50 / ((900 + 750) / 2) * 100, 6);
    expect(r.display.NON_INTEREST.value).toBeCloseTo(20 / 70 * 100, 6);
    expect(r.display.LIQUID.value).toBeCloseTo(350 / 800 * 100, 6);
  });
  it("proxies carry the flag", () => {
    expect(r.display.LDR.flags).toContain("PROKSI");
    expect(r.display.NIM.flags).toContain("PROKSI");
  });
});

describe("null handling (P4)", () => {
  it("zero or negative denominator gives null with reason and blocks Stage C", () => {
    const x = computeStageA({ ...annual, cur: { ...cur, TOTAL_ASSETS_REPORTED: 0 } });
    expect(x.inference.EA.value).toBeNull();
    expect(x.inference.EA.reason).toContain("<= 0");
    expect(x.blocked.length).toBe(1);
  });
  it("missing numerator gives null", () => {
    const x = computeStageA({ ...annual, cur: { ...cur, INTEREST_EXPENSE: null } });
    expect(x.inference.BOPO.value).toBeNull();
  });
  it("negative average equity gives null ROE", () => {
    const x = computeStageA({ ...annual, cur: { ...cur, EQUITY_PARENT: -50 } });
    expect(x.inference.ROE_KINERJA.value).toBeNull();
  });
  it("parent equity falls back to total minus NCI", () => expect(parentEquity({ TOTAL_EQUITY_REPORTED: 150, NCI: 30 })).toBe(120));
});

describe("TTM and estimate mode", () => {
  const interim: StageAInput = {
    isFullYear: false, months: 3,
    cur: { ...cur, NET_INCOME_PARENT: 10, CKPN_EXPENSE: 2 }, start,
    plPrevSame: { NET_INCOME_PARENT: 8, CKPN_EXPENSE: 1 }, plPrevFY: { NET_INCOME_PARENT: 28, CKPN_EXPENSE: 5 },
  };
  it("TTM = YTD + FY(t-1) - YTD(t-1) = 10 + 28 - 8 = 30", () => expect(ttm("NET_INCOME_PARENT", interim).value).toBe(30));
  it("missing comparatives give null by default, with a message naming the missing documents", () => {
    const t = ttm("NET_INCOME_PARENT", { ...interim, plPrevFY: undefined });
    expect(t.value).toBeNull();
    expect(t.reason).toContain("pembanding TTM");
    expect(computeStageA({ ...interim, plPrevFY: undefined }).blocked.length).toBeGreaterThan(0);
  });
  it("estimate mode (off by default) annualises x12/months and flags ESTIMATED", () => {
    expect(DEFAULT_CONFIG.estimasiMode).toBe(false);
    const cfg = { ...DEFAULT_CONFIG, estimasiMode: true };
    const x = computeStageA({ ...interim, plPrevFY: undefined, plPrevSame: undefined }, cfg);
    expect(ttm("CKPN_EXPENSE", { ...interim, plPrevFY: undefined }, cfg).value).toBe(8);
    expect(x.inference.ROE_KINERJA.flags).toContain("ESTIMATED");
  });
  it("BOPO stays YTD and is not annualised", () => expect(computeStageA(interim).inference.BOPO.value).toBeCloseTo(65, 9));
});

describe("ROE_valuasi (A1v)", () => {
  const k = r.inference.ROE_KINERJA;
  it("averages current with up to N-1 prior FY values", () => {
    expect(roeValuasi(k, [20, 10, 99]).value).toBeCloseTo((27.272727 + 20 + 10) / 3, 4);
  });
  it("falls back with a flag when no history exists", () => {
    const v = roeValuasi(k, []);
    expect(v.value).toBeCloseTo(27.272727, 5);
    expect(v.flags).toContain("ROE-VALUASI TIDAK DIHALUSKAN");
  });
  it("is null when ROE kinerja is null", () => expect(roeValuasi({ ...k, value: null }, [10]).value).toBeNull());
});
