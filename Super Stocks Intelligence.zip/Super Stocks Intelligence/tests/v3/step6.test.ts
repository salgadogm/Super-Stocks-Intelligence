// Step 6 tests: T8 period gate. Collections are SINTETIS inventories, not real bank documents.
import { describe, it, expect } from "vitest";
import { checkGate, requirementsFor, type CollectionDoc, type PeriodMode, type Period } from "../../src/domain/v3/periodGate";

const BS = "BALANCE_SHEET", PL = "PROFIT_LOSS";
const doc = (bank: string, statement: "BALANCE_SHEET" | "PROFIT_LOSS", year: number, month: number): CollectionDoc => ({ bank, statement, year, month });
const full = (bank: string, mode: PeriodMode, p: Period) => requirementsFor(mode, p).map((r) => doc(bank, r.statement, r.year, r.month));
const gate = (mode: PeriodMode, period: Period, banks: string[], collection: CollectionDoc[], extra = {}) => checkGate({ mode, period, banks, collection, ...extra });

describe("requirements matrix (spec §11)", () => {
  it("annual FY t: BS Dec t, BS Dec t-1, PL FY t", () => {
    expect(requirementsFor("ANNUAL", { year: 2024, month: 12 }).map((r) => [r.statement, r.year, r.month])).toEqual([[BS, 2024, 12], [BS, 2023, 12], [PL, 2024, 12]]);
  });
  it("interim p t: BS p t, BS p t-1, PL YTD p t, PL YTD p t-1, PL FY t-1", () => {
    expect(requirementsFor("QUARTERLY", { year: 2024, month: 6 }).map((r) => [r.statement, r.year, r.month])).toEqual([[BS, 2024, 6], [BS, 2023, 6], [PL, 2024, 6], [PL, 2023, 6], [PL, 2023, 12]]);
  });
  it("December in an interim mode behaves as annual (3 documents)", () => {
    expect(requirementsFor("QUARTERLY", { year: 2024, month: 12 })).toHaveLength(3);
    expect(requirementsFor("MONTHLY", { year: 2024, month: 12 })).toHaveLength(3);
  });
});

describe("T8 every missing combination yields the exact freeze message", () => {
  const p: Period = { year: 2024, month: 6 };
  const all = full("BMRI", "QUARTERLY", p);
  const roles = requirementsFor("QUARTERLY", p);

  it("complete -> ok, no freeze", () => {
    const g = gate("QUARTERLY", p, ["BMRI"], all);
    expect(g).toMatchObject({ ok: true, frozen: false, missing: [], estimated: false });
  });

  it("each single missing document is reported alone", () => {
    for (const r of roles) {
      const col = all.filter((d) => !(d.statement === r.statement && d.year === r.year && d.month === r.month));
      const g = gate("QUARTERLY", p, ["BMRI"], col);
      expect(g.frozen).toBe(true);
      expect(g.missing).toHaveLength(1);
      expect(g.missing[0]).toMatchObject({ bank: "BMRI", role: r.role, year: r.year, month: r.month });
    }
  });

  it("every one of the 2^5 subsets removed reports exactly the removed roles", () => {
    for (let mask = 1; mask < 32; mask++) {
      const gone = roles.filter((_, i) => mask & (1 << i));
      const col = all.filter((d) => !gone.some((r) => r.statement === d.statement && r.year === d.year && r.month === d.month));
      const g = gate("QUARTERLY", p, ["BMRI"], col);
      expect(g.missing.map((m) => m.role).sort()).toEqual(gone.map((r) => r.role).sort());
    }
  });

  it("the spec example message is reproduced verbatim", () => {
    const col = all.filter((d) => !(d.statement === PL && d.year === 2024 && d.month === 6));
    const g = gate("QUARTERLY", p, ["BMRI"], col);
    expect(g.missing[0].message).toBe("BMRI: Laba Rugi YTD Triwulan II 2024 (periode analisis) belum ada di koleksi. Tambahkan dari: Koleksi > BMRI > 2024 > Triwulan II > Laba Rugi.");
  });

  it("the TTM comparative message names its purpose and points to the right folder", () => {
    const col = all.filter((d) => !(d.statement === PL && d.year === 2023 && d.month === 6));
    const m = gate("QUARTERLY", p, ["BMRI"], col).missing[0];
    expect(m.message).toBe("BMRI: Laba Rugi YTD Triwulan II 2023 (pembanding TTM) belum ada di koleksi. Tambahkan dari: Koleksi > BMRI > 2023 > Triwulan II > Laba Rugi.");
    const fy = gate("QUARTERLY", p, ["BMRI"], all.filter((d) => !(d.statement === PL && d.year === 2023 && d.month === 12))).missing[0];
    expect(fy.collectionPath).toBe("Koleksi > BMRI > 2023 > Tahunan > Laba Rugi");
    expect(fy.message).toContain("Laba Rugi FY 2023 (pembanding TTM)");
  });

  it("annual mode with a missing prior-year balance sheet", () => {
    const a: Period = { year: 2024, month: 12 };
    const col = full("BBCA", "ANNUAL", a).filter((d) => !(d.statement === BS && d.year === 2023));
    const g = gate("ANNUAL", a, ["BBCA"], col);
    expect(g.missing).toHaveLength(1);
    expect(g.missing[0].message).toBe("BBCA: Neraca 31 Des 2023 (pembanding rata-rata) belum ada di koleksi. Tambahkan dari: Koleksi > BBCA > 2023 > Tahunan > Neraca.");
  });

  it("monthly labels use the month name", () => {
    const m: Period = { year: 2026, month: 1 };
    const g = gate("MONTHLY", m, ["BBRI"], []);
    expect(g.missing).toHaveLength(5);
    expect(g.missing[0].collectionPath).toBe("Koleksi > BBRI > 2026 > Januari > Neraca");
  });

  it("each bank is checked independently and reported with its own name", () => {
    const col = [...full("BMRI", "QUARTERLY", p), ...full("BBCA", "QUARTERLY", p).filter((d) => d.statement !== BS)];
    const g = gate("QUARTERLY", p, ["BMRI", "BBCA"], col);
    expect(g.missing.every((x) => x.bank === "BBCA")).toBe(true);
    expect(g.missing).toHaveLength(2);
  });

  it("documents of another bank or another period do not count", () => {
    const g = gate("QUARTERLY", p, ["BMRI"], [...full("BBCA", "QUARTERLY", p), ...full("BMRI", "QUARTERLY", { year: 2024, month: 9 }).filter((d) => d.month === 9 && d.year === 2024)]);
    expect(g.missing).toHaveLength(5);
  });
});

describe("request validity", () => {
  it("period not matching the mode is an error, not a missing list", () => {
    expect(gate("ANNUAL", { year: 2024, month: 6 }, ["BMRI"], []).error).toBe("MODE_PERIOD_INVALID");
    expect(gate("QUARTERLY", { year: 2024, month: 5 }, ["BMRI"], []).error).toBe("MODE_PERIOD_INVALID");
    expect(gate("MONTHLY", { year: 2024, month: 13 }, ["BMRI"], []).error).toBe("MODE_PERIOD_INVALID");
  });
  it("empty and duplicate banks; comparison needs at least two", () => {
    expect(gate("ANNUAL", { year: 2024, month: 12 }, [], []).error).toBe("BANKS_EMPTY");
    expect(gate("ANNUAL", { year: 2024, month: 12 }, ["BMRI", "bmri"], []).error).toBe("BANKS_DUPLICATE");
    expect(gate("ANNUAL", { year: 2024, month: 12 }, ["BMRI"], [], { requireMinTwoBanks: true }).error).toBe("BANKS_MIN_TWO");
  });
  it("an error never reports ok", () => expect(gate("ANNUAL", { year: 2024, month: 6 }, ["BMRI"], []).ok).toBe(false));
});

describe("ESTIMASI mode", () => {
  const p: Period = { year: 2024, month: 6 };
  const noPrior = full("BMRI", "QUARTERLY", p).filter((d) => !(d.statement === PL && d.year === 2023));
  it("off by default: missing P&L comparatives freeze", () => {
    const g = gate("QUARTERLY", p, ["BMRI"], noPrior);
    expect(g.frozen).toBe(true);
    expect(g.missing).toHaveLength(2);
  });
  it("on: P&L comparatives waived, result flagged ESTIMATED", () => {
    const g = gate("QUARTERLY", p, ["BMRI"], noPrior, { estimasiMode: true });
    expect(g).toMatchObject({ ok: true, estimated: true });
    expect(g.waived.BMRI).toEqual(["PL_PRIOR_SAME_PERIOD", "PL_PRIOR_FY"]);
  });
  it("on: balance sheets are never waived", () => {
    const g = gate("QUARTERLY", p, ["BMRI"], noPrior.filter((d) => d.statement !== BS || d.year !== 2023), { estimasiMode: true });
    expect(g.frozen).toBe(true);
    expect(g.missing.map((m) => m.role)).toEqual(["BS_PRIOR_YEAR"]);
  });
  it("on with a complete set: not flagged", () => {
    expect(gate("QUARTERLY", p, ["BMRI"], full("BMRI", "QUARTERLY", p), { estimasiMode: true }).estimated).toBe(false);
  });
  it("has no effect on annual periods", () => {
    const a: Period = { year: 2024, month: 12 };
    const g = gate("ANNUAL", a, ["BMRI"], [], { estimasiMode: true });
    expect(g.frozen).toBe(true);
    expect(g.estimated).toBe(false);
  });
});
