// Step 4 tests: T10 (g fence regression), T12 (scenario grid). SINTETIS fixtures, not real bank data.
import { describe, it, expect } from "vitest";
import { breakEven, bvps, computeScenario, computeStageBBase, reBase, valuationAtPrice } from "../../src/domain/v3/stageB";

const mkt = { rf: 6, beta: 0.8, erp: 5, dpr: 0.6 }; // re = 10
const J = (gCap: number, shift = 0, roe = 20.87, re = 10) => computeScenario(roe, 0.6, re, gCap, shift, 1);

describe("T10 g-fence regression (ROE 20.87, DPR 60%, re 10, PBV market 4.50)", () => {
  it("CAPM re", () => expect(reBase(6, 0.8, 5)).toBeCloseTo(10, 12));
  it("g_cap 7 is inactive vs spread floor: g = 7, JPBV ~ 4.62", () => {
    const s = J(7);
    expect(s.g).toBeCloseTo(7, 12);
    expect(s.jpbv).toBeCloseTo(4.623, 3);
  });
  it("g_cap 6: JPBV ~ 3.72", () => expect(J(6).jpbv).toBeCloseTo(3.7175, 3));
  it("g_cap 5: JPBV ~ 3.17", () => expect(J(5).jpbv).toBeCloseTo(3.174, 3));
  it("without any fence JPBV ~ 7.59", () => {
    const gRaw = 20.87 * 0.4;
    expect((20.87 - gRaw) / (10 - gRaw)).toBeCloseTo(7.58, 1);
  });
  it("the fenced scenarios stay far below the unfenced artefact at PBV 4.50", () => {
    expect(4.5 / J(6).jpbv! - 1).toBeGreaterThan(0.2);
  });
  it("implicit DPR is exposed", () => expect(J(6).dprImplicit).toBeCloseTo(1 - 6 / 20.87, 9));
  it("spread floor with re shift -1: g = min(6, 9-3) = 6", () => expect(J(6, -1).g).toBeCloseTo(6, 12));
  it("g never negative", () => expect(computeScenario(5, 1.5, 10, 6, 0, 1).g).toBe(0));
});

describe("T12 scenario grid", () => {
  const b = computeStageBBase({ bvps: 1000, roeValuasi: 20.87, market: mkt, pbvHistory: [2, 3, 4] });
  it("has 9 scenarios and exactly one base (g_cap 6, shift 0)", () => {
    expect(b.scenarios).toHaveLength(9);
    const bases = b.scenarios.filter((s) => s.isBase);
    expect(bases).toHaveLength(1);
    expect(bases[0]).toMatchObject({ gCap: 6, reShift: 0 });
  });
  it("base equals a one-off computation", () => {
    const one = computeScenario(20.87, 0.6, 10, 6, 0, 1000);
    expect(b.scenarios.find((s) => s.isBase)!.hwJ).toBeCloseTo(one.hwJ!, 9);
  });
  it("non-positive ROE nulls all scenarios with flag and F3 signal", () => {
    const n = computeStageBBase({ bvps: 1000, roeValuasi: -2, market: mkt, pbvHistory: [2, 3, 4] });
    expect(n.scenarios.every((s) => s.hwJ == null && s.flags.includes("ROE NON-POSITIF"))).toBe(true);
    const v = valuationAtPrice(n, 3000);
    expect(v.baseNull).toBe(true);
    expect(v.deltaValRange).toBeNull();
    expect(v.p0).toBeNull();
  });
  it("a single NULL scenario is excluded from ranges with a flag", () => {
    const lowRe = computeStageBBase({ bvps: 1000, roeValuasi: 20, market: { rf: 1, beta: 0, erp: 0, dpr: 0.6 }, pbvHistory: [] });
    const v = valuationAtPrice(lowRe, 1500);
    expect(lowRe.scenarios.filter((s) => s.hwJ == null).length).toBe(3); // re 0 (shift -1) gives re - g <= 0
    expect(v.flags).toContain("SKENARIO NULL DIKELUARKAN");
    expect(v.deltaValRange).not.toBeNull();
  });
});

describe("valuation at a price (Layer 3)", () => {
  const b = computeStageBBase({ bvps: 1000, roeValuasi: 20.87, market: mkt, pbvHistory: [2, 3, 4] });
  const hwJ = b.scenarios.find((s) => s.isBase)!.hwJ!;
  it("BVPS from parent equity and shares", () => {
    expect(bvps(150, 1e9).value).toBeCloseTo(150, 9);
    expect(bvps(150, 0).value).toBeNull();
    expect(bvps(null, 1e9).value).toBeNull();
  });
  it("HW_H = mean PBV x BVPS", () => expect(b.hwH).toBeCloseTo(3000, 9));
  it("Delta_Val = 0.5 dJ + 0.5 dH", () => {
    const v = valuationAtPrice(b, 4500);
    const dJ = (4500 / hwJ - 1) * 100, dH = 50;
    expect(v.deltaH).toBeCloseTo(dH, 9);
    expect(v.scenarios.find((s) => s.isBase)!.deltaVal).toBeCloseTo(0.5 * dJ + 0.5 * dH, 9);
    expect(v.pbvMarket).toBeCloseTo(4.5, 12);
  });
  it("P0 is the price where base Delta_Val = 0", () => {
    const p0 = valuationAtPrice(b, 1000).p0!;
    const at = valuationAtPrice(b, p0).scenarios.find((s) => s.isBase)!;
    expect(at.deltaVal!).toBeCloseTo(0, 9);
  });
  it("Delta_Val is clamped for fuzzy but the raw value is kept", () => {
    const v = valuationAtPrice(b, 100000).scenarios.find((s) => s.isBase)!;
    expect(v.deltaVal!).toBeGreaterThan(100);
    expect(v.deltaValFuzzy).toBe(100);
    expect(valuationAtPrice(b, 1e-6).scenarios[0].deltaValFuzzy).toBe(-60);
  });
  it("ranges are min <= base <= max", () => {
    const r = valuationAtPrice(b, 4500).deltaValRange!;
    expect(r.min).toBeLessThanOrEqual(r.base!);
    expect(r.base!).toBeLessThanOrEqual(r.max);
  });
  it("fewer than 3 history points -> SINGLE-METHOD, Delta_Val = Delta_J, P0 = HW_J", () => {
    const s = computeStageBBase({ bvps: 1000, roeValuasi: 20.87, market: mkt, pbvHistory: [2, 3] });
    const v = valuationAtPrice(s, 4500);
    expect(v.flags).toContain("SINGLE-METHOD");
    const base = v.scenarios.find((x) => x.isBase)!;
    expect(base.deltaVal).toBeCloseTo(base.deltaJ!, 12);
    expect(v.p0).toBeCloseTo(s.scenarios.find((x) => x.isBase)!.hwJ!, 9);
  });
  it("flags conflicting methods when |dJ - dH| > 50 pp", () => {
    const c = computeStageBBase({ bvps: 1000, roeValuasi: 20.87, market: mkt, pbvHistory: [1, 1, 1] });
    expect(valuationAtPrice(c, 4500).flags).toContain("METODE VALUASI BERTENTANGAN");
  });
  it("rejects non-positive price", () => expect(() => valuationAtPrice(b, 0)).toThrow());
  it("breakEven formula", () => expect(breakEven(2, 4)).toBeCloseTo(1 / (0.5 / 2 + 0.5 / 4), 12));
});
