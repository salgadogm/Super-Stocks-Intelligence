// Step 1 tests: config, hash, canonical accounts, bibliography. Run with `pnpm exec vitest run` (vitest must be installed).
import { describe, it, expect } from "vitest";
import { DEFAULT_CONFIG, configHash, unresolvedParams, validateConfig } from "../../src/domain/v3/config";
import { canonicalJson, sha256Hex } from "../../src/domain/v3/hash";
import { ACCOUNTS, ACCOUNT_BY_CODE, codeForLabel, normaliseLabel } from "../../src/domain/v3/accounts";
import { BIBLIOGRAPHY, citableReferences } from "../../src/domain/v3/bibliography";

describe("sha256", () => {
  it("matches known vectors", () => {
    expect(sha256Hex("")).toBe("e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855");
    expect(sha256Hex("abc")).toBe("ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad");
  });
});

describe("config (T7 reproducibility, P3, P7)", () => {
  it("default config is structurally valid", () => {
    expect(validateConfig()).toEqual([]);
  });
  it("hash is identical across runs and independent of key order", () => {
    expect(configHash()).toBe(configHash());
    expect(canonicalJson({ b: 1, a: [2, { d: 1, c: 2 }] })).toBe(canonicalJson({ a: [2, { c: 2, d: 1 }], b: 1 }));
  });
  it("hash changes when any parameter changes", () => {
    const c = structuredClone(DEFAULT_CONFIG);
    c.stageB.wJ = 0.4;
    c.stageB.wH = 0.6;
    expect(configHash(c)).not.toBe(configHash());
  });
  it("rejects non-integer weights and bad grids", () => {
    const c = structuredClone(DEFAULT_CONFIG);
    c.subsystems.A.vars.ROE.weight = 0.6;
    c.stageB.gCapGrid = [5, 6];
    const errs = validateConfig(c);
    expect(errs.some((e) => e.includes("bobot"))).toBe(true);
    expect(errs.some((e) => e.includes("grid"))).toBe(true);
  });
  it("scheme sizes give 9 + 27 + 27 = 63 rules", () => {
    const n = (k: "A" | "B" | "FINAL") => Object.values(DEFAULT_CONFIG.subsystems[k].vars).reduce((p, v) => p * Object.keys(v.points).length, 1);
    expect([n("A"), n("B"), n("FINAL")]).toEqual([9, 27, 27]);
  });
  it("each scheme's point sets match its input MF set names", () => {
    const mfName: Record<string, string> = { ROE: "ROE", BOPO: "BOPO", CoC: "CoC", EA: "EA", GROWTH: "GROWTH", DELTA_VAL: "DELTA_VAL" };
    for (const sub of Object.values(DEFAULT_CONFIG.subsystems))
      for (const [v, def] of Object.entries(sub.vars)) {
        if (!mfName[v]) continue; // K and R come from the intermediate output MFs
        const names = DEFAULT_CONFIG.mf[v as keyof typeof DEFAULT_CONFIG.mf].sets.map((s) => s.name).sort();
        expect(Object.keys(def.points).sort()).toEqual(names);
      }
  });
  it("open spec parameters are reported, not silently defaulted (P4)", () => {
    expect(unresolvedParams()).toHaveLength(2);
  });
});

describe("canonical accounts", () => {
  it("has the 32 codes from spec section 10 with unique codes", () => {
    expect(ACCOUNTS).toHaveLength(32);
    expect(new Set(ACCOUNTS.map((a) => a.code)).size).toBe(32);
    expect(ACCOUNTS.filter((a) => a.statement === "BS")).toHaveLength(19);
    expect(ACCOUNTS.filter((a) => a.statement === "PL")).toHaveLength(13);
  });
  it("no normalised alias maps to two different codes", () => {
    const seen = new Map<string, string>();
    for (const a of ACCOUNTS)
      for (const al of a.aliases) {
        const n = normaliseLabel(al);
        expect(seen.get(n) ?? a.code).toBe(a.code);
        seen.set(n, a.code);
      }
  });
  it("maps the spec example synonym", () => {
    expect(codeForLabel("Kas dan Penempatan pada Bank Indonesia")).toBe("CASH_BI");
    expect(codeForLabel("tidak dikenal")).toBeNull();
  });
  it("expense lines and optional lines are flagged", () => {
    expect(ACCOUNT_BY_CODE.CKPN_EXPENSE.expense).toBe(true);
    expect(ACCOUNT_BY_CODE.SHARIAH_FINANCING.optional).toBe(true);
  });
});

describe("bibliography (spec 16.4)", () => {
  it("every reference is unverified and none is citable", () => {
    expect(BIBLIOGRAPHY.every((r) => r.verified === false)).toBe(true);
    expect(citableReferences()).toHaveLength(0);
  });
});
