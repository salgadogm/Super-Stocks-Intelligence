// Step 5 tests: T4 (centroid), T5 (monotonicity), T6 (sensitivity), T11 (ablation), T13 (integer boundaries), rule generator.
import { describe, it, expect } from "vitest";
import { DEFAULT_CONFIG as C } from "../../src/domain/v3/config";
import { generateRules, rulesToCsv, rulesForSubsystem, classify, rulesHash } from "../../src/domain/v3/rules";
import { centroid, evaluate, finalStage, FuzzyError, infer, labelOf, computeKR, type FuzzyCase } from "../../src/domain/v3/inference";
import { mu } from "../../src/domain/v3/membership";
import { sensitivity } from "../../src/domain/v3/sensitivity";
import { computeStageBBase, valuationAtPrice } from "../../src/domain/v3/stageB";

const base: FuzzyCase = { roe: 18, bopo: 75, coc: 2.5, ea: 12, growth: 8, deltaVal: 0 };
const range = (a: number, b: number, n: number) => Array.from({ length: n + 1 }, (_, i) => a + ((b - a) * i) / n);

describe("membership", () => {
  it("shoulders and triangle", () => {
    const roeRendah = C.mf.ROE.sets[0].pts;
    expect(mu(roeRendah, -10)).toBe(1);
    expect(mu(roeRendah, 11.5)).toBeCloseTo(0.5, 12);
    expect(mu(roeRendah, 13)).toBe(0);
    expect(mu(C.mf.ROE.sets[1].pts, 15)).toBe(1);
    expect(mu(C.mf.ROE.sets[2].pts, 40)).toBe(1);
  });
});

describe("rule generator", () => {
  const rules = generateRules(C);
  it("9 + 27 + 27 = 63", () => {
    expect(rulesForSubsystem(C.subsystems.A)).toHaveLength(9);
    expect(rulesForSubsystem(C.subsystems.B)).toHaveLength(27);
    expect(rulesForSubsystem(C.subsystems.FINAL)).toHaveLength(27);
    expect(rules).toHaveLength(63);
  });
  it("B1: every CoC=Bahaya rule yields Rapuh", () => {
    const hit = rules.filter((r) => r.subsystem === "B" && r.antecedents.CoC === "Bahaya");
    expect(hit).toHaveLength(9);
    expect(hit.every((r) => r.consequent === "Rapuh" && r.veto === "B1")).toBe(true);
  });
  it("F1/F2: Rapuh with K != Tinggi and K=Rendah with R != Kuat are Tidak Layak", () => {
    for (const r of rules.filter((x) => x.subsystem === "FINAL")) {
      const { K, R } = r.antecedents;
      if ((R === "Rapuh" && K !== "Tinggi") || (K === "Rendah" && R !== "Kuat")) expect(r.consequent).toBe("Tidak Layak");
    }
  });
  it("vetoes only ever lower the base class", () => {
    const order = (s: string, sub: "A" | "B" | "FINAL") => C.subsystems[sub].classes.indexOf(s);
    for (const r of rules) expect(order(r.consequent, r.subsystem)).toBeLessThanOrEqual(order(r.baseClass, r.subsystem));
  });
  it("CSV is deterministic with a header and 63 rows; hash stable", () => {
    const csv = rulesToCsv(rules);
    expect(csv.trim().split("\n")).toHaveLength(64);
    expect(rulesToCsv(generateRules(C))).toBe(csv);
    expect(rulesHash(generateRules(C))).toBe(rulesHash(rules));
  });
});

describe("T4 centroid (grid 0.1, tolerance 0.05)", () => {
  it("Sangat Layak at alpha 1 -> 86.83", () => expect(centroid(C, "FINAL", { "Sangat Layak": 1 })).toBeCloseTo(86.83, 1));
  it("Tidak Layak at alpha 1 -> 17.98", () => expect(centroid(C, "FINAL", { "Tidak Layak": 1 })).toBeCloseTo(17.98, 1));
  it("Layak clipped at any alpha < 1 -> 55.00", () => {
    for (const a of [0.1, 0.5, 0.9]) expect(Math.abs(centroid(C, "FINAL", { Layak: a }) - 55)).toBeLessThan(0.05);
  });
  it("zero area raises a structured error (no silent fallback)", () => {
    expect(() => centroid(C, "FINAL", {})).toThrow(FuzzyError);
    try { centroid(C, "FINAL", {}); } catch (e) { expect((e as FuzzyError).code).toBe("CENTROID_ZERO_AREA"); }
  });
  it("non-finite input raises INPUT_INVALID", () => expect(() => infer(C, "A", { ROE: NaN, BOPO: 70 })).toThrow(FuzzyError));
});

describe("T13 integer arithmetic at class boundaries", () => {
  const a = (roe: string, bopo: string) => rulesForSubsystem(C.subsystems.A).find((r) => r.antecedents.ROE === roe && r.antecedents.BOPO === bopo)!;
  it("S10 = 14 is Tinggi (cut inclusive), 13 is Sedang; 7 is Sedang, 6 is Rendah", () => {
    expect(a("Moderat", "Efisien").s10).toBe(14);
    expect(a("Moderat", "Efisien").consequent).toBe("Tinggi");
    expect(a("Tinggi", "Inefisien").s10).toBe(12);
    expect(classify(C.subsystems.A, 13)).toBe("Sedang");
    expect(a("Rendah", "Efisien").s10).toBe(8);
    expect(classify(C.subsystems.A, 7)).toBe("Sedang");
    expect(a("Moderat", "Inefisien").s10).toBe(6);
    expect(a("Moderat", "Inefisien").consequent).toBe("Rendah");
  });
  it("all S10 are integers", () => expect(generateRules(C).every((r) => Number.isInteger(r.s10))).toBe(true));
  it("final labels: 44.9 / 45 / 69.9 / 70", () => {
    expect(labelOf(C, 44.9)).toBe("TIDAK LAYAK");
    expect(labelOf(C, 45)).toBe("LAYAK");
    expect(labelOf(C, 69.9)).toBe("LAYAK");
    expect(labelOf(C, 70)).toBe("SANGAT LAYAK");
  });
});

describe("T5 monotonicity (Growth excluded)", () => {
  const eps = 1e-9;
  const sweep = (key: keyof FuzzyCase, a: number, b: number) => range(a, b, 80).map((v) => evaluate(C, { ...base, [key]: v }).score);
  const nonDecreasing = (xs: number[]) => xs.every((x, i) => i === 0 || x >= xs[i - 1] - eps);
  const nonIncreasing = (xs: number[]) => xs.every((x, i) => i === 0 || x <= xs[i - 1] + eps);
  it("ROE up does not lower Y*", () => expect(nonDecreasing(sweep("roe", -10, 40))).toBe(true));
  it("EA up does not lower Y*", () => expect(nonDecreasing(sweep("ea", 0, 30))).toBe(true));
  it("BOPO up does not raise Y*", () => expect(nonIncreasing(sweep("bopo", 30, 120))).toBe(true));
  it("CoC up does not raise Y*", () => expect(nonIncreasing(sweep("coc", 0, 8))).toBe(true));
  it("Delta_Val up does not raise Y*", () => expect(nonIncreasing(sweep("deltaVal", -60, 100))).toBe(true));
  it("Growth: Sehat zone is highest, lower on both sides", () => {
    const f = { ...base, coc: 1, ea: 12 };
    const r = (g: number) => computeKR(C, { ...f, growth: g }).R.score;
    expect(r(8)).toBeGreaterThan(r(-5));
    expect(r(8)).toBeGreaterThan(r(30));
  });
});

describe("T11 ablation", () => {
  it("neutralizing ROE (K5, pROE = 1) replaces its set by Moderat with degree 1", () => {
    const strong = computeKR(C, { ...base, roe: 35 }, { forced: { ROE: "Moderat" } }).K.score;
    const weak = computeKR(C, { ...base, roe: -5 }, { forced: { ROE: "Moderat" } }).K.score;
    expect(strong).toBeCloseTo(weak, 12);
  });
  it("label with ROE neutralized can be compared against the full label", () => {
    const full = evaluate(C, { ...base, roe: 35, bopo: 50, coc: 1, ea: 20, growth: 8, deltaVal: -30 });
    const ablated = evaluate(C, { ...base, roe: 35, bopo: 50, coc: 1, ea: 20, growth: 8, deltaVal: -30 }, { forced: { ROE: "Moderat" } });
    expect(ablated.score).toBeLessThanOrEqual(full.score);
  });
  it("Delta_Val = Delta_H only when wJ = 0, wH = 1", () => {
    const cfg = structuredClone(C);
    cfg.stageB.wJ = 0; cfg.stageB.wH = 1;
    const b = computeStageBBase({ bvps: 1000, roeValuasi: 20.87, market: { rf: 6, beta: 0.8, erp: 5, dpr: 0.6 }, pbvHistory: [2, 3, 4] }, cfg);
    const v = valuationAtPrice(b, 4500, cfg);
    expect(v.scenarios.find((s) => s.isBase)!.deltaVal!).toBeCloseTo(v.deltaH!, 9);
  });
});

describe("final stage and veto F3", () => {
  it("base scenario NULL -> TIDAK LAYAK without a score", () => {
    const r = finalStage(C, 80, 80, null, true);
    expect(r).toMatchObject({ score: null, label: "TIDAK LAYAK", vetoF3: true });
  });
  it("a strong, undervalued bank scores above 70; a weak, overvalued one below 45", () => {
    expect(evaluate(C, { roe: 30, bopo: 50, coc: 0.5, ea: 20, growth: 8, deltaVal: -50 }).label).toBe("SANGAT LAYAK");
    expect(evaluate(C, { roe: 2, bopo: 100, coc: 6, ea: 5, growth: -10, deltaVal: 80 }).label).toBe("TIDAK LAYAK");
  });
  it("is deterministic", () => expect(evaluate(C, base).score).toBe(evaluate(C, base).score));
});

describe("T6 sensitivity (fuzzy level)", () => {
  const cases: FuzzyCase[] = [];
  for (const roe of [8, 14, 20, 28]) for (const bopo of [55, 72, 90]) for (const coc of [1, 2.5, 4]) for (const ea of [8, 14, 22]) for (const dv of [-40, 0, 40])
    cases.push({ roe, bopo, coc, ea, growth: 8, deltaVal: dv });
  it("reports a label-change rate within [0,1] for every perturbation", () => {
    const rep = sensitivity(C, cases);
    expect(rep.rows.length).toBeGreaterThanOrEqual(2 + 2 * 8 - 0);
    for (const r of rep.rows) { expect(r.rate).toBeGreaterThanOrEqual(0); expect(r.rate).toBeLessThanOrEqual(1); }
    console.log(`T6 label-change rate: ${(rep.rate * 100).toFixed(1)}% over ${rep.total} evaluations`);
  });
});
