# Plan: SSI Spec v3.0 rebuild (staged)

## Context
Spec v3.0 replaces the 9-ratio / 24-rule Mamdani core (`mamdani-bank-v1.0`) with a 3-layer model: Stage A (5 ratios), Stage B (CAPM justified PBV grid), Stage C (63 rules, 3 fuzzy subsystems, vetoes, robustness, price zones). The spec says to build in 10 steps and stop for confirmation after each.

## Assumptions (to be confirmed at approval)
1. Stack: extend the existing TS/React/Vite app (no Python rewrite). Engine goes in a new pure-TS folder `src/domain/v3/` with no JSX, so it is portable to PHP/Python later.
2. AGENTS.md rule "market data never a model input" is superseded by spec v3.0 for Layer 3 (price enters via Delta_Val). AGENTS.md, README, ROADMAP must be updated in the same step; v1 engine stays selectable until v3 is accepted.
3. No backend exists: live price, Rf/beta/ERP and DeepSeek stay manual or SINTETIS fixtures. No invented data. DeepSeek proxy is designed (contract and prompt) but not wired.
4. TTM (spec) replaces the earlier "monthly is unannualized YTD" decision only for Stage A; monthly periods stay unscored until the estimate mode is built (off by default).
5. Tests: add vitest (dev dependency) for T1-T18. The sandbox may block running it; the user runs it.

## Build order (stop and report after each step)
1. **Config + types**: `config.ts` (all parameters, versioned, hashed), canonical accounts (~35), integer rule-weight scheme. Tests: config hash determinism.
2. **Membership + defuzzification**: MF parameters from spec, centroid on 0..100 step 0.1. Tests: T4, T10 (already hand-verified).
3. **Rule generator**: 9 + 27 + 27 = 63 rules from S10 integer scheme, CSV export, vetoes F1-F3 and CoC=Bahaya. Tests: rule counts, table consistency.
4. **Stage A**: five ratios + D1-D6, TTM, averages, flags for proxies.
5. **Stage B**: BVPS, CAPM re, 9-scenario JPBV grid, HW_H, Delta_Val clamp, break-even P0.
6. **Stage C pipeline + robustness**: ROBUST/SENSITIF, near-threshold flag, K1-K5 controls, labels (<45, 45-70, >=70).
7. **Validators V1-V7, warnings W1-W4**, completeness gate matrix (annual vs interim).
8. **Layer separation + cache**: Layer 1 keyed by (bank, period, config version, input hash); Layer 3 never re-triggers Layer 1. Price-zone sweep 0.5-2.0 x P0 step 0.5%, NON-MONOTON flag, hysteresis, stale/jump/corporate-action blocks.
9. **Integration in the app**: adapter from `AnalysisRecord` to v3 result (new record version, archive instead of silent wipe in `migrate()` in `src/domain/store.tsx`), then update consumers (heaviest: `WorkspacePages.tsx`, `EmitenPages.tsx`, `SimulasiPage.tsx`, `WhatIfPanel.tsx`, `FuzzyMamdani.tsx`, `exporters.ts`, `narrative.ts`, `MetodologiPage.tsx`) and i18n keys (ID and EN, no duplicate keys). Remove the `RatioKey`/`VAR_KEYS` coupling (`engine.ts` L134).
10. **DeepSeek contract**: final system prompt and JSON schema, audit log of user confirmation, docs (6 `.md` files only), CHANGELOG.

## Reuse
`tri`/centroid ideas in `src/domain/engine.ts`; `parseStatementNumber`, `detectUnit` in `financial.ts`; `accountMatcher.ts` (add aliases only); `validateComparison` and `validateMonthly` in `yearWindow.ts`; `ui.tsx` primitives; `VerifiedFinancialItem.verifiedAt/By` as audit seed.

## Risks
Persisted `AnalysisRecord` shape changes (24 strengths); hard-coded "9 rasio / 24 rule" strings across 6 i18n files; no tests or `tsc` script exist today; sandbox blocks `tsc`/build.

## Verification
Per step: vitest unit tests for the step's T-cases; at step 9 the user runs `pnpm exec tsc --noEmit -p .` and `pnpm build`, then a manual browser pass (Workspace, Emiten, Simulasi, Metodologi) at 360/768/1280px.
