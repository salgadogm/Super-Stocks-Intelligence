# Roadmap & Keputusan

Menggantikan folder `plans/` lama. Hanya berisi keputusan yang berlaku dan pekerjaan yang belum dikerjakan. Aturan pengembangan ada di `AGENTS.md`, metodologi di `README.md`, status & checklist uji di `HANDOFF.md`, riwayat di `CHANGELOG.md`.

## Keputusan yang berlaku

- Cakupan hanya bank umum konvensional; syariah dikeluarkan (model terpisah bila kelak diperlukan, dengan pilihan Konvensional/Syariah di awal).
- Admin menyuplai koleksi, user menarik dan memverifikasi salinannya sendiri. Tanpa backend, "bersama" hanya berlaku di satu browser.
- AI hanya mengusulkan angka, user memverifikasi, model deterministik. Data pasar tidak pernah menjadi input model.
- Komparasi hanya pada jendela tahun identik (apple-to-apple); tidak ada mode "tahun irisan". Ketidakcocokan tahun memblokir, bukan memperingatkan.
- Desain formal terminal keuangan (lihat `AGENTS.md`); tidak ada tema atau efek dekoratif.
- Rule base 24 rule, `mamdani-bank-v1.0`. Mengubah rule atau himpunan berarti menaikkan versi model.
- Registri tetap bank IDX boleh menampilkan emiten tanpa laporan, tetapi skor hanya berasal dari analisis FY terverifikasi. Bank syariah tetap ditandai dan diblokir.
- Kualitas fundamental dan valuasi adalah dua sumbu terpisah. PBV/PER/PBV wajar/kuadran hanya konteks; tidak boleh mengubah skor Mamdani.
- DeepSeek adalah target penyedia ekstraksi AI, tetapi hanya boleh dipanggil melalui backend dengan `DEEPSEEK_API_KEY` sebagai secret server. Jangan menambahkan input key DeepSeek di frontend.

## Backlog terbuka

Sudah diverifikasi belum ada di kode (per 2026-10-03).

### Verifikasi & kualitas (prioritas pertama)
1. Uji dengan PDF nyata: heuristik `scan.years[0]` dapat memblokir laporan sah yang kolom pertamanya bukan tahun berjalan.
2. Audit registri `ALL_BANKS` terhadap daftar IDX terbaru, termasuk nama resmi, delisting/perubahan nama, dan klasifikasi segmen BUMN/Swasta.
3. Sebagian: chunk utama kini ~1,09 MB. Lanjutan: pecah `WorkspacePages` agar `CollectionsPages`/`MarketPages` bisa lazy.
4. Tahun akhir berbeda antar emiten tidak didukung secara sengaja; ubah hanya bila ada kebutuhan eksplisit.
5. Uji manual Daftar Emiten dengan Data Demo: skor FY, filter, perubahan skor/harga, PBV/PER, PBV wajar, kuadran, empty state, tidak adanya bank syariah di daftar, dan mode Inggris.
6. Uji manual tujuh tahap Simulasi dalam mode ID/EN, tema gelap/terang, serta layar mobile; pastikan autoplay berhenti pada gerbang verifikasi dan semua disclaimer tetap terlihat.

### Fitur analitik
- Segmen bank (BUMN / Swasta) sebagai filter di Ranking dan Perbandingan (`bankSegmentOf` baru dipakai di `MarketPages.tsx`).
- Panel benchmark di Profil Emiten: rasio emiten vs median dan kuartil segmen.
- Screener di Ranking (BOPO < x, ROE > y, LDR dalam rentang).
- Input opsional NPL, CAR, CASA per FY sebagai konteks (tanpa masuk model sampai himpunan fuzzy-nya dibuat); simpan set perbandingan favorit.
- Daftar Emiten sudah memiliki PBV, PER, PBV wajar, dan kuadran kualitas-versus-valuasi berbasis harga FY. `PerbandinganPage` sudah memiliki grafik indeks skor vs harga per emiten. Lanjutan: valuation gap dan korelasi Spearman (hanya bila n >= 5, berlabel indikatif). Tanpa klaim harga real-time.
- Tingkat keyakinan per skor, stempel kesegaran data (tanggal laporan/harga), tiga faktor pendorong skor dalam bahasa awam (`narrative.ts`), alert watchlist saat kategori berubah, riwayat versi analisis, ekspor CSV.

### Kepercayaan & UX
- Disclaimer kontekstual yang selalu terlihat: footer tipis di shell, catatan "Skor bukan rekomendasi" di bawah `ScoreGauge`, banner di Advisor dan di Auth, serta persetujuan awal sekali (simpan di `preferences.ts`; tombol di DisclaimerPage ikut menyimpannya). Satu sumber teks agar PDF ekspor selaras.
- Aksesibilitas: fokus keyboard terlihat, kontras AA, `prefers-reduced-motion`; skeleton loading; tooltip istilah (`Term`) untuk semua rasio.
- Periksa sisa responsivitas pada halaman lebar (tabel, grafik) di layar sempit.
- Berita lama bertema tambang di `news.ts`: beri opsi hapus bagi admin.

### Backend (opsional, pekerjaan lanjutan)
Laravel API di Hostinger shared hosting (PHP 8.3, MySQL, tanpa Node/queue worker/WebSocket), React hasil build statis di `public_html`, Laravel di luar `public_html` dan `public/`-nya disalin ke `public_html/api` (same-origin, Sanctum cookie).
- **Wajib untuk AI produksi**: buat endpoint proxy ekstraksi DeepSeek, simpan `DEEPSEEK_API_KEY` hanya di secret/environment backend, lakukan autentikasi/rate limit/validasi respons, lalu ganti panggilan Anthropic langsung di `aiExtract.ts`. Sampai itu selesai, UI DeepSeek pada Simulasi hanya demonstrasi dan bukan koneksi nyata.
- Auth Sanctum dengan kolom `role` menggantikan `getRole()`; tabel `users`, `issuers`, `reports`, `account_values`, `ratios`, `fuzzy_results`, `news`, `news_blocks`, `comments`, `usage_events`, `user_preferences`, `api_keys` (terenkripsi).
- Endpoint: `/api/auth/*`, `/api/issuers`, `/api/reports` (+ `/evaluate`), `/api/news`, `/api/usage`, `/api/backup`, `/api/market` (proxy agar key tidak terekspos).
- Port Mamdani dan rasio ke PHP (`app/Services/FuzzyMamdani.php`) dengan uji PHPUnit yang membandingkan hasil dengan versi TS pada dataset sama (bukti validitas untuk laporan TA). Versi TS tetap untuk What-if.
- Frontend: `src/domain/api.ts` (fetch wrapper, base `/api`, fallback localStorage bila `VITE_API_URL` kosong) dan repository pengganti akses localStorage di store, news, usage, profile, preferences, apiKeys, backup. PDF ke teks tetap di browser.
- Deploy: set PHP 8.3 dan database di hPanel, `composer install --no-dev`, isi `.env` (`APP_URL`, `SANCTUM_STATEFUL_DOMAINS`, `SESSION_DOMAIN`), `php artisan migrate --force` dan cache config/route, salin `public/`, unggah `dist/` yang di-build dengan `VITE_API_URL=/api`, cron `schedule:run` bila perlu. Atur `upload_max_filesize` untuk PDF besar.
- Kode Laravel tidak bisa dijalankan di Figma Make; siapkan sebagai repo atau folder `backend/` terpisah.
