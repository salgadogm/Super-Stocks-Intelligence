# SSI - Super Stocks Intelligence (Aurevia Intelligence)

Alat bantu analisis fundamental saham bank umum konvensional di BEI (IDX-IC sektor G Financials). Laporan keuangan diubah menjadi 9 rasio, lalu dinilai oleh model **Fuzzy Mamdani** menjadi skor 0-100 dengan kategori *Tidak Layak*, *Dipertimbangkan*, atau *Layak*. Dibuat sebagai proyek tugas akhir. SSI adalah advisor pendukung analisis, **bukan rekomendasi beli/jual** dan bukan kebenaran absolut; AI dan model dapat keliru, keputusan akhir ada pada pengguna.

## Menjalankan

```
pnpm install
pnpm dev                          # dev server
pnpm exec tsc --noEmit -p .       # typecheck
pnpm build                        # build produksi
```

Aplikasi saat ini masih sepenuhnya frontend (React 19, Vite 8, Tailwind v4, TypeScript). Data berada di `localStorage` dan IndexedDB (`ssi-files`) per browser. Backend wajib ditambahkan sebelum ekstraksi DeepSeek nyata digunakan agar `DEEPSEEK_API_KEY` hanya tersimpan sebagai secret server dan tidak pernah dikirim ke frontend. Untuk struktur kode dan aturan pengembangan lihat `AGENTS.md`; status terkini di `HANDOFF.md`, riwayat di `CHANGELOG.md`.

## Alur sistem

1. **Admin** mengunggah PDF laporan keuangan ke *Koleksi Laporan* (ticker, tahun fiskal, periode, satuan). PDF disimpan di IndexedDB. Halaman *Folder Laporan* menampilkan koleksi per bank lalu per tahun, termasuk tahun yang masih kosong.
2. **User** memilih laporan dari koleksi dan menekan *Analisis*. PDF dibaca di browser (pdf.js), hanya halaman Laba Rugi dan Posisi Keuangan yang dipakai, lalu angka dicocokkan dengan aturan (`accountMatcher`). Target produksi untuk akun yang gagal adalah DeepSeek melalui proxy backend dengan key tersembunyi. Implementasi lama `aiExtract.ts` masih memanggil Anthropic dari browser dan harus diganti sebelum fitur AI dipakai sebagai alur produksi.
3. **Verifikasi**: PDF asli di kiri, 9 akun di kanan dengan badge sumber (Rule/AI) dan tingkat keyakinan. Semua baris harus diverifikasi user sebelum skor dihitung. Harga saham (untuk PER) diisi manual.
4. **Model**: 9 akun menjadi 9 rasio, fuzzifikasi, 24 rule, agregasi, defuzzifikasi centroid, skor dan kategori. AI tidak pernah menghitung atau menilai; model deterministik.
5. **Analitik**: Ranking, Profil Emiten (jendela 5 tahun), Perbandingan N tahun, Daftar Emiten, What-if, Advisor, dan ekspor PDF. `Daftar Emiten` menggabungkan registri tetap bank IDX dengan emiten yang diunggah, tetapi hanya menampilkan skor untuk analisis FY yang benar-benar sudah diverifikasi.
6. **Konteks valuasi**: harga FY, perubahan skor/harga, PBV, PER, PBV wajar, dan kuadran kualitas-versus-valuasi ditampilkan terpisah dari skor. Harga saham tetap konteks, kecuali harga manual yang memang diperlukan oleh rasio PER.

## Metodologi

| Rasio | Rumus | Akun sumber |
|---|---|---|
| ROE | Laba bersih / Total ekuitas | net_income, total_equity |
| ROA | Laba bersih / Total aset | net_income, total_assets |
| NIM (proksi) | Pendapatan bunga neto / Total aset | net_interest_income, total_assets |
| NPM | Laba bersih / Total pendapatan operasional | net_income, operating_income |
| BOPO | Beban operasional / Pendapatan operasional | operating_expense, operating_income |
| LDR | Total kredit / Dana pihak ketiga | total_loans, third_party_funds |
| EQA | Total ekuitas / Total aset (proksi permodalan) | total_equity, total_assets |
| LTA | Total kredit / Total aset | total_loans, total_assets |
| PER | Harga saham / EPS dasar | basic_eps + harga (input manual) |

- Fungsi keanggotaan segitiga, tiap rasio punya 3 himpunan (mis. Rendah/Sedang/Tinggi, BOPO: Efisien/Sedang/Boros, PER: Murah/Wajar/Mahal). Definisi ada di `src/domain/engine.ts`.
- 24 rule hard-coded; operator AND = MIN, agregasi = MAX, defuzzifikasi centroid pada himpunan output Tidak Layak [0,0,35], Dipertimbangkan [25,50,75], Layak [65,100,100].
- Kategori: skor < 35 Tidak Layak, < 65 Dipertimbangkan, selainnya Layak.
- Versi mesin dicap pada tiap analisis: `mamdani-bank-v1.0`. Data pasar (World Bank, Frankfurter, opsional FMP/Twelve Data/Finnhub) hanya konteks dan **tidak pernah menjadi input model**.
- `src/domain/valuation.ts` menghitung BVPS, PBV, PER, dan PBV wajar dengan asumsi ilustratif `g = 6%` dan `r = 12%`. Kuadran pada Daftar Emiten membandingkan persentil skor dengan persentil PBV di antara bank yang memiliki data pada tahun akhir; hasilnya bukan rekomendasi beli/jual.

## Data contract

- Hanya bank umum konvensional. Bank syariah (BRIS, BTPS, PNBS) ditolak karena struktur pendapatan (bagi hasil) dan rasio (FDR, NPF, NOM) tidak sebanding; perluasan ke syariah berarti model terpisah, bukan campuran.
- Hanya laporan **konsolidasian**, hanya **Laba Rugi dan Posisi Keuangan**. Arus kas, perubahan ekuitas, catatan, dan ikhtisar tidak boleh menjadi sumber.
- Periode dan satuan seragam (mis. FY, jutaan rupiah). Akun yang tidak ditemukan ditandai "tidak ditemukan", tidak ditebak.
- **Apple-to-apple**: perbandingan memakai satu jendela N tahun (2-10) yang identik untuk semua emiten. Bila ada emiten dengan jumlah atau tahun berbeda (mis. 3 vs 4 tahun, atau 2015-2020 vs 2020-2025) perbandingan diblokir dan tahun yang kurang ditunjukkan. Admin sebaiknya mengunggah rentang tahun lengkap per bank.
- **Pembekuan saat tahun tidak cocok**: bila tahun terdeteksi dari PDF atau kolom hasil AI berbeda dari tahun fiskal dokumen, proses dihentikan dengan dialog dan verifikasi dikunci sampai data disesuaikan.

## Batasan penelitian

- Hanya bank konvensional; skala bank (besar vs kecil) memengaruhi rasio. Bank konvensional dengan unit usaha syariah dilaporkan konsolidasian dan dianggap berpengaruh kecil (alias akun "pendapatan bunga dan syariah - neto" dipertahankan).
- NIM memakai proksi (pendapatan bunga neto / total aset), EQA proksi permodalan; NPL, CAR, dan CASA tidak tersedia dalam laporan yang diizinkan dan tidak dipakai.
- Koleksi bersifat per browser (belum ada backend). Deteksi tahun PDF memakai heuristik kolom pertama; PDF dengan tata letak tidak biasa perlu dicek manual.
- Angka AI wajib diverifikasi manusia. Validasi model terhadap return harga belum dihitung.
- Registri `ALL_BANKS` adalah daftar referensi tetap yang perlu ditinjau berkala terhadap daftar IDX terkini. Keberadaan emiten di registri tidak berarti laporan, skor, atau valuasinya tersedia.
- PBV wajar memakai asumsi pertumbuhan dan tingkat imbal hasil tetap untuk konteks ilustratif; asumsi tersebut belum menjadi parameter pengguna dan tidak boleh diperlakukan sebagai nilai intrinsik final.
