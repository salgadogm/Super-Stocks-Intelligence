# Handoff - status sesi & langkah berikutnya

Dokumen kerja untuk sesi berikutnya. Baca ini dulu, lalu `AGENTS.md` (aturan kode), `README.md` (metodologi), `ROADMAP.md` (backlog), `CHANGELOG.md` (riwayat). Hapus/kosongkan bagian yang sudah selesai.

## Status per 2026-10-03

Fondasi komparasi N tahun apple-to-apple sebelumnya sudah **lolos** `pnpm exec tsc --noEmit -p .` dan `pnpm build`. Code-splitting awal juga sudah lolos; chunk utama terakhir yang terdokumentasi sekitar 1,10 MB.

Perubahan terbaru yang sudah ada di kode:
- `src/pages/SimulasiPage.tsx` + `src/domain/simulation.ts`: walkthrough 7 tahap memakai data ilustratif BBRI/BMRI, engine Mamdani asli, validasi jendela asli, dan dokumen jebakan BMRI FY2025. Tidak ada AI/backend nyata.
- `src/domain/issuers.ts`: `ALL_BANKS` dan `registryWith` menambahkan registri tetap bank IDX. Bank tanpa analisis tetap tampil tanpa skor; bank syariah (BRIS/BTPS/PNBS) sudah dihapus dari registri dan hanya ditolak saat unggah (`isSharia`); registri ditambah AGRS, BBSI, BSWD, INPC (nama/kode perlu ditinjau).
- `src/pages/DaftarEmitenPage.tsx`: skor per FY, kategori, harga FY, perubahan skor/harga, pencarian/filter, serta kolom valuasi.
- `src/domain/valuation.ts`: BVPS, PBV, PER, PBV wajar dengan asumsi `g = 6%`, `r = 12%`, percentile rank, dan kuadran kualitas-versus-valuasi.
- `src/App.tsx`: Simulasi End-to-End dan Daftar Emiten sudah dihubungkan ke navigasi state-based dan dimuat secara lazy.
- `src/domain/apiKeys.ts` + Akun Saya: DeepSeek ditampilkan sebagai secret backend yang tidak dapat dilihat/diubah; key FMP/Twelve Data/Finnhub hanya dapat diubah admin.

**Verifikasi otomatis selesai**: perubahan Simulasi, registri emiten, Daftar Emiten, valuasi, dan i18n telah lolos `pnpm exec tsc --noEmit -p .` serta `pnpm build`. Build Vite menghasilkan chunk utama sekitar 1,09 MB dan hanya memberi peringatan ukuran chunk > 500 kB.

Terjemahan Inggris untuk Simulasi End-to-End dan Daftar Emiten sekarang berada di `src/i18n/extra/simulasi.ts`. Teks dinamis penting—tahap, toast, mismatch tahun, alasan jendela perbandingan, istilah himpunan fuzzy, rule aktif, valuasi, dan deskripsi halaman—sudah melalui lapisan i18n.

`PerbandinganPage` sekarang memiliki panel "Skor vs Harga · indeks awal = 100". Setiap emiten ditampilkan sebagai small-multiple dengan garis skor dan harga sepanjang jendela FY identik. Harga tetap berasal dari input manual per tanggal laporan; bila satu harga hilang, grafik emiten tersebut tidak ditampilkan. Panel hanya membandingkan arah perubahan dan tidak mengklaim sebab-akibat.

**Kesenjangan keamanan/implementasi penting**: target produk adalah DeepSeek melalui backend dengan key tersembunyi, tetapi `src/domain/aiExtract.ts` masih berisi integrasi lama Anthropic langsung dari browser dan `apiKeys.ts` masih mempertahankan tipe/env internal `anthropic` agar kode lama tetap berjalan. UI tidak lagi menyediakan input Anthropic. Sebelum AI produksi diaktifkan, buat proxy backend DeepSeek dengan `DEEPSEEK_API_KEY`, ubah `aiExtract.ts`, lalu hapus jalur Anthropic frontend.

Berkas kunci untuk sesi berikutnya: `src/pages/DaftarEmitenPage.tsx`, `src/domain/valuation.ts`, `src/pages/SimulasiPage.tsx`, `src/domain/simulation.ts`, `src/domain/issuers.ts`, `src/domain/aiExtract.ts`, `src/domain/apiKeys.ts`, `src/pages/EmitenPages.tsx`, dan `src/App.tsx`.

Urutan langkah berikutnya:
1. Uji manual mode Inggris pada seluruh tujuh tahap Simulasi dan tabel Daftar Emiten untuk memastikan tidak ada teks Indonesia yang bocor.
2. Uji visual/manual grafik skor vs harga pada jendela 2-10 tahun, termasuk harga kosong dan layar mobile.
3. Uji visual/manual checklist di bawah, khususnya responsivitas tabel dan gerbang verifikasi.
4. Implementasikan proxy backend DeepSeek; jangan pernah mengekspos key di frontend.
5. Uji laporan bulanan tahun berjalan (belum diverifikasi `tsc`/`pnpm build`; sandbox menolak perintahnya, jalankan manual): unggah FY2021-2025 + Jan 2026 untuk 2 emiten (lolos, panel "Laporan bulanan" muncul); hapus Jan pada satu emiten (diblokir dengan alasan); 1 emiten saja punya bulanan (diblokir, minimal 2); PDF dengan bulan keliru (dialog mismatch). Keputusan terbuka: bulanan tidak dianualisasi dan tidak diberi skor; ubah di `financial.ts`/`MetodologiPage` bila diputuskan lain.

## Checklist uji manual

Komparasi N tahun
- [ ] N = 2..10 dan tahun akhir dapat dipilih; jendela = [akhir-N+1 .. akhir].
- [ ] Semua emiten lengkap di jendela: skor dan ranking tampil.
- [ ] Satu emiten kurang satu tahun: skor dan ranking disembunyikan, `YearDisclaimer` menyebut emiten dan tahun yang hilang. Tidak ada fallback "tahun irisan".
- [ ] Jumlah tahun beda (3 vs 4) dan rentang beda (2015-2020 vs 2020-2025) sama-sama diblokir.

Pembekuan tahun tidak cocok
- [ ] PDF dengan tahun terdeteksi (`scan.years[0]`) berbeda dari tahun fiskal dokumen: `YearMismatchDialog` muncul tanpa tombol lanjut.
- [ ] Kolom AI dengan `columnYear` salah: verifikasi terkunci di `VerifikasiPage`.
- [ ] PDF sah yang kolom pertamanya tahun pembanding (bukan tahun berjalan): catat bila terblokir keliru (risiko heuristik, backlog #2).

Folder Laporan & akses
- [ ] Tampil per bank lalu per tahun, termasuk tahun kosong.
- [ ] Admin bisa hapus; viewer tidak melihat tombol hapus/upload, hanya tarik (pull).
- [ ] Bank syariah (BRIS, BTPS, PNBS) tetap ditolak.

Regresi
- [ ] Mode terang/gelap, drawer mobile, tabel scroll horizontal.
- [ ] Bahasa EN: tidak ada kunci mentah yang bocor.

Simulasi & Daftar Emiten
- [ ] Tujuh tahap Simulasi dapat dijalankan, autoplay berhenti pada gerbang verifikasi, dan reset bekerja.
- [ ] Semua angka simulasi diberi label ilustratif; tidak ada klaim bahwa PDF/AI/backend nyata dipanggil.
- [ ] Daftar seluruh bank tetap tampil saat belum ada laporan; skor hanya muncul dari analisis FY terverifikasi.
- [ ] BRIS, BTPS, dan PNBS tidak muncul di Daftar Emiten.
- [ ] PBV/PER/PBV wajar dan kuadran cocok dengan hitungan tangan pada data demo.
- [ ] Filter kategori, pencarian, tahun akhir, dan jendela 2-5 tahun bekerja.
- [ ] Tabel tetap dapat digulir horizontal pada layar sempit.

## Catatan untuk agen berikutnya
- Bila shell menolak perintah verifikasi, katakan terus terang dan minta user menjalankannya; jangan klaim sudah lolos.
- Jangan menambah file `.md` baru; perbarui keenam file yang ada.
- Jangan menyalin chain-of-thought internal ke dokumentasi. Catat keputusan, alasan tingkat tinggi, alternatif yang ditolak, hasil, risiko, dan pekerjaan lanjutan secara ringkas.
