// Usage analytics store (localStorage only). Real events are tracked per browser; demo events are clearly flagged.
import { useSyncExternalStore } from "react";

export type UsageType = "login" | "page_view" | "upload" | "calculate" | "export" | "advisor" | "pick_report" | "extract";
export interface UsageEvent { ts: number; user: string; name?: string; type: UsageType; page?: string; demo?: boolean }

const KEY = "aurevia.usage.v1";
const MAX_REAL = 5000;
const DAY = 86_400_000;

let current = { email: "anonim", name: "Anonim" };
export const setUsageUser = (email: string, name: string) => { current = { email: email || "anonim", name: name || "Anonim" }; };

let cache: UsageEvent[] | null = null;
const listeners = new Set<() => void>();
const read = (): UsageEvent[] => {
  if (cache) return cache;
  try { const v = JSON.parse(localStorage.getItem(KEY) ?? "[]"); cache = Array.isArray(v) ? v : []; } catch { cache = []; }
  return cache!;
};
const write = (ev: UsageEvent[]) => {
  const real = ev.filter((e) => !e.demo).slice(-MAX_REAL);
  cache = [...ev.filter((e) => e.demo), ...real].sort((a, b) => a.ts - b.ts);
  try { localStorage.setItem(KEY, JSON.stringify(cache)); } catch { /* quota */ }
  listeners.forEach((l) => l());
};

export function track(type: UsageType, page?: string) {
  write([...read(), { ts: Date.now(), user: current.email, name: current.name, type, page }]);
}
export const hasDemo = () => read().some((e) => e.demo);
export const clearDemo = () => write(read().filter((e) => !e.demo));
export const clearReal = () => write(read().filter((e) => e.demo));
export function useUsageEvents() {
  return useSyncExternalStore((cb) => { listeners.add(cb); return () => listeners.delete(cb); }, read, read);
}

const PAGES = ["Overview", "Upload Laporan", "Verifikasi Ekstraksi AI", "Skor & Defuzzifikasi", "Ranking & Comparison", "Profil Emiten", "Perbandingan Emiten", "Tanya Advisor", "News", "Export Laporan (PDF)", "Macro & Banking Dashboard", "Tren Historis"];
const FIRST = ["Rina", "Budi", "Sari", "Andi", "Dewi", "Eko", "Fajar", "Gita", "Hadi", "Intan", "Joko", "Kiki", "Lina", "Made", "Nanda", "Oki", "Putri", "Raka", "Sinta", "Tono"];
const LAST = ["Pratama", "Wijaya", "Santoso", "Lestari", "Hidayat", "Nugroho", "Saputra", "Kusuma"];

/** Deterministic demo dataset: 90 days, 40 fictional users. */
export function seedDemo() {
  let s = 20260101;
  const rnd = () => { s = (s * 1664525 + 1013904223) % 4294967296; return s / 4294967296; };
  const pick = <T,>(a: T[]) => a[Math.floor(rnd() * a.length)];
  const now = Date.now();
  const out: UsageEvent[] = [];
  for (let u = 0; u < 40; u++) {
    const name = `${FIRST[u % FIRST.length]} ${LAST[(u * 3) % LAST.length]}`;
    const user = `demo${u + 1}@contoh.id`;
    const joined = Math.floor(Math.pow(rnd(), 0.8) * 88);
    const habit = 0.05 + rnd() * rnd() * 0.7;
    for (let d = joined; d >= 0; d--) {
      const dt = new Date(now - d * DAY);
      const weekend = dt.getDay() === 0 || dt.getDay() === 6;
      if (d !== joined && rnd() > habit * (weekend ? 0.4 : 1)) continue;
      const hour = Math.min(23, Math.max(0, Math.round(10 + (rnd() + rnd() + rnd() - 1.5) * 5)));
      const base = new Date(dt); base.setHours(hour, Math.floor(rnd() * 60), 0, 0);
      let t = base.getTime();
      const push = (type: UsageType, page?: string) => { out.push({ ts: t, user, name, type, page, demo: true }); t += 60_000 + Math.floor(rnd() * 240_000); };
      push("login");
      const views = 2 + Math.floor(rnd() * 6);
      for (let i = 0; i < views; i++) push("page_view", pick(PAGES));
      if (rnd() < 0.25) push("upload", "Upload Laporan");
      if (rnd() < 0.3) push("calculate", "Skor & Defuzzifikasi");
      if (rnd() < 0.15) push("export", "Export Laporan (PDF)");
      if (rnd() < 0.2) push("advisor", "Tanya Advisor");
    }
  }
  write([...read().filter((e) => !e.demo), ...out]);
}

/* ─── Aggregation ─── */
export type Range = 7 | 30 | 90 | 0;
export type Source = "all" | "real" | "demo";
export type Segment = "all" | "new" | "returning";
export interface UsageFilter { range: Range; type: UsageType | "all"; source: Source; segment: Segment }
export const DEFAULT_FILTER: UsageFilter = { range: 30, type: "all", source: "all", segment: "all" };

const dayStart = (ts: number) => { const d = new Date(ts); d.setHours(0, 0, 0, 0); return d.getTime(); };
const dayKey = (ts: number) => { const d = new Date(ts); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`; };

export interface UserRow { user: string; name: string; active: number; sessions: number; actions: number; last: number; topPage: string; demo: boolean }
export interface Aggregate {
  filtered: UsageEvent[];
  totalUsers: number; dau: number; wau: number; newUsers: number; returning: number;
  sessionsPerUser: number; totalActions: number;
  prev: { totalUsers: number; newUsers: number; totalActions: number; sessionsPerUser: number };
  daily: { key: string; ts: number; active: number; actions: number }[];
  heat: number[][];
  pages: { label: string; count: number }[];
  types: { label: UsageType; count: number }[];
  freq: { label: string; count: number }[];
  users: UserRow[];
}

const inSource = (e: UsageEvent, s: Source) => s === "all" || (s === "demo") === !!e.demo;

export function aggregate(all: UsageEvent[], f: UsageFilter): Aggregate {
  const now = Date.now();
  const src = all.filter((e) => inSource(e, f.source));
  const first = new Map<string, number>();
  for (const e of src) if (!first.has(e.user) || e.ts < first.get(e.user)!) first.set(e.user, e.ts);
  const from = f.range ? dayStart(now - (f.range - 1) * DAY) : 0;
  const prevFrom = f.range ? from - f.range * DAY : 0;

  const segOk = (e: UsageEvent) => {
    if (f.segment === "all") return true;
    const isNew = first.get(e.user)! >= from;
    return f.segment === "new" ? isNew : !isNew;
  };
  const pass = (e: UsageEvent) => (f.type === "all" || e.type === f.type) && segOk(e);
  const filtered = src.filter((e) => e.ts >= from && pass(e));
  const prevEv = f.range ? src.filter((e) => e.ts >= prevFrom && e.ts < from && pass(e)) : [];

  const sessionsOf = (ev: UsageEvent[]) => ev.filter((e) => e.type === "login").length;
  const users = new Set(filtered.map((e) => e.user));
  const prevUsers = new Set(prevEv.map((e) => e.user));
  const newCnt = (set: Set<string>, lo: number, hi: number) => [...set].filter((u) => first.get(u)! >= lo && first.get(u)! < hi).length;
  const newUsers = newCnt(users, from, Infinity);

  const today = dayStart(now);
  const active = (lo: number) => new Set(src.filter((e) => e.ts >= lo && pass(e)).map((e) => e.user)).size;

  const days = f.range || Math.max(1, Math.min(180, Math.ceil((now - (filtered[0]?.ts ?? now)) / DAY) + 1));
  const daily = Array.from({ length: days }, (_, i) => {
    const ts = dayStart(now - (days - 1 - i) * DAY);
    return { key: dayKey(ts), ts, active: 0, actions: 0 };
  });
  const idx = new Map(daily.map((d, i) => [d.key, i]));
  const seen = daily.map(() => new Set<string>());
  const heat = Array.from({ length: 7 }, () => Array(24).fill(0) as number[]);
  const pageCount = new Map<string, number>();
  const typeCount = new Map<UsageType, number>();
  const per = new Map<string, UserRow & { days: Set<string>; pg: Map<string, number> }>();

  for (const e of filtered) {
    const i = idx.get(dayKey(e.ts));
    if (i != null) { daily[i].actions++; seen[i].add(e.user); }
    const d = new Date(e.ts); heat[(d.getDay() + 6) % 7][d.getHours()]++;
    if (e.page) pageCount.set(e.page, (pageCount.get(e.page) ?? 0) + 1);
    typeCount.set(e.type, (typeCount.get(e.type) ?? 0) + 1);
    let r = per.get(e.user);
    if (!r) { r = { user: e.user, name: e.name ?? e.user, active: 0, sessions: 0, actions: 0, last: 0, topPage: "—", demo: !!e.demo, days: new Set(), pg: new Map() }; per.set(e.user, r); }
    r.actions++; r.last = Math.max(r.last, e.ts); r.days.add(dayKey(e.ts));
    if (e.type === "login") r.sessions++;
    if (e.page) r.pg.set(e.page, (r.pg.get(e.page) ?? 0) + 1);
  }
  daily.forEach((d, i) => { d.active = seen[i].size; });

  const rows: UserRow[] = [...per.values()].map((r) => {
    const top = [...r.pg.entries()].sort((a, b) => b[1] - a[1])[0];
    return { user: r.user, name: r.name, active: r.days.size, sessions: r.sessions, actions: r.actions, last: r.last, topPage: top?.[0] ?? "—", demo: r.demo };
  }).sort((a, b) => b.actions - a.actions);

  const buckets = [{ label: "1 hari", lo: 1, hi: 1 }, { label: "2–5 hari", lo: 2, hi: 5 }, { label: "6–15 hari", lo: 6, hi: 15 }, { label: "> 15 hari", lo: 16, hi: Infinity }];
  const freq = buckets.map((b) => ({ label: b.label, count: rows.filter((r) => r.active >= b.lo && r.active <= b.hi).length }));

  const sessions = sessionsOf(filtered);
  return {
    filtered,
    totalUsers: users.size, dau: active(today), wau: active(today - 6 * DAY),
    newUsers, returning: users.size - newUsers,
    sessionsPerUser: users.size ? sessions / users.size : 0,
    totalActions: filtered.length,
    prev: {
      totalUsers: prevUsers.size, newUsers: newCnt(prevUsers, prevFrom, from), totalActions: prevEv.length,
      sessionsPerUser: prevUsers.size ? sessionsOf(prevEv) / prevUsers.size : 0,
    },
    daily, heat,
    pages: [...pageCount.entries()].map(([label, count]) => ({ label, count })).sort((a, b) => b.count - a.count).slice(0, 8),
    types: [...typeCount.entries()].map(([label, count]) => ({ label, count })).sort((a, b) => b.count - a.count),
    freq, users: rows,
  };
}
