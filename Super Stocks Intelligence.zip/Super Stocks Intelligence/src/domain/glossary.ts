// Plain-language definitions. Keys are the displayed term; text is Indonesian source (translated via i18n).
export const GLOSSARY: Record<string, string> = {
  ROE: "Return on Equity: laba bersih dibanding ekuitas. Makin tinggi, makin efisien modal pemilik menghasilkan laba.",
  ROA: "Return on Assets: laba bersih dibanding total aset. Mengukur efisiensi pemakaian aset.",
  NIM: "Net Interest Margin (proksi): pendapatan bunga bersih dibanding total aset. Mengukur kemampuan bank menghasilkan selisih bunga.",
  NPM: "Net Profit Margin: laba bersih dibanding jumlah pendapatan operasional. Berapa persen pendapatan yang jadi laba.",
  BOPO: "Beban Operasional terhadap Pendapatan Operasional: makin rendah, bank makin efisien.",
  LDR: "Loan to Deposit Ratio: kredit yang diberikan dibanding dana pihak ketiga. Menunjukkan seberapa besar simpanan disalurkan sebagai kredit.",
  EQA: "Equity to Assets: ekuitas dibanding total aset. Proksi sederhana kecukupan modal (bukan CAR resmi).",
  LTA: "Loans to Assets: kredit yang diberikan dibanding total aset. Porsi aset yang disalurkan sebagai kredit.",
  PER: "Price to Earnings Ratio: harga saham dibanding laba per saham. Memakai harga yang Anda masukkan.",
  Fuzzifikasi: "Mengubah nilai rasio menjadi derajat keanggotaan (mis. Rendah, Sedang, Tinggi) antara 0 dan 1.",
  Mamdani: "Metode inferensi fuzzy berbasis aturan IF-THEN dengan keluaran himpunan fuzzy.",
  Centroid: "Defuzzifikasi: titik pusat area gabungan keluaran fuzzy, menjadi satu Skor Model 0-100.",
};
