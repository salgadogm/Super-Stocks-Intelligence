// PDF → structured text, fully in the browser, no AI and no server.
// pdf.js is bundled locally (no CDN, works offline); text items are regrouped into visual lines by their
// y-position and split into columns by x-gaps, so "Jumlah aset   12.345   11.234" stays on one row.
import { STATEMENT_TITLE_PATTERNS, type AllowedStatementType, type UnitScale } from "./financial";

import workerUrl from "pdfjs-dist/build/pdf.worker.min.mjs?url";

// eslint-disable-next-line @typescript-eslint/no-explicit-any
let lib: Promise<any> | null = null;
const loadPdfJs = () => {
  lib ??= import("pdfjs-dist").then((m) => { m.GlobalWorkerOptions.workerSrc = workerUrl; return m; });
  return lib;
};

export interface PdfLine { page: number; cells: string[]; text: string }
export interface PdfPage { page: number; lines: PdfLine[]; text: string }

type Item = { str: string; x: number; y: number; w: number };

/** Groups positioned text items into lines (y tolerance) and cells (x gap > ~1.5 chars). */
export function rebuildLines(items: Item[], page: number): PdfLine[] {
  const rows: Item[][] = [];
  for (const it of [...items].sort((a, b) => b.y - a.y || a.x - b.x)) {
    const row = rows.find((r) => Math.abs(r[0].y - it.y) < 3);
    if (row) row.push(it); else rows.push([it]);
  }
  return rows.map((r) => {
    r.sort((a, b) => a.x - b.x);
    const cells: string[] = [];
    let prevEnd = -Infinity;
    for (const it of r) {
      if (cells.length && it.x - prevEnd < 8) cells[cells.length - 1] += (it.x - prevEnd > 1.5 ? " " : "") + it.str;
      else cells.push(it.str);
      prevEnd = it.x + it.w;
    }
    const clean = cells.map((c) => c.trim()).filter(Boolean);
    return { page, cells: clean, text: clean.join(" | ") };
  }).filter((l) => l.cells.length);
}

export async function extractPages(file: File, onProgress?: (done: number, total: number) => void): Promise<PdfPage[]> {
  const pdfjs = await loadPdfJs();
  const doc = await pdfjs.getDocument({ data: await file.arrayBuffer() }).promise;
  const pages: PdfPage[] = [];
  for (let p = 1; p <= doc.numPages; p++) {
    const content = await (await doc.getPage(p)).getTextContent();
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const items: Item[] = content.items.filter((i: any) => i.str?.trim()).map((i: any) => ({ str: i.str, x: i.transform[4], y: i.transform[5], w: i.width }));
    const lines = rebuildLines(items, p);
    pages.push({ page: p, lines, text: lines.map((l) => l.text).join("\n") });
    onProgress?.(p, doc.numPages);
  }
  return pages;
}

/** A PDF with (almost) no text layer is a scan — it needs OCR or AI vision, not this parser. */
export const isScanned = (pages: PdfPage[]) => pages.reduce((s, p) => s + p.text.length, 0) / Math.max(1, pages.length) < 40;

const norm = (s: string) => s.toLowerCase().replace(/\s+/g, " ");

/** Pages whose top lines carry a statement title. Notes pages ("catatan atas…") are skipped. */
export function findStatementPages(pages: PdfPage[]): Record<AllowedStatementType, number[]> {
  const out: Record<AllowedStatementType, number[]> = { profit_loss: [], financial_position: [] };
  for (const p of pages) {
    const head = norm(p.lines.slice(0, 12).map((l) => l.text).join(" "));
    if (/catatan atas|notes to the/.test(head) && !/^\W*laporan (posisi|laba)/.test(head)) continue;
    const numeric = p.lines.filter((l) => l.cells.some((c) => /\d{1,3}([.,]\d{3}){1,}/.test(c))).length;
    if (numeric < 5) continue; // table of contents, auditor letter, etc.
    for (const k of Object.keys(out) as AllowedStatementType[])
      if (STATEMENT_TITLE_PATTERNS[k].some((t) => head.includes(t))) out[k].push(p.page);
  }
  return out;
}

/** Reads "dalam jutaan Rupiah" / "in thousands of US Dollars" style captions. */
export function detectUnitScale(text: string): { unit: UnitScale; currency: "IDR" | "USD" } | null {
  const t = norm(text);
  const m = t.match(/(dalam|in|expressed in)[^.\n]{0,30}?(miliar|milyar|billions?|jutaan|millions?|ribuan|thousands?)[^.\n]{0,20}?(rupiah|idr|dolar|dollars?|usd|us\$)/);
  if (!m) return null;
  const u = m[2];
  const unit: UnitScale = /mili|mily|billion/.test(u) ? "billions" : /juta|million/.test(u) ? "millions" : "thousands";
  return { unit, currency: /dol|usd|us\$/.test(m[3]) ? "USD" : "IDR" };
}

/** Year columns printed in the statement header, newest first (e.g. [2025, 2024]). */
export function detectYears(lines: PdfLine[]): number[] {
  for (const l of lines.slice(0, 25)) {
    const ys = l.cells.flatMap((c) => c.match(/\b20\d{2}\b/g) ?? []).map(Number);
    if (ys.length >= 2) return [...new Set(ys)];
  }
  return [];
}

const ID_MONTHS = ["januari", "februari", "maret", "april", "mei", "juni", "juli", "agustus", "september", "oktober", "november", "desember"];
const EN_MONTHS = ["january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december"];

/** Month (1-12) of the first period-end date printed in the statement text ("31 Januari 2026", "January 31, 2026"), or null. */
export function detectPeriodMonth(text: string): number | null {
  const names = [...ID_MONTHS, ...EN_MONTHS].join("|");
  const m = norm(text).match(new RegExp(`\\b\\d{1,2} (${names}) 20\\d{2}\\b|\\b(${names}) \\d{1,2},? 20\\d{2}\\b`));
  if (!m) return null;
  const name = m[1] ?? m[2];
  const i = ID_MONTHS.indexOf(name);
  return (i >= 0 ? i : EN_MONTHS.indexOf(name)) + 1;
}

/** Rough token estimate (≈4 chars/token) to show the saving of sending only relevant text. */
export const estimateTokens = (s: string) => Math.ceil(s.length / 4);
