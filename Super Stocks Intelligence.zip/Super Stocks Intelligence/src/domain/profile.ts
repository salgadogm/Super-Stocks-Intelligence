// Per-account profile (display name, role, bio, avatar). localStorage only, keyed by email, until a backend exists.
export interface Profile {
  name: string;
  headline: string;   // e.g. "Analis Ekuitas"
  organization: string;
  location: string;
  bio: string;
  avatar: string;     // AvatarId, or "" for monogram
}

export const BIO_MAX = 280;
const KEY = (email: string) => `aurevia.profile.v1:${email || "guest"}`;

export const blankProfile = (name: string): Profile => ({ name, headline: "", organization: "", location: "", bio: "", avatar: "" });

export function loadProfile(email: string, fallbackName: string): Profile {
  try {
    const raw = localStorage.getItem(KEY(email));
    return raw ? { ...blankProfile(fallbackName), ...JSON.parse(raw) } : blankProfile(fallbackName);
  } catch { return blankProfile(fallbackName); }
}

export function saveProfile(email: string, p: Profile) {
  try { localStorage.setItem(KEY(email), JSON.stringify(p)); } catch { /* quota */ }
}
