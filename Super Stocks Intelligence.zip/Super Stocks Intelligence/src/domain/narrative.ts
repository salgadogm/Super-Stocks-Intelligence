// Rule-based issuer summary. Every sentence is a template filled from stored, verified analyses; no model text.
import type { AnalysisRecord } from "./store";
import { VAR_KEYS, VAR_DEFS } from "./engine";
import { translate } from "../i18n";
import { getLang } from "./preferences";
import { fmtNum } from "../ui";

export interface NarrativeInput {
  latest: AnalysisRecord;
  prev?: AnalysisRecord;
  rank: number;
  peers: number;
  yearsHave: number;
  yearsTotal: number;
}

export function buildNarrative({ latest, prev, rank, peers, yearsHave, yearsTotal }: NarrativeInput): string[] {
  const t = (s: string, v?: Record<string, string | number>) => translate(getLang(), s, v);
  const out: string[] = [];
  out.push(t("{ticker} FY {fy} memperoleh Skor Model {score} dan masuk kategori {cat}.", {
    ticker: latest.ticker, fy: latest.period.fiscalYear, score: fmtNum(latest.score, 1), cat: t(latest.category),
  }));

  if (prev) {
    const d = latest.score - prev.score;
    out.push(Math.abs(d) < 0.05
      ? t("Skor relatif stabil dibanding FY {py} ({ps}).", { py: prev.period.fiscalYear, ps: fmtNum(prev.score, 1) })
      : t(d > 0 ? "Skor naik {d} poin dibanding FY {py} (dari {ps})." : "Skor turun {d} poin dibanding FY {py} (dari {ps}).",
        { d: fmtNum(Math.abs(d), 1), py: prev.period.fiscalYear, ps: fmtNum(prev.score, 1) }));

    const mover = VAR_KEYS.map((k) => {
      const [lo, hi] = VAR_DEFS[k].domain;
      return { k, a: prev.ratios[k], b: latest.ratios[k], norm: Math.abs(latest.ratios[k] - prev.ratios[k]) / (hi - lo) };
    }).sort((x, y) => y.norm - x.norm)[0];
    if (mover && mover.norm > 0.005) {
      const u = VAR_DEFS[mover.k].unit;
      out.push(t(mover.b > mover.a ? "Perubahan rasio terbesar: {k} naik dari {a}{u} menjadi {b}{u}." : "Perubahan rasio terbesar: {k} turun dari {a}{u} menjadi {b}{u}.",
        { k: mover.k, a: fmtNum(mover.a, 1), b: fmtNum(mover.b, 1), u }));
    }
  } else {
    out.push(t("Belum ada FY sebelumnya untuk dibandingkan."));
  }

  if (rank > 0 && peers > 0) out.push(t("Peringkat {r} dari {n} emiten yang Anda unggah.", { r: rank, n: peers }));
  out.push(yearsHave >= yearsTotal
    ? t("Cakupan {n} FY lengkap.", { n: yearsTotal })
    : t("Cakupan baru {h} dari {n} FY, sehingga kesimpulan tren masih terbatas.", { h: yearsHave, n: yearsTotal }));
  return out;
}
