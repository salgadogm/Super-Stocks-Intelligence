// Rule-based account matching: finds the 9 canonical accounts in the statement pages by alias.
// Deterministic and free; every suggestion still has to be confirmed manually in Verifikasi.
import { CANONICAL_ACCOUNTS, parseStatementNumber, type CanonicalAccountId } from "./financial";
import type { PdfLine } from "./pdfText";

export interface AccountMatch {
  account: CanonicalAccountId;
  label: string;
  current: string;   // printed text of the current-year column
  prior: string | null; // comparative column, if printed
  page: number;
  confidence: "high" | "medium";
}

const norm = (s: string) => s.toLowerCase().replace(/[^a-z\s]/g, " ").replace(/\s+/g, " ").trim();
const isNum = (c: string) => /\d/.test(c) && parseStatementNumber(c) != null && !/^\d{1,2}[a-z]?$/i.test(c.trim()); // skip note refs like "5" or "12b"

const ALL_ALIASES = Object.values(CANONICAL_ACCOUNTS).flatMap((a) => a.aliases.map((al) => ({ id: a.id, al })));
const LONGER: Record<string, string[]> = Object.fromEntries(ALL_ALIASES.map(({ id, al }) =>
  [al, ALL_ALIASES.filter((o) => o.id !== id && o.al.length > al.length && o.al.includes(al.split(" ").pop()!) && o.al.startsWith(al.split(" ")[0])).map((o) => o.al)]));

export function matchAccounts(lines: PdfLine[], pagesFor: Record<"profit_loss" | "financial_position", number[]>): AccountMatch[] {
  const out: AccountMatch[] = [];
  for (const acc of Object.values(CANONICAL_ACCOUNTS)) {
    const pages = pagesFor[acc.statement];
    const cands: AccountMatch[] = [];
    for (const l of lines) {
      if (!pages.includes(l.page)) continue;
      const label = norm(l.cells.filter((c) => !isNum(c)).join(" "));
      const alias = acc.aliases.find((a) => label === a || label.startsWith(a + " ") || label.endsWith(" " + a) || label.includes(a));
      if (!alias) continue;
      // "jumlah aset" must not claim "jumlah aset lancar": skip when a longer alias of another account fits better
      if (LONGER[alias]?.some((a) => label.includes(a))) continue;
      if (acc.id !== "basic_eps" && /per saham|per share/.test(label)) continue;
      const nums = l.cells.filter(isNum);
      if (!nums.length) continue;
      // exact or "jumlah/total" lines are most likely the subtotal we want
      const exact = label === alias || /^(jumlah|total)\b/.test(label);
      // when a note column precedes values, the last two numbers are the year columns
      const [cur, prior] = nums.length >= 2 ? nums.slice(-2) : [nums[0], null];
      cands.push({ account: acc.id, label: l.cells.filter((c) => !isNum(c)).join(" "), current: cur, prior, page: l.page, confidence: exact ? "high" : "medium" });
    }
    const best = cands.find((c) => c.confidence === "high") ?? cands[0];
    if (best) out.push(best);
  }
  return out;
}
