// Super Stocks Intelligence — financial data contract (Kloter 0 foundation)
// Source of truth for: allowed statements, canonical accounts, ratio → account traceability,
// and document/extraction/verification lifecycle types. No extraction engine lives here.
//
// Ratio keys mirror VAR_KEYS in src/FuzzyMamdani.tsx and Ratio.key in src/data.ts.
// NOTE: the project stores ratio VALUES only; it has no formula code. The formulas below are the
// conventional definitions of each ratio name and must be confirmed against the TA methodology.

/* ─── Source restriction ─────────────────────────── */
export const ALLOWED_STATEMENT_TYPES = ["profit_loss", "financial_position"] as const;
export type AllowedStatementType = (typeof ALLOWED_STATEMENT_TYPES)[number];

/** Every statement a detector may report. Only ALLOWED_STATEMENT_TYPES may supply values. */
export type StatementType =
  | AllowedStatementType
  | "cash_flows"
  | "changes_in_equity"
  | "notes"
  | "other";

export const isAllowedStatement = (t: StatementType): t is AllowedStatementType =>
  (ALLOWED_STATEMENT_TYPES as readonly string[]).includes(t);

export const STATEMENT_LABEL: Record<StatementType, string> = {
  profit_loss: "Profit and Loss",
  financial_position: "Statement of Financial Position",
  cash_flows: "Statement of Cash Flows",
  changes_in_equity: "Statement of Changes in Equity",
  notes: "Notes to Financial Statements",
  other: "Bagian lain",
};

/** Title variants used to recognise the two allowed statements (case-insensitive match). */
export const STATEMENT_TITLE_PATTERNS: Record<AllowedStatementType, string[]> = {
  profit_loss: [
    "statement of profit or loss",
    "statements of profit or loss",
    "consolidated statement of profit or loss",
    "statement of profit or loss and other comprehensive income",
    "laporan laba rugi",
    "laporan laba rugi dan penghasilan komprehensif lain",
    "laporan laba rugi konsolidasian",
  ],
  financial_position: [
    "statement of financial position",
    "statements of financial position",
    "consolidated statement of financial position",
    "balance sheet",
    "laporan posisi keuangan",
    "laporan posisi keuangan konsolidasian",
    "neraca",
  ],
};

export const NOT_FOUND_MESSAGE = "Tidak ditemukan pada sumber yang diizinkan.";
export const INVALID_SOURCE_MESSAGE = "Sumber tidak diizinkan.";

/* ─── Canonical accounts (derived from RATIO_DEFINITIONS only) ─── */
export type CanonicalAccountId =
  | "net_income"
  | "net_interest_income"
  | "operating_income"
  | "operating_expense"
  | "basic_eps"
  | "total_equity"
  | "total_assets"
  | "total_loans"
  | "third_party_funds";

export interface CanonicalAccount {
  id: CanonicalAccountId;
  label: string;
  labelId: string;
  statement: AllowedStatementType;
  /** Common raw labels, used only as mapping hints for the extraction assistant. */
  aliases: string[];
}

export const CANONICAL_ACCOUNTS: Record<CanonicalAccountId, CanonicalAccount> = {
  net_income:          { id: "net_income", label: "Net Income", labelId: "Laba Bersih", statement: "profit_loss",
    aliases: ["profit for the year", "laba tahun berjalan", "laba bersih", "net profit", "laba bersih tahun berjalan"] },
  net_interest_income: { id: "net_interest_income", label: "Net Interest Income", labelId: "Pendapatan Bunga Bersih", statement: "profit_loss",
    aliases: ["net interest income", "pendapatan bunga bersih", "pendapatan bunga - neto", "pendapatan bunga neto", "pendapatan bunga dan syariah - neto"] },
  operating_income:    { id: "operating_income", label: "Total Operating Income", labelId: "Jumlah Pendapatan Operasional", statement: "profit_loss",
    aliases: ["total operating income", "jumlah pendapatan operasional", "total pendapatan operasional", "pendapatan operasional"] },
  operating_expense:   { id: "operating_expense", label: "Total Operating Expenses", labelId: "Jumlah Beban Operasional", statement: "profit_loss",
    aliases: ["total operating expenses", "jumlah beban operasional", "total beban operasional", "beban operasional"] },
  basic_eps:           { id: "basic_eps", label: "Basic Earnings per Share", labelId: "Laba per Saham Dasar", statement: "profit_loss",
    aliases: ["basic earnings per share", "laba per saham dasar", "laba bersih per saham"] },
  total_equity:        { id: "total_equity", label: "Total Equity", labelId: "Jumlah Ekuitas", statement: "financial_position",
    aliases: ["total equity", "jumlah ekuitas", "total ekuitas"] },
  total_assets:        { id: "total_assets", label: "Total Assets", labelId: "Jumlah Aset", statement: "financial_position",
    aliases: ["total assets", "jumlah aset", "total aset"] },
  total_loans:         { id: "total_loans", label: "Total Loans", labelId: "Kredit yang Diberikan", statement: "financial_position",
    aliases: ["total loans", "kredit yang diberikan", "pinjaman yang diberikan", "kredit yang diberikan neto"] },
  third_party_funds:   { id: "third_party_funds", label: "Third-Party Funds", labelId: "Dana Pihak Ketiga", statement: "financial_position",
    aliases: ["third party funds", "deposits from customers", "simpanan nasabah", "dana pihak ketiga", "total simpanan"] },
};

/* ─── Ratio → formula → accounts ─────────────────── */
export type RatioKey = "ROE" | "ROA" | "NIM" | "NPM" | "BOPO" | "LDR" | "EQA" | "LTA" | "PER";

/** Inputs that are not financial-statement accounts (must be flagged, never extracted). */
export type ExternalInputId = "share_price";

export interface RatioDefinition {
  key: RatioKey;
  name: string;
  formula: string;
  requiredAccounts: CanonicalAccountId[];
  externalInputs: ExternalInputId[];
  unit: "%" | "x";
  /** Deterministic calculation; returns null when any input is missing or denominator is 0. */
  compute: (a: Partial<Record<CanonicalAccountId, number>>, ext: Partial<Record<ExternalInputId, number>>) => number | null;
}

const div = (n?: number, d?: number, k = 1) =>
  n == null || d == null || d === 0 ? null : (n / d) * k;

export const RATIO_DEFINITIONS: Record<RatioKey, RatioDefinition> = {
  ROE:  { key: "ROE", name: "Return on Equity", unit: "%", formula: "Net Income / Total Equity × 100",
    requiredAccounts: ["net_income", "total_equity"], externalInputs: [],
    compute: (a) => div(a.net_income, a.total_equity, 100) },
  ROA:  { key: "ROA", name: "Return on Assets", unit: "%", formula: "Net Income / Total Assets × 100",
    requiredAccounts: ["net_income", "total_assets"], externalInputs: [],
    compute: (a) => div(a.net_income, a.total_assets, 100) },
  NIM:  { key: "NIM", name: "Net Interest Margin (proxy)", unit: "%", formula: "Net Interest Income / Total Assets × 100",
    requiredAccounts: ["net_interest_income", "total_assets"], externalInputs: [],
    compute: (a) => div(a.net_interest_income, a.total_assets, 100) },
  NPM:  { key: "NPM", name: "Net Profit Margin", unit: "%", formula: "Net Income / Total Operating Income × 100",
    requiredAccounts: ["net_income", "operating_income"], externalInputs: [],
    compute: (a) => div(a.net_income, a.operating_income, 100) },
  BOPO: { key: "BOPO", name: "Operating Expense to Operating Income", unit: "%", formula: "Total Operating Expenses / Total Operating Income × 100",
    requiredAccounts: ["operating_expense", "operating_income"], externalInputs: [],
    compute: (a) => div(a.operating_expense, a.operating_income, 100) },
  LDR:  { key: "LDR", name: "Loan to Deposit Ratio", unit: "%", formula: "Total Loans / Third-Party Funds × 100",
    requiredAccounts: ["total_loans", "third_party_funds"], externalInputs: [],
    compute: (a) => div(a.total_loans, a.third_party_funds, 100) },
  EQA:  { key: "EQA", name: "Equity to Assets (capital proxy)", unit: "%", formula: "Total Equity / Total Assets × 100",
    requiredAccounts: ["total_equity", "total_assets"], externalInputs: [],
    compute: (a) => div(a.total_equity, a.total_assets, 100) },
  LTA:  { key: "LTA", name: "Loans to Assets", unit: "%", formula: "Total Loans / Total Assets × 100",
    requiredAccounts: ["total_loans", "total_assets"], externalInputs: [],
    compute: (a) => div(a.total_loans, a.total_assets, 100) },
  // PER needs market price, which is not in either allowed statement. Price must come from a
  // separate, labelled market-data input — never extracted from the report.
  PER:  { key: "PER", name: "Price to Earnings Ratio", unit: "x", formula: "Share Price / Basic Earnings per Share",
    requiredAccounts: ["basic_eps"], externalInputs: ["share_price"],
    compute: (a, ext) => div(ext.share_price, a.basic_eps) },
};

/** Union of accounts actually needed by the 9 fuzzy inputs. */
export const REQUIRED_ACCOUNTS: CanonicalAccountId[] = [
  ...new Set(Object.values(RATIO_DEFINITIONS).flatMap((r) => r.requiredAccounts)),
];

export const ratiosAffectedBy = (acc: CanonicalAccountId): RatioKey[] =>
  Object.values(RATIO_DEFINITIONS).filter((r) => r.requiredAccounts.includes(acc)).map((r) => r.key);

/* ─── Periods ────────────────────────────────────── */
export const MONTH_PERIODS = ["M01", "M02", "M03", "M04", "M05", "M06", "M07", "M08", "M09", "M10", "M11", "M12"] as const;
export type MonthPeriod = (typeof MONTH_PERIODS)[number];
export type ReportingPeriod = "Q1" | "Q2" | "Q3" | "FY" | MonthPeriod;
export interface FinancialPeriod {
  fiscalYear: number;
  period: ReportingPeriod;
}
export const isMonthly = (p: ReportingPeriod): p is MonthPeriod => p.startsWith("M");
export const monthOf = (p: ReportingPeriod) => (isMonthly(p) ? Number(p.slice(1)) : 0);
export const periodLabel = (p: FinancialPeriod) => `${p.period}${p.fiscalYear}`;
/** Comparison key: "2024" for FY, "2026-01" for a monthly (year-to-date) report. */
export const periodKey = (p: FinancialPeriod) => (isMonthly(p.period) ? `${p.fiscalYear}-${p.period.slice(1)}` : String(p.fiscalYear));
const MONTH_NAMES = ["Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nov", "Des"];
export const periodText = (p: FinancialPeriod) => (isMonthly(p.period) ? `${MONTH_NAMES[monthOf(p.period) - 1]} ${p.fiscalYear}` : `${p.period} ${p.fiscalYear}`);
export const monthName = (m: number) => MONTH_NAMES[m - 1];

/* ─── Units ──────────────────────────────────────── */
export type Currency = "IDR" | "USD";
export type UnitScale = "unit" | "thousands" | "millions" | "billions";
export const UNIT_MULTIPLIER: Record<UnitScale, number> = {
  unit: 1, thousands: 1e3, millions: 1e6, billions: 1e9,
};

/* ─── Lifecycle statuses ─────────────────────────── */
export type DocumentStatus =
  | "uploaded"
  | "queued"
  | "processing"
  | "extraction_ready"
  | "needs_verification"
  | "verified"
  | "failed";

export type VerificationStatus =
  | "verified"
  | "needs_review"
  | "not_found"
  | "rejected"
  | "invalid_source";

export type AnalysisStatus = "not_started" | "calculated" | "outdated";

/* ─── Documents & extraction ─────────────────────── */
export interface FinancialDocument {
  id: string;
  ticker: string;
  companyName: string;
  period: FinancialPeriod;
  fileName: string;
  fileType: "pdf" | "png" | "jpg";
  fileSize: number;
  currency: Currency;
  unit: UnitScale;
  uploadedAt: string;
  status: DocumentStatus;
  version: number;
}

export interface StatementPage {
  documentId: string;
  pageNumber: number;
  statementType: StatementType;
  /** Only present if the detection engine returns one. Confidence ≠ verified. */
  confidence?: number;
}

export interface BoundingBox { x: number; y: number; width: number; height: number }

/** Immutable record of what the extraction assistant returned. */
export interface ExtractedFinancialItem {
  id: string;
  documentId: string;
  canonicalAccount: CanonicalAccountId | null;
  rawLabel: string;
  rawValue: string;
  currency: Currency;
  unit: UnitScale;
  pageNumber: number;
  statementType: StatementType;
  /** Column year the value was read from, to avoid mixing comparative periods. */
  columnYear?: number;
  confidence?: number;
  boundingBox?: BoundingBox;
}

/** Human decision on a required account. Keeps a reference to the original extraction. */
export interface VerifiedFinancialItem {
  documentId: string;
  canonicalAccount: CanonicalAccountId;
  sourceItemId: string | null;
  status: VerificationStatus;
  /** Parsed from rawValue, in the report's own unit. */
  parsedValue: number | null;
  unitMultiplier: number;
  /** parsedValue × unitMultiplier */
  normalizedValue: number | null;
  edited: boolean;
  verifiedAt?: string;
  verifiedBy?: string;
  note?: string;
}

/** An item may enter the verified dataset only from an allowed statement. */
export const canBeVerified = (item: Pick<ExtractedFinancialItem, "statementType">) =>
  isAllowedStatement(item.statementType);

export interface AnalysisContext {
  documentId: string;
  ticker: string;
  period: FinancialPeriod;
  verification: "complete" | "incomplete";
  modelVersion: string;
  status: AnalysisStatus;
  calculatedAt?: string;
}

/* ─── Value normalization ────────────────────────── */
/**
 * Parses a printed statement number. Handles "1,234,567", "1.234.567", "(1,234)", "-1.234",
 * "1.234,56", and dashes ("-", "—") as nil. Returns null when the text isn't a number.
 */
export function parseStatementNumber(raw: string): number | null {
  let s = raw.trim().replace(/\s|Rp|IDR|USD|\$/gi, "");
  if (/^[-–—]$/.test(s) || s === "") return null;
  let neg = false;
  if (/^\(.*\)$/.test(s)) { neg = true; s = s.slice(1, -1); }
  if (/^[-–]/.test(s)) { neg = true; s = s.slice(1); }
  const lastDot = s.lastIndexOf("."), lastComma = s.lastIndexOf(",");
  if (lastDot >= 0 && lastComma >= 0) {
    // the later separator is the decimal one
    const dec = lastDot > lastComma ? "." : ",";
    const thou = dec === "." ? "," : ".";
    s = s.split(thou).join("").replace(dec, ".");
  } else {
    const sep = lastDot >= 0 ? "." : lastComma >= 0 ? "," : null;
    if (sep) {
      const parts = s.split(sep);
      // repeated separator or 3-digit groups → thousands separator; otherwise decimal
      const isThousands = parts.length > 2 || parts[parts.length - 1].length === 3;
      s = isThousands ? parts.join("") : parts.join(".");
    }
  }
  if (!/^\d+(\.\d+)?$/.test(s)) return null;
  const n = Number(s);
  return neg ? -n : n;
}

export const UNIT_TEXT_PATTERNS: [RegExp, UnitScale][] = [
  [/(in )?billions?|miliar/i, "billions"],
  [/(in )?millions?|jutaan|juta/i, "millions"],
  [/(in )?thousands?|ribuan|ribu/i, "thousands"],
];
export const detectUnit = (text: string): UnitScale =>
  UNIT_TEXT_PATTERNS.find(([re]) => re.test(text))?.[1] ?? "unit";

/* ─── Kloter 0 additions ─────────────────────────── */
/** Statements that must never supply values; detection here → `invalid_source`. */
export const FORBIDDEN_SOURCES = ["cash_flows", "changes_in_equity", "notes", "other"] as const satisfies readonly StatementType[];
export const NOT_FOUND_LABEL = NOT_FOUND_MESSAGE;

/** Engine version stamped on every AnalysisContext (9 inputs, 24 rules, centroid — src/FuzzyMamdani.tsx). */
export const MODEL_VERSION = "mamdani-bank-v1.0";

export type InputOrigin = "financial_statement" | "external_market_input";

export interface RatioTrace {
  formula: string;
  requiredAccounts: CanonicalAccountId[];
  statementsByAccount: Partial<Record<CanonicalAccountId, AllowedStatementType>>;
  externalInputs: { id: ExternalInputId; origin: InputOrigin }[];
}

/** Ratio → accounts → statement traceability, derived from RATIO_DEFINITIONS so they cannot drift. */
export const RATIO_ACCOUNT_MAP = Object.fromEntries(
  Object.values(RATIO_DEFINITIONS).map((r): [RatioKey, RatioTrace] => [
    r.key,
    {
      formula: r.formula,
      requiredAccounts: r.requiredAccounts,
      statementsByAccount: Object.fromEntries(
        r.requiredAccounts.map((a) => [a, CANONICAL_ACCOUNTS[a].statement]),
      ),
      externalInputs: r.externalInputs.map((id) => ({ id, origin: "external_market_input" })),
    },
  ]),
) as Record<RatioKey, RatioTrace>;


/* ─── Accounting consistency checks (warnings only, never block verification) ─── */
export function consistencyIssues(v: Partial<Record<CanonicalAccountId, number | null>>): string[] {
  const g = (k: CanonicalAccountId) => v[k] ?? null;
  const out: string[] = [];
  const [ta, te, loans, dpk, oi, oe, nii] = [g("total_assets"), g("total_equity"), g("total_loans"), g("third_party_funds"), g("operating_income"), g("operating_expense"), g("net_interest_income")];
  if (ta != null && te != null && te > ta) out.push("Ekuitas lebih besar dari total aset.");
  if (ta != null && loans != null && loans > ta) out.push("Kredit yang diberikan lebih besar dari total aset.");
  if (ta != null && dpk != null && dpk > ta) out.push("Dana pihak ketiga lebih besar dari total aset.");
  if (oi != null && nii != null && nii > oi * 1.05) out.push("Pendapatan bunga bersih lebih besar dari jumlah pendapatan operasional.");
  if (oi != null && oe != null && oe > oi * 1.5) out.push("Beban operasional jauh melebihi pendapatan operasional (BOPO > 150%). Cek apakah angka yang diambil sudah benar.");
  return out;
}
