// Super Stocks Intelligence — deterministic Fuzzy Mamdani engine for Indonesian banking issuers.
// Implication (min), aggregation (max) and centroid defuzzification; membership functions are triangular.
import type { RatioKey } from "./financial";
import { palette } from "../theme";

export const C = palette;

/* ─── Fuzzy math ──────────────────────────────────── */
export type Tri = [number, number, number];
export const tri = (x: number, [a, b, c]: Tri): number => {
  if (x <= a || x >= c) return 0;
  if (x === b) return 1;
  return x < b ? (x - a) / (b - a) : (c - x) / (c - b);
};

export type FuzzySet = { name: string; color: string; pts: Tri };
export type VarDef = { domain: [number, number]; unit: string; category: string; label: string; sets: FuzzySet[] };

export const VAR_KEYS = ["ROE","ROA","NIM","NPM","BOPO","LDR","EQA","LTA","PER"] as const;
export type VarKey = (typeof VAR_KEYS)[number];

export const VAR_DEFS: Record<VarKey, VarDef> = {
  ROE:  { domain:[0,30],   unit:"%", category:"Profitabilitas", label:"Return on Equity",
    sets:[{name:"Rendah",color:C.red,pts:[0,0,8]},{name:"Sedang",color:C.yellow,pts:[6,12,18]},{name:"Tinggi",color:C.teal,pts:[14,30,30]}] },
  ROA:  { domain:[0,4],    unit:"%", category:"Profitabilitas", label:"Return on Assets",
    sets:[{name:"Rendah",color:C.red,pts:[0,0,1.2]},{name:"Sedang",color:C.yellow,pts:[0.9,1.8,2.7]},{name:"Tinggi",color:C.teal,pts:[2.2,4,4]}] },
  NIM:  { domain:[0,8],    unit:"%", category:"Profitabilitas", label:"Net Interest Margin (proxy)",
    sets:[{name:"Rendah",color:C.red,pts:[0,0,3]},{name:"Sedang",color:C.yellow,pts:[2.5,4,5.5]},{name:"Tinggi",color:C.teal,pts:[4.5,8,8]}] },
  NPM:  { domain:[0,60],   unit:"%", category:"Profitabilitas", label:"Net Profit Margin",
    sets:[{name:"Rendah",color:C.red,pts:[0,0,15]},{name:"Sedang",color:C.yellow,pts:[10,25,40]},{name:"Tinggi",color:C.teal,pts:[30,60,60]}] },
  BOPO: { domain:[40,110], unit:"%", category:"Efisiensi",      label:"Operating Expense to Operating Income",
    sets:[{name:"Efisien",color:C.teal,pts:[40,40,75]},{name:"Sedang",color:C.yellow,pts:[70,82,92]},{name:"Boros",color:C.red,pts:[88,110,110]}] },
  LDR:  { domain:[50,130], unit:"%", category:"Likuiditas",     label:"Loan to Deposit Ratio",
    sets:[{name:"Rendah",color:C.yellow,pts:[50,50,78]},{name:"Ideal",color:C.teal,pts:[75,87,96]},{name:"Tinggi",color:C.red,pts:[92,130,130]}] },
  EQA:  { domain:[0,25],   unit:"%", category:"Permodalan",     label:"Equity to Assets (capital proxy)",
    sets:[{name:"Rendah",color:C.red,pts:[0,0,8]},{name:"Sedang",color:C.yellow,pts:[6,11,16]},{name:"Tinggi",color:C.teal,pts:[13,25,25]}] },
  LTA:  { domain:[0,100],  unit:"%", category:"Intermediasi",   label:"Loans to Assets",
    sets:[{name:"Rendah",color:C.yellow,pts:[0,0,40]},{name:"Sedang",color:C.teal,pts:[35,55,70]},{name:"Tinggi",color:C.red,pts:[65,100,100]}] },
  PER:  { domain:[0,40],   unit:"x", category:"Valuasi",        label:"Price to Earnings Ratio",
    sets:[{name:"Murah",color:C.teal,pts:[0,0,10]},{name:"Wajar",color:C.yellow,pts:[8,15,24]},{name:"Mahal",color:C.red,pts:[20,40,40]}] },
};

// antecedent: index per VAR_KEYS order, -1 = don't care
const A = (o: Partial<Record<VarKey, number>>) => VAR_KEYS.map((k) => o[k] ?? -1);

export const RULES: { ante: number[]; out: number; text: string }[] = [
  // ─── Layak ───────────────────────────────────────────────────────────
  { ante:A({ROE:2,BOPO:0}), out:2, text:"ROE Tinggi ∧ BOPO Efisien → Layak" },
  { ante:A({ROE:2,PER:0}), out:2, text:"ROE Tinggi ∧ PER Murah → Layak" },
  { ante:A({ROA:2,NIM:2}), out:2, text:"ROA Tinggi ∧ NIM Tinggi → Layak" },
  { ante:A({NPM:2,BOPO:0,PER:1}), out:2, text:"NPM Tinggi ∧ BOPO Efisien ∧ PER Wajar → Layak" },
  { ante:A({BOPO:0,LDR:1,EQA:2}), out:2, text:"BOPO Efisien ∧ LDR Ideal ∧ EQA Tinggi → Layak" },
  { ante:A({ROE:2,ROA:2,NPM:2}), out:2, text:"ROE Tinggi ∧ ROA Tinggi ∧ NPM Tinggi → Layak" },
  { ante:A({ROA:2,LDR:1,EQA:1}), out:2, text:"ROA Tinggi ∧ LDR Ideal ∧ EQA Sedang → Layak" },
  { ante:A({ROE:2,NIM:2,EQA:2}), out:2, text:"ROE Tinggi ∧ NIM Tinggi ∧ EQA Tinggi → Layak" },
  // ─── Dipertimbangkan ─────────────────────────────────────────────────
  { ante:A({ROE:1,BOPO:1}), out:1, text:"ROE Sedang ∧ BOPO Sedang → Dipertimbangkan" },
  { ante:A({ROA:1,LDR:1}), out:1, text:"ROA Sedang ∧ LDR Ideal → Dipertimbangkan" },
  { ante:A({NPM:1,PER:1}), out:1, text:"NPM Sedang ∧ PER Wajar → Dipertimbangkan" },
  { ante:A({NIM:1,EQA:1}), out:1, text:"NIM Sedang ∧ EQA Sedang → Dipertimbangkan" },
  { ante:A({ROE:2,BOPO:2}), out:1, text:"ROE Tinggi ∧ BOPO Boros → Dipertimbangkan" },
  { ante:A({ROA:0,EQA:2}), out:1, text:"ROA Rendah ∧ EQA Tinggi → Dipertimbangkan" },
  { ante:A({LDR:2,EQA:1}), out:1, text:"LDR Tinggi ∧ EQA Sedang → Dipertimbangkan" },
  { ante:A({LTA:1,PER:1}), out:1, text:"LTA Sedang ∧ PER Wajar → Dipertimbangkan" },
  // ─── Tidak Layak ──────────────────────────────────────────────────────
  { ante:A({ROE:0}), out:0, text:"ROE Rendah → Tidak Layak" },
  { ante:A({NPM:0,BOPO:2}), out:0, text:"NPM Rendah ∧ BOPO Boros → Tidak Layak" },
  { ante:A({LDR:2,EQA:0}), out:0, text:"LDR Tinggi ∧ EQA Rendah → Tidak Layak" },
  { ante:A({BOPO:2,PER:2}), out:0, text:"BOPO Boros ∧ PER Mahal → Tidak Layak" },
  { ante:A({NPM:0,EQA:0}), out:0, text:"NPM Rendah ∧ EQA Rendah → Tidak Layak" },
  { ante:A({ROA:0,NIM:0}), out:0, text:"ROA Rendah ∧ NIM Rendah → Tidak Layak" },
  { ante:A({LDR:0,NIM:0}), out:0, text:"LDR Rendah ∧ NIM Rendah → Tidak Layak" },
];

export const OUT: FuzzySet[] = [
  { name:"Tidak Layak",    color:C.red,    pts:[0,0,35]   },
  { name:"Dipertimbangkan",color:C.yellow, pts:[25,50,75]  },
  { name:"Layak",          color:C.teal,   pts:[65,100,100]},
];

export function computeFuzzy(vals: Record<VarKey, number>) {
  const mu: Record<VarKey, number[]> = {} as any;
  for (const k of VAR_KEYS) {
    mu[k] = VAR_DEFS[k].sets.map((s) => tri(vals[k], s.pts));
  }
  const strengths = RULES.map((rule) => {
    const factors = VAR_KEYS.map((k, idx) => {
      const s = rule.ante[idx];
      return s < 0 ? 1 : mu[k][s];
    });
    return Math.min(...factors);
  });
  let num = 0, den = 0;
  const agg: number[] = [];
  for (let x = 0; x <= 100; x++) {
    let m = 0;
    RULES.forEach((rule, i) => {
      const clipped = Math.min(strengths[i], tri(x, OUT[rule.out].pts));
      if (clipped > m) m = clipped;
    });
    agg.push(m);
    num += x * m;
    den += m;
  }
  const classStrength = [0, 1, 2].map((o) =>
    Math.max(0, ...RULES.map((r, i) => (r.out === o ? strengths[i] : 0)))
  );
  return { strengths, agg, classStrength, score: den === 0 ? 0 : num / den };
}


/** Category zones on the output universe (chosen thresholds; the output sets actually cross at ~29.2 and ~70.8). */
export const ZONES = [
  { name: "Tidak Layak", from: 0, to: 35, color: C.red },
  { name: "Dipertimbangkan", from: 35, to: 65, color: C.yellow },
  { name: "Layak", from: 65, to: 100, color: C.teal },
];
export type ModelCategory = "Tidak Layak" | "Dipertimbangkan" | "Layak";
export const categoryOf = (score: number): ModelCategory =>
  score < 35 ? "Tidak Layak" : score < 65 ? "Dipertimbangkan" : "Layak";
export const CATEGORY_COLOR: Record<ModelCategory, string> = { "Tidak Layak": C.red, Dipertimbangkan: C.yellow, Layak: C.teal };

export const ruleId = (i: number) => `R${String(i + 1).padStart(2, "0")}`;
export const RULE_COUNT = RULES.length;

/** Dominant fuzzy set label for a ratio value. */
export function dominantSet(k: VarKey, v: number) {
  const mu = VAR_DEFS[k].sets.map((s) => tri(v, s.pts));
  const i = mu.indexOf(Math.max(...mu));
  return { name: mu[i] > 0 ? VAR_DEFS[k].sets[i].name : "—", mu: mu[i], all: mu };
}

// compile-time check that engine keys match the data contract
const _keys: readonly RatioKey[] = VAR_KEYS; void _keys;
