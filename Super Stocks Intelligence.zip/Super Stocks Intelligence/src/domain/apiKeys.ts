// Optional API keys for free market-context providers. Read from VITE_* env vars, overridable per device in Akun Saya.
// Keys live in the browser bundle / localStorage — acceptable for free-tier keys, never use paid keys here.
import { useSyncExternalStore } from "react";
import { canManageCollection, getRole } from "./news";

export type Provider = "fmp" | "twelvedata" | "finnhub" | "anthropic";

export const PROVIDERS: { id: Provider; name: string; what: string; quota: string; signup: string }[] = [
  { id: "fmp", name: "Financial Modeling Prep", what: "Harga & histori saham IDX (.JK), IHSG", quota: "250 req/hari", signup: "https://site.financialmodelingprep.com/developer/docs" },
  { id: "twelvedata", name: "Twelve Data", what: "Cadangan harga saham IDX", quota: "800 req/hari", signup: "https://twelvedata.com/register" },
  { id: "finnhub", name: "Finnhub", what: "Berita pasar & sektor", quota: "60 req/menit", signup: "https://finnhub.io/register" },
];

/** The paid AI key (DeepSeek) is a server-side secret: it is never listed, shown or editable in the browser. */
export const AI_SERVER_PROVIDER = { name: "DeepSeek", what: "Ekstraksi angka dari TXT laporan (hanya teks)", where: "Disimpan sebagai secret di backend" };

const ENV: Record<Provider, string | undefined> = {
  fmp: import.meta.env.VITE_FMP_KEY,
  twelvedata: import.meta.env.VITE_TWELVEDATA_KEY,
  finnhub: import.meta.env.VITE_FINNHUB_KEY,
  anthropic: import.meta.env.VITE_ANTHROPIC_KEY,
};

const LS = "ssi.apikeys";
const listeners = new Set<() => void>();
let snap = 0;

function stored(): Partial<Record<Provider, string>> {
  try { return JSON.parse(localStorage.getItem(LS) ?? "{}"); } catch { return {}; }
}

export const getKey = (p: Provider) => (stored()[p] || ENV[p] || "").trim();
export const keySource = (p: Provider): "device" | "env" | null => (stored()[p] ? "device" : ENV[p] ? "env" : null);

export function setKey(p: Provider, v: string) {
  if (!canManageCollection(getRole())) throw new Error("Hanya admin yang dapat mengubah API key.");
  const s = stored();
  if (v.trim()) s[p] = v.trim(); else delete s[p];
  localStorage.setItem(LS, JSON.stringify(s));
  snap++; listeners.forEach((l) => l());
}

/** Re-renders when any key changes; returns a version number to use as a fetch dependency. */
export const useKeysVersion = () => useSyncExternalStore((cb) => { listeners.add(cb); return () => listeners.delete(cb); }, () => snap);
