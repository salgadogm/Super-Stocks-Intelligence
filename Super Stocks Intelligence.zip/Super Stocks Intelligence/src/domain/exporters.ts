// Client-side file export helpers. Numbers are written raw (dot decimal) so Excel/pandas read them.
import type { AnalysisRecord } from "./store";
import { VAR_KEYS } from "./engine";
import { track } from "./usage";

export interface CsvColumn<T> { header: string; value: (row: T) => string | number | null | undefined }

const esc = (v: string | number | null | undefined) => {
  if (v == null) return "";
  const s = typeof v === "number" ? (Number.isFinite(v) ? String(v) : "") : v;
  return /[",\r\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
};

export function toCsv<T>(rows: T[], columns: CsvColumn<T>[]): string {
  const head = columns.map((c) => esc(c.header)).join(",");
  const body = rows.map((r) => columns.map((c) => esc(c.value(r))).join(","));
  return [head, ...body].join("\r\n");
}

export function download(name: string, text: string, mime = "text/plain") {
  if (!name.startsWith("data-analytics-")) track("export", "Export Laporan (PDF)");
  const bom = mime.startsWith("text/csv") ? "﻿" : "";
  const url = URL.createObjectURL(new Blob([bom + text], { type: `${mime};charset=utf-8` }));
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export const downloadCsv = <T,>(name: string, rows: T[], columns: CsvColumn<T>[]) => download(name, toCsv(rows, columns), "text/csv");
export const stamp = () => new Date().toISOString().slice(0, 10);

const analysisColumns: CsvColumn<AnalysisRecord>[] = [
  { header: "ticker", value: (a) => a.ticker },
  { header: "company", value: (a) => a.companyName },
  { header: "fiscal_year", value: (a) => a.period.fiscalYear },
  { header: "period", value: (a) => a.period.period },
  ...VAR_KEYS.map((k) => ({ header: k, value: (a: AnalysisRecord) => a.ratios[k] })),
  { header: "model_score", value: (a) => a.score },
  { header: "category", value: (a) => a.category },
  { header: "model_version", value: (a) => a.modelVersion },
  { header: "calculated_at", value: (a) => a.calculatedAt },
  { header: "source", value: (a) => (a.demo ? "demo" : "upload") },
];

export const exportAnalysesCsv = (prefix: string, rows: AnalysisRecord[]) =>
  downloadCsv(`ssi-${prefix}-${stamp()}.csv`, rows, analysisColumns);
