// L3 completeness gate (spec §3 L3, §11). Runs before extraction. Pure: takes an inventory of documents, returns the exact missing list.
export type PeriodMode = "ANNUAL" | "QUARTERLY" | "MONTHLY";
export type StatementKind = "BALANCE_SHEET" | "PROFIT_LOSS";
/** BALANCE_SHEET is point-in-time; PROFIT_LOSS is cumulative YTD, and at month 12 it equals FY. */
export interface CollectionDoc { bank: string; statement: StatementKind; year: number; month: number }
export interface Period { year: number; month: number }

export type Role = "BS_CURRENT" | "BS_PRIOR_YEAR" | "PL_CURRENT" | "PL_PRIOR_SAME_PERIOD" | "PL_PRIOR_FY";
export interface Requirement { role: Role; statement: StatementKind; year: number; month: number; reason: string }
export interface MissingDoc {
  bank: string; statement: StatementKind; year: number; month: number; role: Role;
  reason: string; collectionPath: string; message: string;
}
export type GateError = "MODE_PERIOD_INVALID" | "BANKS_EMPTY" | "BANKS_DUPLICATE" | "BANKS_MIN_TWO";
export interface GateResult {
  ok: boolean;
  frozen: boolean;
  /** Set when the request itself is malformed (cannot be fixed by uploading). */
  error: GateError | null;
  errorMessage: string | null;
  missing: MissingDoc[];
  /** True when the PL comparatives are waived by ESTIMASI mode; every result must then carry the flag ESTIMATED. */
  estimated: boolean;
  /** Per bank: roles that were waived. */
  waived: Record<string, Role[]>;
  requirementsByBank: Record<string, Requirement[]>;
}

const ROMAN = ["", "I", "II", "III", "IV"];
const MONTHS = ["", "Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"];
const STATEMENT_ID: Record<StatementKind, string> = { BALANCE_SHEET: "Neraca", PROFIT_LOSS: "Laba Rugi" };

export function periodValid(mode: PeriodMode, p: Period): boolean {
  if (!Number.isInteger(p.year) || !Number.isInteger(p.month) || p.month < 1 || p.month > 12) return false;
  if (mode === "ANNUAL") return p.month === 12;
  if (mode === "QUARTERLY") return p.month % 3 === 0;
  return true;
}

/** December in an interim mode is treated like annual (spec §11). */
export const isAnnualLike = (mode: PeriodMode, p: Period) => mode === "ANNUAL" || p.month === 12;

export function periodLabel(mode: PeriodMode, p: Period): string {
  if (mode === "ANNUAL" || (p.month === 12 && mode !== "MONTHLY")) return "Tahunan";
  if (mode === "QUARTERLY") return `Triwulan ${ROMAN[p.month / 3]}`;
  return MONTHS[p.month];
}

export const collectionPath = (bank: string, mode: PeriodMode, year: number, month: number) =>
  `Koleksi > ${bank} > ${year} > ${periodLabel(mode, { year, month })}`;

/** Required documents for one bank in one period (spec §11). */
export function requirementsFor(mode: PeriodMode, p: Period): Requirement[] {
  const { year: t, month: m } = p;
  if (isAnnualLike(mode, p)) {
    return [
      { role: "BS_CURRENT", statement: "BALANCE_SHEET", year: t, month: 12, reason: "periode analisis" },
      { role: "BS_PRIOR_YEAR", statement: "BALANCE_SHEET", year: t - 1, month: 12, reason: "pembanding rata-rata" },
      { role: "PL_CURRENT", statement: "PROFIT_LOSS", year: t, month: 12, reason: "periode analisis" },
    ];
  }
  return [
    { role: "BS_CURRENT", statement: "BALANCE_SHEET", year: t, month: m, reason: "periode analisis" },
    { role: "BS_PRIOR_YEAR", statement: "BALANCE_SHEET", year: t - 1, month: m, reason: "pembanding rata-rata" },
    { role: "PL_CURRENT", statement: "PROFIT_LOSS", year: t, month: m, reason: "periode analisis" },
    { role: "PL_PRIOR_SAME_PERIOD", statement: "PROFIT_LOSS", year: t - 1, month: m, reason: "pembanding TTM" },
    { role: "PL_PRIOR_FY", statement: "PROFIT_LOSS", year: t - 1, month: 12, reason: "pembanding TTM" },
  ];
}

const has = (docs: CollectionDoc[], bank: string, r: Requirement) =>
  docs.some((d) => d.bank === bank && d.statement === r.statement && d.year === r.year && d.month === r.month);

function describe(mode: PeriodMode, r: Requirement): string {
  const label = periodLabel(mode, { year: r.year, month: r.month });
  const doc = r.statement === "PROFIT_LOSS"
    ? (r.month === 12 ? `Laba Rugi FY ${r.year}` : `Laba Rugi YTD ${label} ${r.year}`)
    : (r.month === 12 ? `Neraca 31 Des ${r.year}` : `Neraca ${label} ${r.year}`);
  return `${doc} (${r.reason})`;
}

export interface GateInput {
  mode: PeriodMode;
  period: Period;
  banks: string[];
  collection: CollectionDoc[];
  /** ESTIMASI mode (default off): waives the prior-year P&L comparatives and flags the result ESTIMATED. */
  estimasiMode?: boolean;
  /** Comparison needs at least two banks (spec §11); set false for a single-bank view. */
  requireMinTwoBanks?: boolean;
}

export function checkGate(inp: GateInput): GateResult {
  const empty: GateResult = { ok: false, frozen: true, error: null, errorMessage: null, missing: [], estimated: false, waived: {}, requirementsByBank: {} };
  const fail = (error: GateError, errorMessage: string): GateResult => ({ ...empty, error, errorMessage });

  if (!periodValid(inp.mode, inp.period)) return fail("MODE_PERIOD_INVALID", `Periode ${inp.period.month}/${inp.period.year} tidak sesuai mode ${inp.mode}. Mode periode tidak dicampur.`);
  const banks = inp.banks.map((b) => b.trim().toUpperCase()).filter(Boolean);
  if (banks.length === 0) return fail("BANKS_EMPTY", "Pilih minimal satu bank.");
  if (new Set(banks).size !== banks.length) return fail("BANKS_DUPLICATE", "Bank yang dipilih terduplikasi.");
  if (inp.requireMinTwoBanks && banks.length < 2) return fail("BANKS_MIN_TWO", "Perbandingan memerlukan minimal dua bank dengan set periode identik.");

  const reqs = requirementsFor(inp.mode, inp.period);
  const estimated = !!inp.estimasiMode && !isAnnualLike(inp.mode, inp.period);
  const waivable: Role[] = ["PL_PRIOR_SAME_PERIOD", "PL_PRIOR_FY"];
  const missing: MissingDoc[] = [];
  const waived: Record<string, Role[]> = {};
  const requirementsByBank: Record<string, Requirement[]> = {};

  for (const bank of banks) {
    requirementsByBank[bank] = reqs;
    const gaps = reqs.filter((r) => !has(inp.collection, bank, r));
    const prl = gaps.filter((g) => waivable.includes(g.role));
    // ESTIMASI waives whichever P&L comparatives are absent (annualisation replaces TTM); balance sheets are never waived.
    const waiveAll = estimated && prl.length > 0;
    if (waiveAll) waived[bank] = prl.map((g) => g.role);
    for (const r of gaps) {
      if (waiveAll && waivable.includes(r.role)) continue;
      const path = `${collectionPath(bank, inp.mode, r.year, r.month)} > ${STATEMENT_ID[r.statement]}`;
      const what = describe(inp.mode, r);
      missing.push({
        bank, statement: r.statement, year: r.year, month: r.month, role: r.role, reason: r.reason, collectionPath: path,
        message: `${bank}: ${what} belum ada di koleksi. Tambahkan dari: ${path}.`,
      });
    }
  }
  const ok = missing.length === 0;
  return { ok, frozen: !ok, error: null, errorMessage: null, missing, estimated: estimated && Object.keys(waived).length > 0, waived, requirementsByBank };
}
