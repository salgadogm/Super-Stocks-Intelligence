// Deterministic validators run after extraction (spec §9). Values are Rp miliar, expenses as positive magnitudes.
import { DEFAULT_CONFIG, type SsiConfig } from "./config";
import { ACCOUNT_BY_CODE } from "./accounts";

export type Accounts = Record<string, number | null | undefined>;
export type UnitLabel = "juta" | "miliar" | "triliun" | "ambigu" | null;

export interface Issue {
  code: string;
  severity: "critical" | "warning";
  account: string;
  value: number | null;
  expected: number | null;
  diff: number | null;
  message: string;
}

export interface ReportMeta { ticker: string; period: string; consolidated: boolean }

export interface ValidationResult { ok: boolean; critical: Issue[]; warnings: Issue[] }

const ASSET_COMPONENTS = ["CASH_BI", "DUE_FROM_BANKS", "SECURITIES", "ACCEPTANCE_DERIV_ASSET", "LOANS_NET", "SHARIAH_FINANCING", "FIXED_ASSETS", "DEFERRED_TAX_ASSET", "OTHER_ASSETS"];
const num = (v: number | null | undefined): number | null => (typeof v === "number" && Number.isFinite(v) ? v : null);

/** Convert a raw value to Rp miliar from the header unit; null when the unit is ambiguous or unknown (V6). */
export function toMiliar(value: number, unit: UnitLabel): number | null {
  if (unit === "miliar") return value;
  if (unit === "juta") return value / 1e3;
  if (unit === "triliun") return value * 1e3;
  return null;
}

function mismatch(code: string, account: string, value: number, expected: number, tolPct: number, label: string): Issue | null {
  const diff = value - expected;
  const base = Math.max(Math.abs(expected), 1e-9);
  if (Math.abs(diff) / base * 100 <= tolPct) return null;
  return { code, severity: "critical", account, value, expected, diff, message: `${label}: ${value} != ${expected} (selisih ${diff})` };
}

function missing(code: string, account: string, label: string): Issue {
  return { code, severity: "critical", account, value: null, expected: null, diff: null, message: `${label}: akun ${account} tidak tersedia sehingga tidak dapat diverifikasi` };
}

export interface ValidateInput {
  accounts: Accounts;
  unit: UnitLabel;
  meta: ReportMeta;
  expectedMeta: ReportMeta;
}

/** Critical validators V1-V7. Absent component lines count as 0 only when the reported total is present. */
export function validateCritical(inp: ValidateInput, cfg: SsiConfig = DEFAULT_CONFIG): Issue[] {
  const a = inp.accounts;
  const tol = cfg.validators.balanceTolerancePct;
  const out: Issue[] = [];
  const push = (i: Issue | null) => { if (i) out.push(i); };
  const z = (c: string) => num(a[c]) ?? 0;

  // V6 unit
  if (inp.unit == null || inp.unit === "ambigu")
    out.push({ code: "V6", severity: "critical", account: "UNIT", value: null, expected: null, diff: null, message: "Satuan laporan ambigu atau tidak terdeteksi dari header; ditolak" });

  // V7 entity, period, consolidated
  const m = inp.meta, e = inp.expectedMeta;
  if (m.ticker !== e.ticker) out.push({ code: "V7", severity: "critical", account: "ticker", value: null, expected: null, diff: null, message: `Entitas ${m.ticker} tidak sesuai metadata ${e.ticker}` });
  if (m.period !== e.period) out.push({ code: "V7", severity: "critical", account: "period", value: null, expected: null, diff: null, message: `Periode ${m.period} tidak sesuai metadata ${e.period}` });
  if (!m.consolidated) out.push({ code: "V7", severity: "critical", account: "consolidated", value: null, expected: null, diff: null, message: "Laporan bukan konsolidasian" });

  // V5 sign rules
  for (const c of ASSET_COMPONENTS) { const v = num(a[c]); if (v != null && v < 0) out.push({ code: "V5", severity: "critical", account: c, value: v, expected: 0, diff: v, message: `Aset negatif pada ${c} (tanda angka penyeimbang atau ekstraksi salah)` }); }
  const ta = num(a.TOTAL_ASSETS_REPORTED);
  if (ta != null && ta < 0) out.push({ code: "V5", severity: "critical", account: "TOTAL_ASSETS_REPORTED", value: ta, expected: 0, diff: ta, message: "Total aset negatif" });
  for (const d of Object.values(ACCOUNT_BY_CODE)) if (d.expense) { const v = num(a[d.code]); if (v != null && v < 0) out.push({ code: "V5", severity: "critical", account: d.code, value: v, expected: 0, diff: v, message: `Beban ${d.code} harus magnitudo positif` }); }

  // V1 total assets = sum of components
  if (ta == null) out.push(missing("V1", "TOTAL_ASSETS_REPORTED", "V1"));
  else push(mismatch("V1", "TOTAL_ASSETS_REPORTED", ta, ASSET_COMPONENTS.reduce((s, c) => s + z(c), 0), tol, "V1 total aset vs jumlah komponen"));

  // V2 balance sheet identity
  const tl = num(a.TOTAL_LIABILITIES_REPORTED), te = num(a.TOTAL_EQUITY_REPORTED);
  if (ta == null || tl == null || te == null) out.push(missing("V2", ta == null ? "TOTAL_ASSETS_REPORTED" : tl == null ? "TOTAL_LIABILITIES_REPORTED" : "TOTAL_EQUITY_REPORTED", "V2"));
  else push(mismatch("V2", "TOTAL_ASSETS_REPORTED", ta, tl + te, tol, "V2 aset vs liabilitas + ekuitas"));

  // V3 net interest income
  const ii = num(a.INTEREST_INCOME), ie = num(a.INTEREST_EXPENSE), nii = num(a.NET_INTEREST_INCOME_REPORTED);
  if (ii == null || ie == null || nii == null) out.push(missing("V3", ii == null ? "INTEREST_INCOME" : ie == null ? "INTEREST_EXPENSE" : "NET_INTEREST_INCOME_REPORTED", "V3"));
  else push(mismatch("V3", "NET_INTEREST_INCOME_REPORTED", nii, ii - ie, tol, "V3 pendapatan bunga neto"));

  // V4 income statement chain
  const op = num(a.OPERATING_PROFIT_REPORTED), pt = num(a.PRE_TAX_PROFIT_REPORTED), ni = num(a.NET_INCOME_TOTAL), nip = num(a.NET_INCOME_PARENT);
  if (nii != null && op != null) push(mismatch("V4", "OPERATING_PROFIT_REPORTED", op, nii + z("OTHER_OP_INCOME") - z("OTHER_OP_EXPENSE") - z("CKPN_EXPENSE"), tol, "V4 laba operasional"));
  else out.push(missing("V4", nii == null ? "NET_INTEREST_INCOME_REPORTED" : "OPERATING_PROFIT_REPORTED", "V4 laba operasional"));
  if (op != null && pt != null) push(mismatch("V4", "PRE_TAX_PROFIT_REPORTED", pt, op + z("NON_OP"), tol, "V4 laba sebelum pajak"));
  else out.push(missing("V4", pt == null ? "PRE_TAX_PROFIT_REPORTED" : "OPERATING_PROFIT_REPORTED", "V4 laba sebelum pajak"));
  if (pt != null && ni != null) push(mismatch("V4", "NET_INCOME_TOTAL", ni, pt - z("TAX"), tol, "V4 laba bersih"));
  else out.push(missing("V4", ni == null ? "NET_INCOME_TOTAL" : "PRE_TAX_PROFIT_REPORTED", "V4 laba bersih"));
  if (ni != null && nip != null) push(mismatch("V4", "NET_INCOME_TOTAL", ni, nip + z("NET_INCOME_NCI"), tol, "V4 laba bersih = induk + non-pengendali"));
  else out.push(missing("V4", nip == null ? "NET_INCOME_PARENT" : "NET_INCOME_TOTAL", "V4 laba bersih induk"));

  return out;
}

export interface WarningInput {
  accounts: Accounts;
  /** Same statement one comparison period earlier (for W1). */
  previous?: Accounts;
  /** Comparative balances printed in this report vs closing balances of the previous report (for W2). */
  comparative?: Accounts;
  previousClosing?: Accounts;
  ratios?: { roe?: number | null; bopo?: number | null; growth?: number | null };
  ocr: boolean;
}

const BIG_ACCOUNTS = ["TOTAL_ASSETS_REPORTED", "LOANS_NET", "DEPOSITS", "TOTAL_EQUITY_REPORTED", "NET_INCOME_TOTAL", "NET_INTEREST_INCOME_REPORTED", "CKPN_EXPENSE"];

/** Warnings W1-W4: processing continues with flags. */
export function validateWarnings(inp: WarningInput, cfg: SsiConfig = DEFAULT_CONFIG): Issue[] {
  const out: Issue[] = [];
  const w = (code: string, account: string, value: number | null, expected: number | null, message: string) =>
    out.push({ code, severity: "warning", account, value, expected, diff: value != null && expected != null ? value - expected : null, message });

  if (inp.previous)
    for (const c of BIG_ACCOUNTS) {
      const cur = num(inp.accounts[c]), prev = num(inp.previous[c]);
      if (cur == null || prev == null || prev === 0) continue;
      const chg = (cur / prev - 1) * 100;
      if (Math.abs(chg) > cfg.validators.bigChangePct) w("W1", c, cur, prev, `W1 perubahan ${chg.toFixed(1)}% antar periode pada ${c}`);
    }

  if (inp.comparative && inp.previousClosing)
    for (const c of Object.keys(inp.comparative)) {
      const cmp = num(inp.comparative[c]), clo = num(inp.previousClosing[c]);
      if (cmp == null || clo == null) continue;
      if (Math.abs(cmp - clo) > Math.max(Math.abs(clo), 1e-9) * cfg.validators.balanceTolerancePct / 100)
        w("W2", c, cmp, clo, `W2 saldo pembanding ${c} berbeda dari saldo penutupan laporan sebelumnya (kemungkinan restatement), selisih ${cmp - clo}`);
    }

  const p = cfg.validators.plausible, r = inp.ratios ?? {};
  if (r.roe != null && r.roe > p.roeMax) w("W3", "ROE", r.roe, p.roeMax, `W3 ROE ${r.roe}% di luar rentang plausibel`);
  if (r.bopo != null && (r.bopo < p.bopoMin || r.bopo > p.bopoMax)) w("W3", "BOPO", r.bopo, null, `W3 BOPO ${r.bopo}% di luar [${p.bopoMin}, ${p.bopoMax}]`);
  if (r.growth != null && (r.growth < p.growthMin || r.growth > p.growthMax)) w("W3", "GROWTH", r.growth, null, `W3 pertumbuhan kredit ${r.growth}% di luar [${p.growthMin}, ${p.growthMax}]`);

  if (inp.ocr) w("W4", "OCR", null, null, "W4 ekstraksi memakai OCR; periksa angka dengan teliti");
  return out;
}

export function validateAll(c: ValidateInput, w: WarningInput, cfg: SsiConfig = DEFAULT_CONFIG): ValidationResult {
  const critical = validateCritical(c, cfg);
  return { ok: critical.length === 0, critical, warnings: validateWarnings(w, cfg) };
}
