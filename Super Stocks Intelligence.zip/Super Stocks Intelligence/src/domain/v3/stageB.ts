// Stage B: price fairness (spec §6). Percent units for ROE/re/g; prices and BVPS in Rp.
// Layer 1/2 (price independent): bvps, reBase, scenario grid, HW_H. Layer 3: valuationAtPrice.
import { DEFAULT_CONFIG, type SsiConfig } from "./config";

export const BILLION = 1e9;

/** BVPS = parent equity (Rp miliar) x 1e9 / shares outstanding net of treasury. */
export function bvps(equityParentMiliar: number | null, sharesNetTreasury: number | null): { value: number | null; reason?: string } {
  if (equityParentMiliar == null) return { value: null, reason: "ekuitas induk tidak tersedia" };
  if (sharesNetTreasury == null || !(sharesNetTreasury > 0)) return { value: null, reason: "jumlah saham beredar tidak tersedia atau <= 0" };
  return { value: (equityParentMiliar * BILLION) / sharesNetTreasury };
}

/** CAPM: re = Rf + beta x ERP (all in percent). */
export const reBase = (rf: number, beta: number, erp: number) => rf + beta * erp;

export interface Scenario {
  id: string;
  gCap: number;
  reShift: number;
  isBase: boolean;
  re: number;
  /** Null when the scenario is undefined; reason says why. */
  gRaw: number | null;
  g: number | null;
  jpbv: number | null;
  hwJ: number | null;
  dprImplicit: number | null;
  flags: string[];
  reason?: string;
}

export interface MarketParams {
  /** Percent. */
  rf: number;
  beta: number;
  erp: number;
  /** Actual payout ratio as a fraction 0..1 (declared dividend / parent net income of the last FY). */
  dpr: number;
}

export interface StageBBase {
  bvps: number;
  roeValuasi: number | null;
  market: MarketParams;
  reBase: number;
  scenarios: Scenario[];
  /** Mean of year-end PBV series, null when fewer than hist_pbv_min_points. */
  pbvHistMean: number | null;
  hwH: number | null;
  flags: string[];
}

const isBase = (cfg: SsiConfig, gCap: number, shift: number) => gCap === cfg.stageB.baseGCap && shift === cfg.stageB.baseReShift;

export function computeScenario(roe: number | null, dpr: number, re: number, gCap: number, reShift: number, bv: number, cfg: SsiConfig = DEFAULT_CONFIG): Scenario {
  const base = { id: `g${gCap}_re${reShift >= 0 ? "+" : ""}${reShift}`, gCap, reShift, isBase: isBase(cfg, gCap, reShift), re };
  const nul = (reason: string, flags: string[], gRaw: number | null = null): Scenario =>
    ({ ...base, gRaw, g: null, jpbv: null, hwJ: null, dprImplicit: null, flags, reason });
  if (roe == null || !(roe > 0)) return nul("ROE_valuasi non-positif atau tidak tersedia", ["ROE NON-POSITIF"]);
  const gRaw = roe * (1 - dpr);
  const re_s = re + reShift;
  const g = Math.max(0, Math.min(gRaw, gCap, re_s - cfg.stageB.spreadFloorPp));
  if (!(re_s - g > 0)) return nul("re - g <= 0, JPBV tidak terdefinisi", ["JPBV TIDAK TERDEFINISI"], gRaw);
  const jpbv = (roe - g) / (re_s - g);
  return { ...base, re: re_s, gRaw, g, jpbv, hwJ: jpbv * bv, dprImplicit: 1 - g / roe, flags: [] };
}

/** Layer 1/2: everything that does not depend on the live price. */
export function computeStageBBase(
  p: { bvps: number; roeValuasi: number | null; market: MarketParams; pbvHistory: number[] },
  cfg: SsiConfig = DEFAULT_CONFIG,
): StageBBase {
  const re0 = reBase(p.market.rf, p.market.beta, p.market.erp);
  const scenarios: Scenario[] = [];
  for (const gCap of cfg.stageB.gCapGrid)
    for (const sh of cfg.stageB.reShiftGrid) scenarios.push(computeScenario(p.roeValuasi, p.market.dpr, re0, gCap, sh, p.bvps, cfg));
  const hist = p.pbvHistory.filter((x) => Number.isFinite(x) && x > 0);
  const flags: string[] = [];
  let pbvHistMean: number | null = null;
  if (hist.length >= cfg.stageB.histPbvMinPoints) pbvHistMean = hist.reduce((s, v) => s + v, 0) / hist.length;
  else flags.push("SINGLE-METHOD");
  return { bvps: p.bvps, roeValuasi: p.roeValuasi, market: p.market, reBase: re0, scenarios, pbvHistMean, hwH: pbvHistMean == null ? null : pbvHistMean * p.bvps, flags };
}

export interface Range { min: number; base: number | null; max: number }

export interface ScenarioValuation {
  id: string;
  isBase: boolean;
  deltaJ: number | null;
  deltaVal: number | null;
  /** Clamped input for fuzzy; raw value stays in deltaVal. */
  deltaValFuzzy: number | null;
  /** Price at which Delta_Val of this scenario is 0. */
  p0: number | null;
}

export interface ValuationAtPrice {
  price: number;
  pbvMarket: number;
  deltaH: number | null;
  scenarios: ScenarioValuation[];
  deltaValRange: Range | null;
  hwJRange: Range | null;
  hwCombinedRange: Range | null;
  /** Break-even price of the base scenario (Delta_Val = 0). */
  p0: number | null;
  baseNull: boolean;
  flags: string[];
}

const clamp = (x: number, [lo, hi]: [number, number]) => Math.min(hi, Math.max(lo, x));

/** Break-even price: 1 / (wJ/HW_J + wH/HW_H); HW_J alone when single-method (spec B7). */
export function breakEven(hwJ: number | null, hwH: number | null, cfg: SsiConfig = DEFAULT_CONFIG): number | null {
  if (hwJ == null) return null;
  if (hwH == null) return hwJ;
  return 1 / (cfg.stageB.wJ / hwJ + cfg.stageB.wH / hwH);
}

function range(vals: { v: number; base: boolean }[]): Range | null {
  if (vals.length === 0) return null;
  const b = vals.find((x) => x.base);
  return { min: Math.min(...vals.map((x) => x.v)), base: b ? b.v : null, max: Math.max(...vals.map((x) => x.v)) };
}

/** Layer 3: valuation for a live price P. Never re-triggers Layer 1. */
export function valuationAtPrice(base: StageBBase, price: number, cfg: SsiConfig = DEFAULT_CONFIG): ValuationAtPrice {
  if (!(price > 0)) throw new Error("Harga harus > 0");
  const { wJ, wH } = cfg.stageB;
  const single = base.hwH == null;
  const deltaH = base.hwH == null ? null : (price / base.hwH - 1) * 100;
  const flags = [...base.flags];
  const sv: ScenarioValuation[] = base.scenarios.map((s) => {
    if (s.hwJ == null) return { id: s.id, isBase: s.isBase, deltaJ: null, deltaVal: null, deltaValFuzzy: null, p0: null };
    const deltaJ = (price / s.hwJ - 1) * 100;
    const dv = single ? deltaJ : wJ * deltaJ + wH * (deltaH as number);
    return { id: s.id, isBase: s.isBase, deltaJ, deltaVal: dv, deltaValFuzzy: clamp(dv, cfg.stageB.deltaValClamp), p0: breakEven(s.hwJ, base.hwH, cfg) };
  });
  const valid = base.scenarios.filter((s) => s.hwJ != null);
  const baseSc = base.scenarios.find((s) => s.isBase)!;
  const baseVal = sv.find((s) => s.isBase)!;
  if (baseVal.deltaJ != null && deltaH != null && Math.abs(baseVal.deltaJ - deltaH) > cfg.stageB.conflictPp) flags.push("METODE VALUASI BERTENTANGAN");
  if (valid.length < base.scenarios.length) flags.push("SKENARIO NULL DIKELUARKAN");
  return {
    price,
    pbvMarket: price / base.bvps,
    deltaH,
    scenarios: sv,
    deltaValRange: range(sv.filter((s) => s.deltaVal != null).map((s) => ({ v: s.deltaVal as number, base: s.isBase }))),
    hwJRange: range(valid.map((s) => ({ v: s.hwJ as number, base: s.isBase }))),
    hwCombinedRange: range(sv.filter((s) => s.p0 != null).map((s) => ({ v: s.p0 as number, base: s.isBase }))),
    p0: baseSc.hwJ == null ? null : breakEven(baseSc.hwJ, base.hwH, cfg),
    baseNull: baseSc.hwJ == null,
    flags,
  };
}
