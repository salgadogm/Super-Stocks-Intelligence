// Mamdani inference (spec §7.4) and the three-subsystem pipeline (§7.2). AND = min, implication = min, aggregation = max,
// centroid defuzzification on a fixed grid. No silent fallback: a zero area is a structured error.
import { DEFAULT_CONFIG, type SsiConfig } from "./config";
import { fuzzify, mu, mfOf } from "./membership";
import { rulesForSubsystem, type Rule } from "./rules";

export type FuzzyErrorCode = "CENTROID_ZERO_AREA" | "INPUT_INVALID";
export class FuzzyError extends Error {
  constructor(public code: FuzzyErrorCode, message: string) { super(message); this.name = "FuzzyError"; }
}

export interface InferResult {
  score: number;
  classStrength: Record<string, number>;
  activeRules: { id: string; alpha: number; consequent: string }[];
  memberships: Record<string, Record<string, number>>;
}

export interface InferOptions {
  /** Ablation (T11): force a variable to one set with degree 1 (e.g. {ROE: "Moderat"} = pROE neutral). */
  forced?: Record<string, string>;
}

/** Centroid of the aggregated output for given per-class strengths. */
export function centroid(cfg: SsiConfig, sub: "A" | "B" | "FINAL", classStrength: Record<string, number>): number {
  const out = cfg.mfOut[cfg.subsystems[sub].output];
  const step = cfg.inference.gridStep;
  const n = Math.round((out.universe[1] - out.universe[0]) / step);
  let num = 0, den = 0;
  for (let i = 0; i <= n; i++) {
    const y = out.universe[0] + i * step;
    let m = 0;
    for (const s of out.sets) m = Math.max(m, Math.min(classStrength[s.name] ?? 0, mu(s.pts, y)));
    num += y * m;
    den += m;
  }
  if (den === 0) throw new FuzzyError("CENTROID_ZERO_AREA", `Area agregasi nol pada subsistem ${sub}: tidak ada aturan aktif`);
  return num / den;
}

export function infer(cfg: SsiConfig, subId: "A" | "B" | "FINAL", inputs: Record<string, number>, opts: InferOptions = {}, rules?: Rule[]): InferResult {
  const sub = cfg.subsystems[subId];
  const rs = rules ?? rulesForSubsystem(sub);
  const memberships: Record<string, Record<string, number>> = {};
  for (const v of sub.inputs) {
    const forced = opts.forced?.[v];
    if (forced) { memberships[v] = Object.fromEntries(mfOf(cfg, v).sets.map((s) => [s.name, s.name === forced ? 1 : 0])); continue; }
    const x = inputs[v];
    if (typeof x !== "number" || !Number.isFinite(x)) throw new FuzzyError("INPUT_INVALID", `Input ${v} tidak valid pada subsistem ${subId}`);
    memberships[v] = fuzzify(cfg, v, x);
  }
  const classStrength: Record<string, number> = Object.fromEntries(sub.classes.map((c) => [c, 0]));
  const activeRules: InferResult["activeRules"] = [];
  for (const r of rs) {
    const alpha = Math.min(...sub.inputs.map((v) => memberships[v][r.antecedents[v]]));
    if (alpha > 0) {
      activeRules.push({ id: r.id, alpha, consequent: r.consequent });
      classStrength[r.consequent] = Math.max(classStrength[r.consequent], alpha);
    }
  }
  return { score: centroid(cfg, subId, classStrength), classStrength, activeRules, memberships };
}

export function labelOf(cfg: SsiConfig, score: number): string {
  const [lo, hi] = cfg.labels.cuts;
  return score < lo ? cfg.labels.names[0] : score < hi ? cfg.labels.names[1] : cfg.labels.names[2];
}

/** Display-only fairness category of Delta_Val: the set with the largest membership (ties resolve to the first set). */
export function kewajaranOf(cfg: SsiConfig, deltaValFuzzy: number): { category: string; degree: number } {
  const m = fuzzify(cfg, "DELTA_VAL", deltaValFuzzy);
  const [category, degree] = Object.entries(m).reduce((a, b) => (b[1] > a[1] ? b : a));
  return { category, degree };
}

export interface FundamentalInput { roe: number; bopo: number; coc: number; ea: number; growth: number }

/** Layer 1: performance (K) and resilience (R) scores. Price independent. */
export function computeKR(cfg: SsiConfig, f: FundamentalInput, opts: InferOptions = {}) {
  const K = infer(cfg, "A", { ROE: f.roe, BOPO: f.bopo }, opts);
  const R = infer(cfg, "B", { CoC: f.coc, EA: f.ea, GROWTH: f.growth }, opts);
  return { K, R };
}

export interface FinalResult {
  /** Null only for veto F3 (base valuation scenario undefined). */
  score: number | null;
  label: string;
  vetoF3: boolean;
  /** False when the label (set by the score threshold) differs from the class with the largest aggregated alpha. */
  consistent: boolean;
  infer: InferResult | null;
}

/** Layer 3: final system. deltaVal must already be clamped for fuzzy; K and R come from the Layer-1 cache. */
export function finalStage(cfg: SsiConfig, K: number, R: number, deltaVal: number | null, baseNull: boolean, opts: InferOptions = {}): FinalResult {
  if (baseNull) return { score: null, label: cfg.labels.names[0], vetoF3: true, consistent: true, infer: null };
  if (deltaVal == null) throw new FuzzyError("INPUT_INVALID", "Delta_Val tidak tersedia untuk skenario ini");
  const inf = infer(cfg, "FINAL", { K, R, DELTA_VAL: deltaVal }, opts);
  const label = labelOf(cfg, inf.score);
  const classes = cfg.subsystems.FINAL.classes;
  const labelClass = classes[cfg.labels.names.indexOf(label)];
  const max = Math.max(...Object.values(inf.classStrength));
  return { score: inf.score, label, vetoF3: false, consistent: inf.classStrength[labelClass] === max, infer: inf };
}

export interface FuzzyCase extends FundamentalInput { deltaVal: number }

/** Whole chain for one case (used by tests and sensitivity). */
export function evaluate(cfg: SsiConfig, c: FuzzyCase, opts: InferOptions = {}) {
  const { K, R } = computeKR(cfg, c, opts);
  const fin = finalStage(cfg, K.score, R.score, c.deltaVal, false, opts);
  return { K, R, fin, score: fin.score as number, label: fin.label };
}

export { DEFAULT_CONFIG };
