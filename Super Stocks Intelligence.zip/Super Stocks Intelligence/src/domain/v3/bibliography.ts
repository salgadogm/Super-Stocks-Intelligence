// Spec §16.4: every reference is UNVERIFIED. Kept as data only; never shown in UI or reports as evidence
// until the researcher checks title, year, journal and pages in Scopus and sets verified = true.

export interface Reference {
  key: string;
  authors: string;
  year: number | null;
  topic: string;
  doi: string | null;
  verified: false;
  note?: string;
}

const R = (key: string, authors: string, year: number | null, topic: string, note?: string): Reference =>
  ({ key, authors, year, topic, doi: null, verified: false, note });

export const BIBLIOGRAPHY: Reference[] = [
  R("ohlson1995", "Ohlson", 1995, "Residual income valuation"),
  R("penman2013", "Penman", 2013, "Buku: analisis laporan keuangan dan valuasi"),
  R("berger1997", "Berger & Humphrey", 1997, "Efisiensi lembaga keuangan"),
  R("laeven2003", "Laeven & Majnoni", 2003, "Provisi kerugian kredit bank"),
  R("beatty2014", "Beatty & Liao", 2014, "Akuntansi bank"),
  R("berger2013", "Berger & Bouwman", 2013, "Modal bank"),
  R("beltratti2012", "Beltratti & Stulz", 2012, "Modal bank"),
  R("foos2010", "Foos, Norden & Weber", 2010, "Pertumbuhan kredit"),
  R("penman1998", "Penman & Sougiannis", 1998, "Valuasi"),
  R("frankel1998", "Frankel & Lee", 1998, "Valuasi"),
  R("nissim2013", "Nissim", 2013, "PERIKSA topik: kemungkinan asuransi, bukan PBV bank", "Jangan dikutip untuk bank sebelum diperiksa"),
  R("damodaran", "Damodaran", null, "Buku/materi, bukan artikel jurnal terindeks"),
];

/** Only verified references may be rendered as evidence; today this is always empty. */
export const citableReferences = (): Reference[] => BIBLIOGRAPHY.filter((r) => (r.verified as boolean) === true);
