// Fuzzy-level sensitivity (spec T6): shift input MF bounds by +/-10% and scheme weights by +/-1 integer point,
// then report the share of cases whose label changes. Valuation-level perturbations (g_cap, re, w) belong to Step 6.
import type { SsiConfig } from "./config";
import { evaluate, type FuzzyCase } from "./inference";

export function scaleInputMfs(cfg: SsiConfig, factor: number): SsiConfig {
  const c = structuredClone(cfg);
  for (const v of Object.values(c.mf))
    for (const s of v.sets) s.pts = s.pts.map((p) => (typeof p === "number" ? p * factor : p));
  return c;
}

export function shiftWeight(cfg: SsiConfig, sub: "A" | "B" | "FINAL", variable: string, delta: number): SsiConfig | null {
  const w = cfg.subsystems[sub].vars[variable].weight + delta;
  if (w <= 0) return null;
  const c = structuredClone(cfg);
  c.subsystems[sub].vars[variable].weight = w;
  return c;
}

export interface SensitivityRow { name: string; changed: number; total: number; rate: number }
export interface SensitivityReport { rows: SensitivityRow[]; changed: number; total: number; rate: number }

export function sensitivity(cfg: SsiConfig, cases: FuzzyCase[], pct = 0.1): SensitivityReport {
  const baseLabels = cases.map((c) => evaluate(cfg, c).label);
  const variants: [string, SsiConfig][] = [
    [`MF +${pct * 100}%`, scaleInputMfs(cfg, 1 + pct)],
    [`MF -${pct * 100}%`, scaleInputMfs(cfg, 1 - pct)],
  ];
  for (const sub of ["A", "B", "FINAL"] as const)
    for (const v of cfg.subsystems[sub].inputs)
      for (const d of [1, -1]) {
        const c = shiftWeight(cfg, sub, v, d);
        if (c) variants.push([`bobot ${sub}.${v} ${d > 0 ? "+1" : "-1"}`, c]);
      }
  const rows = variants.map(([name, c]) => {
    const changed = cases.reduce((n, k, i) => n + (evaluate(c, k).label !== baseLabels[i] ? 1 : 0), 0);
    return { name, changed, total: cases.length, rate: cases.length ? changed / cases.length : 0 };
  });
  const changed = rows.reduce((s, r) => s + r.changed, 0), total = rows.reduce((s, r) => s + r.total, 0);
  return { rows, changed, total, rate: total ? changed / total : 0 };
}
