// Membership functions (spec §7.1). Triangles [a,b,c] and trapezoids [a,b,c,d]; "-inf"/"+inf" are shoulders.
import type { Bound, MfVar, SsiConfig } from "./config";

const num = (b: Bound): number => (b === "-inf" ? -Infinity : b === "+inf" ? Infinity : b);

/** Degree of membership of x in a set described by 3 or 4 points. */
export function mu(pts: Bound[], x: number): number {
  const p = pts.map(num);
  const [a, b, c, d] = p.length === 3 ? [p[0], p[1], p[1], p[2]] : p;
  const rise = a === -Infinity || x >= b ? 1 : x < a ? 0 : (x - a) / (b - a);
  const fall = d === Infinity || x <= c ? 1 : x >= d ? 0 : (d - x) / (d - c);
  return Math.min(rise, fall);
}

/** Variable name -> its membership definition. K and R are the crisp scores of Subsystems A and B. */
export function mfOf(cfg: SsiConfig, v: string): MfVar {
  if (v === "K") return cfg.mfOut.KINERJA;
  if (v === "R") return cfg.mfOut.KETAHANAN;
  const m = (cfg.mf as Record<string, MfVar>)[v];
  if (!m) throw new Error(`Variabel fuzzy tidak dikenal: ${v}`);
  return m;
}

export const clampTo = (x: number, [lo, hi]: [number, number]) => Math.min(hi, Math.max(lo, x));

/** Fuzzify a crisp value (clamped to the universe) into degrees per set. */
export function fuzzify(cfg: SsiConfig, v: string, x: number): Record<string, number> {
  const m = mfOf(cfg, v);
  const xc = clampTo(x, m.universe);
  return Object.fromEntries(m.sets.map((s) => [s.name, mu(s.pts, xc)]));
}
