// SSI v3.0 single versioned configuration (spec §14, P3). Every parameter lives here; no magic numbers in code.
// All membership-function numbers, scheme weights and class thresholds are INITIAL PARAMETERS to be calibrated (spec §7.1).
import { hashOf } from "./hash";

export const CONFIG_VERSION = "ssi-v3.0.0";

/** Membership bound; infinite shoulders are strings so the config stays JSON-serialisable and hashable. */
export type Bound = number | "-inf" | "+inf";
export interface MfSet { name: string; pts: Bound[] } // 3 pts = triangle, 4 pts = trapezoid

export interface MfVar { universe: [number, number]; sets: MfSet[] }

export type InputVar = "ROE" | "BOPO" | "CoC" | "EA" | "GROWTH" | "DELTA_VAL";
export type OutputVar = "KINERJA" | "KETAHANAN" | "AKHIR";

export interface SchemeVar { weight: number; points: Record<string, number> }
export interface VetoCond { var: string; in?: string[]; notIn?: string[] }
export interface Veto { id: string; all: VetoCond[]; then: string; text: string }
export interface Subsystem {
  id: "A" | "B" | "FINAL";
  output: OutputVar;
  inputs: string[];
  vars: Record<string, SchemeVar>;
  /** Integer cut points on S10 (weights x10); classes.length === cuts.length + 1, lower bound inclusive. */
  cuts: number[];
  classes: string[];
  vetoes: Veto[];
}

export interface SsiConfig {
  version: string;
  units: { internal: "Rp miliar" };
  stageB: {
    gCapGrid: number[];
    reShiftGrid: number[];
    baseGCap: number;
    baseReShift: number;
    spreadFloorPp: number;
    wJ: number;
    wH: number;
    roeSmoothingYears: number;
    histPbvMinPoints: number;
    conflictPp: number;
    deltaValClamp: [number, number];
  };
  mf: Record<InputVar, MfVar>;
  mfOut: Record<OutputVar, { universe: [number, number]; sets: MfSet[] }>;
  subsystems: Record<"A" | "B" | "FINAL", Subsystem>;
  labels: { cuts: [number, number]; names: [string, string, string] };
  inference: { gridStep: number };
  robustness: { robustRatio: number; nearThresholdPoints: number };
  hysteresis: { margin: number; minUpdates: number; minMinutes: number };
  price: { jumpMax: number; maxAgeSec: number | null; recomputeIntervalSec: number | null; zoneSweep: [number, number]; zoneStepPct: number };
  report: { staleDays: number };
  validators: { balanceTolerancePct: number; bigChangePct: number; plausible: { roeMax: number; bopoMin: number; bopoMax: number; growthMin: number; growthMax: number } };
  estimasiMode: boolean;
}

const sets = (...s: [string, Bound[]][]): MfSet[] => s.map(([name, pts]) => ({ name, pts }));

export const DEFAULT_CONFIG: SsiConfig = {
  version: CONFIG_VERSION,
  units: { internal: "Rp miliar" },
  stageB: {
    gCapGrid: [5.0, 6.0, 7.0],
    reShiftGrid: [-1.0, 0.0, 1.0],
    baseGCap: 6.0,
    baseReShift: 0.0,
    spreadFloorPp: 3.0,
    wJ: 0.5,
    wH: 0.5,
    roeSmoothingYears: 3,
    histPbvMinPoints: 3,
    conflictPp: 50,
    deltaValClamp: [-60, 100],
  },
  mf: {
    ROE: { universe: [-10, 40], sets: sets(["Rendah", ["-inf", "-inf", 10, 13]], ["Moderat", [11, 15, 18]], ["Tinggi", [16, 20, "+inf", "+inf"]]) },
    BOPO: { universe: [30, 120], sets: sets(["Efisien", ["-inf", "-inf", 60, 70]], ["Moderat", [65, 75, 82]], ["Inefisien", [78, 85, "+inf", "+inf"]]) },
    CoC: { universe: [0, 8], sets: sets(["Aman", ["-inf", "-inf", 1.2, 2.0]], ["Waspada", [1.5, 2.5, 3.5]], ["Bahaya", [3.0, 4.0, "+inf", "+inf"]]) },
    EA: { universe: [0, 30], sets: sets(["Tipis", ["-inf", "-inf", 8, 10]], ["Cukup", [9, 12, 15]], ["Tebal", [13, 16, "+inf", "+inf"]]) },
    GROWTH: { universe: [-20, 40], sets: sets(["Stagnan", ["-inf", "-inf", 2, 5]], ["Sehat", [3, 6, 12, 16]], ["Agresif", [13, 18, "+inf", "+inf"]]) },
    DELTA_VAL: { universe: [-60, 100], sets: sets(["Undervalued", ["-inf", "-inf", -25, -10]], ["Fair", [-20, 0, 20]], ["Overvalued", [10, 25, "+inf", "+inf"]]) },
  },
  mfOut: {
    KINERJA: { universe: [0, 100], sets: sets(["Rendah", [0, 0, 25, 50]], ["Sedang", [25, 50, 75]], ["Tinggi", [50, 75, 100, 100]]) },
    KETAHANAN: { universe: [0, 100], sets: sets(["Rapuh", [0, 0, 25, 50]], ["Sedang", [25, 50, 75]], ["Kuat", [50, 75, 100, 100]]) },
    AKHIR: { universe: [0, 100], sets: sets(["Tidak Layak", [0, 0, 25, 45]], ["Layak", [35, 55, 75]], ["Sangat Layak", [65, 85, 100, 100]]) },
  },
  subsystems: {
    A: {
      id: "A", output: "KINERJA", inputs: ["ROE", "BOPO"],
      vars: {
        ROE: { weight: 6, points: { Rendah: 0, Moderat: 1, Tinggi: 2 } },
        BOPO: { weight: 4, points: { Inefisien: 0, Moderat: 1, Efisien: 2 } },
      },
      cuts: [7, 14], classes: ["Rendah", "Sedang", "Tinggi"], vetoes: [],
    },
    B: {
      id: "B", output: "KETAHANAN", inputs: ["CoC", "EA", "GROWTH"],
      vars: {
        CoC: { weight: 5, points: { Bahaya: 0, Waspada: 1, Aman: 2 } },
        EA: { weight: 3, points: { Tipis: 0, Cukup: 1, Tebal: 2 } },
        GROWTH: { weight: 2, points: { Agresif: 0, Stagnan: 1, Sehat: 2 } },
      },
      cuts: [8, 16], classes: ["Rapuh", "Sedang", "Kuat"],
      vetoes: [{ id: "B1", all: [{ var: "CoC", in: ["Bahaya"] }], then: "Rapuh", text: "CoC Bahaya memaksa Ketahanan Rapuh" }],
    },
    FINAL: {
      id: "FINAL", output: "AKHIR", inputs: ["K", "R", "DELTA_VAL"],
      vars: {
        K: { weight: 3, points: { Rendah: 0, Sedang: 1, Tinggi: 2 } },
        R: { weight: 3, points: { Rapuh: 0, Sedang: 1, Kuat: 2 } },
        DELTA_VAL: { weight: 4, points: { Overvalued: 0, Fair: 1, Undervalued: 2 } },
      },
      cuts: [9, 17], classes: ["Tidak Layak", "Layak", "Sangat Layak"],
      vetoes: [
        { id: "F1", all: [{ var: "R", in: ["Rapuh"] }, { var: "K", notIn: ["Tinggi"] }], then: "Tidak Layak", text: "Rapuh dan Kinerja bukan Tinggi" },
        { id: "F2", all: [{ var: "K", in: ["Rendah"] }, { var: "R", notIn: ["Kuat"] }], then: "Tidak Layak", text: "Value trap: Kinerja Rendah dan Ketahanan bukan Kuat" },
      ],
    },
  },
  labels: { cuts: [45, 70], names: ["TIDAK LAYAK", "LAYAK", "SANGAT LAYAK"] },
  inference: { gridStep: 0.1 },
  robustness: { robustRatio: 0.75, nearThresholdPoints: 5 },
  hysteresis: { margin: 2.0, minUpdates: 3, minMinutes: 5 },
  // maxAgeSec and recomputeIntervalSec are "(tentukan)" in spec §14: left null on purpose, see unresolvedParams().
  price: { jumpMax: 0.2, maxAgeSec: null, recomputeIntervalSec: null, zoneSweep: [0.5, 2.0], zoneStepPct: 0.5 },
  report: { staleDays: 120 },
  validators: {
    balanceTolerancePct: 0.1,
    bigChangePct: 40,
    plausible: { roeMax: 40, bopoMin: 30, bopoMax: 120, growthMin: -20, growthMax: 40 },
  },
  estimasiMode: false,
};

/** Parameters the spec leaves open; price-dependent services must refuse to run while any is null (P4). */
export function unresolvedParams(c: SsiConfig = DEFAULT_CONFIG): string[] {
  const out: string[] = [];
  if (c.price.maxAgeSec == null) out.push("price.maxAgeSec (price_max_age): tentukan menurut sumber harga");
  if (c.price.recomputeIntervalSec == null) out.push("price.recomputeIntervalSec (recompute_interval_sec): belum ditentukan");
  return out;
}

const finite = (b: Bound) => typeof b === "number";
function checkMf(label: string, pts: Bound[], universe: [number, number], errs: string[]) {
  if (pts.length !== 3 && pts.length !== 4) { errs.push(`${label}: titik MF harus 3 atau 4`); return; }
  const val = pts.map((p) => (p === "-inf" ? -Infinity : p === "+inf" ? Infinity : p));
  for (let i = 1; i < val.length; i++) if (val[i] < val[i - 1]) errs.push(`${label}: titik MF tidak menaik`);
  pts.forEach((p) => { if (finite(p) && ((p as number) < universe[0] - 1e-9 || (p as number) > universe[1] + 1e-9)) errs.push(`${label}: titik ${p} di luar semesta`); });
}

/** Structural validation of the config; returns human-readable errors (empty = valid). */
export function validateConfig(c: SsiConfig = DEFAULT_CONFIG): string[] {
  const e: string[] = [];
  const b = c.stageB;
  if (Math.abs(b.wJ + b.wH - 1) > 1e-9) e.push("stageB: wJ + wH harus 1");
  if (b.gCapGrid.length !== 3 || b.reShiftGrid.length !== 3) e.push("stageB: grid skenario harus 3 x 3 (9 skenario)");
  if (!b.gCapGrid.includes(b.baseGCap)) e.push("stageB: baseGCap harus ada di gCapGrid");
  if (!b.reShiftGrid.includes(b.baseReShift)) e.push("stageB: baseReShift harus ada di reShiftGrid");
  if (b.deltaValClamp[0] >= b.deltaValClamp[1]) e.push("stageB: deltaValClamp tidak valid");
  if (c.labels.cuts[0] >= c.labels.cuts[1]) e.push("labels: ambang harus menaik");
  if (c.inference.gridStep <= 0) e.push("inference: gridStep harus > 0");
  for (const [k, v] of Object.entries(c.mf)) v.sets.forEach((s) => checkMf(`mf.${k}.${s.name}`, s.pts, v.universe, e));
  for (const [k, v] of Object.entries(c.mfOut)) v.sets.forEach((s) => checkMf(`mfOut.${k}.${s.name}`, s.pts, v.universe, e));
  if (c.mf.DELTA_VAL.universe[0] !== b.deltaValClamp[0] || c.mf.DELTA_VAL.universe[1] !== b.deltaValClamp[1]) e.push("mf.DELTA_VAL: semesta harus sama dengan deltaValClamp");
  for (const s of Object.values(c.subsystems)) {
    if (s.classes.length !== s.cuts.length + 1) e.push(`subsistem ${s.id}: jumlah kelas harus jumlah ambang + 1`);
    if (s.cuts.some((x, i) => !Number.isInteger(x) || (i > 0 && x <= s.cuts[i - 1]))) e.push(`subsistem ${s.id}: ambang S10 harus bilangan bulat menaik (P7)`);
    for (const [vn, v] of Object.entries(s.vars)) {
      if (!Number.isInteger(v.weight) || v.weight <= 0) e.push(`subsistem ${s.id}.${vn}: bobot harus bilangan bulat positif (P7)`);
      if (Object.values(v.points).some((p) => !Number.isInteger(p))) e.push(`subsistem ${s.id}.${vn}: poin harus bilangan bulat`);
    }
    const outNames = c.mfOut[s.output].sets.map((x) => x.name);
    s.classes.forEach((cl) => { if (!outNames.includes(cl)) e.push(`subsistem ${s.id}: kelas ${cl} tidak ada di MF keluaran`); });
    s.vetoes.forEach((v) => { if (!s.classes.includes(v.then)) e.push(`veto ${v.id}: kelas ${v.then} tidak dikenal`); });
  }
  return e;
}

/** Stable hash of the full config; part of the Layer-1 cache key and of every output's metadata (P5). */
export const configHash = (c: SsiConfig = DEFAULT_CONFIG) => hashOf(c);
