// Canonical account dictionary for SSI v3.0 (spec §10). The code maps synonyms to canonical codes; the AI never does.
// Aliases are normalised (lowercase, letters and spaces) by the matcher and may be extended without touching the engine.

export type Statement = "BS" | "PL";
export type AccountKind = "component" | "reported_total";

export interface AccountDef {
  code: string;
  statement: Statement;
  kind: AccountKind;
  label: string;
  /** Optional for banks with no such line (e.g. SHARIAH_FINANCING on conventional banks); a missing value is not an error. */
  optional?: boolean;
  /** Expense lines are stored as positive magnitudes (spec §5.0). */
  expense?: boolean;
  aliases: string[];
}

const A = (code: string, statement: Statement, kind: AccountKind, label: string, aliases: string[], extra: Partial<AccountDef> = {}): AccountDef =>
  ({ code, statement, kind, label, aliases, ...extra });

export const ACCOUNTS: AccountDef[] = [
  // Neraca (Statement of Financial Position)
  A("CASH_BI", "BS", "component", "Kas dan penempatan pada Bank Indonesia", ["kas dan penempatan pada bank indonesia", "kas dan giro pada bank indonesia", "cash and placements with bank indonesia", "cash and current accounts with bank indonesia"]),
  A("DUE_FROM_BANKS", "BS", "component", "Giro dan penempatan pada bank lain", ["giro dan penempatan pada bank lain", "giro pada bank lain", "penempatan pada bank lain", "current accounts and placements with other banks"]),
  A("SECURITIES", "BS", "component", "Efek-efek", ["efek efek", "surat berharga", "investasi pada efek", "marketable securities", "securities"]),
  A("ACCEPTANCE_DERIV_ASSET", "BS", "component", "Tagihan akseptasi dan derivatif (aset)", ["tagihan akseptasi", "tagihan derivatif", "tagihan akseptasi dan derivatif", "acceptances receivable", "derivative receivables"]),
  A("LOANS_NET", "BS", "component", "Kredit yang diberikan, neto", ["kredit yang diberikan neto", "kredit yang diberikan setelah cadangan kerugian penurunan nilai", "pinjaman yang diberikan neto", "loans net", "loans net of allowance for impairment losses"]),
  A("SHARIAH_FINANCING", "BS", "component", "Piutang dan pembiayaan syariah", ["piutang dan pembiayaan syariah", "pembiayaan syariah", "sharia financing"], { optional: true }),
  A("FIXED_ASSETS", "BS", "component", "Aset tetap", ["aset tetap", "aset tetap neto", "fixed assets", "premises and equipment"]),
  A("DEFERRED_TAX_ASSET", "BS", "component", "Aset pajak tangguhan", ["aset pajak tangguhan", "deferred tax assets"]),
  A("OTHER_ASSETS", "BS", "component", "Aset lain-lain", ["aset lain lain", "aset lainnya", "other assets"]),
  A("TOTAL_ASSETS_REPORTED", "BS", "reported_total", "Total aset", ["total aset", "jumlah aset", "total assets"]),
  A("DEPOSITS", "BS", "component", "Simpanan nasabah", ["simpanan nasabah", "simpanan dari nasabah", "dana pihak ketiga", "deposits from customers", "customer deposits"]),
  A("DUE_TO_BANKS", "BS", "component", "Simpanan dari bank lain", ["simpanan dari bank lain", "liabilitas kepada bank lain", "deposits from other banks"]),
  A("ACCEPTANCE_DERIV_LIAB", "BS", "component", "Utang akseptasi dan derivatif (liabilitas)", ["utang akseptasi", "liabilitas akseptasi", "liabilitas derivatif", "acceptances payable", "derivative payables"]),
  A("DEBT_ISSUED_BORROWINGS", "BS", "component", "Efek utang yang diterbitkan dan pinjaman", ["efek yang diterbitkan", "efek utang yang diterbitkan", "pinjaman yang diterima", "surat berharga yang diterbitkan", "debt securities issued", "borrowings"]),
  A("OTHER_LIABILITIES", "BS", "component", "Liabilitas lain-lain", ["liabilitas lain lain", "liabilitas lainnya", "other liabilities"]),
  A("TOTAL_LIABILITIES_REPORTED", "BS", "reported_total", "Total liabilitas", ["total liabilitas", "jumlah liabilitas", "total liabilities"]),
  A("EQUITY_PARENT", "BS", "component", "Ekuitas yang dapat diatribusikan kepada pemilik entitas induk", ["ekuitas yang dapat diatribusikan kepada pemilik entitas induk", "ekuitas yang diatribusikan kepada pemilik entitas induk", "jumlah ekuitas yang dapat diatribusikan kepada pemilik entitas induk", "equity attributable to owners of the parent entity", "equity attributable to equity holders of the parent"]),
  A("NCI", "BS", "component", "Kepentingan non-pengendali", ["kepentingan non pengendali", "kepentingan nonpengendali", "non controlling interests", "non controlling interest"]),
  A("TOTAL_EQUITY_REPORTED", "BS", "reported_total", "Total ekuitas", ["total ekuitas", "jumlah ekuitas", "total equity"]),
  // Laba rugi (Profit or Loss; YTD, consolidated)
  A("INTEREST_INCOME", "PL", "component", "Pendapatan bunga", ["pendapatan bunga", "interest income"]),
  A("INTEREST_EXPENSE", "PL", "component", "Beban bunga", ["beban bunga", "interest expense"], { expense: true }),
  A("NET_INTEREST_INCOME_REPORTED", "PL", "reported_total", "Pendapatan bunga neto", ["pendapatan bunga neto", "pendapatan bunga bersih", "net interest income"]),
  A("OTHER_OP_INCOME", "PL", "component", "Pendapatan operasional lainnya", ["pendapatan operasional lainnya", "pendapatan operasional lain", "other operating income"]),
  A("OTHER_OP_EXPENSE", "PL", "component", "Beban operasional lainnya", ["beban operasional lainnya", "beban operasional lain", "other operating expenses"], { expense: true }),
  A("CKPN_EXPENSE", "PL", "component", "Beban kerugian penurunan nilai aset keuangan (CKPN)", ["beban kerugian penurunan nilai aset keuangan", "beban penyisihan kerugian penurunan nilai", "beban cadangan kerugian penurunan nilai", "ckpn", "impairment losses on financial assets", "allowance for impairment losses"], { expense: true }),
  A("OPERATING_PROFIT_REPORTED", "PL", "reported_total", "Laba operasional", ["laba operasional", "laba usaha", "operating profit"]),
  A("NON_OP", "PL", "component", "Pendapatan (beban) non-operasional, neto", ["pendapatan beban non operasional neto", "pendapatan non operasional neto", "beban non operasional neto", "non operating income expenses net"]),
  A("PRE_TAX_PROFIT_REPORTED", "PL", "reported_total", "Laba sebelum pajak", ["laba sebelum pajak", "laba sebelum beban pajak penghasilan", "profit before tax", "income before tax"]),
  A("TAX", "PL", "component", "Beban pajak penghasilan", ["beban pajak penghasilan", "beban pajak", "income tax expense", "tax expense"], { expense: true }),
  A("NET_INCOME_TOTAL", "PL", "reported_total", "Laba bersih tahun/periode berjalan", ["laba tahun berjalan", "laba periode berjalan", "laba bersih tahun berjalan", "laba bersih periode berjalan", "profit for the year", "profit for the period"]),
  A("NET_INCOME_PARENT", "PL", "component", "Laba bersih yang dapat diatribusikan kepada pemilik entitas induk", ["pemilik entitas induk", "laba yang dapat diatribusikan kepada pemilik entitas induk", "owners of the parent entity", "equity holders of the parent"]),
  A("NET_INCOME_NCI", "PL", "component", "Laba bersih yang dapat diatribusikan kepada kepentingan non-pengendali", ["kepentingan non pengendali laba", "laba yang dapat diatribusikan kepada kepentingan non pengendali", "non controlling interests profit"]),
];

export const ACCOUNT_BY_CODE: Record<string, AccountDef> = Object.fromEntries(ACCOUNTS.map((a) => [a.code, a]));

/** Lowercase, letters and spaces only; same normalisation the matcher applies to statement labels. */
export const normaliseLabel = (s: string) =>
  s.toLowerCase().replace(/[^a-z\s]/g, " ").replace(/\s+/g, " ").trim();

/** Exact alias lookup after normalisation; returns the canonical code or null. Fuzzy matching stays in the matcher. */
export function codeForLabel(label: string): string | null {
  const n = normaliseLabel(label);
  for (const a of ACCOUNTS) if (a.aliases.some((x) => normaliseLabel(x) === n)) return a.code;
  return null;
}
