// Stage A: financial ratios (spec §5). Pure functions; values in Rp miliar, ratios in percent.
// Layer 1 (price independent). Null ratio + reason instead of a guessed value (P4, P6).
import { DEFAULT_CONFIG, type SsiConfig } from "./config";
import type { Accounts } from "./validators";

export type Flag = "PROKSI" | "ESTIMATED" | "ROE-VALUASI TIDAK DIHALUSKAN" | "DAYA BEDA RENDAH";

export interface RatioResult {
  id: string;
  value: number | null;
  /** Reason when value is null. */
  reason?: string;
  formula: string;
  components: Record<string, number | null>;
  flags: string[];
}

export interface StageAInput {
  /** True for FY / December: TTM = FY and no comparative P&L is needed. */
  isFullYear: boolean;
  /** Months elapsed in the YTD period (3, 6, 9, 12 or 1-12 for monthly); used only by estimate mode. */
  months: number;
  /** Balance sheet at period end and P&L YTD of the analysis period. */
  cur: Accounts;
  /** Balance sheet at the same date one year earlier (31 Dec t-1 for annual). */
  start: Accounts;
  /** P&L YTD of the same period last year (interim only). */
  plPrevSame?: Accounts;
  /** P&L FY of last year (interim only). */
  plPrevFY?: Accounts;
  /** Validated FY ROE_kinerja history, most recent first, excluding the current period. */
  roeHistory?: number[];
}

const n = (v: number | null | undefined): number | null => (typeof v === "number" && Number.isFinite(v) ? v : null);

interface Ttm { value: number | null; estimated: boolean; reason?: string }

/** TTM(x) = YTD now + FY last year - YTD same period last year; FY periods use the FY value (spec §5.0). */
export function ttm(code: string, inp: StageAInput, cfg: SsiConfig = DEFAULT_CONFIG): Ttm {
  const cur = n(inp.cur[code]);
  if (cur == null) return { value: null, estimated: false, reason: `${code} periode berjalan tidak tersedia` };
  if (inp.isFullYear) return { value: cur, estimated: false };
  const fy = n(inp.plPrevFY?.[code]), same = n(inp.plPrevSame?.[code]);
  if (fy != null && same != null) return { value: cur + fy - same, estimated: false };
  if (cfg.estimasiMode && inp.months > 0) return { value: (cur * 12) / inp.months, estimated: true };
  return { value: null, estimated: false, reason: `${code}: pembanding TTM (Laba Rugi FY t-1 dan YTD periode sama t-1) belum ada` };
}

const avg = (a: number | null, b: number | null) => (a == null || b == null ? null : (a + b) / 2);

/** Parent equity: reported parent line, else total equity minus NCI (spec §5.1 A1). */
export function parentEquity(a: Accounts): number | null {
  const p = n(a.EQUITY_PARENT);
  if (p != null) return p;
  const te = n(a.TOTAL_EQUITY_REPORTED);
  return te == null ? null : te - (n(a.NCI) ?? 0);
}

function make(id: string, formula: string, components: Record<string, number | null>, num: number | null, den: number | null, flags: string[], reasonNum?: string, scale = 100): RatioResult {
  const base = { id, formula, components, flags };
  if (num == null) return { ...base, value: null, reason: reasonNum ?? "pembilang tidak tersedia" };
  if (den == null) return { ...base, value: null, reason: "penyebut tidak tersedia" };
  if (den <= 0) return { ...base, value: null, reason: `penyebut <= 0 (${den})` };
  return { ...base, value: (num / den) * scale };
}

const est = (t: Ttm, flags: string[]) => (t.estimated ? [...flags, "ESTIMATED"] : flags);
const sum = (vals: (number | null)[]) => (vals.some((v) => v == null) ? null : (vals as number[]).reduce((s, v) => s + v, 0));

export interface StageAResult {
  inference: { ROE_KINERJA: RatioResult; BOPO: RatioResult; COC: RatioResult; EA: RatioResult; GROWTH: RatioResult };
  display: { ROA: RatioResult; CIR: RatioResult; LDR: RatioResult; NIM: RatioResult; NON_INTEREST: RatioResult; LIQUID: RatioResult };
  roeValuasi: RatioResult;
  /** Stage C is blocked while any inference ratio is null. */
  blocked: string[];
}

export function roeValuasi(roeKinerja: RatioResult, history: number[] | undefined, cfg: SsiConfig = DEFAULT_CONFIG): RatioResult {
  const id = "ROE_VALUASI";
  const formula = `rata-rata ROE kinerja terkini dan ROE FY sebelumnya (hingga ${cfg.stageB.roeSmoothingYears} titik)`;
  const prior = (history ?? []).filter((x) => Number.isFinite(x)).slice(0, cfg.stageB.roeSmoothingYears - 1);
  if (roeKinerja.value == null) return { id, formula, components: {}, flags: [], value: null, reason: "ROE kinerja NULL" };
  if (prior.length === 0)
    return { id, formula, components: { ROE_KINERJA: roeKinerja.value }, flags: [...roeKinerja.flags, "ROE-VALUASI TIDAK DIHALUSKAN"], value: roeKinerja.value };
  const pts = [roeKinerja.value, ...prior];
  const components: Record<string, number | null> = { ROE_KINERJA: roeKinerja.value };
  prior.forEach((v, i) => (components[`ROE_FY_MIN_${i + 1}`] = v));
  return { id, formula, components, flags: roeKinerja.flags.filter((f) => f === "ESTIMATED"), value: pts.reduce((s, v) => s + v, 0) / pts.length };
}

export function computeStageA(inp: StageAInput, cfg: SsiConfig = DEFAULT_CONFIG): StageAResult {
  const c = inp.cur, s = inp.start;

  const niP = ttm("NET_INCOME_PARENT", inp, cfg);
  const eqEnd = parentEquity(c), eqStart = parentEquity(s);
  const roeK = make("ROE_KINERJA", "TTM(Laba Bersih Induk) / rata-rata(Ekuitas Induk) x 100",
    { NI_PARENT_TTM: niP.value, EQUITY_PARENT_END: eqEnd, EQUITY_PARENT_START: eqStart }, niP.value, avg(eqEnd, eqStart), est(niP, []), niP.reason);

  const ii = n(c.INTEREST_INCOME), ie = n(c.INTEREST_EXPENSE), ooi = n(c.OTHER_OP_INCOME), ooe = n(c.OTHER_OP_EXPENSE), ck = n(c.CKPN_EXPENSE);
  const bopoNum = sum([ie, ooe, ck]), bopoDen = sum([ii, ooi]);
  const bopo = make("BOPO", "(Beban Bunga + Beban Operasional Lainnya + Beban CKPN) / (Pendapatan Bunga + Pendapatan Operasional Lainnya) x 100 (YTD, tanpa anualisasi)",
    { INTEREST_EXPENSE: ie, OTHER_OP_EXPENSE: ooe, CKPN_EXPENSE: ck, INTEREST_INCOME: ii, OTHER_OP_INCOME: ooi }, bopoNum, bopoDen, [], "akun beban/pendapatan tidak lengkap");

  const ckT = ttm("CKPN_EXPENSE", inp, cfg);
  const loansEnd = n(c.LOANS_NET), loansStart = n(s.LOANS_NET);
  const coc = make("COC", "TTM(Beban CKPN) / rata-rata(Kredit Neto) x 100",
    { CKPN_TTM: ckT.value, LOANS_NET_END: loansEnd, LOANS_NET_START: loansStart }, ckT.value, avg(loansEnd, loansStart), est(ckT, ["PROKSI"]), ckT.reason);

  const te = n(c.TOTAL_EQUITY_REPORTED), ta = n(c.TOTAL_ASSETS_REPORTED);
  const ea = make("EA", "Total Ekuitas akhir / Total Aset akhir x 100", { TOTAL_EQUITY: te, TOTAL_ASSETS: ta }, te, ta, ["PROKSI"]);

  const growth: RatioResult = {
    id: "GROWTH", formula: "(Kredit Neto akhir / Kredit Neto awal - 1) x 100", components: { LOANS_NET_END: loansEnd, LOANS_NET_START: loansStart }, flags: ["PROKSI"],
    ...(loansEnd == null || loansStart == null ? { value: null, reason: "kredit neto tidak tersedia" }
      : loansStart <= 0 ? { value: null, reason: `penyebut <= 0 (${loansStart})` }
      : { value: (loansEnd / loansStart - 1) * 100 }),
  };

  const niT = ttm("NET_INCOME_TOTAL", inp, cfg), taStart = n(s.TOTAL_ASSETS_REPORTED);
  const roa = make("ROA", "TTM(Laba Bersih Total) / rata-rata(Total Aset) x 100", { NI_TTM: niT.value, TA_END: ta, TA_START: taStart }, niT.value, avg(ta, taStart), est(niT, []), niT.reason);

  const nii = n(c.NET_INTEREST_INCOME_REPORTED);
  const cir = make("CIR", "Beban Operasional Lainnya / (Pendapatan Bunga Neto + Pendapatan Operasional Lainnya) x 100",
    { OTHER_OP_EXPENSE: ooe, NII: nii, OTHER_OP_INCOME: ooi }, ooe, sum([nii, ooi]), [], "akun tidak lengkap");

  const dep = n(c.DEPOSITS);
  const ldr = make("LDR", "Kredit Neto / Simpanan Nasabah x 100 (bukan LFR OJK)", { LOANS_NET: loansEnd, DEPOSITS: dep }, loansEnd, dep, ["PROKSI"]);

  const niiT = ttm("NET_INTEREST_INCOME_REPORTED", inp, cfg);
  const earning = (a: Accounts) => sum([n(a.CASH_BI), n(a.DUE_FROM_BANKS), n(a.SECURITIES), n(a.LOANS_NET)]);
  const nim = make("NIM", "TTM(Pendapatan Bunga Neto) / rata-rata(Kas&BI + Giro&Penempatan Bank Lain + Efek + Kredit Neto) x 100",
    { NII_TTM: niiT.value, EARNING_END: earning(c), EARNING_START: earning(s) }, niiT.value, avg(earning(c), earning(s)), est(niiT, ["PROKSI"]), niiT.reason);

  const nonInt = make("NON_INTEREST", "Pendapatan Operasional Lainnya / (Pendapatan Bunga Neto + Pendapatan Operasional Lainnya) x 100",
    { OTHER_OP_INCOME: ooi, NII: nii }, ooi, sum([nii, ooi]), [], "akun tidak lengkap");

  const liquid = sum([n(c.CASH_BI), n(c.DUE_FROM_BANKS), n(c.SECURITIES)]);
  const liq = make("LIQUID", "(Kas&BI + Giro&Penempatan Bank Lain + Efek) / Simpanan Nasabah x 100", { LIQUID_ASSETS: liquid, DEPOSITS: dep }, liquid, dep, [], "akun likuid tidak lengkap");

  const inference = { ROE_KINERJA: roeK, BOPO: bopo, COC: coc, EA: ea, GROWTH: growth };
  const blocked = Object.values(inference).filter((r) => r.value == null).map((r) => `${r.id}: ${r.reason}`);
  return { inference, display: { ROA: roa, CIR: cir, LDR: ldr, NIM: nim, NON_INTEREST: nonInt, LIQUID: liq }, roeValuasi: roeValuasi(roeK, inp.roeHistory, cfg), blocked };
}
