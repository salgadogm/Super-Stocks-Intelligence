// Rule generator (spec §7.2). Rules are produced from the integer scheme in the config and must never be edited by hand.
import type { SsiConfig, Subsystem } from "./config";
import { hashOf } from "./hash";

export interface Rule {
  id: string;
  subsystem: "A" | "B" | "FINAL";
  antecedents: Record<string, string>;
  /** Weighted points times 10 scheme; integer arithmetic only (P7). */
  s10: number;
  baseClass: string;
  veto: string | null;
  consequent: string;
}

/** Class of an integer S10: lower bound inclusive. */
export function classify(sub: Subsystem, s10: number): string {
  let i = 0;
  while (i < sub.cuts.length && s10 >= sub.cuts[i]) i++;
  return sub.classes[i];
}

export function rulesForSubsystem(sub: Subsystem): Rule[] {
  const vars = sub.inputs;
  const prefix = sub.id === "FINAL" ? "F" : sub.id;
  const out: Rule[] = [];
  const walk = (i: number, ant: Record<string, string>) => {
    if (i < vars.length) {
      for (const set of Object.keys(sub.vars[vars[i]].points)) walk(i + 1, { ...ant, [vars[i]]: set });
      return;
    }
    const s10 = vars.reduce((s, v) => s + sub.vars[v].weight * sub.vars[v].points[ant[v]], 0);
    const baseClass = classify(sub, s10);
    const hit = sub.vetoes.find((vt) => vt.all.every((c) => (!c.in || c.in.includes(ant[c.var])) && (!c.notIn || !c.notIn.includes(ant[c.var]))));
    out.push({
      id: `${prefix}${String(out.length + 1).padStart(2, "0")}`,
      subsystem: sub.id, antecedents: { ...ant }, s10, baseClass, veto: hit ? hit.id : null, consequent: hit ? hit.then : baseClass,
    });
  };
  walk(0, {});
  return out;
}

export function generateRules(cfg: SsiConfig): Rule[] {
  return (["A", "B", "FINAL"] as const).flatMap((k) => rulesForSubsystem(cfg.subsystems[k]));
}

export const ruleText = (r: Rule) =>
  Object.entries(r.antecedents).map(([v, s]) => `${v}=${s}`).join(" AND ") + ` -> ${r.consequent}`;

/** Audit export (spec §7). Deterministic column order and row order. */
export function rulesToCsv(rules: Rule[]): string {
  const head = "id,subsystem,antecedent,s10,base_class,veto,consequent";
  const rows = rules.map((r) => [r.id, r.subsystem, Object.entries(r.antecedents).map(([v, s]) => `${v}=${s}`).join(" AND "), r.s10, r.baseClass, r.veto ?? "", r.consequent].join(","));
  return [head, ...rows].join("\n") + "\n";
}

export const rulesHash = (rules: Rule[]) => hashOf(rules);
