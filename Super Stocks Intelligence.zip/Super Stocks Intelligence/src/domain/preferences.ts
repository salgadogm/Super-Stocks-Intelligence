// Device-level UI preferences (theme). localStorage only.
import { useCallback, useEffect, useState } from "react";

export type ThemePref = "dark" | "light" | "system";
export const THEME_KEY = "aurevia.theme.v1";

const readPref = (): ThemePref => {
  try {
    const v = localStorage.getItem(THEME_KEY);
    return v === "dark" || v === "light" || v === "system" ? v : "system";
  } catch { return "system"; }
};

const resolve = (p: ThemePref): "dark" | "light" =>
  p === "system" ? (window.matchMedia("(prefers-color-scheme: light)").matches ? "light" : "dark") : p;

const apply = (p: ThemePref) => { document.documentElement.dataset.theme = resolve(p); };

const listeners = new Set<(p: ThemePref) => void>();

export type Lang = "id" | "en";
export const LANG_KEY = "aurevia.lang.v1";
const langListeners = new Set<(l: Lang) => void>();
const readLang = (): Lang => {
  try { return localStorage.getItem(LANG_KEY) === "en" ? "en" : "id"; } catch { return "id"; }
};
let currentLang: Lang = readLang();
export const getLang = () => currentLang;

export function useLang() {
  const [lang, setLangState] = useState<Lang>(currentLang);
  useEffect(() => {
    langListeners.add(setLangState);
    return () => { langListeners.delete(setLangState); };
  }, []);
  useEffect(() => { document.documentElement.lang = lang; }, [lang]);
  const setLang = useCallback((l: Lang) => {
    currentLang = l;
    try { localStorage.setItem(LANG_KEY, l); } catch { /* quota */ }
    langListeners.forEach((fn) => fn(l));
  }, []);
  return { lang, setLang };
}

export function useTheme() {
  const [pref, setPrefState] = useState<ThemePref>(readPref);

  useEffect(() => {
    listeners.add(setPrefState);
    return () => { listeners.delete(setPrefState); };
  }, []);

  useEffect(() => {
    apply(pref);
    if (pref !== "system") return;
    const mq = window.matchMedia("(prefers-color-scheme: light)");
    const on = () => apply("system");
    mq.addEventListener("change", on);
    return () => mq.removeEventListener("change", on);
  }, [pref]);

  const setPref = useCallback((p: ThemePref) => {
    try { localStorage.setItem(THEME_KEY, p); } catch { /* quota */ }
    listeners.forEach((l) => l(p));
  }, []);

  const resolved = resolve(pref);
  const toggle = useCallback(() => setPref(resolve(readPref()) === "dark" ? "light" : "dark"), [setPref]);
  return { pref, resolved, setPref, toggle };
}
