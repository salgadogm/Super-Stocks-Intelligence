// AI fallback for accounts the rule-based matcher could not find. The model only READS printed numbers from
// the statement pages; it never computes. Every returned number must literally appear in that page's text.
import { CANONICAL_ACCOUNTS, type CanonicalAccountId, type ExtractedFinancialItem, type UnitScale } from "./financial";
import { getKey } from "./apiKeys";

const MODEL = "claude-sonnet-5";
const UNITS: UnitScale[] = ["unit", "thousands", "millions", "billions"];
const NUM_RE = /\d[\d.,]*/g;
const digits = (s: string) => s.replace(/\D/g, "").replace(/^0+(?=\d)/, "");

/** True when the printed value matches a numeric token on the page (separators and parentheses ignored). */
function appearsIn(value: string, text: string): boolean {
  const want = digits(value);
  if (!want) return false;
  return (text.match(NUM_RE) ?? []).some((tok) => digits(tok) === want);
}

export async function aiExtract(
  pagesText: { page: number; statement: "profit_loss" | "financial_position"; text: string }[],
  missing: CanonicalAccountId[],
  signal?: AbortSignal,
): Promise<ExtractedFinancialItem[]> {
  const key = getKey("anthropic");
  if (!key || !missing.length || !pagesText.length) return [];

  const accounts = missing.map((id) => `- ${id}: ${CANONICAL_ACCOUNTS[id].label} (${CANONICAL_ACCOUNTS[id].labelId}), statement: ${CANONICAL_ACCOUNTS[id].statement}`).join("\n");
  const pages = pagesText.map((p) => `=== PAGE ${p.page} (${p.statement}) ===\n${p.text}`).join("\n\n");
  const prompt = `You read bank financial statement pages (Indonesian or English). Find the CURRENT-year printed value for each requested account.
Rules:
- Copy the number exactly as printed (keep separators and parentheses). Do NOT calculate, sum, convert, round or estimate anything.
- Use the most recent year column; report that column's year in "columnYear".
- If an account is not printed on the pages, omit it.
- "unit" is the scale stated on the page: one of "unit", "thousands", "millions", "billions".
- Respond with ONLY a JSON array, no prose: [{"account": "<id>", "value": "<printed number>", "page": <page number>, "unit": "<unit>", "columnYear": <year>}]

Accounts to find:
${accounts}

${pages}`;

  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    signal,
    headers: {
      "content-type": "application/json",
      "x-api-key": key,
      "anthropic-version": "2023-06-01",
      "anthropic-dangerous-direct-browser-access": "true",
    },
    body: JSON.stringify({ model: MODEL, max_tokens: 2000, messages: [{ role: "user", content: prompt }] }),
  });
  if (!res.ok) throw new Error(`AI ${res.status}`);
  const body = await res.json() as { content?: { type: string; text?: string }[] };
  const raw = (body.content ?? []).filter((c) => c.type === "text").map((c) => c.text ?? "").join("");
  const json = raw.match(/\[[\s\S]*\]/)?.[0];
  if (!json) return [];
  let arr: unknown;
  try { arr = JSON.parse(json); } catch { return []; }
  if (!Array.isArray(arr)) return [];

  const out: ExtractedFinancialItem[] = [];
  const seen = new Set<string>();
  for (const r of arr as Record<string, unknown>[]) {
    const account = String(r?.account) as CanonicalAccountId;
    const value = String(r?.value ?? "").trim();
    const page = Number(r?.page);
    if (!missing.includes(account) || seen.has(account)) continue;
    const pg = pagesText.find((p) => p.page === page);
    if (!pg || pg.statement !== CANONICAL_ACCOUNTS[account].statement || !appearsIn(value, pg.text)) continue; // not literally on that page: drop
    const unit = UNITS.includes(r.unit as UnitScale) ? (r.unit as UnitScale) : "unit";
    const columnYear = Number(r.columnYear);
    seen.add(account);
    out.push({
      id: `ai_${account}_${page}`, documentId: "", canonicalAccount: account,
      rawLabel: CANONICAL_ACCOUNTS[account].label, rawValue: value, currency: "IDR", unit,
      pageNumber: page, statementType: pg.statement, columnYear: Number.isFinite(columnYear) ? columnYear : undefined, confidence: 0.7,
    });
  }
  return out;
}
