// Apple-to-apple year-window validation for multi-year comparison: every compared issuer must have a
// calculated FY analysis for every year of the same consecutive window.
import type { AnalysisRecord, Workspace } from "./store";
import { isMonthly, monthName, monthOf } from "./financial";

export const MIN_YEARS = 2;
export const MAX_YEARS = 10;

export function fyByYear(ws: Pick<Workspace, "analyses">, ticker: string) {
  const m = new Map<number, AnalysisRecord>();
  for (const a of ws.analyses) {
    if (a.ticker !== ticker || a.period.period !== "FY") continue;
    const cur = m.get(a.period.fiscalYear);
    if (!cur || a.calculatedAt > cur.calculatedAt) m.set(a.period.fiscalYear, a);
  }
  return m;
}

export const buildWindow = (endYear: number, n: number) => Array.from({ length: n }, (_, i) => endYear - n + 1 + i);

export type TickerCheck = { ticker: string; have: number[]; missing: number[] };
export type WindowCheck = { ok: boolean; window: number[]; perTicker: TickerCheck[]; reasons: string[] };

export function validateComparison(maps: Record<string, Map<number, AnalysisRecord>>, tickers: string[], endYear: number, n: number): WindowCheck {
  const window = buildWindow(endYear, n);
  const perTicker = tickers.map((ticker) => {
    const years = new Set(maps[ticker]?.keys() ?? []);
    return { ticker, have: window.filter((y) => years.has(y)), missing: window.filter((y) => !years.has(y)) };
  });
  const reasons = perTicker.filter((p) => p.missing.length).map((p) =>
    `${p.ticker}: ${p.have.length} dari ${n} tahun tersedia, belum ada FY ${p.missing.join(", ")}`);
  return { ok: tickers.length > 0 && reasons.length === 0, window, perTicker, reasons };
}

/** Monthly (year-to-date) analyses of one ticker for `year`, keyed by month number 1-12. */
export function monthsByTicker(ws: Pick<Workspace, "analyses">, ticker: string, year: number) {
  const m = new Map<number, AnalysisRecord>();
  for (const a of ws.analyses) {
    if (a.ticker !== ticker || a.period.fiscalYear !== year || !isMonthly(a.period.period)) continue;
    const k = monthOf(a.period.period);
    const cur = m.get(k);
    if (!cur || a.calculatedAt > cur.calculatedAt) m.set(k, a);
  }
  return m;
}

export type MonthlyCheck = { ok: boolean; year: number; months: number[]; perTicker: TickerCheck[]; reasons: string[] };

/**
 * Current-year monthly reports (e.g. 2021-2025 FY + Jan 2026): no monthly data is fine, but if any compared
 * issuer has some, there must be at least 2 issuers and every issuer must have the identical month set, running
 * contiguously from January.
 */
export function validateMonthly(maps: Record<string, Map<number, AnalysisRecord>>, tickers: string[], year: number): MonthlyCheck {
  const union = [...new Set(tickers.flatMap((t) => [...(maps[t]?.keys() ?? [])]))];
  if (!union.length) return { ok: true, year, months: [], perTicker: [], reasons: [] };
  const months = Array.from({ length: Math.max(...union) }, (_, i) => i + 1);
  const perTicker = tickers.map((ticker) => {
    const have = new Set(maps[ticker]?.keys() ?? []);
    return { ticker, have: months.filter((m) => have.has(m)), missing: months.filter((m) => !have.has(m)) };
  });
  const reasons = perTicker.filter((p) => p.missing.length).map((p) =>
    `${p.ticker}: ${p.have.length} dari ${months.length} laporan bulanan ${year} tersedia, belum ada ${p.missing.map((m) => `${monthName(m)} ${year}`).join(", ")}`);
  if (tickers.length < 2) reasons.unshift("Perbandingan laporan bulanan membutuhkan minimal 2 emiten");
  return { ok: reasons.length === 0, year, months, perTicker, reasons };
}

/** Candidate end years (descending) that at least one selected issuer has. */
export function endYearOptions(maps: Record<string, Map<number, AnalysisRecord>>, tickers: string[]) {
  return [...new Set(tickers.flatMap((t) => [...(maps[t]?.keys() ?? [])]))].sort((a, b) => b - a);
}

/** Longest N for which `endYear` is covered by every selected issuer with consecutive years. */
export function maxCommonYears(maps: Record<string, Map<number, AnalysisRecord>>, tickers: string[], endYear: number) {
  let n = 0;
  while (n < MAX_YEARS && tickers.length && tickers.every((t) => maps[t]?.has(endYear - n))) n++;
  return n;
}
