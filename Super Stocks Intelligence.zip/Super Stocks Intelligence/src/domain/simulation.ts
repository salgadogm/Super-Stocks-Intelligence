// Scripted end-to-end simulation (design walkthrough). Illustrative BBRI & BMRI figures close to published scale,
// IDR millions. No real PDF, AI or backend call happens: scores are still computed by the real engine.
import { RATIO_DEFINITIONS, CANONICAL_ACCOUNTS, type CanonicalAccountId, type RatioKey } from "./financial";
import { computeFuzzy, VAR_KEYS, type VarKey } from "./engine";

export type SimTicker = "BBRI" | "BMRI";
type Row = [ni: number, nii: number, oi: number, oe: number, eps: number, eq: number, ta: number, loans: number, dpk: number, price: number];

const DATA: Record<SimTicker, Record<number, Row>> = {
  BBRI: {
    2020: [18_660_393, 101_020_000, 152_110_000, 128_540_000, 152.0, 199_911_376, 1_511_804_628, 938_373_000, 1_121_102_000, 4170],
    2021: [30_755_766, 114_030_000, 165_250_000, 127_410_000, 207.0, 291_786_804, 1_678_097_734, 1_042_867_000, 1_138_743_000, 4110],
    2022: [51_408_207, 125_510_000, 182_040_000, 117_120_000, 339.0, 303_395_317, 1_865_639_010, 1_139_077_000, 1_307_884_000, 4940],
    2023: [60_425_048, 135_020_000, 197_330_000, 122_210_000, 398.0, 316_315_578, 1_965_007_148, 1_266_429_000, 1_358_329_000, 5725],
    2024: [60_643_584, 140_210_000, 205_540_000, 131_120_000, 400.0, 330_318_589, 1_992_983_351, 1_354_644_000, 1_365_450_000, 4080],
    2025: [57_102_000, 145_630_000, 211_040_000, 140_310_000, 377.0, 338_020_000, 2_110_450_000, 1_420_380_000, 1_480_220_000, 3800],
  },
  BMRI: {
    2021: [28_028_155, 72_010_000, 115_230_000, 83_040_000, 300.3, 222_111_282, 1_725_611_128, 1_050_120_000, 1_291_030_000, 3525],
    2022: [41_170_637, 85_040_000, 130_110_000, 82_520_000, 441.2, 252_245_455, 1_992_544_687, 1_172_400_000, 1_490_060_000, 4962],
    2023: [55_060_057, 94_020_000, 142_300_000, 81_830_000, 590.0, 287_720_120, 2_174_219_449, 1_400_210_000, 1_577_040_000, 6050],
    2024: [55_783_000, 100_420_000, 150_060_000, 87_610_000, 598.0, 315_004_000, 2_427_223_000, 1_620_330_000, 1_700_120_000, 5700],
    2025: [54_201_000, 104_050_000, 156_020_000, 93_540_000, 581.0, 330_110_000, 2_580_400_000, 1_760_220_000, 1_830_500_000, 4900],
  },
};

export const SIM_BANKS: Record<SimTicker, { name: string; short: string }> = {
  BBRI: { name: "PT Bank Rakyat Indonesia (Persero) Tbk", short: "Bank BRI" },
  BMRI: { name: "PT Bank Mandiri (Persero) Tbk", short: "Bank Mandiri" },
};

const ORDER: CanonicalAccountId[] = ["net_income", "net_interest_income", "operating_income", "operating_expense", "basic_eps", "total_equity", "total_assets", "total_loans", "third_party_funds"];

/** The BMRI FY2025 file is a deliberate trap: its first column is the prior year (2024). */
export const TRAP = { ticker: "BMRI" as SimTicker, year: 2025, found: 2024 };

export type SimDoc = { id: string; ticker: SimTicker; year: number; file: string; pages: number; sizeMb: number; uploadedBy: string; trap?: boolean };
export const SIM_DOCS: SimDoc[] = (Object.keys(DATA) as SimTicker[]).flatMap((t) =>
  Object.keys(DATA[t]).map(Number).map((y, i) => ({
    id: `${t}-${y}`, ticker: t, year: y, file: `${t}_LK_Konsolidasian_FY${y}.pdf`,
    pages: 180 + ((y * 7 + i * 13) % 60), sizeMb: +(6.2 + ((y + i) % 5) * 0.9).toFixed(1), uploadedBy: "admin@aurevia.id",
    trap: t === TRAP.ticker && y === TRAP.year,
  })));

export const simAccounts = (t: SimTicker, y: number) =>
  Object.fromEntries(ORDER.map((id, i) => [id, DATA[t][y][i]])) as Record<CanonicalAccountId, number>;
export const simPrice = (t: SimTicker, y: number) => DATA[t][y][9];
export const simYears = (t: SimTicker) => Object.keys(DATA[t]).map(Number);

export function simRatios(acc: Partial<Record<CanonicalAccountId, number>>, price?: number) {
  return Object.fromEntries((Object.keys(RATIO_DEFINITIONS) as RatioKey[]).map((k) =>
    [k, RATIO_DEFINITIONS[k].compute(acc, { share_price: price })])) as Record<RatioKey, number | null>;
}

export function simScore(t: SimTicker, y: number) {
  const r = simRatios(simAccounts(t, y), simPrice(t, y));
  const vals = Object.fromEntries(VAR_KEYS.map((k) => [k, r[k] ?? 0])) as Record<VarKey, number>;
  return { ratios: vals, ...computeFuzzy(vals) };
}

/* ─── Simulated PDF → TXT output ─────────────────── */
const fmt = (v: number) => (Number.isInteger(v) ? v.toLocaleString("id-ID") : v.toLocaleString("id-ID", { minimumFractionDigits: 2, maximumFractionDigits: 2 }));

export type SimPage = { page: number; statement: "profit_loss" | "financial_position"; title: string; lines: string[] };

export function simTxt(t: SimTicker, y: number): SimPage[] {
  const cur = DATA[t][y], prev = DATA[t][y - 1] ?? cur.map((v) => Math.round(v * 0.93)) as Row;
  const trap = t === TRAP.ticker && y === TRAP.year;
  const [a, b] = trap ? [prev, cur] : [cur, prev];
  const head = trap ? `Catatan | ${y - 1} | ${y}` : `Catatan | ${y} | ${y - 1}`;
  const line = (label: string, note: string, i: number) => `${label} | ${note} | ${fmt(a[i])} | ${fmt(b[i])}`;
  const p1 = 4 + (y % 3);
  return [
    { page: p1, statement: "financial_position", title: "LAPORAN POSISI KEUANGAN KONSOLIDASIAN", lines: [
      SIM_BANKS[t].name.toUpperCase() + " DAN ENTITAS ANAK",
      `LAPORAN POSISI KEUANGAN KONSOLIDASIAN 31 DESEMBER ${y}`,
      "(Disajikan dalam jutaan Rupiah, kecuali dinyatakan lain)",
      head,
      "ASET | | |",
      line("Kredit yang diberikan", "11", 7),
      line("Jumlah Aset", "", 6),
      "LIABILITAS | | |",
      `Giro | 20 | ${fmt(Math.round(a[8] * 0.31))} | ${fmt(Math.round(b[8] * 0.31))}`,
      `Tabungan | 21 | ${fmt(Math.round(a[8] * 0.38))} | ${fmt(Math.round(b[8] * 0.38))}`,
      `Deposito berjangka | 22 | ${fmt(a[8] - Math.round(a[8] * 0.31) - Math.round(a[8] * 0.38))} | ${fmt(b[8] - Math.round(b[8] * 0.31) - Math.round(b[8] * 0.38))}`,
      "EKUITAS | | |",
      line("Jumlah Ekuitas", "", 5),
    ] },
    { page: p1 + 2, statement: "profit_loss", title: "LAPORAN LABA RUGI DAN PENGHASILAN KOMPREHENSIF LAIN KONSOLIDASIAN", lines: [
      `UNTUK TAHUN YANG BERAKHIR 31 DESEMBER ${y}`,
      "(Disajikan dalam jutaan Rupiah, kecuali dinyatakan lain)",
      head,
      line("Pendapatan bunga - neto", "33", 1),
      line("Jumlah pendapatan operasional", "", 2),
      line("Jumlah beban operasional", "", 3),
      line("Laba tahun berjalan", "", 0),
      line("Laba per saham dasar (Rupiah penuh)", "45", 4),
    ] },
  ];
}

/* ─── Simulated AI proposals (what DeepSeek returns from the TXT) ─── */
export type SimProposal = { account: CanonicalAccountId; value: number | null; page: number; source: "rule" | "deepseek" | "manual"; confidence: number; note?: string };
export type SimDropped = { account: CanonicalAccountId; value: number; reason: string };

export function simExtraction(t: SimTicker, y: number): { proposals: SimProposal[]; dropped: SimDropped[] } {
  const acc = simAccounts(t, y), pages = simTxt(t, y);
  const pageOf = (id: CanonicalAccountId) => pages.find((p) => p.statement === CANONICAL_ACCOUNTS[id].statement)!.page;
  const ruleHit: CanonicalAccountId[] = ["total_assets", "total_equity", "net_income", "operating_income"];
  const proposals = ORDER.map((id): SimProposal =>
    id === "third_party_funds"
      ? { account: id, value: null, page: pageOf(id), source: "manual", confidence: 0, note: "DPK tersaji terpisah (giro, tabungan, deposito); tidak ada baris total. Jumlahkan manual." }
      : { account: id, value: acc[id], page: pageOf(id), source: ruleHit.includes(id) ? "rule" : "deepseek", confidence: ruleHit.includes(id) ? 0.98 : 0.82 + ((id.length * 7) % 14) / 100 });
  return { proposals, dropped: [{ account: "total_loans", value: Math.round(acc.total_loans * 1.0213), reason: "Angka tidak muncul di halaman sumber (kemungkinan dari Catatan 11 bruto). Ditolak validator, diganti hasil baris \"Kredit yang diberikan\"." }] };
}
