// News & comments store. Client-side only (localStorage).
//
// ACCESS MODEL (important for future maintainers / AI agents):
//   - The role comes from the session (getRole(), set by App.tsx from ADMIN_EMAILS / dev bypass = admin).
//   - ONLY admins may publish or delete news (text + images, structured as blocks).
//   - Everyone else (viewer role) may ONLY read news and post comments under an article.
//   - There is no role switcher in the UI by design. When a real backend/auth exists, derive the
//     role from the session and keep this rule: publishing = admin only, commenting = anyone.
import { useSyncExternalStore } from "react";

export type Role = "admin" | "viewer";
/** Emails that get the admin role on real login. The dev-bypass button is always admin. */
export const ADMIN_EMAILS: string[] = ["admin@aurevia.local"];
export const roleForEmail = (email: string): Role => (ADMIN_EMAILS.includes(email.trim().toLowerCase()) ? "admin" : "viewer");
let sessionRole: Role = "viewer";
/** Set by App.tsx when the session starts; viewer until then. */
export const setSessionRole = (role: Role) => { sessionRole = role; };
export const getRole = (): Role => sessionRole;
export const canPublishNews = (role: Role) => role === "admin";
/** Collection (Koleksi Laporan) uploads, deletion and AI keys: admin only. Other users only pull existing reports. */
export const canManageCollection = (role: Role) => role === "admin";
export const canViewUserAmounts = (role: Role) => role === "admin";

export type NewsCategory = "Emiten" | "Regulasi" | "Perbankan & Moneter" | "Pasar";
export const NEWS_CATEGORIES: NewsCategory[] = ["Emiten", "Regulasi", "Perbankan & Moneter", "Pasar"];

export type NewsBlock =
  | { id: string; type: "heading"; text: string }
  | { id: string; type: "paragraph"; text: string }
  | { id: string; type: "list"; text: string } // one bullet per line
  | { id: string; type: "quote"; text: string }
  | { id: string; type: "image"; src: string; caption: string };

export interface NewsComment { id: string; author: string; body: string; at: string }
export interface NewsArticle {
  id: string; title: string; summary: string; category: NewsCategory; ticker: string; source: string;
  author: string; publishedAt: string; cover: string | null; blocks: NewsBlock[]; comments: NewsComment[];
}

const KEY = "aurevia.news.v2";
export const uid = (p: string) => `${p}_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;

function load(): NewsArticle[] {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) {
      const list = (JSON.parse(raw).articles ?? []) as NewsArticle[];
      // Legacy category "Komoditas" (mining era) maps to the banking category.
      return list.map((a) => ((a.category as string) === "Komoditas" ? { ...a, category: "Perbankan & Moneter" as NewsCategory } : a));
    }
  } catch { /* ignore */ }
  return [];
}

let articles: NewsArticle[] = load();
const listeners = new Set<() => void>();
/** Returns false (and keeps previous state) when the browser storage quota is exceeded. */
function commit(next: NewsArticle[]): boolean {
  try { localStorage.setItem(KEY, JSON.stringify({ articles: next })); } catch { return false; }
  articles = next;
  listeners.forEach((l) => l());
  return true;
}

export const newsActions = {
  publish(a: Omit<NewsArticle, "id" | "publishedAt" | "comments">): string | null {
    const art: NewsArticle = { ...a, id: uid("news"), publishedAt: new Date().toISOString(), comments: [] };
    return commit([art, ...articles]) ? art.id : null;
  },
  remove(id: string) { commit(articles.filter((a) => a.id !== id)); },
  comment(articleId: string, author: string, body: string) {
    const c: NewsComment = { id: uid("c"), author, body, at: new Date().toISOString() };
    commit(articles.map((a) => a.id === articleId ? { ...a, comments: [...a.comments, c] } : a));
  },
  removeComment(articleId: string, commentId: string) {
    commit(articles.map((a) => a.id === articleId ? { ...a, comments: a.comments.filter((c) => c.id !== commentId) } : a));
  },
};

export function useNews() {
  const list = useSyncExternalStore((cb) => { listeners.add(cb); return () => { listeners.delete(cb); }; }, () => articles);
  return { articles: list, role: getRole(), ...newsActions };
}

/** Reads an image file and downsizes it to a JPEG data URL so it fits in localStorage. */
export function imageToDataUrl(file: File, maxSide = 1400, quality = 0.8): Promise<string> {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      const k = Math.min(1, maxSide / Math.max(img.width, img.height));
      const c = document.createElement("canvas");
      c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
      const ctx = c.getContext("2d");
      if (!ctx) { URL.revokeObjectURL(url); return reject(new Error("canvas")); }
      ctx.fillStyle = "#14141C"; ctx.fillRect(0, 0, c.width, c.height);
      ctx.drawImage(img, 0, 0, c.width, c.height);
      URL.revokeObjectURL(url);
      resolve(c.toDataURL("image/jpeg", quality));
    };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error("image")); };
    img.src = url;
  });
}
