// Market & macro CONTEXT. Never an input to the Fuzzy Mamdani model.
// Live sources that are free, keyless and browser-callable (CORS) are fetched directly:
//   · World Bank Indicators API — Indonesia macro (annual)
//   · Frankfurter (ECB reference rates) — USD/IDR (daily, business days)
import { useEffect, useState } from "react";
import { getKey, useKeysVersion } from "./apiKeys";

export interface Point { t: string; v: number }
export interface MacroSeries { id: string; label: string; unit: string; source: string; points: Point[] }

export const WB_INDICATORS = [
  { id: "FP.CPI.TOTL.ZG", label: "Inflasi (CPI)", unit: "%" },
  { id: "NY.GDP.MKTP.KD.ZG", label: "Pertumbuhan PDB", unit: "%" },
  { id: "FR.INR.LEND", label: "Suku bunga kredit", unit: "%" },
] as const;

async function json(url: string) {
  const r = await fetch(url);
  if (!r.ok) throw new Error(`${r.status}`);
  return r.json();
}

export async function fetchWorldBank(id: string): Promise<Point[]> {
  const d = await json(`https://api.worldbank.org/v2/country/IDN/indicator/${id}?format=json&per_page=12`);
  return ((d?.[1] ?? []) as { date: string; value: number | null }[])
    .filter((x) => x.value != null).map((x) => ({ t: x.date, v: x.value as number })).reverse();
}

export async function fetchUsdIdr(days = 60): Promise<Point[]> {
  const start = new Date(Date.now() - days * 864e5).toISOString().slice(0, 10);
  const d = await json(`https://api.frankfurter.app/${start}..?from=USD&to=IDR`);
  return Object.entries(d.rates as Record<string, { IDR: number }>).map(([t, r]) => ({ t, v: r.IDR }));
}

/* ─── Hooks (module cache so Overview and the dashboard share one fetch) ─── */
type Load<T> = { data: T | null; error: string | null; loading: boolean; at: string | null };
const cache = new Map<string, Promise<unknown>>();
const once = <T,>(key: string, fn: () => Promise<T>) => {
  if (!cache.has(key)) cache.set(key, fn().catch((e) => { cache.delete(key); throw e; }));
  return cache.get(key) as Promise<T>;
};

function useLoad<T>(key: string, fn: () => Promise<T>, pollMs?: number): Load<T> {
  const [s, setS] = useState<Load<T>>({ data: null, error: null, loading: true, at: null });
  useEffect(() => {
    let live = true;
    const run = (fresh: boolean) => {
      if (fresh) cache.delete(key);
      once(key, fn).then((data) => live && setS({ data, error: null, loading: false, at: new Date().toISOString() }))
        .catch((e) => live && setS((p) => ({ ...p, error: String(e?.message ?? e), loading: false })));
    };
    run(false);
    const id = pollMs ? window.setInterval(() => run(true), pollMs) : undefined;
    return () => { live = false; if (id) window.clearInterval(id); };
  }, [key]); // eslint-disable-line react-hooks/exhaustive-deps
  return s;
}

export const useUsdIdr = () => useLoad("usdidr", () => fetchUsdIdr());
export const useMacro = () => useLoad("wb", () => Promise.all(WB_INDICATORS.map(async (i) => ({
  ...i, source: "World Bank", points: await fetchWorldBank(i.id).catch(() => [] as Point[]),
} satisfies MacroSeries))));

/* ─── Keyed free-tier providers (optional; see apiKeys.ts) ─────────────
   Responses are cached in localStorage with a TTL so free quotas are respected across reloads. */
const MIN = 6e4;
function persisted<T>(key: string, ttl: number, fn: () => Promise<T>): Promise<T> {
  const k = `ssi.mkt.${key}`;
  try {
    const hit = JSON.parse(localStorage.getItem(k) ?? "null") as { at: number; data: T } | null;
    if (hit && Date.now() - hit.at < ttl) return Promise.resolve(hit.data);
  } catch { /* ignore corrupt cache */ }
  return fn().then((data) => { localStorage.setItem(k, JSON.stringify({ at: Date.now(), data })); return data; });
}

export type SourceState = "nokey" | "loading" | "live" | "error";
export const sourceState = (hasKey: boolean, l: Load<unknown>): SourceState =>
  !hasKey ? "nokey" : l.loading ? "loading" : l.error ? "error" : "live";

export interface Quote { ticker: string; price: number; changePct: number; history: Point[]; source: string }

async function quoteFmp(t: string, key: string): Promise<Quote> {
  const sym = t.startsWith("^") ? t : `${t}.JK`;
  const [q, h] = await Promise.all([
    json(`https://financialmodelingprep.com/api/v3/quote/${encodeURIComponent(sym)}?apikey=${key}`),
    json(`https://financialmodelingprep.com/api/v3/historical-price-full/${encodeURIComponent(sym)}?timeseries=90&apikey=${key}`),
  ]);
  if (!Array.isArray(q) || !q[0]) throw new Error("no data");
  const hist = ((h?.historical ?? []) as { date: string; close: number }[]).map((x) => ({ t: x.date, v: x.close })).reverse();
  return { ticker: t, price: q[0].price, changePct: q[0].changesPercentage, history: hist, source: "FMP" };
}

async function quoteTwelve(t: string, key: string): Promise<Quote> {
  const sym = t === "^JKSE" ? "symbol=JKSE" : `symbol=${t}&exchange=IDX`;
  const d = await json(`https://api.twelvedata.com/time_series?${sym}&interval=1day&outputsize=90&apikey=${key}`);
  if (d.status === "error" || !d.values?.length) throw new Error(d.message ?? "no data");
  const hist = (d.values as { datetime: string; close: string }[]).map((x) => ({ t: x.datetime, v: +x.close })).reverse();
  const l = hist[hist.length - 1].v, p = hist[hist.length - 2]?.v ?? l;
  return { ticker: t, price: l, changePct: ((l - p) / p) * 100, history: hist, source: "Twelve Data" };
}

export async function fetchQuote(t: string): Promise<Quote> {
  const fmp = getKey("fmp"), td = getKey("twelvedata");
  return persisted(`q.${t}`, 15 * MIN, async () => {
    if (fmp) { try { return await quoteFmp(t, fmp); } catch (e) { if (!td) throw e; } }
    return quoteTwelve(t, td);
  });
}

export interface NewsItem { headline: string; url: string; source: string; at: string }
const SECTOR_RX = /bank|perbankan|banking|suku bunga|interest rate|bi rate|rate cut|rate hike|kredit|credit|loan|ojk|lps|inflasi|inflation|rupiah|indonesia|monetary|moneter|financial|lender|deposit/i;
export async function fetchSectorNews(key: string): Promise<NewsItem[]> {
  return persisted("finnhub.news", 30 * MIN, async () => {
    const d = (await json(`https://finnhub.io/api/v1/news?category=general&token=${key}`)) as { headline: string; url: string; source: string; datetime: number }[];
    const rel = d.filter((n) => SECTOR_RX.test(n.headline));
    return (rel.length >= 3 ? rel : d).slice(0, 6).map((n) => ({ headline: n.headline, url: n.url, source: n.source, at: new Date(n.datetime * 1000).toISOString() }));
  });
}

export function useQuotes(tickers: string[]) {
  const v = useKeysVersion();
  const has = !!(getKey("fmp") || getKey("twelvedata"));
  const list = [...new Set(tickers)].sort();
  const l = useLoad(`quotes.${v}.${list.join(",")}`, async () => {
    if (!has) return {} as Record<string, Quote>;
    const r = await Promise.allSettled(list.map(fetchQuote));
    const out: Record<string, Quote> = {};
    r.forEach((x, i) => { if (x.status === "fulfilled") out[list[i]] = x.value; });
    if (list.length && !Object.keys(out).length) throw new Error("Tidak ada harga yang berhasil dimuat");
    return out;
  });
  return { ...l, state: sourceState(has, l) };
}

export function useSectorNews() {
  const v = useKeysVersion();
  const k = getKey("finnhub");
  const l = useLoad(`news.${v}`, async () => (k ? fetchSectorNews(k) : []));
  return { ...l, state: sourceState(!!k, l) };
}
