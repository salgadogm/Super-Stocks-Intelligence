// Issuer registry — derived ONLY from reports the user uploaded and confirmed. There is no pre-seeded list:
// an issuer (company name + IDX code) exists in Super Stocks Intelligence once its report has been uploaded.
import { MONTH_PERIODS, type AllowedStatementType, type ReportingPeriod } from "./financial";

export interface Issuer { code: string; name: string; docs: number; fiscalYears: number[] }

/** Number of consecutive FY reports required for a full trend window. */
export const WINDOW_YEARS = 5;

export function issuersFrom(docs: { ticker: string; companyName: string; period: { fiscalYear: number; period: ReportingPeriod } }[]): Issuer[] {
  const m = new Map<string, Issuer>();
  for (const d of docs) {
    const cur = m.get(d.ticker) ?? { code: d.ticker, name: d.companyName, docs: 0, fiscalYears: [] };
    cur.docs += 1;
    if (!cur.name && d.companyName) cur.name = d.companyName;
    if (d.period.period === "FY" && !cur.fiscalYears.includes(d.period.fiscalYear)) cur.fiscalYears.push(d.period.fiscalYear);
    m.set(d.ticker, cur);
  }
  return [...m.values()].map((i) => ({ ...i, fiscalYears: i.fiscalYears.sort() })).sort((a, b) => a.code.localeCompare(b.code));
}

/** The 5-year window ending at the latest available FY, with which years are present. */
export function coverageWindow(years: number[], end?: number) {
  const last = end ?? (years.length ? Math.max(...years) : new Date().getFullYear() - 1);
  const window = Array.from({ length: WINDOW_YEARS }, (_, i) => last - WINDOW_YEARS + 1 + i);
  const have = window.filter((y) => years.includes(y));
  return { window, have, complete: have.length === WINDOW_YEARS, missing: window.filter((y) => !years.includes(y)) };
}

/* ─── Identity suggestion ────────────────────────────
   No AI extraction provider is connected, so identity is SUGGESTED deterministically from the
   file name and previously confirmed issuers. Every suggestion must be checked manually by the user. */
export type StatementCoverage = AllowedStatementType | "both";
export interface IdentitySuggestion {
  ticker: string; companyName: string; fiscalYear: string; period: ReportingPeriod; statement: StatementCoverage;
  matched: ("ticker" | "year" | "statement" | "period")[];
}

/** File-name month tokens, Jan..Dec. December is excluded from monthly detection (a December report is the FY). */
const MONTH_TOKENS = [
  ["JAN", "JANUARI", "JANUARY"], ["FEB", "FEBRUARI", "FEBRUARY"], ["MAR", "MARET", "MARCH"], ["APR", "APRIL"], ["MEI", "MAY"], ["JUN", "JUNI", "JUNE"],
  ["JUL", "JULI", "JULY"], ["AGU", "AGS", "AGUSTUS", "AUG", "AUGUST"], ["SEP", "SEPT", "SEPTEMBER"], ["OKT", "OCT", "OKTOBER", "OCTOBER"],
  ["NOV", "NOVEMBER"], ["DES", "DEC", "DESEMBER", "DECEMBER"],
];

const STOP = new Set(["SEPT", "JUNI", "JULI", "JUNE", "JULY", "MARET", "MARCH", "APRIL", "LAPK", "TBK", "FULL", "YEAR", "AUDI", "LAPO", "KEUA", "DRAF", "PERS", "FINA", "ANNU", "LAPORAN", "INCOME", "BALANCE", "NERACA"]);

export function suggestIdentity(fileName: string, known: Issuer[]): IdentitySuggestion {
  const base = fileName.replace(/\.[a-z0-9]+$/i, "");
  const tokens = base.toUpperCase().split(/[^A-Z0-9]+/).filter(Boolean);
  const lower = base.toLowerCase();
  const matched: IdentitySuggestion["matched"] = [];

  const knownHit = known.find((i) => tokens.includes(i.code));
  const raw = knownHit?.code ?? tokens.find((t) => /^[A-Z]{4}$/.test(t) && !STOP.has(t)) ?? "";
  if (raw) matched.push("ticker");

  const years = base.match(/20\d{2}/g);
  const fiscalYear = years ? years[years.length - 1] : "";
  if (fiscalYear) matched.push("year");

  const q = tokens.find((t) => /^(Q[1-3]|TW[1-3])$/.test(t));
  const monthIdx = q ? -1 : tokens.map((t) => MONTH_TOKENS.findIndex((names) => names.includes(t))).find((i) => i >= 0 && i < 11) ?? -1;
  const period = (q ? `Q${q.slice(-1)}` : monthIdx >= 0 ? MONTH_PERIODS[monthIdx] : "FY") as ReportingPeriod;
  if (monthIdx >= 0) matched.push("period");
  if (q) matched.push("period");

  const pl = /laba|rugi|profit|loss|income|\bpl\b|\bpnl\b/.test(lower);
  const sfp = /neraca|posisi|position|balance|\bsfp\b|\bbs\b/.test(lower);
  const statement: StatementCoverage = pl && !sfp ? "profit_loss" : sfp && !pl ? "financial_position" : "both";
  if (pl !== sfp) matched.push("statement");

  return { ticker: raw, companyName: knownHit?.name ?? "", fiscalYear, period, statement, matched };
}

/* ─── Bank segments (context only) ───────────────────
   Ownership/business segment per known IDX-IC Financials (Banks) issuer, used to group uploaded issuers on Overview.
   Never an input to the Fuzzy Mamdani model. */
export type BankSegment = "BUMN" | "Swasta";
export const BANK_SEGMENTS: Record<string, BankSegment> = {
  BBRI: "BUMN", BMRI: "BUMN", BBNI: "BUMN", BBTN: "BUMN",
  BBCA: "Swasta", BDMN: "Swasta", BNGA: "Swasta", PNBN: "Swasta", MEGA: "Swasta", BNII: "Swasta", NISP: "Swasta", BTPN: "Swasta",
};
/** Upload guard only: sharia banks are not in the registry and cannot be uploaded (ratios FDR, NPF, NOM are not comparable). */
export const SHARIA_BANKS = ["BRIS", "BTPS", "PNBS"];
export const isSharia = (code: string) => SHARIA_BANKS.includes(code.toUpperCase());
export const bankSegmentOf = (code: string): BankSegment | undefined => BANK_SEGMENTS[code.toUpperCase()];

/* ─── Fixed registry of IDX banks ─────────────────────
   Codes/names are from general knowledge and must be reviewed by the user. A listed bank has NO score until its
   consolidated report is uploaded and verified; scores are never invented. */
export const ALL_BANKS: Record<string, string> = {
  AGRO: "Bank Raya Indonesia", AMAR: "Bank Amar Indonesia", ARTO: "Bank Jago", BABP: "Bank MNC Internasional", BACA: "Bank Capital Indonesia",
  BBCA: "Bank Central Asia", BBHI: "Allo Bank Indonesia", BBKP: "Bank KB Bukopin", BBMD: "Bank Mestika Dharma", BBNI: "Bank Negara Indonesia",
  BBRI: "Bank Rakyat Indonesia", BBTN: "Bank Tabungan Negara", BBYB: "Bank Neo Commerce", BCIC: "Bank JTrust Indonesia", BDMN: "Bank Danamon Indonesia",
  BGTG: "Bank Ganesha", BINA: "Bank Ina Perdana", BJBR: "Bank Pembangunan Daerah Jawa Barat dan Banten", BJTM: "Bank Pembangunan Daerah Jawa Timur",
  BKSW: "Bank QNB Indonesia", BMAS: "Bank Maspion Indonesia", BMRI: "Bank Mandiri", BNBA: "Bank Bumi Arta", BNGA: "Bank CIMB Niaga", BNII: "Bank Maybank Indonesia",
  BNLI: "Bank Permata", BSIM: "Bank Sinarmas", BVIC: "Bank Victoria International", DNAR: "Bank Oke Indonesia", MAYA: "Bank Mayapada Internasional",
  MCOR: "Bank China Construction Bank Indonesia", MEGA: "Bank Mega", NISP: "Bank OCBC NISP", NOBU: "Bank Nationalnobu", PNBN: "Bank Pan Indonesia",
  SDRA: "Bank Woori Saudara Indonesia 1906", BTPN: "Bank BTPN",
  AGRS: "Bank IBK Indonesia", BBSI: "Krom Bank Indonesia", BSWD: "Bank of India Indonesia", INPC: "Bank Artha Graha Internasional",
};

export interface RegistryRow { code: string; name: string; sharia: boolean }
/** Fixed registry merged with any uploaded issuer outside it. */
export function registryWith(uploaded: Issuer[]): RegistryRow[] {
  const m = new Map<string, RegistryRow>(Object.entries(ALL_BANKS).map(([code, name]) => [code, { code, name, sharia: isSharia(code) }]));
  for (const i of uploaded) if (!m.has(i.code)) m.set(i.code, { code: i.code, name: i.name, sharia: isSharia(i.code) });
  return [...m.values()].sort((a, b) => a.code.localeCompare(b.code));
}
