// In-browser PDF → text pass (no AI): finds SFP / P&L pages, unit, year columns and rule-based account matches.
import { extractPages, isScanned, findStatementPages, detectUnitScale, detectYears, detectPeriodMonth, estimateTokens } from "./pdfText";
import { matchAccounts, type AccountMatch } from "./accountMatcher";

/** Result of the in-browser PDF → text pass (no AI). */
export interface TextScan {
  status: "reading" | "done" | "scanned" | "error";
  progress: number; total: number;
  pages?: { profit_loss: number[]; financial_position: number[] };
  years?: number[];
  /** Month (1-12) of the period-end date printed in the statements; absent when not found or for older cached scans. */
  endMonth?: number;
  unitFound?: boolean;
  matches?: AccountMatch[];
  tokensAll?: number; tokensRelevant?: number;
  /** Text of the statement pages only (what an AI step would be allowed to see). */
  pagesText?: { page: number; statement: "profit_loss" | "financial_position"; text: string }[];
}

export async function scanPdf(file: File, onProgress: (d: number, t: number) => void): Promise<{ scan: TextScan; unit?: ReturnType<typeof detectUnitScale> }> {
  const pages = await extractPages(file, onProgress);
  if (isScanned(pages)) return { scan: { status: "scanned", progress: pages.length, total: pages.length } };
  const sp = findStatementPages(pages);
  const relevant = pages.filter((p) => sp.profit_loss.includes(p.page) || sp.financial_position.includes(p.page));
  const lines = relevant.flatMap((p) => p.lines);
  const relText = relevant.map((p) => p.text).join("\n");
  const unit = detectUnitScale(relText);
  return {
    unit,
    scan: {
      status: "done", progress: pages.length, total: pages.length, pages: sp, years: detectYears(lines), endMonth: detectPeriodMonth(relText) ?? undefined, unitFound: !!unit,
      matches: matchAccounts(lines, sp),
      tokensAll: estimateTokens(pages.map((p) => p.text).join("\n")), tokensRelevant: estimateTokens(relText),
      pagesText: relevant.map((p) => ({ page: p.page, statement: sp.profit_loss.includes(p.page) ? "profit_loss" as const : "financial_position" as const, text: p.text })),
    },
  };
}
