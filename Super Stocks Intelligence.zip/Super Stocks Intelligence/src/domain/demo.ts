// DEMO dataset — fictitious banks with illustrative numbers, for preview/walkthrough only.
// Not real IDX reports. Every record is flagged `demo: true` and badged "DEMO" in the UI.
// Scores are NOT stored here: they are computed by the engine from these verified accounts.
// Amounts are in IDR millions; EPS and share price are in IDR.
import { CANONICAL_ACCOUNTS, REQUIRED_ACCOUNTS, type CanonicalAccountId } from "./financial";
import { SIM_BANKS, TRAP, simAccounts, simPrice, simYears, type SimTicker } from "./simulation";
import { blankItem, type DocRecord, type MarketInput, type WorkingItem } from "./store";

type Acc = Record<CanonicalAccountId, number>;
const ROWS: { ticker: string; name: string; year: number; acc: Acc; price: number | null }[] = [
  { ticker: "DEMO-A", name: "PT Bank Contoh A Tbk (DEMO)", year: 2023, price: 4_500,
    acc: { net_income: 40_100_000, net_interest_income: 74_000_000, operating_income: 98_000_000, operating_expense: 50_000_000, basic_eps: 325, total_assets: 1_408_000_000, total_equity: 192_000_000, total_loans: 900_000_000, third_party_funds: 1_050_000_000 } },
  { ticker: "DEMO-A", name: "PT Bank Contoh A Tbk (DEMO)", year: 2024, price: 4_900,
    acc: { net_income: 45_000_000, net_interest_income: 80_000_000, operating_income: 105_000_000, operating_expense: 54_000_000, basic_eps: 365, total_assets: 1_500_000_000, total_equity: 205_000_000, total_loans: 950_000_000, third_party_funds: 1_120_000_000 } },
  { ticker: "DEMO-B", name: "PT Bank Contoh B Tbk (DEMO)", year: 2023, price: 520,
    acc: { net_income: 4_200_000, net_interest_income: 26_000_000, operating_income: 34_000_000, operating_expense: 30_500_000, basic_eps: 28, total_assets: 800_000_000, total_equity: 55_000_000, total_loans: 640_000_000, third_party_funds: 560_000_000 } },
  { ticker: "DEMO-B", name: "PT Bank Contoh B Tbk (DEMO)", year: 2024, price: 480,
    acc: { net_income: 4_800_000, net_interest_income: 26_500_000, operating_income: 35_000_000, operating_expense: 31_000_000, basic_eps: 32, total_assets: 830_000_000, total_equity: 57_000_000, total_loans: 665_000_000, third_party_funds: 580_000_000 } },
  // DEMO-C has no 2023 report (missing period stays missing) and no 2024 share price (PER not computable).
  { ticker: "DEMO-C", name: "PT Bank Contoh C Tbk (DEMO)", year: 2022, price: 1_300,
    acc: { net_income: 3_300_000, net_interest_income: 13_500_000, operating_income: 18_000_000, operating_expense: 13_500_000, basic_eps: 110, total_assets: 300_000_000, total_equity: 36_000_000, total_loans: 190_000_000, third_party_funds: 230_000_000 } },
  { ticker: "DEMO-C", name: "PT Bank Contoh C Tbk (DEMO)", year: 2024, price: null,
    acc: { net_income: 4_300_000, net_interest_income: 15_500_000, operating_income: 20_500_000, operating_expense: 14_900_000, basic_eps: 143, total_assets: 340_000_000, total_equity: 41_000_000, total_loans: 220_000_000, third_party_funds: 262_000_000 } },
];

// BBRI & BMRI illustrative series from the simulation; BMRI FY2025 is the year-mismatch trap and is never loaded.
const SIM_ROWS: typeof ROWS = (Object.keys(SIM_BANKS) as SimTicker[]).flatMap((t) =>
  simYears(t).filter((y) => !(t === TRAP.ticker && y === TRAP.year)).map((y) => (
    { ticker: t, name: `${SIM_BANKS[t].name} (DEMO)`, year: y, acc: simAccounts(t, y), price: simPrice(t, y) })));

export function buildDemo() {
  const documents: DocRecord[] = [];
  const items: WorkingItem[] = [];
  const market: MarketInput[] = [];
  const at = new Date().toISOString();
  for (const r of [...ROWS, ...SIM_ROWS]) {
    const id = `demo_${r.ticker}_${r.year}`;
    const doc: DocRecord = {
      id, ticker: r.ticker, companyName: r.name, period: { fiscalYear: r.year, period: "FY" }, subSector: "DEMO",
      fileName: `${r.ticker}_FY${r.year}_DEMO.pdf`, fileType: "pdf", fileSize: 0, currency: "IDR", unit: "millions",
      uploadedAt: at, status: "verified", version: 1, demo: true,
    };
    documents.push(doc);
    for (const a of REQUIRED_ACCOUNTS) {
      const ca = CANONICAL_ACCOUNTS[a];
      const v = r.acc[a];
      items.push({
        ...blankItem(doc, a), status: "verified", rawLabel: ca.aliases[0], rawValue: v.toLocaleString("en-US"),
        pageNumber: ca.statement === "profit_loss" ? 5 : 3, statementType: ca.statement,
        parsedValue: v, normalizedValue: v * (a === "basic_eps" ? 1 : 1e6), verifiedAt: at, verifiedBy: "DEMO", updatedAt: at,
      });
    }
    market.push({ documentId: id, sharePrice: r.price, currency: "IDR", priceDate: r.price ? `${r.year}-12-31` : "", source: r.price ? "DEMO (ilustratif)" : "" });
  }
  return { documents, items, market };
}
