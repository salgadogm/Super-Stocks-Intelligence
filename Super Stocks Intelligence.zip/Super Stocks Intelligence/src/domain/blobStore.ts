// IndexedDB store for uploaded report files and cached page text (localStorage cannot hold 50 MB PDFs).
const DB = "ssi-files";
const FILES = "files";
const TEXTS = "texts";

let dbp: Promise<IDBDatabase> | null = null;
function open(): Promise<IDBDatabase> {
  if (dbp) return dbp;
  dbp = new Promise((resolve, reject) => {
    const req = indexedDB.open(DB, 1);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(FILES)) db.createObjectStore(FILES);
      if (!db.objectStoreNames.contains(TEXTS)) db.createObjectStore(TEXTS);
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => { dbp = null; reject(req.error); };
  });
  return dbp;
}

async function run<T>(store: string, mode: IDBTransactionMode, fn: (s: IDBObjectStore) => IDBRequest<T>): Promise<T> {
  const db = await open();
  return new Promise<T>((resolve, reject) => {
    const tx = db.transaction(store, mode);
    const req = fn(tx.objectStore(store));
    tx.oncomplete = () => resolve(req.result);
    tx.onerror = () => reject(tx.error);
    tx.onabort = () => reject(tx.error);
  });
}

export const putFile = (id: string, file: File): Promise<void> => run(FILES, "readwrite", (s) => s.put(file, id)).then(() => undefined);
export const getFile = (id: string): Promise<File | undefined> => run<File | undefined>(FILES, "readonly", (s) => s.get(id));
export const deleteFile = async (id: string): Promise<void> => {
  await run(FILES, "readwrite", (s) => s.delete(id));
  await run(TEXTS, "readwrite", (s) => s.delete(id));
};
export const putText = <T,>(id: string, data: T): Promise<void> => run(TEXTS, "readwrite", (s) => s.put(data, id)).then(() => undefined);
export const getText = <T = unknown,>(id: string): Promise<T | undefined> => run<T | undefined>(TEXTS, "readonly", (s) => s.get(id));
