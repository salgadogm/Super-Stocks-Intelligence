// Super Stocks Intelligence — client-side workspace store.
// Holds the whole pipeline: document → original extraction → verified dataset → analysis.
// Persisted to localStorage only (no backend). Uploaded file bytes live in memory for the session.
import { createContext, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { putFile, getFile, deleteFile, putText, getText } from "./blobStore";
import { scanPdf, type TextScan } from "./pdfScan";
import { aiExtract } from "./aiExtract";
import { getKey } from "./apiKeys";
import {
  CANONICAL_ACCOUNTS, MODEL_VERSION, RATIO_DEFINITIONS, REQUIRED_ACCOUNTS, UNIT_MULTIPLIER,
  isAllowedStatement, isMonthly, monthOf, parseStatementNumber, periodText,
  type AnalysisStatus, type CanonicalAccountId, type Currency, type ExtractedFinancialItem,
  type FinancialDocument, type FinancialPeriod, type RatioKey, type StatementType, type UnitScale,
  type VerificationStatus, type VerifiedFinancialItem,
} from "./financial";
import type { StatementCoverage } from "./issuers";
import { track } from "./usage";
import { translate } from "../i18n";
import { getLang } from "./preferences";
const T_ = (k: string, v?: Record<string, string | number>) => translate(getLang(), k, v);
import { VAR_KEYS, computeFuzzy, categoryOf, type ModelCategory } from "./engine";

/** True when an Anthropic key is configured (env or set by the admin on this device). Without it extraction stops at rules. */
export const hasAi = (): boolean => !!getKey("anthropic");

export interface PullProgress { stage: "reading" | "extracting" | "filling"; done?: number; total?: number }
export interface PullResult { filled: number; ai: number; missing: CanonicalAccountId[] }
/** Thrown when the year read from a PDF differs from the fiscal year the document is filed under. */
export class YearMismatchError extends Error {
  constructor(public ticker: string, public expected: number, public found: number, public source: "pdf" | "ai", public months?: { expected: number; found: number }) {
    super(months
      ? `Bulan tidak cocok: ${ticker} berlabel bulan ke-${months.expected}, tetapi PDF terbaca bulan ke-${months.found}`
      : `Tahun tidak cocok: ${ticker} berlabel FY${expected}, tetapi ${source === "ai" ? "AI membaca kolom" : "PDF terbaca"} ${found}`);
  }
}

export interface DocRecord extends FinancialDocument {
  demo?: boolean;
  subSector?: string;
  /** Files that make up this period (P&L and SFP may arrive as separate files), each confirmed by the user. */
  sources?: { fileName: string; fileSize: number; statement: StatementCoverage }[];
}

/** Working row for one required account. `source*` fields describe where the value is printed. */
export interface WorkingItem extends VerifiedFinancialItem {
  rawLabel: string;
  rawValue: string;
  pageNumber: number | null;
  statementType: StatementType | null;
  updatedAt: string;
}

export interface MarketInput {
  documentId: string;
  sharePrice: number | null;
  currency: Currency;
  priceDate: string;
  source: string;
}

export interface AnalysisRecord {
  id: string;
  documentId: string;
  ticker: string;
  companyName: string;
  period: FinancialPeriod;
  modelVersion: string;
  calculatedAt: string;
  accounts: Partial<Record<CanonicalAccountId, number>>;
  sharePrice: number | null;
  ratios: Record<RatioKey, number>;
  strengths: number[];
  classStrength: number[];
  score: number;
  category: ModelCategory;
  demo?: boolean;
}

export interface ActivityEvent { at: string; title: string; detail: string }

export interface State {
  documents: DocRecord[];
  extractions: ExtractedFinancialItem[];
  items: WorkingItem[];
  market: MarketInput[];
  analyses: AnalysisRecord[];
  watchlist: string[];
  events: ActivityEvent[];
}

export const EMPTY: State = { documents: [], extractions: [], items: [], market: [], analyses: [], watchlist: [], events: [] };
const KEY = "aurevia.workspace.v1";
const now = () => new Date().toISOString();
const uid = (p: string) => `${p}_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;

// Data saved under the pre-banking model uses account ids and ratios that no longer exist: drop them,
// add blank rows for the new required accounts and discard analyses from another model version.
export function migrate(s: State): State {
  const valid = (a: string) => a in CANONICAL_ACCOUNTS;
  const items = s.items.filter((i) => valid(i.canonicalAccount));
  const extractions = s.extractions.filter((i) => valid((i as { canonicalAccount: string }).canonicalAccount));
  const analyses = s.analyses.filter((a) => a.modelVersion === MODEL_VERSION);
  const have = new Set(items.map((i) => `${i.documentId}|${i.canonicalAccount}`));
  const added: WorkingItem[] = [];
  const documents = s.documents.map((d) => {
    const missing = REQUIRED_ACCOUNTS.filter((a) => !have.has(`${d.id}|${a}`));
    if (!missing.length) return d;
    added.push(...missing.map((a) => blankItem(d, a)));
    return { ...d, status: "needs_verification" as DocRecord["status"] };
  });
  return { ...s, documents, items: [...items, ...added], extractions, analyses };
}

function load(): State {
  try {
    const raw = localStorage.getItem(KEY);
    return raw ? migrate({ ...EMPTY, ...JSON.parse(raw) }) : EMPTY;
  } catch { return EMPTY; }
}

/** EPS is printed per share in full currency units, so the report's scale is not applied to it. */
export const multiplierFor = (acc: CanonicalAccountId, unit: UnitScale) => (acc === "basic_eps" ? 1 : UNIT_MULTIPLIER[unit]);

export const blankItem = (doc: DocRecord, acc: CanonicalAccountId): WorkingItem => ({
  documentId: doc.id, canonicalAccount: acc, sourceItemId: null, status: "needs_review",
  parsedValue: null, unitMultiplier: multiplierFor(acc, doc.unit), normalizedValue: null, edited: false,
  rawLabel: "", rawValue: "", pageNumber: null, statementType: null, updatedAt: now(),
});

/* ─── Derived helpers (pure) ─────────────────────── */
export type RatioResult = { key: RatioKey; value: number | null; missing: string[] };

export function verifiedAccounts(items: WorkingItem[], docId: string) {
  const out: Partial<Record<CanonicalAccountId, number>> = {};
  for (const it of items) {
    if (it.documentId === docId && it.status === "verified" && it.normalizedValue != null) out[it.canonicalAccount] = it.normalizedValue;
  }
  return out;
}

export function computeRatios(acc: Partial<Record<CanonicalAccountId, number>>, market?: MarketInput, docCurrency?: Currency): RatioResult[] {
  return VAR_KEYS.map((k) => {
    const def = RATIO_DEFINITIONS[k];
    const missing = def.requiredAccounts.filter((a) => acc[a] == null).map((a) => T_(CANONICAL_ACCOUNTS[a].labelId));
    const ext: { share_price?: number } = {};
    if (def.externalInputs.includes("share_price")) {
      if (market?.sharePrice == null) missing.push(T_("Harga saham (input pasar eksternal)"));
      else if (docCurrency && market.currency !== docCurrency) missing.push(T_("Harga saham dalam {cur} (mata uang tidak sama, tidak dikonversi)", { cur: docCurrency }));
      else ext.share_price = market.sharePrice;
    }
    const value = missing.length ? null : def.compute(acc, ext);
    if (value == null && !missing.length) missing.push(T_("Pembagi bernilai nol"));
    return { key: k, value, missing };
  });
}

export const docLabel = (d: Pick<DocRecord, "ticker" | "period">) => `${d.ticker} · ${periodText(d.period)}`;
export const periodSort = (p: FinancialPeriod) => p.fiscalYear * 100 + (p.period === "FY" ? 13 : p.period[0] === "Q" ? Number(p.period[1]) * 3 + 0.5 : monthOf(p.period));

/** Pure: verified items → ratios → Fuzzy Mamdani. Returns an error message when inputs are incomplete. */
export function buildAnalysis(doc: DocRecord, items: WorkingItem[], market?: MarketInput): AnalysisRecord | string {
  const docItems = items.filter((i) => i.documentId === doc.id);
  if (!docItems.length || docItems.some((i) => i.status !== "verified")) return T_("Semua akun wajib harus berstatus Verified sebelum kalkulasi.");
  const acc = verifiedAccounts(items, doc.id);
  const ratios = computeRatios(acc, market, doc.currency);
  const missing = ratios.filter((r) => r.value == null);
  if (missing.length) return `${T_("Rasio belum dapat dihitung:")} ${missing.map((m) => `${m.key} (${m.missing.join(", ")})`).join("; ")}`;
  const vals = Object.fromEntries(ratios.map((r) => [r.key, r.value as number])) as Record<RatioKey, number>;
  const f = computeFuzzy(vals);
  return {
    id: uid("an"), documentId: doc.id, ticker: doc.ticker, companyName: doc.companyName, period: doc.period,
    modelVersion: MODEL_VERSION, calculatedAt: now(), accounts: acc, sharePrice: market?.sharePrice ?? null,
    ratios: vals, strengths: f.strengths, classStrength: f.classStrength, score: f.score, category: categoryOf(f.score), demo: doc.demo,
  };
}

/* ─── Hook ───────────────────────────────────────── */
function useWorkspaceState() {
  const [s, setS] = useState<State>(load);
  const [files, setFiles] = useState<Record<string, string>>({}); // docId → object URL (session only)
  const filesRef = useRef(files);
  filesRef.current = files;
  const [focusDoc, setFocusDoc] = useState<string | null>(null); // document the user is working on
  useEffect(() => { try { localStorage.setItem(KEY, JSON.stringify(s)); } catch { /* quota */ } }, [s]);

  const log = (st: State, title: string, detail: string): State =>
    ({ ...st, events: [{ at: now(), title, detail }, ...st.events].slice(0, 60) });

  const updateItem = (docId: string, acc: CanonicalAccountId, patch: Partial<Pick<WorkingItem, "rawLabel" | "rawValue" | "pageNumber" | "statementType" | "note">>) => {
    setS((st) => ({
      ...st,
      items: st.items.map((it) => {
        if (it.documentId !== docId || it.canonicalAccount !== acc) return it;
        const next = { ...it, ...patch, edited: true, updatedAt: now() };
        const parsed = parseStatementNumber(next.rawValue);
        next.parsedValue = parsed;
        next.normalizedValue = parsed == null ? null : parsed * next.unitMultiplier;
        // any edit to a decided row re-opens it for review
        if (it.status !== "needs_review") next.status = "needs_review";
        return next;
      }),
    }));
  };

  const actions = {
    addDocument(meta: Omit<DocRecord, "id" | "uploadedAt" | "status" | "version">, file?: File) {
      const id = uid("doc");
      track("upload", "Upload Laporan");
      const version = s.documents.filter((d) => d.ticker === meta.ticker && d.period.fiscalYear === meta.period.fiscalYear && d.period.period === meta.period.period).length + 1;
      const doc: DocRecord = { ...meta, id, uploadedAt: now(), status: "needs_verification", version };
      if (file) {
        const url = URL.createObjectURL(file);
        filesRef.current = { ...filesRef.current, [id]: url };
        setFiles((f) => ({ ...f, [id]: url }));
        putFile(id, file).catch(() => { /* IndexedDB unavailable or quota: file stays session-only */ });
      }
      setS((st) => log({
        ...st,
        documents: [doc, ...st.documents],
        items: [...st.items, ...REQUIRED_ACCOUNTS.map((a) => blankItem(doc, a))],
        market: [...st.market, { documentId: id, sharePrice: null, currency: doc.currency, priceDate: "", source: "" }],
      }, "Laporan diunggah", `${docLabel(doc)} · ${doc.fileName}`));
      return id;
    },
    attachFile(docId: string, file: File) {
      const url = URL.createObjectURL(file);
      filesRef.current = { ...filesRef.current, [docId]: url };
      setFiles((f) => ({ ...f, [docId]: url }));
      putFile(docId, file).catch(() => { /* session-only */ });
    },
    /** Returns an object URL for the stored PDF (memoized in `files`), or undefined when no file is stored. */
    async openFile(docId: string): Promise<string | undefined> {
      const have = filesRef.current[docId];
      if (have) return have;
      try {
        const f = await getFile(docId);
        if (!f) return undefined;
        const again = filesRef.current[docId];
        if (again) return again;
        const url = URL.createObjectURL(f);
        filesRef.current = { ...filesRef.current, [docId]: url };
        setFiles((x) => ({ ...x, [docId]: url }));
        return url;
      } catch { return undefined; }
    },
    /**
     * Pull flow: stored PDF → text (cached) → rule matches → AI only for still-missing accounts (if a key exists)
     * → rows filled with status needs_review, source tagged "[rule]" / "[ai]" at the start of the item note.
     */
    async pullFromCollection(docId: string, userKey: string, onProgress?: (p: PullProgress) => void): Promise<PullResult> {
      const doc = s.documents.find((d) => d.id === docId);
      if (!doc) return { filled: 0, ai: 0, missing: [...REQUIRED_ACCOUNTS] };
      track("pick_report", docLabel(doc));
      onProgress?.({ stage: "reading" });
      const file = await getFile(docId).catch(() => undefined);
      let scan: TextScan | undefined = await getText<{ scan: TextScan }>(docId).then((c) => c?.scan).catch(() => undefined);
      if (!scan) {
        if (!file) return { filled: 0, ai: 0, missing: [...REQUIRED_ACCOUNTS] };
        const r = await scanPdf(file, (done, total) => onProgress?.({ stage: "reading", done, total }));
        scan = r.scan;
        if (scan.status === "done") putText(docId, { scan, by: userKey }).catch(() => { /* cache is optional */ });
      }
      if (scan.status !== "done") return { filled: 0, ai: 0, missing: [...REQUIRED_ACCOUNTS] };

      onProgress?.({ stage: "extracting" });
      const year = scan.years?.[0];
      if (year && year !== doc.period.fiscalYear) throw new YearMismatchError(doc.ticker, doc.period.fiscalYear, year, "pdf");
      if (isMonthly(doc.period.period) && scan.endMonth && scan.endMonth !== monthOf(doc.period.period)) {
        throw new YearMismatchError(doc.ticker, doc.period.fiscalYear, year ?? doc.period.fiscalYear, "pdf", { expected: monthOf(doc.period.period), found: scan.endMonth });
      }
      const base = { documentId: docId, currency: doc.currency, unit: doc.unit, columnYear: year };
      const proposals: ExtractedFinancialItem[] = [];
      const fills: { acc: CanonicalAccountId; label: string; value: string; page: number; src: "rule" | "ai"; note: string }[] = [];
      for (const m of scan.matches ?? []) {
        if (fills.some((f) => f.acc === m.account)) continue;
        const st = CANONICAL_ACCOUNTS[m.account].statement;
        proposals.push({ ...base, id: `rule_${docId}_${m.account}`, canonicalAccount: m.account, rawLabel: m.label, rawValue: m.current,
          pageNumber: m.page, statementType: st, confidence: m.confidence === "high" ? 0.9 : 0.6 });
        fills.push({ acc: m.account, label: m.label, value: m.current, page: m.page, src: "rule",
          note: `[rule] Diusulkan otomatis (rule-based) dari teks PDF hlm. ${m.page}${m.prior ? ` · komparatif: ${m.prior}` : ""}. Wajib dicek.` });
      }
      let missing = REQUIRED_ACCOUNTS.filter((a) => !fills.some((f) => f.acc === a));
      let ai = 0;
      if (missing.length && hasAi() && scan.pagesText?.length) {
        try {
          const found = await aiExtract(scan.pagesText, missing);
          const bad = found.find((it) => it.columnYear && it.columnYear !== doc.period.fiscalYear);
          if (bad?.columnYear) throw new YearMismatchError(doc.ticker, doc.period.fiscalYear, bad.columnYear, "ai");
          for (const it of found) {
            if (!it.canonicalAccount || fills.some((f) => f.acc === it.canonicalAccount)) continue;
            proposals.push({ ...it, documentId: docId, currency: doc.currency, unit: doc.unit });
            fills.push({ acc: it.canonicalAccount, label: it.rawLabel, value: it.rawValue, page: it.pageNumber, src: "ai",
              note: `[ai] Dibaca AI dari teks PDF hlm. ${it.pageNumber}${it.columnYear ? ` · kolom ${it.columnYear}` : ""} (angka tervalidasi ada di halaman). Wajib dicek.` });
            ai++;
          }
        } catch (e) {
          if (e instanceof YearMismatchError) throw e;
        }
        missing = REQUIRED_ACCOUNTS.filter((a) => !fills.some((f) => f.acc === a));
      }

      onProgress?.({ stage: "filling" });
      setS((st) => ({ ...st, extractions: [...st.extractions.filter((e) => e.documentId !== docId), ...proposals] }));
      for (const f of fills) {
        updateItem(docId, f.acc, { rawLabel: f.label, rawValue: f.value, pageNumber: f.page, statementType: CANONICAL_ACCOUNTS[f.acc].statement, note: f.note });
      }
      track("extract", docLabel(doc));
      return { filled: fills.length, ai, missing };
    },
    removeDocument(id: string) {
      deleteFile(id).catch(() => { /* nothing stored */ });
      setS((st) => ({
        ...st,
        documents: st.documents.filter((d) => d.id !== id),
        items: st.items.filter((i) => i.documentId !== id),
        extractions: st.extractions.filter((i) => i.documentId !== id),
        market: st.market.filter((m) => m.documentId !== id),
        analyses: st.analyses.filter((a) => a.documentId !== id),
      }));
    },
    /** Updates the working row. Values are parsed deterministically from the printed text. */
    updateItem,
    setStatus(docId: string, acc: CanonicalAccountId, status: VerificationStatus, by: string): string | null {
      const it = s.items.find((i) => i.documentId === docId && i.canonicalAccount === acc);
      if (!it) return T_("Baris tidak ditemukan.");
      if (status === "verified") {
        if (it.statementType == null || it.pageNumber == null) return T_("Lengkapi halaman sumber dan jenis laporan sebelum verifikasi.");
        if (!isAllowedStatement(it.statementType)) status = "invalid_source";
        else if (it.statementType !== CANONICAL_ACCOUNTS[acc].statement) return `Akun ini harus berasal dari ${CANONICAL_ACCOUNTS[acc].statement === "profit_loss" ? "Profit and Loss" : "Statement of Financial Position"}.`;
        else if (it.normalizedValue == null) return T_("Nilai tidak dapat dibaca sebagai angka.");
      }
      setS((st) => {
        const items = st.items.map((i) => i === it ? { ...i, status, verifiedAt: now(), verifiedBy: by, updatedAt: now(), ...(status === "not_found" ? { parsedValue: null, normalizedValue: null } : {}) } : i);
        const docItems = items.filter((i) => i.documentId === docId);
        const done = docItems.every((i) => i.status === "verified");
        return {
          ...st, items,
          documents: st.documents.map((d) => d.id === docId ? { ...d, status: done ? "verified" : "needs_verification" } : d),
        };
      });
      return status === "invalid_source" ? T_("Sumber tidak diizinkan — baris ditandai Invalid Source.") : null;
    },
    setMarket(docId: string, patch: Partial<MarketInput>) {
      setS((st) => ({ ...st, market: st.market.map((m) => m.documentId === docId ? { ...m, ...patch } : m) }));
    },
    /** Runs ratio calculation + Fuzzy Mamdani. Refuses unless every required account is verified. */
    runAnalysis(docId: string): string | null {
      const doc = s.documents.find((d) => d.id === docId);
      if (!doc) return T_("Dokumen tidak ditemukan.");
      const r = buildAnalysis(doc, s.items, s.market.find((m) => m.documentId === docId));
      if (typeof r === "string") return r;
      track("calculate", "Skor & Defuzzifikasi");
      setS((st) => log({ ...st, analyses: [...st.analyses.filter((a) => a.documentId !== docId), r] },
        "Analisis dihitung", `${docLabel(doc)} · Skor Model ${r.score.toFixed(1)} (${r.category})`));
      return null;
    },
    toggleWatch(ticker: string) {
      setS((st) => ({ ...st, watchlist: st.watchlist.includes(ticker) ? st.watchlist.filter((t) => t !== ticker) : [...st.watchlist, ticker] }));
    },
    /** Appends the clearly-labelled demo dataset (see demo.ts) and computes it through the same engine. */
    seedDemo(build: () => { documents: DocRecord[]; items: WorkingItem[]; market: MarketInput[] }) {
      const d = build();
      const analyses = d.documents.map((doc) => buildAnalysis(doc, d.items, d.market.find((m) => m.documentId === doc.id)))
        .filter((a): a is AnalysisRecord => typeof a !== "string");
      setS((st) => log({
        ...st,
        documents: [...d.documents, ...st.documents.filter((x) => !x.demo)],
        items: [...st.items.filter((i) => !d.documents.some((x) => x.id === i.documentId)), ...d.items],
        market: [...st.market.filter((m) => !d.documents.some((x) => x.id === m.documentId)), ...d.market],
        analyses: [...st.analyses.filter((a) => !a.demo), ...analyses],
      }, "Data demo dimuat", `${d.documents.length} dokumen DEMO (angka ilustratif)`));
    },
    clearDemo() {
      setS((st) => {
        const ids = new Set(st.documents.filter((d) => d.demo).map((d) => d.id));
        return { ...st, documents: st.documents.filter((d) => !ids.has(d.id)), items: st.items.filter((i) => !ids.has(i.documentId)),
          market: st.market.filter((m) => !ids.has(m.documentId)), analyses: st.analyses.filter((a) => !ids.has(a.documentId)) };
      });
    },
    reset() { setS(EMPTY); setFiles({}); },
  };

  const derived = useMemo(() => {
    const analysisStatus = (docId: string): AnalysisStatus => {
      const a = s.analyses.find((x) => x.documentId === docId);
      if (!a) return "not_started";
      const changed = s.items.some((i) => i.documentId === docId && (i.updatedAt > a.calculatedAt || i.status !== "verified"));
      const m = s.market.find((x) => x.documentId === docId);
      if (changed || (m?.sharePrice ?? null) !== a.sharePrice) return "outdated";
      return "calculated";
    };
    const progress = (docId: string) => {
      const its = s.items.filter((i) => i.documentId === docId);
      return { total: its.length, verified: its.filter((i) => i.status === "verified").length,
        open: its.filter((i) => i.status === "needs_review").length,
        flagged: its.filter((i) => ["not_found", "rejected", "invalid_source"].includes(i.status)).length };
    };
    /** Latest analysis per ticker (by reporting period). */
    const latestByTicker = () => {
      const m = new Map<string, AnalysisRecord>();
      for (const a of s.analyses) {
        const cur = m.get(a.ticker);
        if (!cur || periodSort(a.period) > periodSort(cur.period)) m.set(a.ticker, a);
      }
      return [...m.values()];
    };
    const previousOf = (a: AnalysisRecord) =>
      s.analyses.filter((x) => x.ticker === a.ticker && x.period.period === a.period.period && x.period.fiscalYear < a.period.fiscalYear)
        .sort((x, y) => y.period.fiscalYear - x.period.fiscalYear)[0];
    return { analysisStatus, progress, latestByTicker, previousOf };
  }, [s]);

  return { ...s, files, focusDoc, setFocusDoc, ...actions, ...derived };
}

export type Workspace = ReturnType<typeof useWorkspaceState>;
// Kept on globalThis so Vite hot reloads of this module don't orphan the mounted provider.
const g = globalThis as { __aureviaWsCtx?: ReturnType<typeof createContext<Workspace | null>> };
const Ctx = (g.__aureviaWsCtx ??= createContext<Workspace | null>(null));

export function WorkspaceProvider({ children }: { children: ReactNode }) {
  const ws = useWorkspaceState();
  return <Ctx.Provider value={ws}>{children}</Ctx.Provider>;
}

export function useWorkspace() {
  const ws = useContext(Ctx);
  if (!ws) throw new Error("useWorkspace must be used inside WorkspaceProvider");
  return ws;
}
