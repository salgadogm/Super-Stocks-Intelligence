// Valuation context derived from verified accounts + a share price. Never an input to the Mamdani model.
import type { AnalysisRecord } from "./store";

export const DEFAULT_ASSUMPTIONS = { g: 0.06, r: 0.12 };

export interface Valuation { bvps: number | null; pbv: number | null; per: number | null; fairPbv: number | null }

export function valuationOf(a: AnalysisRecord, price: number | null | undefined, g = DEFAULT_ASSUMPTIONS.g, r = DEFAULT_ASSUMPTIONS.r): Valuation {
  const { net_income: ni, basic_eps: eps, total_equity: eq } = a.accounts;
  const shares = ni && eps ? ni / eps : null;
  const bvps = shares && eq ? eq / shares : null;
  const roe = a.ratios.ROE / 100;
  return {
    bvps,
    pbv: price && bvps ? price / bvps : null,
    per: price && eps ? price / eps : null,
    fairPbv: r > g ? (roe - g) / (r - g) : null,
  };
}

/** Percentile rank (0-1) of v within values. */
export const pctRank = (v: number, values: number[]) => values.length < 2 ? 0.5 : values.filter((x) => x < v).length / (values.length - 1);

export type Quadrant = "Kualitas tinggi, valuasi murah" | "Kualitas tinggi, valuasi mahal" | "Kualitas menengah/rendah, valuasi murah" | "Kualitas menengah/rendah, valuasi mahal";
export const quadrant = (scoreRank: number, pbvRank: number): Quadrant =>
  scoreRank >= 0.5
    ? (pbvRank >= 0.5 ? "Kualitas tinggi, valuasi mahal" : "Kualitas tinggi, valuasi murah")
    : (pbvRank >= 0.5 ? "Kualitas menengah/rendah, valuasi mahal" : "Kualitas menengah/rendah, valuasi murah");
