/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_FMP_KEY?: string;
  readonly VITE_TWELVEDATA_KEY?: string;
  readonly VITE_FINNHUB_KEY?: string;
  readonly VITE_ANTHROPIC_KEY?: string;
}
