// Single palette. Values are CSS variables defined in index.css (:root = dark, [data-theme="light"] = light).
export const palette = {
  page: "var(--c-page)", bg: "var(--c-bg)", card: "var(--c-card)", inner: "var(--c-inner)",
  line: "var(--c-line)", cardBorder: "var(--c-line)",
  input: "var(--c-input)", inputBorder: "var(--c-input)",
  border: "var(--c-border)", lineHover: "var(--c-line-hover)", borderHover: "var(--c-line-hover)",
  text: "var(--c-text)", sub: "var(--c-sub)", ter: "var(--c-ter)", ink: "var(--c-ink)",
  hover: "var(--c-hover)", rowHover: "var(--c-row-hover)", track: "var(--c-track)",
  teal: "var(--c-teal)", tealMuted: "var(--c-teal-muted)", accentMuted: "var(--c-teal-muted)", tealBorder: "var(--c-teal-border)",
  lime: "var(--c-lime)", yellow: "var(--c-yellow)", amber: "var(--c-amber)", red: "var(--c-red)", green: "var(--c-green)",
  blue: "var(--c-blue)", violet: "var(--c-violet)", pink: "var(--c-pink)",
  onAccent: "var(--c-on-accent)",
};

/** Transparent tint of any palette color (works with var() colors, unlike hex-suffix concatenation). */
export const alpha = (color: string, pct: number) => `color-mix(in srgb, ${color} ${pct}%, transparent)`;