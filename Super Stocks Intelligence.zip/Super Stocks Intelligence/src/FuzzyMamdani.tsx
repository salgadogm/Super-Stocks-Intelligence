import { useEffect, useMemo, useRef, useState } from "react";
import { TrendingUp, Zap, Gauge as GaugeIcon, RotateCcw, Calculator, ListTree, ArrowRight, CheckSquare, AlertTriangle } from "lucide-react";
import { alpha } from "./theme";
import { C, tri, VAR_KEYS, VAR_DEFS, RULES, OUT, ZONES, computeFuzzy, categoryOf, ruleId, dominantSet, type VarKey } from "./domain/engine";
import { CANONICAL_ACCOUNTS, RATIO_DEFINITIONS } from "./domain/financial";
import { useWorkspace, docLabel } from "./domain/store";
import { canManageCollection, getRole } from "./domain/news";
import ScoreGauge from "./components/ScoreGauge";
import { useT } from "./i18n";
import { tx, Panel, Btn, Badge, DemoBadge, EmptyState, Notice, Select, CategoryBadge, ANALYSIS_META, fmtNum, fmtDate } from "./ui";

/* ─── MembershipChart ─────────────────────────────── */
function MembershipChart({
  varKey, value, onChange,
}: {
  varKey: VarKey;
  value: number;
  onChange: (v: number) => void;
}) {
  const cfg = VAR_DEFS[varKey];
  const W = 260; const H = 80; const padY = 8;
  const [min, max] = cfg.domain;
  const sx = (x: number) => ((x - min) / (max - min)) * W;
  const sy = (m: number) => H - padY - m * (H - padY * 2);
  const vx = sx(value);

  return (
    <div className="rounded-[6px] p-3" style={{ background: C.inner, border: `1px solid ${C.cardBorder}` }}>
      <div className="flex items-center justify-between mb-1">
        <div>
          <div className="text-[11px] font-semibold">{varKey}</div>
          <div className="text-[10px]" style={{ color: C.ter }}>{tx(cfg.category)}</div>
        </div>
        <span className="text-[13px] font-bold tnum" style={{ color: C.teal }}>
          {value % 1 === 0 ? value : value.toFixed(1)}{cfg.unit}
        </span>
      </div>
      <svg width="100%" viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none" style={{ display: "block" }}>
        <line x1={0} y1={H - padY} x2={W} y2={H - padY} stroke={C.inputBorder} strokeWidth="1" />
        {cfg.sets.map((s) => {
          const pts = `${sx(s.pts[0])},${sy(0)} ${sx(s.pts[1])},${sy(1)} ${sx(s.pts[2])},${sy(0)}`;
          const mu = tri(value, s.pts);
          return (
            <g key={s.name}>
              <polygon points={pts} fill={s.color} fillOpacity={0.1} />
              <polyline points={pts} fill="none" stroke={s.color} strokeWidth="1.5" strokeOpacity={0.6} />
              <circle cx={vx} cy={sy(mu)} r={mu > 0.01 ? 3.5 : 0} fill={s.color}
                style={{ transition: "cx 0.3s ease, cy 0.3s ease, r 0.2s ease" }} />
            </g>
          );
        })}
        <line x1={vx} y1={padY} x2={vx} y2={H - padY} stroke={C.text} strokeWidth="1.5"
          strokeDasharray="3 3" style={{ transition: "x1 0.3s ease, x2 0.3s ease" }} />
      </svg>
      <input type="range" min={min} max={max}
        step={cfg.unit === "x" && max <= 5 ? 0.1 : 1}
        value={value} onChange={(e) => onChange(Number(e.target.value))}
        className="w-full mt-1.5 fuzzy-range" style={{ accentColor: C.teal }} />
      <div className="flex gap-2 mt-1">
        {cfg.sets.map((s) => {
          const mu = tri(value, s.pts);
          return (
            <div key={s.name} className="flex items-center gap-1 text-[10px]" style={{ color: C.sub }}>
              <span style={{ width: 6, height: 6, borderRadius: 2, background: s.color, display: "inline-block", opacity: 0.3 + mu * 0.7 }} />
              {s.name} <span className="tnum font-semibold" style={{ color: mu > 0 ? s.color : C.ter }}>{mu.toFixed(2)}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ─── Defuzzification: score + aggregated output ──── */
function useAnimated(target: number, dur = 700) {
  const [display, setDisplay] = useState(target);
  const cur = useRef(target);
  useEffect(() => {
    const from = cur.current; const start = performance.now(); let raf = 0;
    const tick = (now: number) => {
      const t = Math.min(1, (now - start) / dur);
      cur.current = from + (target - from) * (1 - Math.pow(1 - t, 3));
      setDisplay(cur.current);
      if (t < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [target, dur]);
  return display;
}

function ScoreVisual({ score, agg, classStrength }: { score: number; agg: number[]; classStrength: number[] }) {
  const display = useAnimated(score);
  const vColor = display < 35 ? C.red : display < 65 ? C.yellow : C.teal;
  const verdict = categoryOf(display);

  const W = 300; const H = 120; const padB = 18; const padT = 10;
  const sx = (x: number) => (x / 100) * W;
  const sy = (m: number) => H - padB - m * (H - padB - padT);
  const line = agg.map((m, x) => `${x === 0 ? "M" : "L"}${sx(x).toFixed(1)},${sy(m).toFixed(1)}`).join(" ");
  const area = `${line} L${W},${sy(0)} L0,${sy(0)} Z`;
  const cx = sx(score);
  const hasArea = agg.some((m) => m > 0.001);

  return (
    <div className="flex flex-col gap-5 w-full">
      {/* Headline */}
      <div className="flex items-end justify-between gap-3">
        <div>
          <div className="text-[10px] uppercase tracking-wider mb-1" style={{ color: C.ter }}>{tx("Skor Model")}</div>
          <div className="flex items-baseline gap-1.5">
            <span className="text-[52px] font-bold tnum leading-none tracking-tight" style={{ color: vColor, transition: "color .4s" }}>
              {display.toFixed(1)}
            </span>
            <span className="text-[14px] tnum" style={{ color: C.ter }}>/ 100</span>
          </div>
        </div>
        <div className="px-2.5 py-1 rounded-[4px] text-[12px] font-semibold flex items-center gap-2 mb-1" title={tx("Kategori Kelayakan Berdasarkan Model")}
          style={{ color: vColor, background: alpha(vColor, 11), border: `1px solid ${alpha(vColor, 25)}`, transition: "all .4s" }}>
          <span className="w-1.5 h-1.5 rounded-full" style={{ background: vColor }} />
          {tx(verdict)}
        </div>
      </div>

      {/* Spectrum bar */}
      <div>
        <div className="relative pt-2 pb-1">
          <div className="flex h-3 rounded-full overflow-hidden gap-[3px]">
            {ZONES.map((z) => (
              <div key={z.name} style={{ width: `${z.to - z.from}%`, background: alpha(z.color, 19), position: "relative" }}>
                <div className="absolute inset-y-0 left-0 rounded-full"
                  style={{
                    width: `${Math.max(0, Math.min(1, (display - z.from) / (z.to - z.from))) * 100}%`,
                    background: z.color,
                  }} />
              </div>
            ))}
          </div>
          <div className="absolute top-0 -translate-x-1/2 flex flex-col items-center" style={{ left: `${display}%` }}>
            <div className="w-[3px] h-[22px] rounded-full" style={{ background: C.text, boxShadow: `0 0 0 2px ${C.card}` }} />
          </div>
        </div>
        <div className="relative h-4 text-[10px] tnum" style={{ color: C.ter }}>
          <span className="absolute left-0">0</span>
          <span className="absolute -translate-x-1/2" style={{ left: "35%" }}>35</span>
          <span className="absolute -translate-x-1/2" style={{ left: "65%" }}>65</span>
          <span className="absolute right-0">100</span>
        </div>
      </div>

      {/* Aggregated output area */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <span className="text-[11px] font-semibold" style={{ color: C.sub }}>{tx("Area agregasi keluaran")}</span>
          <span className="flex items-center gap-1.5 text-[10px]" style={{ color: C.ter }}>
            <span className="inline-block w-3 border-t border-dashed" style={{ borderColor: C.text }} /> centroid
          </span>
        </div>
        <div className="rounded-[6px] px-2 pt-2 pb-1" style={{ background: C.inner, border: `1px solid ${C.cardBorder}` }}>
          <svg viewBox={`0 0 ${W} ${H}`} width="100%" style={{ display: "block", overflow: "visible" }}>
            <defs>
              <linearGradient id="aggFill" x1="0" x2="1" y1="0" y2="0">
                <stop offset="0%" stopColor={C.red} />
                <stop offset="35%" stopColor={C.red} />
                <stop offset="50%" stopColor={C.yellow} />
                <stop offset="65%" stopColor={C.teal} />
                <stop offset="100%" stopColor={C.teal} />
              </linearGradient>
              <linearGradient id="aggFade" x1="0" x2="0" y1="0" y2="1">
                <stop offset="0%" stopColor="#fff" stopOpacity="0.55" />
                <stop offset="100%" stopColor="#fff" stopOpacity="0.05" />
              </linearGradient>
              <mask id="aggMask"><rect width={W} height={H} fill="url(#aggFade)" /></mask>
            </defs>
            {[0.5, 1].map((g) => (
              <line key={g} x1={0} x2={W} y1={sy(g)} y2={sy(g)} stroke={C.cardBorder} strokeDasharray="2 4" />
            ))}
            <line x1={0} x2={W} y1={sy(0)} y2={sy(0)} stroke={C.inputBorder} />
            {hasArea && (
              <>
                <path d={area} fill="url(#aggFill)" mask="url(#aggMask)" />
                <path d={line} fill="none" stroke="url(#aggFill)" strokeWidth="2" strokeLinejoin="round" strokeLinecap="round" />
                <line x1={cx} x2={cx} y1={padT - 4} y2={sy(0)} stroke={C.text} strokeWidth="1.5" strokeDasharray="3 3"
                  style={{ transition: "all .5s ease" }} />
                <circle cx={cx} cy={sy(0)} r="4" fill={C.text} stroke={C.inner} strokeWidth="2" style={{ transition: "all .5s ease" }} />
              </>
            )}
            {[0, 35, 65, 100].map((t) => (
              <text key={t} x={sx(t)} y={H - 3} fontSize="9" fill={C.ter} textAnchor={t === 0 ? "start" : t === 100 ? "end" : "middle"}>{t}</text>
            ))}
          </svg>
        </div>
      </div>

      {/* Class degrees */}
      <div className="flex flex-col gap-2">
        {ZONES.map((z, i) => (
          <div key={z.name} className="flex items-center gap-3">
            <span className="w-2 h-2 rounded-full shrink-0" style={{ background: z.color }} />
            <span className="text-[12px] w-[110px] shrink-0" style={{ color: C.sub }}>{tx(z.name)}</span>
            <div className="flex-1 h-2 rounded-full overflow-hidden" style={{ background: C.inner }}>
              <div className="h-full rounded-full" style={{ width: `${classStrength[i] * 100}%`, background: z.color, transition: "width .5s cubic-bezier(0.22,1,0.36,1)" }} />
            </div>
            <span className="text-[11px] font-semibold tnum w-9 text-right" style={{ color: classStrength[i] > 0 ? C.text : C.ter }}>
              {classStrength[i].toFixed(2)}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ─── Main Component ─────────────────────────────── */
const txRule = (s: string) => s.replace(/Tidak Layak|[A-Za-z]{3,}/g, (w) => (/^[A-Z]+$/.test(w) ? w : tx(w)));
const FLOW = ["Ratio Input", "Fuzzification", "Membership", "Fired Rules", "Aggregation", "Defuzzification", "Final Result"];

export default function FuzzyMamdani({ onNavigate, flash }: { onNavigate: (p: string) => void; flash: (m: string) => void }) {
  const { t } = useT();
  const ws = useWorkspace();
  const analyses = [...ws.analyses].sort((a, b) => a.ticker.localeCompare(b.ticker) || b.period.fiscalYear - a.period.fiscalYear);
  const current = analyses.find((a) => a.documentId === ws.focusDoc) ?? analyses[0];
  const [vals, setVals] = useState<Record<VarKey, number> | null>(null);

  useEffect(() => { setVals(current ? { ...current.ratios } : null); }, [current?.id]);

  const live = useMemo(() => (vals ? computeFuzzy(vals) : null), [vals]);
  const isSimulation = !!(current && vals && VAR_KEYS.some((k) => Math.abs(vals[k] - current.ratios[k]) > 1e-9));

  if (!current || !vals || !live) {
    const ready = ws.documents.filter((d) => d.status === "verified");
    return (
      <Panel><EmptyState icon={GaugeIcon} title="Belum ada analisis yang dihitung"
        why={ready.length
          ? t("{n} dokumen sudah Verified tetapi belum dihitung. Jalankan kalkulasi dari workspace verifikasi.", { n: ready.length })
          : "Skor Model hanya dihitung dari verified dataset. Tarik laporan dari koleksi dan verifikasi 9 akun wajib terlebih dahulu."}
        action={<><Btn kind="primary" icon={CheckSquare} onClick={() => onNavigate("Verifikasi Ekstraksi AI")}>Buka Verifikasi</Btn>{canManageCollection(getRole())
          ? <Btn onClick={() => onNavigate("Upload Laporan")}>Upload Laporan</Btn>
          : <Btn onClick={() => onNavigate("Perpustakaan Laporan")}>Pilih laporan dari koleksi</Btn>}</>} /></Panel>
    );
  }

  const status = ws.analysisStatus(current.documentId);
  const { strengths, agg, classStrength, score } = live;
  const fired = RULES.map((r, i) => ({ r, i, a: strengths[i] })).filter((x) => x.a > 0.005);
  const recalc = () => { const e = ws.runAnalysis(current.documentId); flash(e ? tx(e) : tx("Analisis dihitung ulang dari verified dataset")); };

  return (
    <div className="flex flex-col gap-4">
      {/* ── Context bar ─── */}
      <div className="flex items-center gap-3 flex-wrap px-4 py-3 rounded-[6px]" style={{ background: C.card, border: `1px solid ${C.cardBorder}` }}>
        <Select value={current.documentId} onChange={(v) => ws.setFocusDoc(v)} className="!w-auto min-w-[240px]">
          {analyses.map((a) => <option key={a.id} value={a.documentId}>{docLabel(a)}{a.demo ? " (DEMO)" : ""}</option>)}
        </Select>
        <span className="text-[12px]" style={{ color: C.sub }}>{current.companyName}</span>
        {current.demo && <DemoBadge />}
        <Badge tone={ANALYSIS_META[status].tone}>{ANALYSIS_META[status].label}</Badge>
        {isSimulation ? <Badge tone="amber">Mode Simulasi — tidak disimpan</Badge> : <Badge tone="teal">Nilai dari verified dataset</Badge>}
        <span className="ml-auto text-[11px]" style={{ color: C.ter }}>{current.modelVersion} · {tx("dihitung")} {fmtDate(current.calculatedAt)}</span>
      </div>

      {status === "outdated" && (
        <Notice tone="amber" icon={AlertTriangle}>
          <div className="flex items-center gap-3 flex-wrap"><span>{tx("Verified dataset atau input pasar berubah setelah analisis ini dihitung. Hasil di bawah adalah hasil tersimpan terakhir.")}</span>
            <Btn kind="primary" icon={Calculator} onClick={recalc}>Hitung ulang</Btn></div>
        </Notice>
      )}

      {/* ── Flow ─── */}
      <div className="flex items-center gap-1.5 flex-wrap text-[11px]" style={{ color: C.sub }}>
        {FLOW.map((f, i) => (
          <span key={tx(f)} className="flex items-center gap-1.5">
            <span className="px-2 h-6 inline-flex items-center rounded-[3px]" style={{ background: C.inner, border: `1px solid ${C.cardBorder}` }}><span className="tnum mr-1.5" style={{ color: C.ter }}>{i + 1}</span>{tx(f)}</span>
            {i < FLOW.length - 1 && <ArrowRight size={11} style={{ color: C.ter }} />}
          </span>
        ))}
      </div>

      {/* ── 1. Ratio input trace ─── */}
      <Panel title="1 · Ratio Input — dari verified dataset" icon={ListTree} pad={false}>
        <div className="overflow-x-auto">
          <table className="w-full text-[12px]" style={{ minWidth: 820 }}>
            <thead><tr className="text-left text-[10.5px] uppercase" style={{ color: C.ter }}>
              {["Rasio", "Formula", "Input akun (terverifikasi)", "Nilai", "Himpunan dominan"].map((h) => <th key={h} className="px-4 h-9 font-semibold" style={{ borderBottom: `1px solid ${C.cardBorder}` }}>{tx(h)}</th>)}
            </tr></thead>
            <tbody>
              {VAR_KEYS.map((k) => {
                const d = RATIO_DEFINITIONS[k];
                const dom = dominantSet(k, current.ratios[k]);
                return (
                  <tr key={k} style={{ borderBottom: `1px solid ${C.cardBorder}` }}>
                    <td className="px-4 py-2 font-semibold">{k}</td>
                    <td className="px-4 py-2" style={{ color: C.sub }}>{tx(d.formula)}</td>
                    <td className="px-4 py-2 tnum" style={{ color: C.sub }}>
                      {d.requiredAccounts.map((a) => `${tx(CANONICAL_ACCOUNTS[a].labelId)} ${fmtNum(current.accounts[a], 0)}`).join(" · ")}
                      {d.externalInputs.length > 0 && ` · ${tx("Harga saham")} ${fmtNum(current.sharePrice, 0)} (${tx("eksternal")})`}
                    </td>
                    <td className="px-4 py-2 tnum font-semibold">{fmtNum(current.ratios[k])}{d.unit}</td>
                    <td className="px-4 py-2" style={{ color: C.sub }}>{tx(dom.name)} <span className="tnum" style={{ color: C.ter }}>μ={dom.mu.toFixed(2)}</span></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Panel>

      <div className="grid gap-4 grid-cols-1 xl:grid-cols-[1.5fr_1fr]">
        {/* ── 2–3. Fuzzification ─── */}
        <Panel title="2–3 · Fuzzification & Membership" icon={TrendingUp}
          right={<span className="text-[11px]" style={{ color: C.ter }}>{tx("Geser slider untuk simulasi")}</span>}>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {VAR_KEYS.map((k) => (
              <MembershipChart key={k} varKey={k} value={vals[k]} onChange={(v) => setVals((prev) => prev && ({ ...prev, [k]: v }))} />
            ))}
          </div>
        </Panel>

        {/* ── 5–7. Defuzzification ─── */}
        <div className="flex flex-col gap-4">
          <Panel title="5–7 · Aggregation, Defuzzification & Final Result" icon={GaugeIcon}>
            <ScoreVisual score={score} agg={agg} classStrength={classStrength} />
            <p className="text-[11px] mt-4 leading-relaxed" style={{ color: C.ter }}>
              {tx("Implikasi min, agregasi max, defuzzifikasi centroid pada semesta 0–100 (resolusi 1). Kategori Kelayakan Berdasarkan Model: <35 Tidak Layak · 35–65 Dipertimbangkan · ≥65 Layak.")}
            </p>
          </Panel>
          <Panel>
            <div className="flex justify-center pb-3 mb-3" style={{ borderBottom: `1px solid ${C.cardBorder}` }}>
              <ScoreGauge score={score} label={tx(isSimulation ? "Skor simulasi" : "Skor Model")} />
            </div>
            <div className="flex items-center justify-between gap-3">
              <div>
                <div className="text-[10.5px] uppercase" style={{ color: C.ter }}>{tx("Hasil tersimpan")}</div>
                <div className="flex items-center gap-2 mt-1"><span className="text-[20px] font-semibold tnum">{current.score.toFixed(2)}</span><CategoryBadge cat={current.category} /></div>
              </div>
              <Btn icon={RotateCcw} disabled={!isSimulation} onClick={() => setVals({ ...current.ratios })}>Reset ke nilai aktual</Btn>
            </div>
            <div className="text-[11px] mt-3 leading-relaxed" style={{ color: C.ter }}>{tx("Skor Model bukan rekomendasi beli/jual. Simulasi tidak mengubah hasil tersimpan.")}</div>
          </Panel>
        </div>
      </div>

      {/* ── 4. Fired rules ─── */}
      <Panel title={t("4 · Fired Rules — {n} dari {total} rule aktif", { n: fired.length, total: RULES.length })} icon={Zap}
        right={<Btn kind="ghost" onClick={() => onNavigate("Rule Base Viewer")}>{tx("Rule Base Viewer")} <ArrowRight size={13} /></Btn>}>
        <div className="text-[11px] mb-3" style={{ color: C.ter }}>{tx("α = min(μ anteseden). Rule non-aktif ditampilkan redup.")}</div>
        <div className="flex flex-col gap-1.5">
          {RULES.map((rule, i) => {
            const a = strengths[i];
            const active = a > 0.005;
            const oc = OUT[rule.out].color;
            return (
              <div key={i} className="flex items-center gap-3 rounded-[4px] px-3 py-1.5"
                style={{ background: active ? alpha(oc, 6) : "transparent", border: `1px solid ${active ? alpha(oc, 19) : C.cardBorder}`, opacity: active ? 1 : 0.4 }}>
                <span className="text-[10px] font-bold tnum w-7 shrink-0" style={{ color: C.ter }}>{ruleId(i)}</span>
                <span className="text-[12px] flex-1" style={{ color: active ? C.text : C.sub }}>{txRule(rule.text)}</span>
                <div className="w-24 h-1.5 rounded-full overflow-hidden shrink-0" style={{ background: C.inner }}>
                  <div className="h-full rounded-full" style={{ width: `${a * 100}%`, background: oc, transition: "width 0.3s ease" }} />
                </div>
                <span className="text-[11px] font-bold tnum w-9 text-right shrink-0" style={{ color: active ? oc : C.ter }}>{a.toFixed(3)}</span>
              </div>
            );
          })}
        </div>
      </Panel>
    </div>
  );
}
