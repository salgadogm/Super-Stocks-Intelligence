import { useEffect, useRef, useState } from "react";
import { Mail, Lock, User, Eye, EyeOff, ArrowRight, ArrowLeft, Check, Sun, Moon, Database, Target, BarChart3 } from "lucide-react";
import { palette as C, alpha } from "./theme";
import { useTheme, useLang } from "./domain/preferences";
import { useT } from "./i18n";
import Logo from "./components/Logo";
import AuthHeroVisual from "./components/AuthHeroVisual";
import { roleForEmail, type Role } from "./domain/news";

type Mode = "login" | "register" | "verify";

function useTypewriter(text: string) {
  const [length, setLength] = useState(0);
  const [deleting, setDeleting] = useState(false);
  const [reducedMotion, setReducedMotion] = useState(
    () => typeof window !== "undefined" && window.matchMedia("(prefers-reduced-motion: reduce)").matches,
  );

  useEffect(() => {
    const query = window.matchMedia("(prefers-reduced-motion: reduce)");
    const syncPreference = () => setReducedMotion(query.matches);
    query.addEventListener("change", syncPreference);
    return () => query.removeEventListener("change", syncPreference);
  }, []);

  useEffect(() => {
    setLength(reducedMotion ? text.length : 0);
    setDeleting(false);
  }, [text, reducedMotion]);

  useEffect(() => {
    if (reducedMotion) return;

    const atEnd = length === text.length;
    const atStart = length === 0;
    const delay = atEnd && !deleting ? 2200 : atStart && deleting ? 500 : deleting ? 28 : 52;
    const timer = window.setTimeout(() => {
      if (atEnd && !deleting) {
        setDeleting(true);
      } else if (atStart && deleting) {
        setDeleting(false);
      } else {
        setLength((current) => current + (deleting ? -1 : 1));
      }
    }, delay);

    return () => window.clearTimeout(timer);
  }, [deleting, length, reducedMotion, text.length]);

  return text.slice(0, length);
}

function Field({
  icon: Icon,
  type = "text",
  placeholder,
  value,
  onChange,
  autoComplete,
  trailing,
}: {
  icon: any;
  type?: string;
  placeholder: string;
  value: string;
  onChange: (v: string) => void;
  autoComplete?: string;
  trailing?: React.ReactNode;
}) {
  const [focused, setFocused] = useState(false);
  return (
    <div
      className="flex items-center gap-3 h-11 rounded-[6px] px-3.5 transition-colors"
      style={{ background: C.inner, border: `1px solid ${focused ? C.teal : C.inputBorder}` }}
    >
      <Icon size={16} strokeWidth={1.75} style={{ color: focused ? C.teal : C.ter }} />
      <input
        type={type}
        value={value}
        autoComplete={autoComplete}
        onChange={(e) => onChange(e.target.value)}
        onFocus={() => setFocused(true)}
        onBlur={() => setFocused(false)}
        placeholder={placeholder}
        aria-label={placeholder}
        className="bg-transparent outline-none text-[14px] w-full"
        style={{ color: C.text }}
      />
      {trailing}
    </div>
  );
}

function Check18({ on, onClick }: { on: boolean; onClick: () => void }) {
  return (
    <span
      onClick={onClick}
      className="flex items-center justify-center rounded-[4px] transition-colors shrink-0"
      style={{
        width: 16,
        height: 16,
        background: on ? C.teal : "transparent",
        border: `1px solid ${on ? C.teal : C.inputBorder}`,
      }}
    >
      {on && <Check size={12} strokeWidth={3} color={C.onAccent} />}
    </span>
  );
}

export default function Auth({ onAuthed }: { onAuthed: (user?: { name: string; email: string; role: Role }) => void }) {
  const theme = useTheme();
  const { t, lang } = useT();
  const { setLang } = useLang();
  const [mode, setMode] = useState<Mode>("login");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [remember, setRemember] = useState(true);
  const [agree, setAgree] = useState(false);

  const [code, setCode] = useState<string[]>(["", "", "", "", "", ""]);
  const [seconds, setSeconds] = useState(0);
  const [error, setError] = useState("");
  const otpRefs = useRef<(HTMLInputElement | null)[]>([]);
  const heroPrefix = t("Intelijen saham, dari laporan keuangan jadi");
  const heroAccent = t("keputusan investasi.");
  const heroText = `${heroPrefix} ${heroAccent}`;
  const typedHeroText = useTypewriter(heroText);
  const typedHeroPrefix = typedHeroText.slice(0, Math.min(typedHeroText.length, heroPrefix.length));
  const typedHeroAccent = typedHeroText.slice(heroPrefix.length + 1);

  useEffect(() => {
    if (mode !== "verify") return;
    setSeconds(45);
    const t = window.setInterval(() => {
      setSeconds((s) => (s <= 1 ? 0 : s - 1));
    }, 1000);
    otpRefs.current[0]?.focus();
    return () => window.clearInterval(t);
  }, [mode]);

  const emailValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  const codeValue = code.join("");

  const submitCredentials = () => {
    setError("");
    if (!emailValid) return setError(t("Masukkan alamat email yang valid."));
    if (password.length < 6) return setError(t("Kata sandi minimal 6 karakter."));
    if (mode === "register" && !name.trim()) return setError(t("Nama lengkap wajib diisi."));
    if (mode === "register" && !agree) return setError(t("Setujui syarat dan ketentuan untuk melanjutkan."));
    setMode("verify");
  };

  const setDigit = (i: number, v: string) => {
    const digit = v.replace(/\D/g, "").slice(-1);
    setCode((prev) => {
      const next = [...prev];
      next[i] = digit;
      return next;
    });
    if (digit && i < 5) otpRefs.current[i + 1]?.focus();
  };

  const onOtpKey = (i: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Backspace" && !code[i] && i > 0) otpRefs.current[i - 1]?.focus();
    if (e.key === "ArrowLeft" && i > 0) otpRefs.current[i - 1]?.focus();
    if (e.key === "ArrowRight" && i < 5) otpRefs.current[i + 1]?.focus();
  };

  const onOtpPaste = (e: React.ClipboardEvent) => {
    const pasted = e.clipboardData.getData("text").replace(/\D/g, "").slice(0, 6);
    if (!pasted) return;
    e.preventDefault();
    const next = ["", "", "", "", "", ""];
    for (let i = 0; i < pasted.length; i++) next[i] = pasted[i];
    setCode(next);
    otpRefs.current[Math.min(pasted.length, 5)]?.focus();
  };

  const verify = () => {
    setError("");
    if (codeValue.length < 6) return setError(t("Masukkan 6 digit kode verifikasi."));
    onAuthed({ name, email, role: roleForEmail(email) });
  };

  const heading = t(mode === "login" ? "Masuk" : mode === "register" ? "Buat akun" : "Verifikasi email");
  const sub =
    mode === "login"
      ? t("Masuk ke workspace analisis Super Stocks Intelligence.")
      : mode === "register"
        ? t("Daftar untuk mulai menganalisis laporan keuangan emiten.")
        : t("Kami mengirim kode 6 digit ke {email}.", { email: email || t("email Anda") });

  return (
    <div className="w-full h-dvh overflow-hidden" style={{ background: C.bg, color: C.text }}>
      <div className="grid h-full lg:grid-cols-[1.05fr_1fr]">
        {/* BRAND PANEL */}
        <aside
          className="relative hidden lg:flex flex-col justify-between p-12 overflow-hidden"
          style={{ background: "linear-gradient(160deg, #0C0E14 0%, #090A0F 60%, #0B0F14 100%)", borderRight: `1px solid ${C.cardBorder}` }}
        >
          <AuthHeroVisual />

          <div className="ssi-hero-logo relative z-10">
            <Logo size={26} />
          </div>

          <div className="relative z-10 max-w-[480px]">
            <h2
              className="relative text-[clamp(34px,3.2vw,46px)] leading-[1.08] font-bold tracking-[-0.03em]"
              style={{ color: "#F3F4F6" }}
              aria-label={heroText}
            >
              <span className="invisible" aria-hidden="true">
                {heroPrefix} <span>{heroAccent}</span>
              </span>
              <span className="absolute inset-0" aria-hidden="true">
                {typedHeroPrefix}
                {typedHeroText.length > heroPrefix.length && " "}
                <span style={{ color: "#20D5C2" }}>{typedHeroAccent}</span>
                <span className="ssi-typewriter-cursor" />
              </span>
            </h2>
          </div>

          <div className="relative z-10">
            <div className="mb-6 flex flex-wrap gap-x-7 gap-y-3">
              {[
                { Icon: Database, a: "Model skor", b: "yang transparan" },
                { Icon: Target, a: "Fokus pada", b: "bank konvensional BEI" },
                { Icon: BarChart3, a: "Pendukung keputusan,", b: "bukan spekulasi" },
              ].map(({ Icon, a, b }) => (
                <div key={a} className="flex items-center gap-2.5">
                  <span
                    className="flex h-8 w-8 items-center justify-center rounded-[8px]"
                    style={{ background: "rgba(17,20,28,0.7)", border: "1px solid rgba(32,213,194,0.16)", color: "#20D5C2" }}
                  >
                    <Icon size={15} strokeWidth={1.6} />
                  </span>
                  <span className="text-[11px] leading-[1.35]" style={{ color: "#94A3B8" }}>
                    {t(a)}
                    <br />
                    <span style={{ color: "#CBD5E1" }}>{t(b)}</span>
                  </span>
                </div>
              ))}
            </div>
            <div className="text-[11.5px]" style={{ color: C.ter }}>
              Super Stocks Intelligence · {new Date().getFullYear()}
            </div>
          </div>
        </aside>

        {/* FORM PANEL */}
        <main className="relative flex items-center justify-center px-6 py-10 overflow-y-auto">
          <div className="absolute top-6 left-6 lg:hidden">
            <Logo size={24} />
          </div>
          <button
            type="button"
            onClick={() => setLang(lang === "id" ? "en" : "id")}
            aria-label={t("Ganti bahasa")}
            className="absolute top-5 right-16 flex items-center justify-center rounded-[6px] text-[12px] font-semibold transition-colors"
            style={{ width: 36, height: 36, background: C.inner, border: `1px solid ${C.cardBorder}`, color: C.text }}
          >
            {lang === "id" ? "ID" : "EN"}
          </button>
          <button
            type="button"
            onClick={theme.toggle}
            aria-label={t(theme.resolved === "dark" ? "Beralih ke mode terang" : "Beralih ke mode gelap")}
            className="absolute top-5 right-5 flex items-center justify-center rounded-[6px] transition-colors"
            style={{ width: 36, height: 36, background: C.inner, border: `1px solid ${C.cardBorder}`, color: C.text }}
          >
            {theme.resolved === "dark" ? <Sun size={16} strokeWidth={1.75} /> : <Moon size={16} strokeWidth={1.75} />}
          </button>
          <div className="w-full max-w-[380px]">
            {mode === "verify" && (
              <button
                onClick={() => {
                  setMode("login");
                  setError("");
                }}
                className="flex items-center gap-1.5 text-[13px] mb-6 transition-colors"
                style={{ color: C.sub }}
                onMouseEnter={(e) => (e.currentTarget.style.color = C.text)}
                onMouseLeave={(e) => (e.currentTarget.style.color = C.sub)}
              >
                <ArrowLeft size={15} strokeWidth={2} /> {t("Kembali")}
              </button>
            )}

            <h1 className="text-[24px] font-bold tracking-[-0.02em] leading-tight">{heading}</h1>
            <p className="text-[13.5px] mt-2" style={{ color: C.sub }}>
              {sub}
            </p>

            {mode !== "verify" && (
              <div className="mt-6 flex gap-6" style={{ borderBottom: `1px solid ${C.cardBorder}` }}>
                {(["login", "register"] as const).map((m) => (
                  <button
                    key={m}
                    onClick={() => {
                      setMode(m);
                      setError("");
                    }}
                    className="h-10 text-[13px] font-semibold transition-colors -mb-px"
                    style={{
                      color: mode === m ? C.text : C.sub,
                      borderBottom: `2px solid ${mode === m ? C.teal : "transparent"}`,
                    }}
                  >
                    {t(m === "login" ? "Masuk" : "Daftar")}
                  </button>
                ))}
              </div>
            )}

            <form
              className="mt-6 flex flex-col gap-3.5"
              onSubmit={(e) => {
                e.preventDefault();
                mode === "verify" ? verify() : submitCredentials();
              }}
            >
              {mode === "register" && (
                <Field icon={User} placeholder={t("Nama lengkap")} value={name} onChange={setName} autoComplete="name" />
              )}

              {mode !== "verify" && (
                <>
                  <Field
                    icon={Mail}
                    type="email"
                    placeholder={t("Alamat email")}
                    value={email}
                    onChange={setEmail}
                    autoComplete="email"
                  />
                  <Field
                    icon={Lock}
                    type={showPw ? "text" : "password"}
                    placeholder={t("Kata sandi")}
                    value={password}
                    onChange={setPassword}
                    autoComplete={mode === "login" ? "current-password" : "new-password"}
                    trailing={
                      <button
                        type="button"
                        onClick={() => setShowPw((v) => !v)}
                        aria-label={t(showPw ? "Sembunyikan kata sandi" : "Tampilkan kata sandi")}
                        style={{ color: C.ter }}
                      >
                        {showPw ? <EyeOff size={16} strokeWidth={1.75} /> : <Eye size={16} strokeWidth={1.75} />}
                      </button>
                    }
                  />
                </>
              )}

              {mode === "login" && (
                <div className="flex items-center justify-between">
                  <label className="flex items-center gap-2 cursor-pointer select-none">
                    <Check18 on={remember} onClick={() => setRemember((v) => !v)} />
                    <span className="text-[12.5px]" style={{ color: C.sub }}>
                      {t("Ingat saya")}
                    </span>
                  </label>
                  <button type="button" className="text-[12.5px] font-medium" style={{ color: C.teal }}>
                    {t("Lupa kata sandi?")}
                  </button>
                </div>
              )}

              {mode === "register" && (
                <label className="flex items-start gap-2.5 cursor-pointer select-none">
                  <span className="mt-0.5">
                    <Check18 on={agree} onClick={() => setAgree((v) => !v)} />
                  </span>
                  <span className="text-[12.5px] leading-snug" style={{ color: C.sub }}>
                    {t("Saya menyetujui")} <span style={{ color: C.teal }}>{t("Syarat Layanan")}</span> {t("dan")}{" "}
                    <span style={{ color: C.teal }}>{t("Kebijakan Privasi")}</span>.
                  </span>
                </label>
              )}

              {mode === "verify" && (
                <div>
                  <div className="flex items-center justify-between gap-2" onPaste={onOtpPaste}>
                    {code.map((d, i) => (
                      <input
                        key={i}
                        ref={(el) => {
                          otpRefs.current[i] = el;
                        }}
                        value={d}
                        inputMode="numeric"
                        maxLength={1}
                        aria-label={`Digit ${i + 1}`}
                        onChange={(e) => setDigit(i, e.target.value)}
                        onKeyDown={(e) => onOtpKey(i, e)}
                        className="text-center text-[20px] font-bold rounded-[6px] outline-none transition-colors focus:border-[var(--c-teal)]"
                        style={{
                          width: 50,
                          height: 56,
                          background: C.inner,
                          border: `1px solid ${d ? C.teal : C.inputBorder}`,
                          color: C.text,
                        }}
                      />
                    ))}
                  </div>
                  <div className="mt-4 text-[12.5px] text-center" style={{ color: C.sub }}>
                    {t("Belum menerima kode?")}{" "}
                    {seconds > 0 ? (
                      <span style={{ color: C.ter }}>{t("Kirim ulang dalam {n}d", { n: seconds })}</span>
                    ) : (
                      <button
                        type="button"
                        onClick={() => {
                          setSeconds(45);
                          setCode(["", "", "", "", "", ""]);
                          otpRefs.current[0]?.focus();
                        }}
                        className="font-semibold"
                        style={{ color: C.teal }}
                      >
                        {t("Kirim ulang kode")}
                      </button>
                    )}
                  </div>
                </div>
              )}

              {error && (
                <div
                  className="text-[12.5px] rounded-[6px] px-3 py-2"
                  style={{ color: C.red, background: alpha(C.red, 10), border: `1px solid ${alpha(C.red, 25)}` }}
                >
                  {error}
                </div>
              )}

              <button
                type="submit"
                disabled={mode === "verify" && codeValue.length < 6}
                className="mt-1 w-full h-11 rounded-[6px] text-[14px] font-semibold flex items-center justify-center gap-2 transition-opacity active:opacity-90 disabled:cursor-not-allowed disabled:opacity-50"
                style={{ background: C.teal, color: C.onAccent }}
              >
                {mode === "login" ? (
                  <>
                    {t("Masuk")} <ArrowRight size={16} strokeWidth={2} />
                  </>
                ) : mode === "register" ? (
                  <>
                    {t("Buat akun")} <ArrowRight size={16} strokeWidth={2} />
                  </>
                ) : (
                  <>
                    {t("Verifikasi & lanjutkan")} <Check size={16} strokeWidth={2.5} />
                  </>
                )}
              </button>
            </form>

            {/* TEMP: bypass login untuk development. Hapus sebelum rilis. */}
            <button
              type="button"
              onClick={() => onAuthed({ name: "Admin", email: "admin@aurevia.local", role: "admin" })}
              className="mt-3 w-full h-10 rounded-[6px] text-[13px] font-medium transition-colors"
              style={{ background: "transparent", border: `1px dashed ${C.inputBorder}`, color: C.sub }}
              onMouseEnter={(e) => (e.currentTarget.style.background = C.hover)}
              onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
            >
              {t("Lewati login (dev)")}
            </button>

            {mode !== "verify" && (
              <p className="mt-6 text-center text-[13px]" style={{ color: C.sub }}>
                {t(mode === "login" ? "Belum punya akun?" : "Sudah punya akun?")}{" "}
                <button
                  onClick={() => {
                    setMode(mode === "login" ? "register" : "login");
                    setError("");
                  }}
                  className="font-semibold"
                  style={{ color: C.teal }}
                >
                  {t(mode === "login" ? "Daftar" : "Masuk")}
                </button>
              </p>
            )}
          </div>
        </main>
      </div>
    </div>
  );
}
