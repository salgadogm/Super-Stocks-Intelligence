// Display-only translation. Source strings are the Indonesian originals; page keys, stored data
// (e.g. category values) and navigation identifiers are never translated, only what is rendered.
import { useCallback } from "react";
import { useLang, type Lang } from "../domain/preferences";
import { EN } from "./en";
import { id as extraId } from "./extra";

// English-sourced keys (nav, page titles, labels) shown in their Indonesian form when the language is ID.
const ID_BASE: Record<string, string> = {
  Main: "Utama", Features: "Fitur", Support: "Dukungan",
  "Overview": "Ringkasan",
  "Ranking & Comparison": "Peringkat & Perbandingan",
  "Collections": "Koleksi Laporan",
  "Analyzer": "Analisis",
  "Insight": "Wawasan",
  "Advisor": "Penasihat",
  "Rule Base Viewer": "Penampil Basis Aturan",
  "Macro & Banking Dashboard": "Dasbor Makro & Perbankan",
  "News": "Berita",
  "User Guidelines": "Panduan Pengguna",
  "Help Center": "Pusat Bantuan",
  "Logout": "Keluar",
  "Data Analytics": "Analitik Data",
  "Ratio Input": "Input Rasio", "Fuzzification": "Fuzzifikasi", "Membership": "Keanggotaan", "Fired Rules": "Aturan Aktif",
  "Aggregation": "Agregasi", "Defuzzification": "Defuzzifikasi", "Final Result": "Hasil Akhir",
  "View Source": "Lihat Sumber", "Edit Value": "Ubah Nilai", "Edit Mapping": "Ubah Pemetaan", "Verify": "Verifikasi", "Reject": "Tolak", "Mark Not Found": "Tandai Tidak Ditemukan",
  "Verified dataset": "Dataset terverifikasi",
  "Profit and Loss": "Laba Rugi", "Statement of Financial Position": "Laporan Posisi Keuangan",
  "Tips": "Tips", "Admin": "Admin", "Investor": "Investor",
};

const ID: Record<string, string> = { ...ID_BASE, ...extraId };

export const translate = (lang: Lang, s: string, vars?: Record<string, string | number>) => {
  let out = lang === "en" ? EN[s] ?? s : ID[s] ?? s;
  if (vars) for (const [k, v] of Object.entries(vars)) out = out.split(`{${k}}`).join(String(v));
  return out;
};

export function useT() {
  const { lang } = useLang();
  const t = useCallback((s: string, vars?: Record<string, string | number>) => translate(lang, s, vars), [lang]);
  return { t, lang };
}
