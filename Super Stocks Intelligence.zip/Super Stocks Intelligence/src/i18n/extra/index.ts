import * as a from "./app";
import * as b from "./collections";
import * as c from "./workspace";
import * as d from "./market";
import * as e from "./simulasi";

export const en: Record<string, string> = { ...a.en, ...b.en, ...c.en, ...d.en, ...e.en };
export const id: Record<string, string> = { ...a.id, ...b.id, ...c.id, ...d.id, ...e.id };
