// Shared UI primitives for the SSI terminal look. Tokens mirror App.tsx `C`.
import type { CSSProperties, ReactNode } from "react";
import type { LucideIcon } from "lucide-react";
import type { AnalysisStatus, VerificationStatus } from "./domain/financial";
import { CATEGORY_COLOR, type ModelCategory } from "./domain/engine";
import { palette, alpha } from "./theme";
import { getLang } from "./domain/preferences";
import { translate } from "./i18n";

export const T = palette;

export const tx = <N,>(n: N): N | string => (typeof n === "string" ? translate(getLang(), n) : n);
const locale = () => (getLang() === "en" ? "en-US" : "id-ID");

export const fmtNum = (v: number | null | undefined, d = 2) =>
  v == null || !Number.isFinite(v) ? "—" : v.toLocaleString(locale(), { minimumFractionDigits: d, maximumFractionDigits: d });
export const fmtDate = (iso?: string) =>
  iso ? new Date(iso).toLocaleString(locale(), { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" }) : "—";

export function Panel({ title, icon: Icon, right, children, className = "", pad = true }: {
  title?: ReactNode; icon?: LucideIcon; right?: ReactNode; children: ReactNode; className?: string; pad?: boolean;
}) {
  return (
    <section className={"rounded-[6px] min-w-0 " + className} style={{ background: T.card, border: `1px solid ${T.line}` }}>
      {title && (
        <header className="flex flex-wrap items-center gap-x-2 gap-y-1.5 px-4 py-2 min-h-11" style={{ borderBottom: `1px solid ${T.line}` }}>
          {Icon && <Icon size={15} strokeWidth={1.75} className="shrink-0" style={{ color: T.sub }} />}
          <h2 className="text-[13px] font-semibold min-w-0">{tx(title)}</h2>
          <div className="ml-auto flex flex-wrap items-center gap-2">{right}</div>
        </header>
      )}
      <div className={pad ? "p-4" : ""}>{children}</div>
    </section>
  );
}

type BtnKind = "primary" | "secondary" | "ghost" | "danger";
export function Btn({ kind = "secondary", icon: Icon, children, onClick, disabled, title, className = "", type = "button" }: {
  kind?: BtnKind; icon?: LucideIcon; children?: ReactNode; onClick?: () => void; disabled?: boolean; title?: string; className?: string; type?: "button" | "submit";
}) {
  const st: Record<BtnKind, CSSProperties> = {
    primary: { background: T.teal, color: T.onAccent, border: `1px solid ${T.teal}` },
    secondary: { background: T.inner, color: T.text, border: `1px solid ${T.input}` },
    ghost: { background: "transparent", color: T.sub, border: "1px solid transparent" },
    danger: { background: T.inner, color: T.red, border: `1px solid ${T.input}` },
  };
  return (
    <button type={type} onClick={onClick} disabled={disabled} title={tx(title)}
      className={"inline-flex items-center justify-center gap-1.5 h-8 px-3 rounded-[4px] text-[12px] font-medium whitespace-nowrap transition-opacity hover:opacity-85 disabled:opacity-40 disabled:cursor-not-allowed " + className}
      style={st[kind]}>
      {Icon && <Icon size={14} strokeWidth={1.75} />}{tx(children)}
    </button>
  );
}

export type Tone = "neutral" | "teal" | "green" | "amber" | "red" | "blue";
const TONE: Record<Tone, { c: string; bg: string }> = {
  neutral: { c: T.sub, bg: T.hover },
  teal: { c: T.teal, bg: alpha(T.teal, 12) },
  green: { c: T.green, bg: alpha(T.green, 12) },
  amber: { c: T.amber, bg: alpha(T.amber, 12) },
  red: { c: T.red, bg: alpha(T.red, 12) },
  blue: { c: T.blue, bg: alpha(T.blue, 12) },
};
export function Badge({ tone = "neutral", children, title }: { tone?: Tone; children: ReactNode; title?: string }) {
  const s = TONE[tone];
  return <span title={tx(title)} className="inline-flex items-center h-5 px-1.5 rounded-[3px] text-[10.5px] font-semibold whitespace-nowrap" style={{ color: s.c, background: s.bg }}>{tx(children)}</span>;
}
export const Skeleton = ({ w = "100%", h = 14, className = "" }: { w?: number | string; h?: number | string; className?: string }) =>
  <div className={"skeleton " + className} style={{ width: w, height: h }} aria-hidden="true" />;
export const DemoBadge =() => <Badge tone="blue" title="Data demo ilustratif, bukan laporan emiten sebenarnya">DEMO</Badge>;

export const VERIF_META: Record<VerificationStatus, { label: string; tone: Tone }> = {
  verified: { label: "Verified", tone: "green" },
  needs_review: { label: "Needs Review", tone: "amber" },
  not_found: { label: "Not Found", tone: "neutral" },
  rejected: { label: "Rejected", tone: "red" },
  invalid_source: { label: "Invalid Source", tone: "red" },
};
export const ANALYSIS_META: Record<AnalysisStatus, { label: string; tone: Tone }> = {
  not_started: { label: "Belum dihitung", tone: "neutral" },
  calculated: { label: "Terhitung", tone: "teal" },
  outdated: { label: "Perlu dihitung ulang", tone: "amber" },
};

export function CategoryBadge({ cat }: { cat: ModelCategory }) {
  const c = CATEGORY_COLOR[cat];
  return <span className="inline-flex items-center gap-1.5 h-5 px-1.5 rounded-[3px] text-[10.5px] font-semibold" style={{ color: c, background: alpha(c, 12) }}>
    <span className="w-1.5 h-1.5 rounded-full" style={{ background: c }} />{tx(cat)}</span>;
}

export function EmptyState({ icon: Icon, title, why, action, compact }: {
  icon: LucideIcon; title: string; why: ReactNode; action?: ReactNode; compact?: boolean;
}) {
  return (
    <div className={"flex flex-col items-center text-center gap-3 " + (compact ? "py-8" : "py-14")}>
      <div className="flex items-center justify-center rounded-[6px]" style={{ width: 40, height: 40, background: T.inner, border: `1px solid ${T.line}` }}>
        <Icon size={18} strokeWidth={1.5} style={{ color: T.sub }} />
      </div>
      <div className="max-w-md">
        <div className="text-[13px] font-semibold">{tx(title)}</div>
        <div className="text-[12px] mt-1 leading-relaxed" style={{ color: T.sub }}>{tx(why)}</div>
      </div>
      {action && <div className="flex items-center gap-2 mt-1">{action}</div>}
    </div>
  );
}

export function Notice({ tone = "neutral", icon: Icon, children }: { tone?: Tone; icon: LucideIcon; children: ReactNode }) {
  const s = TONE[tone];
  return (
    <div className="flex items-start gap-2.5 px-3 py-2.5 rounded-[4px] text-[12px] leading-relaxed"
      style={{ background: tone === "neutral" ? T.inner : s.bg, border: `1px solid ${tone === "neutral" ? T.line : alpha(s.c, 25)}`, color: tone === "neutral" ? T.sub : T.text }}>
      <Icon size={14} strokeWidth={1.75} className="shrink-0 mt-[2px]" style={{ color: s.c }} />
      <div className="min-w-0">{tx(children)}</div>
    </div>
  );
}

export function Stat({ label, value, sub, accent }: { label: string; value: ReactNode; sub?: ReactNode; accent?: boolean }) {
  return (
    <div className="rounded-[6px] px-4 py-3 min-w-0" style={{ background: T.card, border: `1px solid ${T.line}` }}>
      <div className="text-[11px]" style={{ color: T.ter }}>{tx(label)}</div>
      <div className="text-[20px] font-semibold tnum mt-1 leading-none" style={{ color: accent ? T.teal : T.text }}>{value}</div>
      {sub && <div className="text-[11px] mt-1.5 truncate" style={{ color: T.sub }}>{tx(sub)}</div>}
    </div>
  );
}

export const inputCls = "w-full h-9 px-2.5 rounded-[4px] text-[12.5px] outline-none focus:border-[var(--c-teal)]";
export const inputStyle: CSSProperties = { background: T.inner, border: `1px solid ${T.input}`, color: T.text };

export function Field({ label, hint, children }: { label: string; hint?: ReactNode; children: ReactNode }) {
  return (
    <label className="flex flex-col gap-1.5 min-w-0">
      <span className="text-[11px] font-medium" style={{ color: T.sub }}>{tx(label)}</span>
      {children}
      {hint && <span className="text-[11px]" style={{ color: T.ter }}>{tx(hint)}</span>}
    </label>
  );
}

/** Dense data table. `cols` is a CSS grid-template-columns value. */
export function Table({ cols, head, children, minWidth }: { cols: string; head: ReactNode[]; children: ReactNode; minWidth?: number }) {
  return (
    <div className="overflow-x-auto">
      <div style={{ minWidth }}>
        <div className="grid items-center gap-3 px-4 h-9 text-[10.5px] uppercase font-semibold" style={{ gridTemplateColumns: cols, color: T.ter, letterSpacing: "0.04em", borderBottom: `1px solid ${T.line}` }}>
          {head.map((h, i) => <span key={i} className="truncate">{tx(h)}</span>)}
        </div>
        {children}
      </div>
    </div>
  );
}
export function Row({ cols, children, onClick, active }: { cols: string; children: ReactNode; onClick?: () => void; active?: boolean }) {
  return (
    <div onClick={onClick} className={"grid items-center gap-3 px-4 min-h-[44px] py-1.5 text-[12.5px] transition-colors hover:bg-[var(--c-row-hover)] " + (onClick ? "cursor-pointer" : "")}
      style={{ gridTemplateColumns: cols, borderBottom: `1px solid ${T.line}`, background: active ? T.tealMuted : undefined }}>
      {children}
    </div>
  );
}

export function Select({ value, onChange, children, className = "" }: { value: string; onChange: (v: string) => void; children: ReactNode; className?: string }) {
  return <select value={value} onChange={(e) => onChange(e.target.value)} className={inputCls + " " + className} style={inputStyle}>{children}</select>;
}
