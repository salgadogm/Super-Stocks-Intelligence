import ErrorBoundary from "./components/ErrorBoundary";
import { palette, alpha } from "./theme";
import { useTheme, useLang } from "./domain/preferences";
import { useT } from "./i18n";
import { lazy, Suspense, useEffect, useMemo, useRef, useState } from "react";
import Auth from "./Auth";
import SearchBox from "./components/CommandPalette";
import ShareMenu from "./components/ShareMenu";
import Logo from "./components/Logo";
import { WorkspaceProvider } from "./domain/store";
import { RULE_COUNT } from "./domain/engine";
import AkunPage from "./pages/AkunPage";
import { setSessionRole, canViewUserAmounts, canManageCollection, type Role } from "./domain/news";
import { track, setUsageUser } from "./domain/usage";
import Avatar from "./components/Avatar";
import { MacroPage } from "./pages/MarketPages";
import { CollectionsLanding, UploadPage, VerifikasiPage, PerpustakaanPage } from "./pages/CollectionsPages";
import { loadProfile, saveProfile, type Profile } from "./domain/profile";

const NewsPage = lazy(() => import("./pages/NewsPage"));
const FuzzyMamdani = lazy(() => import("./FuzzyMamdani"));
const HelpCenterPage = lazy(() => import("./pages/HelpCenterPage"));
const MetodologiPage = lazy(() => import("./pages/MetodologiPage"));
const UserAmountsPage = lazy(() => import("./pages/UserAmountsPage"));
const FolderLibraryPage = lazy(() => import("./pages/FolderLibraryPage"));
const SimulasiPage = lazy(() => import("./pages/SimulasiPage"));
const DaftarEmitenPage = lazy(() => import("./pages/DaftarEmitenPage"));
const ProfilEmitenPage = lazy(() => import("./pages/EmitenPages").then((m) => ({ default: m.ProfilEmitenPage })));
const PerbandinganPage = lazy(() => import("./pages/EmitenPages").then((m) => ({ default: m.PerbandinganPage })));
import {
  OverviewPage, AnalyzerLanding, RuleBasePage, ValidasiModelPage, RankingPage, WatchlistPage, InsightLanding, RingkasanPage,
  HargaSahamPage, TrenPage, ExportPage, AdvisorLanding, TanyaAdvisorPage,
} from "./pages/WorkspacePages";
import {
  Menu, ChevronDown, ChevronRight, LayoutDashboard, BarChart3, Sparkles, Settings,
  HelpCircle, BookOpen, LogOut, User, UserRound, PieChart, Calendar, Plus,
  PlusCircle, DollarSign, ArrowUpRight, MoreHorizontal, SlidersHorizontal, Globe,
  TrendingUp, ListOrdered, Table2, Bookmark, FolderOpen, Upload, CheckSquare, Library,
  FlaskConical, Gauge, GitBranch, ShieldCheck, Lightbulb, LineChart, FileDown,
  Users, MessageSquare, Newspaper, AlertCircle, BookmarkCheck, FileText, X, Send,
  PlayCircle, UploadCloud, Bot, BarChart2, FileOutput, AlertTriangle, Sun, Moon, Workflow,
} from "lucide-react";

/* ─── Design tokens ─────────────────────────────────────────────── */
const C = palette;

/* ─── Utility components ─────────────────────────────────────────── */
function NavItem({ icon: Icon, label, active, collapsed, hasSubmenu, expanded, onClick }: {
  icon: any; label: string; active?: boolean; collapsed?: boolean;
  hasSubmenu?: boolean; expanded?: boolean; onClick?: () => void;
}) {
  const { t } = useT();
  return (
    <div onClick={onClick} role="button" tabIndex={0}
      onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); onClick?.(); } }}
      title={collapsed ? t(label) : undefined} aria-current={active ? "page" : undefined}
      aria-expanded={hasSubmenu ? expanded : undefined}
      className={"flex items-center gap-2.5 h-10 rounded-[4px] cursor-pointer transition-colors duration-150 " + (collapsed ? "justify-center px-0" : "px-3")}
      style={{ background: active ? C.accentMuted : "transparent", color: active ? C.teal : C.sub, boxShadow: active ? `inset 2px 0 0 ${C.teal}` : "none" }}
      onMouseEnter={(e) => { if (!active) e.currentTarget.style.background = C.hover; }}
      onMouseLeave={(e) => { if (!active) e.currentTarget.style.background = "transparent"; }}>
      <Icon size={17} strokeWidth={1.75} />
      {!collapsed && (
        <>
          <span className="text-[13px] font-medium flex-1">{t(label)}</span>
          {hasSubmenu && (
            <ChevronRight size={15} strokeWidth={1.75}
              className="transition-transform duration-200"
              style={{ color: active ? C.teal : C.ter, transform: expanded ? "rotate(90deg)" : "none" }} />
          )}
        </>
      )}
    </div>
  );
}

function SectionLabel({ text, first }: { text: string; first?: boolean }) {
  const { t } = useT();
  return (
    <div className={(first ? "mt-0" : "mt-6") + " mb-2 px-3"}>
      <span className="text-[11px] font-semibold uppercase" style={{ color: C.ter, letterSpacing: "0.1em" }}>{t(text)}</span>
    </div>
  );
}

function Pill({ children, className = "", style = {}, onClick, "aria-label": ariaLabel }: {
  children: React.ReactNode; className?: string; style?: React.CSSProperties;
  onClick?: () => void; "aria-label"?: string;
}) {
  return (
    <div onClick={onClick} aria-label={ariaLabel}
      className={"flex items-center gap-2 rounded-[6px] text-[12px] font-medium cursor-pointer transition-colors " + className}
      style={{ background: C.inner, border: `1px solid ${C.border}`, color: C.text, ...style }}
      onMouseEnter={(e) => (e.currentTarget.style.borderColor = C.borderHover)}
      onMouseLeave={(e) => (e.currentTarget.style.borderColor = C.border)}>
      {children}
    </div>
  );
}

function Card({ children, className = "", style = {} }: { children: React.ReactNode; className?: string; style?: React.CSSProperties }) {
  return (
    <div className={"rounded-[6px] p-6 " + className}
      style={{ background: C.card, border: `1px solid ${C.cardBorder}`, ...style }}>
      {children}
    </div>
  );
}

function IconBtn({ icon: Icon, size = 32, solid, onClick, "aria-label": ariaLabel }: {
  icon: any; size?: number; solid?: boolean; onClick?: () => void; "aria-label"?: string;
}) {
  return (
    <div onClick={onClick} aria-label={ariaLabel} role={ariaLabel ? "button" : undefined}
      className="flex items-center justify-center rounded-[6px] cursor-pointer shrink-0 transition-colors active:scale-95"
      style={{ width: size, height: size, background: solid ? C.teal : C.inner, border: solid ? "none" : `1px solid ${C.border}`, color: solid ? C.onAccent : C.text }}
      onMouseEnter={(e) => { if (!solid) e.currentTarget.style.background = C.border; }}
      onMouseLeave={(e) => { if (!solid) e.currentTarget.style.background = C.inner; }}>
      <Icon size={16} strokeWidth={1.75} />
    </div>
  );
}

/* User Guidelines */
function UserGuidelinesPage() {
  const { t } = useT();
  const [activeChapter, setActiveChapter] = useState(0);

  const chapters = [
    { title: "Memulai", icon: PlayCircle,
      body: "Super Stocks Intelligence menilai kelayakan investasi emiten perbankan BEI dengan model Fuzzy Mamdani berbasis 9 rasio keuangan.\n\nAlur kerja: Admin mengisi koleksi → User menarik laporan → Konversi PDF → teks (kode, tanpa AI) → Deteksi halaman SFP/P&L → Usulan 9 akun (AI hanya mengusulkan angka) → Verifikasi manusia → Verified dataset → Rasio → Fuzzy Mamdani → Hasil → Ranking / Insight / Tren / Export.\n\nWorkspace kosong secara default. Untuk mencoba alur, muat data DEMO dari halaman Collections; semua data demo diberi label DEMO.",
      tip: "Data workspace tersimpan di browser ini (localStorage) dan PDF koleksi di IndexedDB; keduanya hanya terlihat di perangkat yang sama." },
    { title: "Koleksi Laporan", icon: UploadCloud,
      body: "Collections → Perpustakaan Laporan. User tidak mengunggah PDF sendiri: pilih laporan di koleksi lalu tekan Analisis laporan ini. Angka akun diisi otomatis dan Anda memeriksanya di halaman Verifikasi.\n\nKhusus admin: Collections → Upload Laporan. Admin mengisi koleksi secara berkala dengan banyak PDF/JPG/PNG sekaligus, boleh beberapa emiten dan tahun. Kode emiten, nama perusahaan, tahun, dan jenis laporan diusulkan otomatis; buka tiap file, koreksi bila perlu, lalu centang Sudah dicek manual. Tidak ada daftar emiten bawaan: emiten muncul setelah laporannya disimpan.\n\nFile dengan emiten, tahun, dan periode yang sama digabung menjadi satu laporan yang wajib memuat Profit and Loss dan Statement of Financial Position. Siapkan 5 tahun FY agar tren lengkap.\n\nSistem hanya menggunakan Profit and Loss dan Statement of Financial Position. Laporan Arus Kas, Perubahan Ekuitas, Catatan, Ikhtisar Keuangan, dan narasi tidak dipakai.\n\nKonversi PDF → teks: PDF digital langsung dibaca oleh kode di browser (pdf.js), tanpa AI dan tanpa biaya token. Sistem mencari halaman SFP dan P&L dari judulnya, membaca satuan (\"dalam jutaan Rupiah\") dan kolom tahun, lalu mencocokkan 9 akun dengan daftar nama alternatif. Status per file menampilkan halaman yang ditemukan, akun ketemu x/9, dan perkiraan token yang dihemat. PDF hasil scan (tanpa lapisan teks) diberi peringatan dan diisi manual.",
      tip: "Satuan (ribuan/jutaan/miliar) menentukan normalisasi nilai. Laba per saham tidak diskalakan." },
    { title: "Verifikasi", icon: CheckSquare,
      body: "Collections → Verifikasi Ekstraksi AI. Penampil dokumen di kiri, tabel 9 akun wajib di kanan.\n\nAngka diisi otomatis dari laporan di koleksi; bandingkan dengan PDF asli (tombol Bandingkan dengan laporan asli) sebelum konfirmasi. Tombol Terima semua angka yang terisi memverifikasi semua baris yang punya nilai, halaman, dan jenis laporan.\n\nUntuk tiap akun: periksa atau koreksi label mentah, nilai, halaman sumber, dan jenis laporan, lalu Verify. Akun yang tidak ada ditandai Not Found — sistem tidak pernah mengestimasi. Untuk PDF digital, label, nilai, dan halaman sumber sudah terisi otomatis dari konversi teks (rule-based, tanpa AI) dengan catatan nilai tahun komparatif; semuanya tetap berstatus Needs Review sampai Anda Verify. Tanpa kunci AI hanya pencocokan otomatis (rule-based) yang aktif; akun yang tidak ketemu diisi manual.\n\nPER membutuhkan harga saham sebagai input pasar eksternal.",
      tip: "Mengubah nilai setelah Verify mengembalikan akun ke Needs Review dan menandai analisis perlu dihitung ulang." },
    { title: "Skor Fuzzy Mamdani", icon: Gauge,
      body: `Analyzer → Skor & Defuzzifikasi menampilkan jejak: Ratio Input → Fuzzification → Membership → Fired Rules → Aggregation → Defuzzification → Final Result.\n\nFungsi keanggotaan segitiga, {n} rule, AND = min, implikasi min, agregasi max, defuzzifikasi centroid pada semesta 0–100.\n\nKategori Kelayakan Berdasarkan Model: <35 Tidak Layak · 35–65 Dipertimbangkan · ≥65 Layak. Slider mengaktifkan mode simulasi yang tidak disimpan.`,
      tip: "Seluruh perhitungan deterministik. AI tidak menghitung rasio, keanggotaan, rule, maupun skor." },
    { title: "Ranking, Watchlist & Tren", icon: ListOrdered,
      body: "Ranking mengurutkan Skor Model periode terbaru tiap emiten. Watchlist memantau emiten pilihan (bukan portofolio). Tren Historis menampilkan skor dan rasio per tahun; tahun tanpa analisis ditampilkan n/a tanpa interpolasi.",
      tip: "Ranking bukan rekomendasi beli/jual." },
    { title: "Export & Advisor", icon: FileOutput,
      body: "Insight → Export Laporan (PDF) mengunduh PDF berisi akun terverifikasi, rasio, input fuzzy, rule aktif, defuzzifikasi, hasil, metodologi, dan disclaimer.\n\nTanya Advisor menjelaskan skor, rasio, dan rule hanya dari analisis tersimpan. LLM, feed harga, berita, dan data makro belum terhubung dan ditandai demikian.",
      tip: "Data makro hanya konteks dan bukan input model." },
  ];

  return (
    <div className="flex flex-col md:flex-row gap-5 items-stretch md:items-start">
      {/* TOC sidebar */}
      <div className="shrink-0 rounded-[10px] overflow-hidden w-full md:w-[200px]" style={{ background: C.card, border: `1px solid ${C.cardBorder}` }}>
        <div className="px-4 py-3" style={{ borderBottom: `1px solid ${C.cardBorder}` }}>
          <div className="text-[11px] font-semibold uppercase" style={{ color: C.ter, letterSpacing: "0.08em" }}>{t("Daftar Isi")}</div>
        </div>
        {chapters.map((ch, i) => (
          <div key={i}
            onClick={() => setActiveChapter(i)}
            className="flex items-center gap-2.5 px-4 py-2.5 cursor-pointer transition-colors"
            style={{
              background: activeChapter === i ? C.accentMuted : "transparent",
              borderBottom: `1px solid ${C.cardBorder}`,
            }}
            onMouseEnter={(e) => { if (activeChapter !== i) e.currentTarget.style.background = C.hover; }}
            onMouseLeave={(e) => { if (activeChapter !== i) e.currentTarget.style.background = "transparent"; }}>
            <ch.icon size={16} strokeWidth={1.75} style={{ color: activeChapter === i ? C.teal : C.ter, flexShrink: 0 }} />
            <span className="text-[12px] font-medium" style={{ color: activeChapter === i ? C.text : C.sub }}>{t(ch.title)}</span>
          </div>
        ))}
      </div>

      {/* Content */}
      <div className="flex-1 min-w-0 flex flex-col gap-4">
        <div className="rounded-[10px] p-6" style={{ background: C.card, border: `1px solid ${C.cardBorder}` }}>
          <div className="flex items-center gap-3 mb-5">
            {(() => { const Icon = chapters[activeChapter].icon; return (
              <span className="flex items-center justify-center rounded-[6px] shrink-0" style={{ width: 40, height: 40, background: C.inner, border: `1px solid ${C.cardBorder}` }}>
                <Icon size={20} strokeWidth={1.75} style={{ color: C.sub }} />
              </span>
            ); })()}
            <div>
              <div className="text-[11px] uppercase font-semibold" style={{ color: C.ter, letterSpacing: "0.08em" }}>{t("Bab {n} dari {total}", { n: activeChapter + 1, total: chapters.length })}</div>
              <h2 className="text-[18px] font-bold">{t(chapters[activeChapter].title)}</h2>
            </div>
          </div>

          <div className="flex flex-col gap-4">
            {chapters[activeChapter].body.split("\n\n").map((raw) => t(raw, { n: RULE_COUNT })).map((para, i) => (
              <p key={i} className="text-[13px] leading-[1.75]" style={{ color: C.sub }}>
                {para.split("\n").map((line, j) => (
                  <span key={j}>
                    {line.startsWith("•") ? (
                      <span className="flex items-start gap-2">
                        <span style={{ color: C.teal, flexShrink: 0 }}>•</span>
                        <span>{line.slice(1).trim()}</span>
                      </span>
                    ) : line.match(/^\d+\./) ? (
                      <span className="flex items-start gap-2">
                        <span style={{ color: C.teal, flexShrink: 0, minWidth: 16 }}>{line.match(/^\d+/)?.[0]}.</span>
                        <span>{line.replace(/^\d+\./, "").trim()}</span>
                      </span>
                    ) : (
                      line
                    )}
                    {j < para.split("\n").length - 1 && <br />}
                  </span>
                ))}
              </p>
            ))}
          </div>

          {/* Tip callout */}
          <div className="mt-5 flex items-start gap-3 px-4 py-3 rounded-[4px]"
            style={{ background: C.inner, border: `1px solid ${C.cardBorder}` }}>
            <Lightbulb size={16} strokeWidth={1.75} style={{ color: C.yellow, flexShrink: 0, marginTop: 1 }} />
            <div>
              <div className="text-[11px] font-bold mb-0.5 uppercase" style={{ color: C.sub, letterSpacing: "0.06em" }}>{t("Tips")}</div>
              <div className="text-[12px] leading-relaxed" style={{ color: C.sub }}>{t(chapters[activeChapter].tip)}</div>
            </div>
          </div>
        </div>

        {/* Prev / Next */}
        <div className="flex items-center justify-between">
          <button
            onClick={() => setActiveChapter((v) => Math.max(0, v - 1))}
            disabled={activeChapter === 0}
            className="h-9 px-4 rounded-[6px] text-[12px] font-medium transition-opacity"
            style={{ background: C.card, border: `1px solid ${C.cardBorder}`, color: C.sub, opacity: activeChapter === 0 ? 0.4 : 1 }}>
            {t("← Bab Sebelumnya")}
          </button>
          <span className="text-[12px]" style={{ color: C.ter }}>{activeChapter + 1} / {chapters.length}</span>
          <button
            onClick={() => setActiveChapter((v) => Math.min(chapters.length - 1, v + 1))}
            disabled={activeChapter === chapters.length - 1}
            className="h-9 px-4 rounded-[6px] text-[12px] font-medium transition-opacity"
            style={{ background: C.teal, color: C.onAccent, opacity: activeChapter === chapters.length - 1 ? 0.4 : 1 }}>
            {t("Bab Berikutnya →")}
          </button>
        </div>
      </div>
    </div>
  );
}

/* Disclaimer Investasi */
function DisclaimerPage({ flash }: { flash: (m: string) => void }) {
  const { t } = useT();
  const [acknowledged, setAcknowledged] = useState(false);

  const sections = [
    { title: "1. Tujuan akademik", body: "Super Stocks Intelligence adalah sistem pendukung keputusan untuk penelitian akademik tentang penilaian kelayakan investasi emiten perbankan BEI menggunakan Fuzzy Mamdani." },
    { title: "2. Bukan rekomendasi investasi", body: "Skor Model dan kategori kelayakan bukan rekomendasi, nasihat keuangan, atau ajakan membeli/menjual efek. Hasil tidak menjamin kinerja atau return di masa depan." },
    { title: "3. Batasan sumber data", body: "Analisis hanya memakai akun dari Profit and Loss dan Statement of Financial Position. Arus kas, perubahan ekuitas, catatan, ikhtisar, narasi, dan asumsi AI tidak dipakai. Akun yang tidak ditemukan ditandai 'Tidak ditemukan pada sumber yang diizinkan' dan tidak diestimasi." },
    { title: "4. Kesalahan ekstraksi & verifikasi manusia", body: "Ekstraksi otomatis dapat salah membaca label, nilai, atau satuan. Karena itu setiap akun wajib diverifikasi manusia terhadap halaman sumber sebelum dihitung. Kebenaran verified dataset menjadi tanggung jawab verifikator." },
    { title: "5. Metode Fuzzy Mamdani", body: "Skor dihitung deterministik dari 9 rasio dengan fungsi keanggotaan segitiga, rule base, operator min/max, dan defuzzifikasi centroid. Model tidak memperhitungkan faktor kualitatif (manajemen, regulasi, geopolitik) dan belum divalidasi secara prediktif terhadap return saham." },
    { title: "6. Data eksternal", body: "Harga saham untuk PER dimasukkan manual dan bukan data real-time. Feed harga, berita, dan data makro belum terhubung; data makro hanya konteks dan bukan input model." },
    { title: "7. Tanggung jawab pengguna", body: "Keputusan investasi sepenuhnya tanggung jawab pengguna. Lakukan riset mandiri dan konsultasikan dengan profesional berlisensi." },
  ];

  return (
    <div className="flex flex-col gap-5 max-w-3xl">
      {/* Warning banner */}
      <div className="flex items-start gap-3 px-5 py-4 rounded-[8px]"
        style={{ background: alpha(C.yellow, 8), border: `1px solid ${alpha(C.yellow, 25)}` }}>
        <AlertTriangle size={18} strokeWidth={1.75} style={{ color: C.yellow, flexShrink: 0, marginTop: 1 }} />
        <div>
          <div className="text-[13px] font-bold mb-0.5" style={{ color: C.yellow }}>{t("Baca seluruh halaman sebelum menggunakan sistem")}</div>
          <div className="text-[12px] leading-relaxed" style={{ color: C.sub }}>
            {t("Dokumen ini menjelaskan tujuan, batasan, dan tanggung jawab pengguna terkait penggunaan Super Stocks Intelligence sebagai sistem pendukung keputusan investasi.")}
          </div>
        </div>
      </div>

      {/* Content sections */}
      <div className="rounded-[10px] overflow-hidden" style={{ background: C.card, border: `1px solid ${C.cardBorder}` }}>
        {sections.map((s, i) => (
          <div key={i} className="p-6" style={{ borderBottom: i < sections.length - 1 ? `1px solid ${C.cardBorder}` : "none" }}>
            <h3 className="text-[14px] font-bold mb-2" style={{ color: C.text }}>{t(s.title)}</h3>
            <p className="text-[13px] leading-[1.8]" style={{ color: C.sub }}>{t(s.body)}</p>
          </div>
        ))}
      </div>

      {/* Acknowledgment + actions */}
      <div className="rounded-[10px] p-5 flex flex-col gap-4" style={{ background: C.card, border: `1px solid ${C.cardBorder}` }}>
        <label className="flex items-start gap-3 cursor-pointer">
          <input type="checkbox" checked={acknowledged} onChange={(e) => setAcknowledged(e.target.checked)}
            className="mt-0.5 cursor-pointer"
            style={{ accentColor: C.teal, width: 16, height: 16 }} />
          <span className="text-[13px] leading-relaxed" style={{ color: C.sub }}>
            {t("Saya telah membaca dan memahami seluruh isi disclaimer ini, termasuk tujuan sistem, batasan model, dan ketentuan tanggung jawab pengguna.")}
          </span>
        </label>
        <div className="flex items-center gap-3">
          <button
            onClick={() => { if (acknowledged) flash(t("Konfirmasi disclaimer berhasil disimpan")); }}
            disabled={!acknowledged}
            className="h-11 px-8 rounded-[6px] text-[13px] font-semibold transition-opacity"
            style={{ background: C.teal, color: C.onAccent, opacity: acknowledged ? 1 : 0.35, cursor: acknowledged ? "pointer" : "not-allowed" }}>
            {t("Konfirmasi & Lanjutkan")}
          </button>
          <span className="ml-auto text-[11px]" style={{ color: C.ter }}>{t("Konfirmasi hanya berlaku untuk sesi ini")}</span>
        </div>
      </div>
    </div>
  );
}

const NAV = {
  Main: [
    { icon: LayoutDashboard, label: "Overview" },
    { icon: ListOrdered,     label: "Ranking & Comparison" },
    { icon: Table2,          label: "Daftar Emiten" },
    { icon: Bookmark,        label: "Watchlist Saya" },
  ],
  Features: [
    { icon: FolderOpen,   label: "Collections", submenu: ["Upload Laporan","Verifikasi Ekstraksi AI","Perpustakaan Laporan","Folder Laporan","Simulasi End-to-End"] as const },
    { icon: FlaskConical, label: "Analyzer",    submenu: ["Skor & Defuzzifikasi","Rule Base Viewer","Validasi Model"] as const },
    { icon: Lightbulb,    label: "Insight",     submenu: ["Profil Emiten","Perbandingan Emiten","Ringkasan Rasio & Skor","Harga Saham Real-Time","Tren Historis","Export Laporan (PDF)"] as const },
    { icon: Sparkles,     label: "Advisor",     submenu: ["Tanya Advisor","Macro & Banking Dashboard"] as const },
  ],
  Support: [
    { icon: Newspaper,    label: "News" },
    { icon: Workflow,     label: "Metodologi & Alur" },
    { icon: BookOpen,     label: "User Guidelines" },
    { icon: HelpCircle,   label: "Help Center" },
    { icon: AlertCircle,  label: "Disclaimer Investasi" },
  ],
} as const;

/** Only admins may upload to the report collection; everyone else just pulls existing reports. */
const ADMIN_ONLY_PAGES: readonly string[] = ["Upload Laporan"];
const visibleSubmenu = (subs: readonly string[], role: Role) => canManageCollection(role) ? subs : subs.filter((s) => !ADMIN_ONLY_PAGES.includes(s));

/* ─── Page descriptions ──────────────────────────────────────────── */
const PAGE_DESC: Record<string, string> = {
  "Data Analytics": "Analitik penggunaan aplikasi: jumlah pengguna, tren harian, dan frekuensi penggunaan (khusus admin).",
  "Akun Saya": "Ubah nama, peran, institusi, deskripsi, dan avatar akun Anda.",
  "Overview": "Ringkasan workspace: laporan, antrian verifikasi, dan Skor Model terbaru dari verified dataset.",
  "Daftar Emiten": "Daftar seluruh emiten bank beserta Skor Model per tahun fiskal, kategori, dan harga saham. Bukan rekomendasi beli/jual.",
  "Ranking & Comparison": "Urutan emiten berdasarkan Skor Model periode terbaru. Bukan rekomendasi beli/jual.",
  "Watchlist Saya": "Pantau skor terbaru, kesegaran periode, dan status laporan emiten pilihan.",
  "Collections": "Upload, verifikasi, dan arsip laporan keuangan (P&L dan Statement of Financial Position).",
  "Upload Laporan": "Unggah banyak laporan sekaligus. Identitas emiten diusulkan otomatis dan wajib dicek manual.",
  "Verifikasi Ekstraksi AI": "Verifikasi 9 akun wajib terhadap halaman sumber sebelum masuk ke model.",
  "Perpustakaan Laporan": "Arsip laporan beserta status ekstraksi, verifikasi, dan analisis.",
  "Folder Laporan": "Koleksi laporan dari admin, dikelompokkan per emiten dan tahun. Pilih tahun yang lengkap dan berurutan untuk komparasi.",
  "Simulasi End-to-End": "Simulasi alur lengkap BBRI & BMRI: PDF → TXT → DeepSeek → verifikasi 9 akun → Mamdani → skor → komparasi apple-to-apple.",
  "Analyzer": "Perhitungan Fuzzy Mamdani dari verified dataset: skor, rule base, dan statistik model.",
  "Skor & Defuzzifikasi": "Jejak perhitungan: rasio → fuzzifikasi → rule aktif → agregasi → centroid → Skor Model.",
  "Rule Base Viewer": `Basis ${RULE_COUNT} rule Mamdani dengan aktivasi pada analisis terpilih.`,
  "Validasi Model": "Statistik deskriptif dari analisis tersimpan. Validasi prediktif menunggu data harga terverifikasi.",
  "Insight": "Ringkasan rasio, harga input, tren historis, dan export PDF.",
  "Profil Emiten": "Satu emiten: kelayakan model, tren 5 FY, harga vs kualitas laporan, dan posisi terhadap emiten lain.",
  "Perbandingan Emiten": "Bandingkan hingga 5 emiten terunggah: tren, peta 9 rasio, dan harga vs kualitas.",
  "Ringkasan Rasio & Skor": "Nilai rasio, perbandingan periode sebelumnya, dan derajat keanggotaan.",
  "Harga Saham Real-Time": "Harga saham yang dimasukkan untuk PER. Feed harga pasar belum terhubung.",
  "Tren Historis": "Riwayat Skor Model dan rasio per tahun. Periode kosong tidak diinterpolasi.",
  "Export Laporan (PDF)": "Unduh PDF jejak analisis lengkap untuk satu emiten dan periode.",
  "Advisor": "Penjelasan hasil model dan konteks eksternal.",
  "Tanya Advisor": "Tanya tentang skor, rasio, dan rule; dijawab hanya dari data terverifikasi.",
  "Macro & Banking Dashboard": "Kurs USD/IDR, makro Indonesia (World Bank), dan faktor mikro sektor. Sumber gratis & publik; konteks saja, bukan input model.",
  "News": "Berita emiten dan regulasi dari admin. Viewer dapat membaca dan berkomentar.",
  "User Guidelines": "Alur kerja lengkap dari memilih laporan di koleksi hingga membaca Skor Model.",
  "Metodologi & Alur": "Alur end-to-end dari koleksi laporan hingga kategori kelayakan, dalam flowchart dan DFD.",
  "Help Center": "FAQ dan pencarian bantuan penggunaan Super Stocks Intelligence.",
  "Disclaimer Investasi": "Batasan penggunaan, data, dan metode Super Stocks Intelligence.",
};

/* ─── Main App ───────────────────────────────────────────────────── */
function AppShell() {
  const [authed, setAuthed] = useState(false);
  const [collapsedRaw, setCollapsed] = useState(() => window.innerWidth < 1024);
  const [mobile, setMobile] = useState(() => window.innerWidth < 768);
  useEffect(() => {
    const mq = window.matchMedia("(max-width: 767px)");
    const on = () => { setMobile(mq.matches); if (mq.matches) setCollapsed(true); };
    mq.addEventListener("change", on);
    return () => mq.removeEventListener("change", on);
  }, []);
  const collapsed = collapsedRaw && !mobile;
  const drawerHidden = mobile && collapsedRaw;
  const theme = useTheme();
  const { t, lang } = useT();
  const { setLang } = useLang();
  const [active, setActive] = useState("Overview");
  useEffect(() => { if (mobile) setCollapsed(true); }, [active, mobile]);
  useEffect(() => { if (authed && active !== "Data Analytics") track("page_view", active); }, [active, authed]);
  const [openSubmenus, setOpenSubmenus] = useState<string[]>([]);
  const [user, setUser] = useState<{ name: string; email: string; role: Role }>({ name: "Investor", email: "", role: "viewer" });
  setSessionRole(user.role);
  const isAdmin = canManageCollection(user.role);
  // page-switch guard: a non-admin can never sit on an admin-only page (palette, deep link, role change)
  useEffect(() => { if (!isAdmin && ADMIN_ONLY_PAGES.includes(active)) setActive("Perpustakaan Laporan"); }, [active, isAdmin]);
  const [profileTicker, setProfileTicker] = useState<string | undefined>(undefined);
  const [toast, setToast] = useState<string | null>(null);
  const [userOpen, setUserOpen] = useState(false);
  const [profile, setProfile] = useState<Profile>(() => loadProfile("", "Investor"));
  const searchRef = useRef<HTMLInputElement>(null);

  const flash = (msg: string) => {
    setToast(msg);
    window.clearTimeout((flash as any)._t);
    (flash as any)._t = window.setTimeout(() => setToast(null), 2200);
  };


  const navigate = (page: string) => {
    const parentMap: Record<string, string> = {
      "Upload Laporan": "Collections", "Verifikasi Ekstraksi AI": "Collections", "Perpustakaan Laporan": "Collections", "Folder Laporan": "Collections", "Simulasi End-to-End": "Collections",
      "Skor & Defuzzifikasi": "Analyzer", "Rule Base Viewer": "Analyzer", "Validasi Model": "Analyzer",
      "Profil Emiten": "Insight", "Perbandingan Emiten": "Insight", "Ringkasan Rasio & Skor": "Insight", "Harga Saham Real-Time": "Insight", "Tren Historis": "Insight", "Export Laporan (PDF)": "Insight",
      "Tanya Advisor": "Advisor", "Macro & Banking Dashboard": "Advisor",
    };
    const parent = parentMap[page];
    if (parent) setOpenSubmenus((s) => (s.includes(parent) ? s : [...s, parent]));
    setActive(!isAdmin && ADMIN_ONLY_PAGES.includes(page) ? "Perpustakaan Laporan" : page);
    if (mobile) setCollapsed(true);
  };



  if (!authed) {
    return (
      <Auth onAuthed={(u) => {
        const name = u?.name?.trim() || (u?.email ? u.email.split("@")[0] : "Investor");
        const role: Role = u?.role ?? "viewer";
        setSessionRole(role);
        setUser({ name, email: u?.email ?? "", role });
        setUsageUser(u?.email ?? "", name); track("login");
        setProfile(loadProfile(u?.email ?? "", name));
        setActive("Overview"); setAuthed(true);
      }} />
    );
  }

  return (
    <div className="w-full h-dvh flex flex-col overflow-hidden relative" style={{ background: C.bg, color: C.text }}>
      {/* ── GLOBAL HEADER ── */}
      <header className="shrink-0 flex items-center gap-2 sm:gap-3 px-3 sm:px-5"
        style={{ height: 60, paddingTop: "env(safe-area-inset-top)", boxSizing: "content-box", borderBottom: `1px solid ${C.cardBorder}`, background: C.card }}>
        <div className="flex items-center gap-3 shrink-0">
          <button onClick={() => setCollapsed((v) => !v)}
            className="flex items-center justify-center rounded-[8px] cursor-pointer transition-colors"
            style={{ width: 36, height: 36, background: "transparent", border: "none" }}
            onMouseEnter={(e) => (e.currentTarget.style.background = C.hover)}
            onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
            aria-label={t("Toggle sidebar")}>
            <Menu size={18} strokeWidth={1.75} style={{ color: C.sub }} />
          </button>
          <Logo size={22} />
        </div>

        <div className="flex-1" />

        <Pill className="h-9 px-2.5 sm:px-4" onClick={() => navigate("Export Laporan (PDF)")} aria-label={t("Export Laporan")}>
          <PieChart size={15} strokeWidth={1.75} /> <span className="hidden sm:inline">{t("Export Laporan")}</span>
        </Pill>

        {/* search */}
        <SearchBox inputRef={searchRef} placeholder={t("Cari emiten, halaman, rule, rasio…")}
          pages={(Object.values(NAV) as unknown as readonly { label: string; submenu?: readonly string[] }[][]).flatMap((s) => s.flatMap((i) => [i.label, ...visibleSubmenu(i.submenu ?? [], user.role)]))}
          onGo={(page, ticker) => { if (ticker) setProfileTicker(ticker); navigate(page); }} />

        <div onClick={() => setLang(lang === "id" ? "en" : "id")} role="button" tabIndex={0} aria-label={t("Ganti bahasa")}
          onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); setLang(lang === "id" ? "en" : "id"); } }}
          className="flex items-center justify-center rounded-[6px] cursor-pointer text-[12px] font-semibold max-[400px]:hidden"
          style={{ width: 36, height: 36, background: C.inner, border: `1px solid ${C.border}`, color: C.text }}>
          {lang === "id" ? "ID" : "EN"}
        </div>
        <IconBtn icon={theme.resolved === "dark" ? Sun : Moon} size={36}
          aria-label={t(theme.resolved === "dark" ? "Beralih ke mode terang" : "Beralih ke mode gelap")} onClick={theme.toggle} />

        <div className="hidden sm:block"><ShareMenu title={t(active)} onCopied={flash} /></div>

        {/* User menu */}
        <div className="relative">
          <div onClick={() => setUserOpen((v) => !v)}
            className="flex items-center gap-2 h-9 pl-1.5 pr-2.5 rounded-[6px] cursor-pointer transition-colors"
            style={{ background: C.card, border: `1px solid ${C.border}` }}
            onMouseEnter={(e) => (e.currentTarget.style.background = C.inner)}
            onMouseLeave={(e) => (e.currentTarget.style.background = C.card)}>
            <Avatar id={profile.avatar} name={profile.name} />
            <span className="text-[13px] font-medium hidden lg:block">{profile.name}</span>
            <ChevronDown size={14} strokeWidth={1.75} style={{ color: C.sub }} />
          </div>
          {userOpen && (
            <div className="absolute right-0 mt-1.5 z-20 rounded-[6px] overflow-hidden py-1"
              style={{ background: C.card, border: `1px solid ${C.inputBorder}`, minWidth: 170 }}>
              {[
                { icon: UserRound, label: "Akun Saya" },
                ...(canViewUserAmounts(user.role) ? [{ icon: Users, label: "Data Analytics" }] : []),
                { icon: LogOut, label: "Logout" },
              ].map(({ icon: Icon, label }) => (
                <div key={label} onClick={() => { setUserOpen(false); if (label === "Logout") { setAuthed(false); return; } navigate(label); }}
                  className="flex items-center gap-2.5 px-3 py-2 text-[12px] cursor-pointer"
                  style={{ color: C.text }}
                  onMouseEnter={(e) => (e.currentTarget.style.background = C.hover)}
                  onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}>
                  <Icon size={15} strokeWidth={1.75} style={{ color: C.sub }} /> {t(label)}
                </div>
              ))}
            </div>
          )}
        </div>
      </header>

      {/* ── BODY ── */}
      <div className="flex flex-1 min-h-0 overflow-hidden relative">
        {mobile && !collapsedRaw && <div className="absolute inset-0 z-30 bg-black/50" onClick={() => setCollapsed(true)} aria-hidden="true" />}
        {/* SIDEBAR */}
        <aside className={"shrink-0 h-full flex flex-col transition-all duration-200 " + (mobile ? "absolute left-0 top-0 z-40" : "relative")}
          style={{ display: drawerHidden ? "none" : undefined, width: collapsed ? 72 : 240, padding: collapsed ? "20px 12px" : "20px 16px", borderRight: `1px solid ${C.cardBorder}`, background: C.card }}>
          <nav className="flex-1 min-h-0 overflow-y-auto -mx-1 px-1">
            {(Object.keys(NAV) as (keyof typeof NAV)[]).map((section, si) => (
              <div key={section}>
                {!collapsed && <SectionLabel text={section} first={si === 0} />}
                {collapsed && <div className="mt-6" />}
                <div className="flex flex-col gap-1">
                  {NAV[section].map((item) => {
                    const submenu = "submenu" in item ? visibleSubmenu(item.submenu as readonly string[], user.role) : undefined;
                    const isOpen = openSubmenus.includes(item.label);
                    return (
                      <div key={item.label}>
                        <NavItem icon={item.icon} label={item.label}
                          active={active === item.label}
                          collapsed={collapsed} hasSubmenu={!!submenu} expanded={isOpen}
                          onClick={() => {
                            setActive(item.label);
                            if (submenu && !collapsed) {
                              setOpenSubmenus((prev) => prev.includes(item.label)
                                ? prev.filter((l) => l !== item.label)
                                : [...prev, item.label]);
                            }
                          }} />
                        {submenu && !collapsed && (
                          <div className="overflow-hidden transition-all duration-200"
                            style={{ maxHeight: isOpen ? submenu.length * 38 : 0 }}>
                            <div className="flex flex-col gap-0.5 mt-0.5 mb-1 pl-8">
                              {submenu.map((sub) => (
                                <div key={sub} role="button" tabIndex={0}
                                  onClick={() => setActive(sub)}
                                  onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); setActive(sub); } }}
                                  className="flex items-center h-8 px-3 rounded-[6px] text-[12px] cursor-pointer transition-colors"
                                  style={{ color: active === sub ? C.text : C.sub }}
                                  onMouseEnter={(e) => { if (active !== sub) e.currentTarget.style.background = C.hover; }}
                                  onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}>
                                  {t(sub)}
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            ))}
          </nav>
        </aside>

        {/* CONTENT */}
        <main key={active} className="page-enter flex-1 min-w-0 flex flex-col gap-5 overflow-y-auto p-3 sm:p-6">
          {/* Page title */}
          <div className="flex items-end justify-between flex-wrap gap-2">
            <div>
              <div className="flex items-center gap-1.5 text-[12px] mb-2" style={{ color: C.ter }}>
                <span>Home</span><ChevronRight size={13} strokeWidth={1.75} />
                <span style={{ color: C.sub }}>{t(active)}</span>
              </div>
              <h1 className="text-[24px] font-bold leading-tight">{t(active)}</h1>
              <p className="text-[13px] mt-0.5" style={{ color: C.sub }}>
                {t(PAGE_DESC[active] ?? PAGE_DESC["Overview"])}
              </p>
            </div>
          </div>

          <ErrorBoundary key={active}>
          <Suspense fallback={<div className="text-[12px]" style={{ color: C.sub }}>{t("Memuat…")}</div>}>
          {active === "Akun Saya" && <AkunPage key={user.email} profile={profile} email={user.email} onSave={(p) => { setProfile(p); saveProfile(user.email, p); flash("Profil tersimpan"); }} />}
          {active === "Data Analytics" && <UserAmountsPage />}
          {active === "Overview" && <OverviewPage onNavigate={navigate} />}

          {/* ── FUNCTIONAL PAGES ── */}
          {active === "Daftar Emiten" && <DaftarEmitenPage onNavigate={navigate} />}
          {active === "Ranking & Comparison" && <RankingPage onNavigate={navigate} flash={flash} />}
          {active === "Watchlist Saya" && <WatchlistPage onNavigate={navigate} />}
          {active === "Collections" && <CollectionsLanding onNavigate={navigate} />}
          {active === "Upload Laporan" && isAdmin && <UploadPage onNavigate={navigate} />}
          {active === "Verifikasi Ekstraksi AI" && <VerifikasiPage onNavigate={navigate} flash={flash} user={profile.name} />}
          {active === "Perpustakaan Laporan" && <PerpustakaanPage onNavigate={navigate} user={user.email || profile.name} />}
          {active === "Folder Laporan" && <FolderLibraryPage onNavigate={navigate} user={user.email || profile.name} />}
          {active === "Simulasi End-to-End" && <SimulasiPage />}
          {active === "Analyzer" &&<AnalyzerLanding onNavigate={navigate} />}
          {active === "Skor & Defuzzifikasi" && <FuzzyMamdani onNavigate={navigate} flash={flash} />}
          {active === "Rule Base Viewer" && <RuleBasePage />}
          {active === "Validasi Model" && <ValidasiModelPage onNavigate={navigate} />}
          {active === "Insight" && <InsightLanding onNavigate={navigate} />}
          {active === "Profil Emiten" && <ProfilEmitenPage key={profileTicker ?? ""} ticker={profileTicker} onPick={setProfileTicker} onNavigate={navigate} />}
          {active === "Perbandingan Emiten" && <PerbandinganPage onNavigate={navigate} />}
          {active === "Ringkasan Rasio & Skor" && <RingkasanPage onNavigate={navigate} />}
          {active === "Harga Saham Real-Time" && <HargaSahamPage onNavigate={navigate} />}
          {active === "Tren Historis" && <TrenPage onNavigate={navigate} />}
          {active === "Export Laporan (PDF)" && <ExportPage onNavigate={navigate} flash={flash} />}
          {active === "Advisor" && <AdvisorLanding onNavigate={navigate} />}
          {active === "Tanya Advisor" && <TanyaAdvisorPage />}
          {active === "Macro & Banking Dashboard" && <MacroPage />}
          {active === "News" && <NewsPage user={profile.name} />}
          {active === "Metodologi & Alur" && <MetodologiPage onNavigate={navigate} />}
          {active === "User Guidelines" && <UserGuidelinesPage />}
          {active === "Help Center" && <HelpCenterPage flash={flash} onNavigate={navigate} />}
          {active === "Disclaimer Investasi" && <DisclaimerPage flash={flash} />}
          </Suspense>
          </ErrorBoundary>

          {active !== "Disclaimer Investasi" && (
            <p className="mt-auto pt-4 text-[11px] leading-relaxed" style={{ color: C.ter }}>
              {t("Alat pendukung keputusan untuk penelitian akademik, bukan rekomendasi beli/jual.")}{" "}
              <button onClick={() => navigate("Disclaimer Investasi")} className="underline underline-offset-2" style={{ color: C.sub }}>
                {t("Baca disclaimer")}
              </button>
            </p>
          )}
        </main>
      </div>

      {/* TOAST */}
      {toast && (
        <div className="absolute left-1/2 -translate-x-1/2 bottom-6 z-50 max-w-[calc(100vw-2rem)] px-4 py-2.5 rounded-[8px] text-[13px] font-medium shadow-lg"
          style={{ background: C.inner, border: `1px solid ${C.border}`, color: C.text }}>
          {toast}
        </div>
      )}
    </div>
  );
}

export default function App() {
  return <WorkspaceProvider><AppShell /></WorkspaceProvider>;
}
