// Metodologi & Alur: end-to-end flow of Super Stocks Intelligence as a flowchart and a DFD (level 0 / level 1).
// Pure documentation view — it reads constants from the engine so counts never drift from the model.
import { useState } from "react";
import { Workflow, Network, Sparkles, Cpu, ArrowRight, ArrowDown, User, ShieldCheck, Sigma } from "lucide-react";
import { VAR_KEYS, VAR_DEFS, RULE_COUNT, type VarKey } from "../domain/engine";
import { MODEL_VERSION, RATIO_DEFINITIONS } from "../domain/financial";
import { T, Panel, tx } from "../ui";
import { useT } from "../i18n";

type Nav = (p: string) => void;
type Zone = "human" | "ai" | "det";

const ZONE: Record<Zone, { label: string; color: string }> = {
  human: { label: "Manusia", color: T.blue },
  ai: { label: "AI (asistif)", color: T.violet },
  det: { label: "Deterministik", color: T.teal },
};

const STEPS: { n: string; title: string; detail: string; zone: Zone; page?: string; vars?: Record<string, string | number> }[] = [
  { n: "01", title: "Admin mengisi koleksi", detail: "Admin mengunggah PDF P&L dan SFP emiten bank. Di browser, kode membaca teks, mendeteksi satuan, mata uang, dan tahun. Validasi: kode 4 huruf, bank syariah ditolak, P&L + SFP lengkap, maks 50 MB, lalu wajib cek manual identitas.", zone: "human", page: "Perpustakaan Laporan" },
  { n: "02", title: "User menarik laporan", detail: "User memilih laporan dari koleksi. Kode (pdf.js) mencari halaman SFP/P&L, memakai satuan yang sudah ditetapkan saat unggah, dan mencocokkan 9 akun dengan alias. Tanpa AI.", zone: "det", page: "Perpustakaan Laporan" },
  { n: "03", title: "AI mengusulkan angka (cadangan)", detail: "Hanya untuk akun yang tidak ketemu; hanya teks halaman SFP/P&L yang dikirim. Setiap angka harus tampil persis di halaman yang disebut, kalau tidak dibuang. AI tidak menghitung. PDF pindaian tanpa OCR diisi manual.", zone: "ai", page: "Verifikasi Ekstraksi AI" },
  { n: "04", title: "Konfirmasi manual", detail: "Setiap usulan wajib dikonfirmasi; tanpa konfirmasi tidak ada data.", zone: "human", page: "Verifikasi Ekstraksi AI" },
  { n: "04b", title: "Verified dataset", detail: "Akun terverifikasi + harga saham input manual (untuk PER). Mata uang harga harus sama dengan dokumen.", zone: "human", page: "Perpustakaan Laporan" },
  { n: "05", title: "Kalkulasi rasio", detail: "{n} rasio dengan rumus tetap: {list}.", vars: { n: VAR_KEYS.length, list: VAR_KEYS.join(", ") }, zone: "det", page: "Ringkasan Rasio & Skor" },
  { n: "06", title: "Fuzzifikasi", detail: "Derajat keanggotaan μ tiap rasio pada himpunan segitiga.", zone: "det", page: "Skor & Defuzzifikasi" },
  { n: "07", title: "Inferensi Mamdani", detail: "{n} rule hard-coded, operator MIN (AND) dan MAX (agregasi).", vars: { n: RULE_COUNT }, zone: "det", page: "Rule Base Viewer" },
  { n: "08", title: "Defuzzifikasi centroid", detail: "Titik berat area agregat pada x = 0..100. Secara praktis skor berada di 12–88.", zone: "det", page: "Skor & Defuzzifikasi" },
  { n: "09", title: "Kategori kelayakan", detail: "Tidak Layak (<35) · Dipertimbangkan (35–65) · Layak (≥65).", zone: "det", page: "Ranking & Comparison" },
];

function MembershipCurve({ k }: { k: VarKey }) {
  const cfg = VAR_DEFS[k];
  const def = RATIO_DEFINITIONS[k];
  const W = 240, H = 70, pad = 6;
  const [min, max] = cfg.domain;
  const sx = (x: number) => ((x - min) / (max - min)) * W;
  const sy = (m: number) => H - pad - m * (H - pad * 2);
  return (
    <div className="rounded-[6px] p-3" style={{ background: T.inner, border: `1px solid ${T.line}` }}>
      <div className="flex items-baseline justify-between gap-2">
        <span className="text-[12px] font-semibold">{k}</span>
        <span className="text-[10px] truncate" style={{ color: T.ter }}>{tx(cfg.category)}</span>
      </div>
      <div className="text-[10.5px] mb-1.5 truncate" style={{ color: T.sub }} title={def.formula}>{def.formula}</div>
      <svg width="100%" viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none" style={{ display: "block" }}>
        <line x1={0} y1={H - pad} x2={W} y2={H - pad} stroke={T.line} />
        {cfg.sets.map((s) => {
          const pts = `${sx(s.pts[0])},${sy(0)} ${sx(s.pts[1])},${sy(1)} ${sx(s.pts[2])},${sy(0)}`;
          return (
            <g key={s.name}>
              <polygon points={pts} fill={s.color} fillOpacity={0.12} />
              <polyline points={pts} fill="none" stroke={s.color} strokeWidth="1.5" strokeOpacity={0.7} />
            </g>
          );
        })}
      </svg>
      <div className="flex justify-between text-[9.5px] tabular-nums mt-0.5" style={{ color: T.ter }}>
        <span>{min}{cfg.unit}</span><span>{max}{cfg.unit}</span>
      </div>
      <div className="flex flex-wrap gap-x-2.5 gap-y-0.5 mt-1.5">
        {cfg.sets.map((s) => (
          <span key={s.name} className="inline-flex items-center gap-1 text-[10px]" style={{ color: T.sub }}>
            <span className="w-1.5 h-1.5 rounded-sm" style={{ background: s.color }} />{tx(s.name)}
          </span>
        ))}
      </div>
    </div>
  );
}

function MembershipPanel({ onNavigate }: { onNavigate: Nav }) {
  const { t } = useT();
  return (
    <Panel
      title="Fungsi keanggotaan & rasio"
      icon={Sigma}
      right={
        <span className="inline-flex items-center gap-2 text-[11px] tabular-nums" style={{ color: T.sub }}>
          <span className="px-1.5 py-0.5 rounded-[4px]" style={{ background: T.inner, border: `1px solid ${T.line}` }}>{MODEL_VERSION}</span>
          {t("{n} rasio · {r} rule", { n: VAR_KEYS.length, r: RULE_COUNT })}
        </span>
      }
    >
      <div className="grid gap-3 grid-cols-1 sm:grid-cols-2 xl:grid-cols-3">
        {VAR_KEYS.map((k) => <MembershipCurve key={k} k={k} />)}
      </div>
      <button
        onClick={() => onNavigate("Rule Base Viewer")}
        className="mt-3 inline-flex items-center gap-1.5 text-[12px] font-medium"
        style={{ color: T.teal }}
      >
        {t("Lihat {r} rule lengkap", { r: RULE_COUNT })}<ArrowRight size={13} strokeWidth={1.75} />
      </button>
    </Panel>
  );
}

export default function MetodologiPage({ onNavigate }: { onNavigate: Nav }) {
  const [view, setView] = useState<"flow" | "dfd0" | "dfd1" | "dfd2">("flow");
  const [l2, setL2] = useState<"ekstraksi" | "verifikasi" | "fuzzy">("ekstraksi");
  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-wrap items-center gap-3">
        <div className="inline-flex rounded-[4px] p-0.5" style={{ border: `1px solid ${T.input}` }}>
          {([["flow", "Flowchart", Workflow], ["dfd0", "DFD Level 0", Network], ["dfd1", "DFD Level 1", Network], ["dfd2", "DFD Level 2", Network]] as const).map(([v, l, Icon]) => (
            <button key={v} onClick={() => setView(v)} className="h-8 px-3 rounded-[3px] text-[12px] font-medium inline-flex items-center gap-1.5"
              style={{ background: view === v ? T.inner : "transparent", color: view === v ? T.text : T.sub }}><Icon size={14} strokeWidth={1.75} />{tx(l)}</button>
          ))}
        </div>
        <div className="flex gap-3 text-[11px] ml-auto" style={{ color: T.sub }}>
          {(Object.keys(ZONE) as Zone[]).map((z) => <span key={z} className="inline-flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-sm" style={{ background: ZONE[z].color }} />{tx(ZONE[z].label)}</span>)}
        </div>
      </div>

      {view === "flow" && <Flowchart onNavigate={onNavigate} />}
      {view === "dfd0" && <Panel title="DFD Level 0 — Diagram Konteks" icon={Network}><Dfd0 /></Panel>}
      {view === "dfd1" && <Panel title="DFD Level 1 — Proses Utama" icon={Network}><Dfd1 /></Panel>}
      {view === "dfd2" && (
        <Panel title="DFD Level 2 — Rincian Proses" icon={Network}>
          <div className="inline-flex rounded-[4px] p-0.5 mb-3" style={{ border: `1px solid ${T.input}` }}>
            {([["ekstraksi", "2.0 Ekstraksi Akun"], ["verifikasi", "3.0 Verifikasi Manual"], ["fuzzy", "5.0 Fuzzy Mamdani"]] as const).map(([v, l]) => (
              <button key={v} onClick={() => setL2(v)} className="h-7 px-3 rounded-[3px] text-[12px] font-medium"
                style={{ background: l2 === v ? T.inner : "transparent", color: l2 === v ? T.text : T.sub }}>{tx(l)}</button>
            ))}
          </div>
          {l2 === "ekstraksi" && <Dfd2Ekstraksi />}
          {l2 === "verifikasi" && <Dfd2Verifikasi />}
          {l2 === "fuzzy" && <Dfd2Fuzzy />}
          <p className="mt-2 text-[11px]" style={{ color: T.ter }}>{tx("Kalkulasi Rasio (4.0) tidak dirinci: berupa sembilan rumus tetap, lihat panel Fungsi keanggotaan & rasio.")}</p>
        </Panel>
      )}

      <MembershipPanel onNavigate={onNavigate} />

      <Panel title="Batasan penelitian" icon={ShieldCheck}>
        <ul className="list-disc pl-5 flex flex-col gap-1.5 text-[12.5px] leading-relaxed" style={{ color: T.sub }}>
          <li>{tx("Hanya bank umum konvensional, sengaja, demi komparabilitas: pendapatan bunga berbeda dari bagi hasil, dan LDR, NIM, NPL tidak setara dengan FDR, NOM, NPF.")}</li>
          <li>{tx("Semua bank memakai basis laporan konsolidasian dan periode yang sama. Unit usaha syariah dalam bank konvensional ikut terkonsolidasi (efek kecil, dicatat sebagai asumsi).")}</li>
          <li>{tx("Bank besar dan kecil memiliki karakter rasio berbeda; skor dibaca sebagai perbandingan antar bank sejenis, bukan nilai absolut.")}</li>
          <li>{tx("Koleksi laporan dikelola admin secara berkala; user tidak dapat mengunggah PDF sendiri.")}</li>
          <li>{tx("Koleksi tersimpan di browser (tanpa backend), sehingga hanya terlihat di perangkat yang sama.")}</li>
          <li>{tx("PDF hasil pindaian atau gambar tidak dibaca (tanpa OCR); nilai akun harus diisi dan dicek manual.")}</li>
          <li>{tx("Rasio memakai proksi: NIM terhadap total aset (bukan aset produktif) dan EQA sebagai pengganti CAR. Tidak ada rasio kualitas aset (NPL).")}</li>
          <li>{tx("Skor praktis berada di 12–88, bukan 0–100, karena skor adalah centroid himpunan keluaran. Ambang 35 dan 65 adalah pilihan penelitian, bukan hasil turunan.")}</li>
          <li>{tx("Fungsi keanggotaan bahu bernilai 0 tepat di batas domain (mis. ROE ≥ 30, ROE ≤ 0, BOPO ≥ 110). Bank dengan nilai ekstrem dapat kehilangan rule terkait.")}</li>
          <li>{tx("Periode interim (Q1–Q3 dan bulanan) bersifat kumulatif dan tidak dianualisasi, sehingga tidak sebanding dengan tahunan (FY). Skor Model dan ranking hanya memakai FY; laporan bulanan tahun berjalan hanya ditampilkan sebagai rasio, dengan syarat semua emiten yang dibandingkan (minimal 2) memiliki bulan yang identik.")}</li>
          <li>{tx("Kunci API Anthropic dipanggil langsung dari browser (tanpa backend). Jangan memakai kunci produksi di perangkat bersama.")}</li>
        </ul>
      </Panel>

      <Panel title="Prinsip pemisahan AI dan model" icon={ShieldCheck}>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-[12.5px] leading-relaxed" style={{ color: T.sub }}>
          <p><b style={{ color: ZONE.ai.color }}>AI</b> {tx("hanya membaca dokumen dan mengusulkan nilai akun. AI tidak menghitung rasio, keanggotaan, rule, maupun skor.")}</p>
          <p><b style={{ color: ZONE.human.color }}>{tx("Manusia")}</b> {tx("mengonfirmasi setiap nilai. Hanya data terverifikasi yang masuk ke kalkulasi.")}</p>
          <p><b style={{ color: ZONE.det.color }}>{tx("Model")}</b> {tx("sepenuhnya deterministik: input yang sama selalu menghasilkan skor yang sama dan dapat ditelusuri ke rule yang aktif.")}</p>
        </div>
      </Panel>
    </div>
  );
}

function Flowchart({ onNavigate }: { onNavigate: Nav }) {
  const { t } = useT();
  const lanes: { zone: Zone; title: string; icon: typeof Cpu; steps: typeof STEPS }[] = [
    { zone: "human", title: "Input, konversi & verifikasi", icon: User, steps: STEPS.slice(0, 5) },
    { zone: "det", title: "Kalkulasi rasio", icon: Cpu, steps: STEPS.slice(5, 6) },
    { zone: "det", title: "Fuzzy Mamdani", icon: Sparkles, steps: STEPS.slice(6) },
  ];
  return (
    <div className="flex flex-col gap-2">
      {lanes.map((lane, li) => (
        <div key={lane.title}>
          <Panel title={t(lane.title)} icon={lane.icon}>
            <div className="flex flex-col lg:flex-row items-stretch gap-2">
              {lane.steps.map((s, i) => (
                <div key={s.n} className="flex flex-col lg:flex-row items-center gap-2 flex-1 min-w-0">
                  <button onClick={() => s.page && onNavigate(s.page)}
                    className="w-full flex-1 text-left rounded-[6px] p-3 transition-colors hover:brightness-110"
                    style={{ background: T.inner, border: `1px solid ${T.line}`, borderTop: `2px solid ${ZONE[s.zone].color}` }}>
                    <div className="flex items-center justify-between text-[10.5px] tnum" style={{ color: T.ter }}>
                      <span>{String(STEPS.indexOf(s) + 1).padStart(2, "0")}</span><span style={{ color: ZONE[s.zone].color }}>{t(ZONE[s.zone].label)}</span>
                    </div>
                    <div className="text-[13px] font-semibold mt-1">{t(s.title)}</div>
                    <div className="text-[11.5px] mt-1 leading-snug" style={{ color: T.sub }}>{t(s.detail, s.vars)}</div>
                  </button>
                  {i < lane.steps.length - 1 && <><ArrowRight size={14} className="hidden lg:block shrink-0" style={{ color: T.ter }} /><ArrowDown size={14} className="lg:hidden" style={{ color: T.ter }} /></>}
                </div>
              ))}
            </div>
          </Panel>
          {li === 0 && (
            <>
              <div className="flex justify-center py-1"><ArrowDown size={16} style={{ color: T.ter }} /></div>
              <Panel title="Flowchart SIA: input, konversi & verifikasi" icon={Workflow}>
                <SiaFlow />
                <p className="mt-2 text-[11px] leading-relaxed" style={{ color: T.ter }}>{t("Validasi unggahan: kode emiten 4 huruf, bank syariah ditolak, P&L dan SFP lengkap, maksimal 50 MB. Notasi mengikuti flowchart dokumen Sistem Informasi Akuntansi.")}</p>
              </Panel>
            </>
          )}
          {li < lanes.length - 1 && <div className="flex justify-center py-1"><ArrowDown size={16} style={{ color: T.ter }} /></div>}
        </div>
      ))}
      <p className="text-[11px]" style={{ color: T.ter }}>{t("Klik langkah mana pun untuk membuka halaman terkait.")}</p>
    </div>
  );
}

/* ─── Flowchart SIA: standard document-flowchart symbols in swimlanes ─── */
type SymKind = "term" | "input" | "proc" | "dec" | "doc" | "db" | "manual" | "predef" | "offpage";

const wrapText = (s: string, max: number) => {
  const out: string[] = [];
  let cur = "";
  for (const w of s.split(" ")) {
    if (cur && (cur + " " + w).length > max) { out.push(cur); cur = w; } else cur = cur ? `${cur} ${w}` : w;
  }
  if (cur) out.push(cur);
  return out;
};

const TEXT_FIT: Record<SymKind, number> = { term: 0.8, input: 0.85, proc: 0.88, dec: 0.52, doc: 0.88, db: 0.88, manual: 0.7, predef: 0.8, offpage: 0.88 };

function Sym({ kind, cx, cy, w = 164, h = 44, color, label }: { kind: SymKind; cx: number; cy: number; w?: number; h?: number; color: string; label?: string }) {
  const x = cx - w / 2, y = cy - h / 2, b = y + h, r = x + w;
  const p = { fill: T.inner, stroke: color, strokeWidth: 1.5 };
  const ry = 7;
  let shape: React.ReactNode;
  switch (kind) {
    case "term": shape = <rect x={x} y={y} width={w} height={h} rx={h / 2} {...p} />; break;
    case "input": shape = <polygon points={`${x},${y + h * 0.22} ${r},${y} ${r},${b} ${x},${b}`} {...p} />; break;
    case "proc": shape = <rect x={x} y={y} width={w} height={h} {...p} />; break;
    case "dec": shape = <polygon points={`${cx},${y} ${r},${cy} ${cx},${b} ${x},${cy}`} {...p} />; break;
    case "doc": shape = <path d={`M${x},${y} H${r} V${y + h * 0.85} Q${x + w * 0.75},${y + h * 0.7} ${cx},${y + h * 0.85} T${x},${y + h * 0.85} Z`} {...p} />; break;
    case "db": shape = (
      <g {...p}>
        <path d={`M${x},${y + ry} A${w / 2},${ry} 0 0 1 ${r},${y + ry} V${b - ry} A${w / 2},${ry} 0 0 1 ${x},${b - ry} Z`} />
        <path d={`M${x},${y + ry} A${w / 2},${ry} 0 0 0 ${r},${y + ry}`} fill="none" />
      </g>
    ); break;
    case "manual": shape = <polygon points={`${x},${y} ${r},${y} ${r - w * 0.12},${b} ${x + w * 0.12},${b}`} {...p} />; break;
    case "predef": shape = (
      <g {...p}>
        <rect x={x} y={y} width={w} height={h} />
        <line x1={x + 8} x2={x + 8} y1={y} y2={b} /><line x1={r - 8} x2={r - 8} y1={y} y2={b} />
      </g>
    ); break;
    case "offpage": shape = <polygon points={`${x},${y} ${r},${y} ${r},${y + h * 0.65} ${cx},${b} ${x},${y + h * 0.65}`} {...p} />; break;
  }
  const lines = label ? wrapText(tx(label), Math.floor((w * TEXT_FIT[kind]) / 5.6)) : [];
  const dy = kind === "doc" || kind === "offpage" ? -4 : kind === "input" ? 3 : kind === "db" ? 4 : 0;
  return (
    <g>
      {shape}
      {lines.map((l, i) => (
        <text key={i} x={cx} y={cy + dy + 4 - ((lines.length - 1) * 13) / 2 + i * 13} textAnchor="middle" fontSize="10.5" fontWeight={500} fill={T.text}>{l}</text>
      ))}
    </g>
  );
}

const SIA_LANES = [
  { cx: 95, label: "Admin", color: T.blue },
  { cx: 285, label: "Sistem (kode deterministik)", color: T.teal },
  { cx: 475, label: "Pengguna", color: T.blue },
  { cx: 665, label: "Penyedia AI", color: T.violet },
];

const SIA_LEGEND: { kind: SymKind; label: string }[] = [
  { kind: "term", label: "Awal / akhir" },
  { kind: "input", label: "Input manual" },
  { kind: "proc", label: "Proses" },
  { kind: "dec", label: "Keputusan" },
  { kind: "doc", label: "Dokumen" },
  { kind: "db", label: "Basis data" },
  { kind: "manual", label: "Operasi manual" },
  { kind: "predef", label: "Proses terdefinisi" },
  { kind: "offpage", label: "Konektor antarhalaman" },
];

function SiaFlow() {
  const A = 95, S = 285, P = 475, I = 665;
  return (
    <div className="overflow-x-auto"><svg viewBox={`0 0 ${W} 1060`} className="w-full min-w-[680px] h-auto">
      <Defs />
      {SIA_LANES.map((l, i) => (
        <g key={l.label}>
          {i > 0 && <line x1={i * 190} x2={i * 190} y1={0} y2={905} stroke={T.line} />}
          <text x={l.cx} y={18} textAnchor="middle" fontSize="11" fontWeight={600} fill={l.color}>{tx(l.label)}</text>
        </g>
      ))}
      <line x1={0} x2={W} y1={28} y2={28} stroke={T.line} />
      <line x1={0} x2={W} y1={905} y2={905} stroke={T.line} />

      <Flow d={`M${A},69 V103`} />
      <Flow d={`M${A + 82},125 H${S - 82}`} />
      <Flow d={`M${S},147 V170`} />
      <Flow d={`M${S - 82},200 H${A + 70}`} label="Tidak" lx={184} ly={193} />
      <Flow d={`M${A},177 V147`} label="unggah ulang" lx={A + 36} ly={166} />
      <Flow d={`M${S},230 V275 H${A + 78}`} label="Ya" lx={S + 14} ly={254} />
      <Flow d={`M${A},297 V350 H${S - 65}`} />
      <Flow d={`M${S},375 V403`} />
      <Flow d={`M${P},372 V425 H${S + 82}`} label="permintaan tarik" lx={P - 60} ly={418} />
      <Flow d={`M${S},447 V468`} />
      <Flow d={`M${S + 82},500 H${I - 82}`} label="Tidak" lx={400} ly={493} />
      <Flow d={`M${I},522 V575 H${S + 82}`} label="usulan angka" lx={520} ly={568} />
      <Flow d={`M${S - 82},500 H197 V650 H${S - 70}`} label="Ya" lx={212} ly={520} />
      <Flow d={`M${S},597 V627`} />
      <Flow d={`M${S + 70},650 H${P - 82}`} label="draf untuk dicek" lx={S + 120} ly={642} />
      <Flow d={`M${P},672 V703`} />
      <Flow d={`M${P},747 V800 H${S + 65}`} label="terverifikasi" lx={P - 55} ly={793} />
      <Flow d={`M${S},825 V852`} />

      <Sym kind="term" cx={A} cy={55} w={100} h={28} color={T.blue} label="Mulai" />
      <Sym kind="input" cx={A} cy={125} color={T.blue} label="Unggah PDF P&L + SFP" />
      <Sym kind="proc" cx={S} cy={125} color={T.teal} label="Baca teks, deteksi satuan, mata uang, tahun" />
      <Sym kind="dec" cx={S} cy={200} h={60} color={T.teal} label="Lolos validasi?" />
      <Sym kind="doc" cx={A} cy={200} w={140} h={46} color={T.blue} label="Pesan penolakan" />
      <Sym kind="manual" cx={A} cy={275} color={T.blue} label="Cek manual identitas laporan" />
      <Sym kind="db" cx={S} cy={350} w={130} h={50} color={T.amber} label="Koleksi laporan (IndexedDB)" />
      <Sym kind="input" cx={P} cy={350} color={T.blue} label="Pilih & tarik laporan" />
      <Sym kind="proc" cx={S} cy={425} color={T.teal} label="Cocokkan 9 akun dengan alias (tanpa AI)" />
      <Sym kind="dec" cx={S} cy={500} h={64} color={T.teal} label="Semua akun ketemu?" />
      <Sym kind="predef" cx={I} cy={500} color={T.violet} label="Usulkan angka dari teks halaman SFP/P&L" />
      <Sym kind="proc" cx={S} cy={575} color={T.teal} label="Buang angka yang tidak tampil di halaman" />
      <Sym kind="doc" cx={S} cy={650} w={140} h={46} color={T.teal} label="Draf akun" />
      <Sym kind="manual" cx={P} cy={650} color={T.blue} label="Verifikasi & konfirmasi tiap akun" />
      <Sym kind="input" cx={P} cy={725} color={T.blue} label="Harga saham (untuk PER)" />
      <Sym kind="db" cx={S} cy={800} w={130} h={50} color={T.amber} label="Verified dataset" />
      <Sym kind="offpage" cx={S} cy={872} w={140} h={40} color={T.teal} label="Ke Kalkulasi rasio" />

      <text x={14} y={928} fontSize="11" fontWeight={600} fill={T.sub}>{tx("Keterangan simbol")}</text>
      {SIA_LEGEND.map((s, i) => {
        const row = i < 5 ? 0 : 1;
        const cx = row === 0 ? 76 + i * 152 : 152 + (i - 5) * 152;
        const cy = 965 + row * 62;
        return (
          <g key={s.kind}>
            <Sym kind={s.kind} cx={cx} cy={cy} w={56} h={26} color={T.sub} />
            <text x={cx} y={cy + 28} textAnchor="middle" fontSize="10" fill={T.sub}>{tx(s.label)}</text>
          </g>
        );
      })}
    </svg></div>
  );
}

/* ─── DFD primitives (Yourdon/DeMarco notation) ─── */
const W = 760;
const Entity = ({ x, y, w = 130, label }: { x: number; y: number; w?: number; label: string }) => (
  <g><rect x={x} y={y} width={w} height={44} fill={T.inner} stroke={T.blue} strokeWidth={1.5} />
    <text x={x + w / 2} y={y + 26} textAnchor="middle" fontSize="12" fontWeight={600} fill={T.text}>{tx(label)}</text></g>
);
const Proc = ({ cx, cy, r = 50, id, label, color = T.teal }: { cx: number; cy: number; r?: number; id: string; label: string[]; color?: string }) => (
  <g><circle cx={cx} cy={cy} r={r} fill={T.inner} stroke={color} strokeWidth={1.5} />
    <text x={cx} y={cy - 8 - (label.length - 1) * 6} textAnchor="middle" fontSize="10" fill={T.ter}>{id}</text>
    {label.map((l, i) => <text key={i} x={cx} y={cy + 8 + i * 13 - (label.length - 1) * 6} textAnchor="middle" fontSize="11.5" fontWeight={600} fill={T.text}>{tx(l)}</text>)}</g>
);
const Store = ({ x, y, id, label }: { x: number; y: number; id: string; label: string }) => (
  <g><line x1={x} x2={x + 150} y1={y} y2={y} stroke={T.amber} /><line x1={x} x2={x + 150} y1={y + 30} y2={y + 30} stroke={T.amber} />
    <line x1={x + 34} x2={x + 34} y1={y} y2={y + 30} stroke={T.amber} />
    <text x={x + 17} y={y + 19} textAnchor="middle" fontSize="10.5" fill={T.ter}>{id}</text>
    <text x={x + 42} y={y + 19} fontSize="11.5" fill={T.text}>{tx(label)}</text></g>
);
const Flow = ({ d, label, lx, ly }: { d: string; label?: string; lx?: number; ly?: number }) => (
  <g><path d={d} fill="none" stroke={T.sub} strokeWidth={1.2} markerEnd="url(#dfd-arrow)" />
    {label && <text x={lx} y={ly} textAnchor="middle" fontSize="10" fill={T.sub}>{tx(label)}</text>}</g>
);
const Defs = () => (
  <defs><marker id="dfd-arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
    <path d="M0,0 L10,5 L0,10 z" fill={T.sub} /></marker></defs>
);

function Dfd0() {
  return (
    <div className="overflow-x-auto"><svg viewBox={`0 0 ${W} 300`} className="w-full min-w-[620px] h-auto">
      <Defs />
      <Entity x={20} y={60} label="Admin" />
      <Entity x={20} y={200} label="Pengguna" />
      <Entity x={610} y={125} label="Penyedia AI" />
      <Proc cx={380} cy={150} r={80} id="0" label={["Super Stocks Intelligence", "(SSI)"]} />
      <Flow d="M150,68 L322,108" label="laporan P&L/SFP, kunci API" lx={235} ly={68} />
      <Flow d="M318,122 L150,96" label="status koleksi" lx={235} ly={128} />
      <Flow d="M150,206 L308,176" label="tarik, konfirmasi, harga" lx={238} ly={182} />
      <Flow d="M314,194 L150,232" label="skor, kategori, PDF" lx={238} ly={236} />
      <Flow d="M458,132 L610,138" label="teks halaman laporan" lx={535} ly={124} />
      <Flow d="M610,160 L458,168" label="usulan nilai akun" lx={535} ly={182} />
      <text x={W / 2} y={285} textAnchor="middle" fontSize="10" fill={T.ter}>{tx("Konteks pasar (World Bank, Frankfurter, FMP/Twelve Data, Finnhub) hanya tampilan dan bukan input model, sehingga tidak digambar.")}</text>
    </svg></div>
  );
}

function Dfd1() {
  return (
    <div className="overflow-x-auto"><svg viewBox={`0 0 ${W} 600`} className="w-full min-w-[620px] h-auto">
      <Defs />
      <Entity x={145} y={6} w={100} label="Admin" />
      <Entity x={650} y={108} w={100} label="Penyedia AI" />
      <Entity x={10} y={298} w={110} label="Pengguna" />
      <Proc cx={195} cy={130} r={46} id="1.0" label={["Kelola", "Koleksi"]} color={T.blue} />
      <Proc cx={520} cy={130} r={46} id="2.0" label={["Ekstraksi", "Akun"]} color={T.violet} />
      <Proc cx={520} cy={320} r={46} id="3.0" label={["Verifikasi", "Manual"]} color={T.blue} />
      <Proc cx={520} cy={510} r={46} id="4.0" label={["Kalkulasi", "Rasio"]} />
      <Proc cx={330} cy={510} r={46} id="5.0" label={["Fuzzy", "Mamdani"]} />
      <Proc cx={135} cy={425} r={46} id="6.0" label={["Penyajian", "& Ekspor"]} />
      <Store x={275} y={115} id="D1" label="Dokumen" />
      <Store x={445} y={14} id="D2" label="Cache teks" />
      <Store x={445} y={205} id="D3" label="Draf akun" />
      <Store x={445} y={400} id="D4" label="Verified + harga" />
      <Store x={60} y={495} id="D5" label="Hasil analisis" />
      {/* Admin ↔ 1.0 */}
      <Flow d="M180,50 L182,84" label="laporan, kunci API" lx={105} ly={70} />
      <Flow d="M210,84 L208,50" label="status koleksi" lx={290} ly={70} />
      <Flow d="M241,130 L275,130" label="berkas" lx={258} ly={124} />
      <Flow d="M425,130 L474,130" label="PDF" lx={450} ly={124} />
      {/* 2.0 ↔ AI, D2, D3 */}
      <Flow d="M566,120 L650,120" label="teks" lx={608} ly={113} />
      <Flow d="M650,142 L566,140" label="usulan" lx={608} ly={158} />
      <Flow d="M505,85 L505,46" label="simpan" lx={470} ly={68} />
      <Flow d="M538,46 L538,88" label="baca" lx={568} ly={68} />
      <Flow d="M520,176 L520,205" label="draf akun" lx={575} ly={194} />
      {/* Pengguna */}
      <Flow d="M65,298 L65,215 L484,157" label="tarik laporan" lx={310} ly={176} />
      <Flow d="M520,235 L520,274" label="draf" lx={548} ly={258} />
      <Flow d="M474,310 L120,310" label="draf untuk dicek" lx={300} ly={303} />
      <Flow d="M120,330 L474,332" label="konfirmasi, koreksi, harga" lx={300} ly={346} />
      {/* 3.0 → 4.0 → 5.0 → D5 → 6.0 → Pengguna */}
      <Flow d="M520,366 L520,400" label="terverifikasi" lx={600} ly={388} />
      <Flow d="M520,430 L520,464" label="akun, harga" lx={585} ly={452} />
      <Flow d="M474,510 L376,510" label="9 rasio" lx={425} ly={503} />
      <Flow d="M284,510 L210,510" label="skor, kategori" lx={247} ly={503} />
      <Flow d="M135,495 L135,471" label="hasil" lx={170} ly={487} />
      <Flow d="M118,388 L85,342" label="skor, kategori, PDF" lx={52} ly={372} />
      <text x={W / 2} y={590} textAnchor="middle" fontSize="10" fill={T.ter}>{tx("Seluruh data store saat ini berada di peramban (localStorage dan IndexedDB). Kunci API disimpan di peramban admin.")}</text>
    </svg></div>
  );
}

function Dfd2Ekstraksi() {
  return (
    <div className="overflow-x-auto"><svg viewBox={`0 0 ${W} 330`} className="w-full min-w-[620px] h-auto">
      <Defs />
      <Entity x={10} y={88} w={90} label="Pengguna" />
      <Entity x={640} y={238} w={100} label="Penyedia AI" />
      <Store x={105} y={10} id="D2" label="Cache teks" />
      <Store x={10} y={195} id="D1" label="Dokumen" />
      <Store x={585} y={10} id="D3" label="Draf akun" />
      <Proc cx={180} cy={110} r={40} id="2.1" label={["Baca PDF", "→ teks"]} color={T.teal} />
      <Proc cx={340} cy={110} r={40} id="2.2" label={["Cari halaman", "& satuan"]} color={T.teal} />
      <Proc cx={500} cy={110} r={40} id="2.3" label={["Cocokkan", "9 akun"]} color={T.teal} />
      <Proc cx={660} cy={110} r={40} id="2.5" label={["Susun", "draf"]} color={T.teal} />
      <Proc cx={500} cy={260} r={40} id="2.4" label={["Usul AI", "(cadangan)"]} color={T.violet} />
      <Flow d="M100,100 L140,100" label="pilih" lx={120} ly={94} />
      <Flow d="M85,195 L156,142" label="berkas PDF" lx={170} ly={180} />
      <Flow d="M165,70 L165,40" label="simpan" lx={128} ly={60} />
      <Flow d="M195,40 L195,70" label="baca" lx={222} ly={60} />
      <Flow d="M220,110 L300,110" label="teks halaman" lx={260} ly={104} />
      <Flow d="M380,110 L460,110" label="halaman, unit" lx={420} ly={104} />
      <Flow d="M540,110 L620,110" label="akun cocok" lx={580} ly={104} />
      <Flow d="M490,150 L490,220" label="akun hilang" lx={436} ly={190} />
      <Flow d="M538,250 L640,250" label="teks halaman" lx={590} ly={244} />
      <Flow d="M640,270 L538,270" label="usulan angka" lx={590} ly={284} />
      <Flow d="M526,228 L640,145" label="usulan valid" lx={612} ly={205} />
      <Flow d="M660,70 L660,40" label="draf akun" lx={705} ly={60} />
      <text x={W / 2} y={318} textAnchor="middle" fontSize="10" fill={T.ter}>{tx("Angka dari AI dibuang jika tidak tampil persis di halaman yang disebut. PDF pindaian (tanpa teks) tidak melewati 2.2 dan diisi manual.")}</text>
    </svg></div>
  );
}

function Dfd2Verifikasi() {
  return (
    <div className="overflow-x-auto"><svg viewBox={`0 0 ${W} 360`} className="w-full min-w-[620px] h-auto">
      <Defs />
      <Entity x={10} y={240} w={110} label="Pengguna" />
      <Store x={125} y={10} id="D3" label="Draf akun" />
      <Store x={445} y={240} id="D4" label="Verified + harga" />
      <Proc cx={200} cy={130} r={40} id="3.1" label={["Tinjau", "usulan"]} color={T.blue} />
      <Proc cx={360} cy={130} r={40} id="3.2" label={["Validasi &", "normalisasi"]} color={T.teal} />
      <Proc cx={520} cy={130} r={40} id="3.3" label={["Tetapkan", "status"]} color={T.teal} />
      <Proc cx={680} cy={130} r={40} id="3.4" label={["Simpan", "harga"]} color={T.blue} />
      <Flow d="M200,40 L200,90" label="draf akun" lx={240} ly={70} />
      <Flow d="M240,130 L320,130" label="nilai usulan" lx={280} ly={124} />
      <Flow d="M175,164 L100,240" label="nilai, sumber" lx={60} ly={200} />
      <Flow d="M120,252 L335,160" label="konfirmasi, koreksi" lx={200} ly={275} />
      <Flow d="M400,130 L480,130" label="nilai valid" lx={440} ly={124} />
      <Flow d="M520,170 L520,240" label="akun verified" lx={578} ly={210} />
      <Flow d="M505,93 Q400,20 275,25" label="status akun" lx={400} ly={30} />
      <Flow d="M65,284 L65,320 L680,320 L680,170" label="harga saham" lx={380} ly={313} />
      <Flow d="M660,162 L580,242" label="harga" lx={650} ly={218} />
      <text x={W / 2} y={350} textAnchor="middle" fontSize="10" fill={T.ter}>{tx("Angka dicocokkan ke halaman sumber dan satuan dinormalkan. Harga saham wajib bermata uang sama dengan dokumen.")}</text>
    </svg></div>
  );
}

function Dfd2Fuzzy() {
  return (
    <div className="overflow-x-auto"><svg viewBox={`0 0 ${W} 330`} className="w-full min-w-[620px] h-auto">
      <Defs />
      <Entity x={10} y={108} w={100} label="4.0 Kalkulasi" />
      <Store x={255} y={10} id="K1" label="Basis aturan" />
      <Store x={585} y={240} id="D5" label="Hasil analisis" />
      <Proc cx={190} cy={130} r={38} id="5.1" label={["Fuzzifikasi"]} color={T.teal} />
      <Proc cx={320} cy={130} r={38} id="5.2" label={["Evaluasi", "rule"]} color={T.teal} />
      <Proc cx={450} cy={130} r={38} id="5.3" label={["Agregasi"]} color={T.teal} />
      <Proc cx={580} cy={130} r={38} id="5.4" label={["Centroid"]} color={T.teal} />
      <Proc cx={710} cy={130} r={38} id="5.5" label={["Kategori"]} color={T.teal} />
      <Flow d="M110,130 L152,130" label="9 rasio" lx={131} ly={124} />
      <Flow d="M228,130 L282,130" label="μ rasio" lx={255} ly={124} />
      <Flow d="M358,130 L412,130" label="kekuatan" lx={385} ly={124} />
      <Flow d="M488,130 L542,130" label="kurva μ(x)" lx={515} ly={124} />
      <Flow d="M618,130 L672,130" label="skor" lx={645} ly={124} />
      <Flow d="M280,40 L210,97" label="fungsi keanggotaan" lx={150} ly={52} />
      <Flow d="M330,40 L322,92" label="24 rule" lx={366} ly={72} />
      <Flow d="M395,40 L430,97" label="himpunan output" lx={490} ly={62} />
      <Flow d="M710,168 L710,240" label="skor, kategori" lx={655} ly={210} />
      <text x={W / 2} y={310} textAnchor="middle" fontSize="10" fill={T.ter}>{tx("MIN untuk AND, MAX untuk agregasi pada 101 titik (x = 0..100). Tanpa rule aktif, skor = 0. Basis aturan berada di kode (engine.ts).")}</text>
    </svg></div>
  );
}
