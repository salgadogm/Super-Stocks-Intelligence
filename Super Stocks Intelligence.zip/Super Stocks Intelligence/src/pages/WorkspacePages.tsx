// Store-backed pages: Overview, Analyzer, Ranking, Watchlist, Insight, Advisor, News.
// Every number shown here comes from a verified dataset + deterministic engine run. Nothing is estimated.
import { useMemo, useState } from "react";
import { getLang } from "../domain/preferences";
import { track } from "../domain/usage";
import { exportAnalysesCsv } from "../domain/exporters";
import { translate } from "../i18n";
import {
  Gauge, GitBranch, ShieldCheck, ListOrdered, Bookmark, BookmarkMinus, Search, LineChart, FileDown, Table2,
  CandlestickChart, MessageSquare, Globe2, Newspaper, Upload, CheckSquare, ArrowRight, Info, Send, Lightbulb, Calculator,
  Sparkles, Activity, Database, Scale, Library,
} from "lucide-react";
import { canManageCollection, getRole } from "../domain/news";
import { jsPDF } from "jspdf";
import { RULES, OUT, VAR_KEYS, VAR_DEFS, RULE_COUNT, ruleId, dominantSet, CATEGORY_COLOR, ZONES, tri, type VarKey } from "../domain/engine";
import { CANONICAL_ACCOUNTS, RATIO_DEFINITIONS, REQUIRED_ACCOUNTS, NOT_FOUND_MESSAGE, STATEMENT_LABEL, periodText } from "../domain/financial";
import { useWorkspace, docLabel, periodSort, type AnalysisRecord } from "../domain/store";
import { issuersFrom } from "../domain/issuers";
import { SOURCE_NOTICE } from "./CollectionsPages";
import { MarketStrip, SourceHealth, BankSegments, ScoreVsMarket, SectorNews } from "./MarketPages";
import { useQuotes } from "../domain/market";
import GettingStarted from "../components/GettingStarted";
import {
  T, Panel, Btn, Badge, DemoBadge, CategoryBadge, EmptyState, Notice, Stat, Table, Row, Select, inputCls, inputStyle,
  fmtNum, fmtDate, ANALYSIS_META, tx,
} from "../ui";

const L = (s: string, v?: Record<string, string | number>) => translate(getLang(), s, v);
type Nav = (p: string) => void;
type Flash = (m: string) => void;

const NoAnalysis = ({ onNavigate, what }: { onNavigate: Nav; what: string }) => (
  <Panel><EmptyState icon={Gauge} title={L("{what} belum tersedia", { what: L(what) })}
    why="Halaman ini hanya menampilkan hasil yang dihitung dari verified dataset. Belum ada analisis tersimpan di workspace."
    action={<>{canManageCollection(getRole())
      ? <Btn kind="primary" icon={Upload} onClick={() => onNavigate("Upload Laporan")}>Upload Laporan</Btn>
      : <Btn kind="primary" icon={Library} onClick={() => onNavigate("Perpustakaan Laporan")}>Pilih laporan dari koleksi</Btn>}<Btn onClick={() => onNavigate("Collections")}>Muat data demo di Collections</Btn></>} /></Panel>
);

function Landing({ items, onNavigate }: { items: { icon: typeof Gauge; label: string; sub: string; desc: string }[]; onNavigate: Nav }) {
  return (
    <div className="grid gap-3 grid-cols-1 md:grid-cols-2 xl:grid-cols-4">
      {items.map(({ icon: Icon, label, sub, desc }) => (
        <button key={label} onClick={() => onNavigate(label)} className="text-left rounded-[6px] p-4 flex flex-col gap-2 transition-colors hover:bg-[var(--c-row-hover)]"
          style={{ background: T.card, border: `1px solid ${T.line}` }}>
          <div className="flex items-center gap-2"><Icon size={15} strokeWidth={1.75} style={{ color: T.sub }} /><span className="text-[13px] font-semibold">{tx(label)}</span><ArrowRight size={13} className="ml-auto" style={{ color: T.ter }} /></div>
          <div className="text-[11px] tnum" style={{ color: T.teal }}>{tx(sub)}</div>
          <div className="text-[12px] leading-relaxed" style={{ color: T.sub }}>{tx(desc)}</div>
        </button>
      ))}
    </div>
  );
}

/* ─── Overview ─────────────────────────────────────── */
export function OverviewPage({ onNavigate }: { onNavigate: Nav }) {
  const ws = useWorkspace();
  const [fYear, setFYear] = useState("all");
  const [fPeriod, setFPeriod] = useState("all");
  const [fCat, setFCat] = useState("all");
  const [fSrc, setFSrc] = useState("all");
  const years = [...new Set(ws.analyses.map((a) => a.period.fiscalYear))].sort((a, b) => b - a);
  const filterActive = [fYear, fPeriod, fCat, fSrc].some((v) => v !== "all");
  const resetFilters = () => { setFYear("all"); setFPeriod("all"); setFCat("all"); setFSrc("all"); };
  const latest = useMemo(() => {
    const m = new Map<string, AnalysisRecord>();
    for (const a of ws.analyses) {
      if ((fYear !== "all" && String(a.period.fiscalYear) !== fYear) || (fPeriod !== "all" && a.period.period !== fPeriod) ||
        (fSrc === "demo" && !a.demo) || (fSrc === "upload" && a.demo)) continue;
      const cur = m.get(a.ticker);
      if (!cur || periodSort(a.period) > periodSort(cur.period)) m.set(a.ticker, a);
    }
    return [...m.values()].filter((a) => fCat === "all" || a.category === fCat).sort((a, b) => b.score - a.score);
  }, [ws.analyses, fYear, fPeriod, fCat, fSrc]);
  const queue = ws.documents.filter((d) => ws.progress(d.id).verified < ws.progress(d.id).total);
  const dist = (["Layak", "Dipertimbangkan", "Tidak Layak"] as const).map((c) => ({ c, n: latest.filter((a) => a.category === c).length }));
  const quotes = useQuotes(latest.slice(0, 8).map((a) => a.ticker));
  const openKeys = () => onNavigate("Akun Saya");
  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center gap-3 flex-wrap">
        <span className="text-[12px] tnum" style={{ color: T.sub }}>{new Date().toLocaleDateString(getLang() === "en" ? "en-GB" : "id-ID", { weekday: "long", day: "numeric", month: "long", year: "numeric" })}</span>
        <span className="ml-auto"><SourceHealth onKeys={openKeys} /></span>
      </div>
      <GettingStarted onNavigate={onNavigate} />
      <div className="flex items-center gap-2 flex-wrap">
        <Select value={fYear} onChange={setFYear} className="!w-auto"><option value="all">{tx("Semua tahun")}</option>{years.map((y) => <option key={y} value={y}>{y}</option>)}</Select>
        <Select value={fPeriod} onChange={setFPeriod} className="!w-auto"><option value="all">{tx("Semua periode")}</option>{["Q1", "Q2", "Q3", "FY"].map((p) => <option key={p} value={p}>{p}</option>)}</Select>
        <Select value={fCat} onChange={setFCat} className="!w-auto"><option value="all">{tx("Semua kategori")}</option>{["Layak", "Dipertimbangkan", "Tidak Layak"].map((c) => <option key={c} value={c}>{translate(getLang(), c)}</option>)}</Select>
        <Select value={fSrc} onChange={setFSrc} className="!w-auto"><option value="all">{tx("Semua sumber")}</option><option value="upload">{tx("Unggahan")}</option><option value="demo">{tx("Demo")}</option></Select>
        {filterActive && <Btn kind="ghost" onClick={resetFilters}>Reset filter</Btn>}
        <Btn icon={FileDown} disabled={latest.length === 0} onClick={() => exportAnalysesCsv("overview", latest)}>Ekspor CSV</Btn>
        <span className="ml-auto text-[11px]" style={{ color: T.ter }}>{tx("Filter memengaruhi tabel skor, distribusi, dan Emiten terskor")}</span>
      </div>
      <div className="grid gap-3 grid-cols-2 xl:grid-cols-4">
        <Stat label="Laporan di workspace" value={ws.documents.length} sub={translate(getLang(), "{n} demo", { n: ws.documents.filter((d) => d.demo).length })} />
        <Stat label="Menunggu verifikasi" value={queue.length} sub="Belum semua 9 akun Verified" />
        <Stat label="Emiten terskor" value={latest.length} sub={translate(getLang(), "dari {n} emiten terunggah", { n: issuersFrom(ws.documents).length })} accent />
        <Stat label="Analisis tersimpan" value={ws.analyses.length} sub="Skor Model terbaru per emiten" />
      </div>
      <MarketStrip onOpen={() => onNavigate("Macro & Banking Dashboard")} onKeys={openKeys} />
      {ws.analyses.length === 0 ? <NoAnalysis onNavigate={onNavigate} what="Ringkasan workspace" /> : latest.length === 0 ? (
        <Panel><EmptyState icon={Search} title="Tidak ada emiten yang cocok" why="Tidak ada analisis tersimpan yang memenuhi kombinasi filter ini." action={<Btn onClick={resetFilters}>Reset filter</Btn>} /></Panel>
      ) : (
        <div className="grid gap-4 grid-cols-1 xl:grid-cols-[1.6fr_1fr]">
          <Panel title="Skor Model terbaru per emiten" icon={ListOrdered} pad={false}
            right={<Btn kind="ghost" onClick={() => onNavigate("Ranking & Comparison")}>{tx("Ranking")} <ArrowRight size={13} /></Btn>}>
            <Table cols="1fr 2fr 80px 130px 90px 90px 70px" head={["Ticker", "Perusahaan", "Skor", "Kategori", "Periode", "Harga", "Δ1D"]} minWidth={720}>
              {latest.slice(0, 8).map((a) => { const q = quotes.data?.[a.ticker]; return (
                <Row key={a.id} cols="1fr 2fr 80px 130px 90px 90px 70px" onClick={() => { ws.setFocusDoc(a.documentId); onNavigate("Skor & Defuzzifikasi"); }}>
                  <span className="font-semibold flex items-center gap-1.5">{a.ticker}{a.demo && <DemoBadge />}</span>
                  <span className="truncate" style={{ color: T.sub }}>{a.companyName}</span>
                  <span className="tnum font-semibold">{a.score.toFixed(2)}</span><CategoryBadge cat={a.category} />
                  <span className="tnum" style={{ color: T.sub }}>{a.period.period} {a.period.fiscalYear}</span>
                  <span className="tnum" style={{ color: q ? T.text : T.ter }}>{q ? fmtNum(q.price, 0) : "—"}</span>
                  <span className="tnum text-[11.5px]" style={{ color: !q ? T.ter : q.changePct >= 0 ? T.teal : T.red }}>{q ? `${q.changePct >= 0 ? "+" : ""}${fmtNum(q.changePct, 1)}%` : "—"}</span>
                </Row>
              ); })}
            </Table>
          </Panel>
          <div className="flex flex-col gap-4">
            <Panel title="Distribusi kategori (periode terbaru)" icon={Activity}>
              <div className="flex flex-col gap-2.5">
                {dist.map(({ c, n }) => (
                  <div key={c} className="flex items-center gap-3 text-[12px]">
                    <span className="w-28" style={{ color: T.sub }}>{tx(c)}</span>
                    <div className="flex-1 h-1.5 rounded-full" style={{ background: T.inner }}><div className="h-full rounded-full" style={{ width: `${(n / latest.length) * 100}%`, background: CATEGORY_COLOR[c] }} /></div>
                    <span className="tnum w-6 text-right">{n}</span>
                  </div>
                ))}
              </div>
            </Panel>
            <Panel title="Antrian verifikasi" icon={CheckSquare} right={queue.length > 0 ? <Btn kind="ghost" onClick={() => onNavigate("Verifikasi Ekstraksi AI")}>{tx("Verifikasi")} <ArrowRight size={13} /></Btn> : undefined}>
              {queue.length === 0 ? <div className="text-[12px]" style={{ color: T.ter }}>{tx("Semua laporan sudah terverifikasi.")}</div> :
                <div className="flex flex-col gap-2">{queue.slice(0, 4).map((d) => { const p = ws.progress(d.id); return (
                  <div key={d.id} className="flex items-center gap-3 text-[12px]">
                    <span className="flex-1 truncate">{docLabel(d)}</span>
                    <div className="w-20 h-1.5 rounded-full" style={{ background: T.inner }}><div className="h-full rounded-full" style={{ width: `${(p.verified / p.total) * 100}%`, background: T.amber }} /></div>
                    <span className="tnum w-8 text-right" style={{ color: T.sub }}>{p.verified}/{p.total}</span>
                  </div>
                ); })}</div>}
            </Panel>
            <Panel title="Aktivitas terakhir" icon={Database}>
              {ws.events.length === 0 ? <div className="text-[12px]" style={{ color: T.ter }}>{tx("Belum ada aktivitas.")}</div> :
                <div className="flex flex-col gap-2">{ws.events.slice(0, 5).map((e, i) => (
                  <div key={i} className="text-[12px]"><div>{tx(e.title)}</div><div className="text-[11px]" style={{ color: T.ter }}>{tx(e.detail)} · {fmtDate(e.at)}</div></div>
                ))}</div>}
            </Panel>
          </div>
        </div>
      )}
      {latest.length > 0 && (
        <div className="grid gap-4 grid-cols-1 lg:grid-cols-3">
          <ScoreVsMarket rows={latest.map((a) => ({ ticker: a.ticker, score: a.score, category: a.category, quote: quotes.data?.[a.ticker] }))} />
          <BankSegments tickers={latest.map((a) => a.ticker)} />
          <SectorNews />
        </div>
      )}
    </div>
  );
}

/* ─── Analyzer ─────────────────────────────────────── */
export function AnalyzerLanding({ onNavigate }: { onNavigate: Nav }) {
  const ws = useWorkspace();
  const focus = ws.analyses.find((a) => a.documentId === ws.focusDoc) ?? ws.analyses[0];
  return (
    <div className="flex flex-col gap-4">
      <Panel title="Konteks analisis aktif" icon={Calculator}>
        {focus ? (
          <div className="flex items-center gap-3 flex-wrap text-[12.5px]">
            <span className="font-semibold">{docLabel(focus)}</span>{focus.demo && <DemoBadge />}
            <span style={{ color: T.sub }}>{focus.companyName}</span>
            <span className="tnum font-semibold">{tx("Skor Model")} {focus.score.toFixed(2)}</span><CategoryBadge cat={focus.category} />
            <Badge tone={ANALYSIS_META[ws.analysisStatus(focus.documentId)].tone}>{tx(ANALYSIS_META[ws.analysisStatus(focus.documentId)].label)}</Badge>
          </div>
        ) : <div className="text-[12px]" style={{ color: T.sub }}>{tx("Belum ada analisis. Selesaikan verifikasi 9 akun wajib lalu hitung dari halaman Verifikasi.")}</div>}
      </Panel>
      <Landing onNavigate={onNavigate} items={[
        { icon: Gauge, label: "Skor & Defuzzifikasi", sub: L("{n} analisis tersimpan", { n: ws.analyses.length }), desc: "Jejak lengkap: rasio → fuzzifikasi → rule aktif → agregasi → centroid → Skor Model." },
        { icon: GitBranch, label: "Rule Base Viewer", sub: L("{n} rule · AND = min", { n: RULE_COUNT }), desc: "Basis aturan Mamdani beserta aktivasi pada analisis yang dipilih." },
        { icon: ShieldCheck, label: "Validasi Model", sub: "Statistik deskriptif", desc: "Hanya metrik yang benar-benar dihitung dari analisis tersimpan." },
      ]} />
    </div>
  );
}

export function RuleBasePage() {
  const ws = useWorkspace();
  const [q, setQ] = useState("");
  const [out, setOut] = useState("all");
  const current = ws.analyses.find((a) => a.documentId === ws.focusDoc) ?? ws.analyses[0];
  const rows = RULES.map((r, i) => ({ r, i, act: current?.strengths[i] ?? null })).filter(({ r, i }) =>
    (out === "all" || String(r.out) === out) && (ruleId(i) + " " + r.text).toLowerCase().includes(q.toLowerCase()));
  const ante = (text: string) => text.replace(/^IF\s+/i, "").split(/\s+THEN\s+/i)[0];
  const cols = "56px 1fr 90px 130px 110px";
  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center gap-3 flex-wrap">
        <div className="relative"><Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2" style={{ color: T.ter }} />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder={L("Cari rule, rasio, himpunan…")} className={inputCls + " !w-72 pl-8"} style={inputStyle} /></div>
        <Select value={out} onChange={setOut} className="!w-auto"><option value="all">{tx("Semua konsekuen")}</option>{OUT.map((o, i) => <option key={o.name} value={i}>{tx(o.name)}</option>)}</Select>
        {ws.analyses.length > 0 && current && (
          <Select value={current.documentId} onChange={ws.setFocusDoc} className="!w-auto">{ws.analyses.map((a) => <option key={a.id} value={a.documentId}>{tx("Aktivasi:")} {docLabel(a)}{a.demo ? " (DEMO)" : ""}</option>)}</Select>
        )}
        <span className="ml-auto text-[11px]" style={{ color: T.ter }}>{rows.length} / {RULE_COUNT} {tx("rule")}</span>
      </div>
      <Panel pad={false}>
        <Table cols={cols} head={["Rule ID", "Antecedent", "Operator", "Consequent", "Aktivasi (α)"]} minWidth={760}>
          {rows.map(({ r, i, act }) => (
            <Row key={i} cols={cols}>
              <span className="tnum font-semibold" style={{ color: T.sub }}>{ruleId(i)}</span>
              <span className="text-[12px]">{ante(r.text)}</span>
              <span className="text-[11px]" style={{ color: T.sub }}>{tx("AND (min)")}</span>
              <span className="text-[12px] font-semibold" style={{ color: OUT[r.out].color }}>{tx(OUT[r.out].name)}</span>
              <span className="tnum" style={{ color: act && act > 0.005 ? T.teal : T.ter }}>{act == null ? "—" : act.toFixed(3)}</span>
            </Row>
          ))}
        </Table>
      </Panel>
      {!current && <Notice icon={Info}>Kolom aktivasi kosong karena belum ada analisis tersimpan.</Notice>}
    </div>
  );
}

export function ValidasiModelPage({ onNavigate }: { onNavigate: Nav }) {
  const ws = useWorkspace();
  const a = ws.analyses;
  if (!a.length) return <NoAnalysis onNavigate={onNavigate} what="Statistik model" />;
  const scores = a.map((x) => x.score);
  const mean = scores.reduce((s, v) => s + v, 0) / scores.length;
  const sd = Math.sqrt(scores.reduce((s, v) => s + (v - mean) ** 2, 0) / scores.length);
  const firedAvg = a.reduce((s, x) => s + x.strengths.filter((v) => v > 0.005).length, 0) / a.length;
  const ruleUse = RULES.map((_, i) => a.filter((x) => x.strengths[i] > 0.005).length);
  const never = ruleUse.filter((n) => n === 0).length;
  return (
    <div className="flex flex-col gap-4">
      <Notice tone="amber" icon={Info}>
        Validasi prediktif (mis. korelasi skor dengan return saham) belum dihitung: dibutuhkan data harga historis terverifikasi yang belum terhubung. Tidak ada angka akurasi yang ditampilkan sampai data itu tersedia.
      </Notice>
      <div className="grid gap-3 grid-cols-2 xl:grid-cols-4">
        <Stat label="Analisis dihitung" value={a.length} sub={L("{n} demo", { n: a.filter((x) => x.demo).length })} />
        <Stat label="Rata-rata Skor Model" value={mean.toFixed(2)} sub={`σ ${sd.toFixed(2)} · min ${Math.min(...scores).toFixed(1)} · max ${Math.max(...scores).toFixed(1)}`} />
        <Stat label="Rata-rata rule aktif" value={firedAvg.toFixed(1)} sub={L("dari {n} rule", { n: RULE_COUNT })} />
        <Stat label="Rule tidak pernah aktif" value={never} sub="Pada analisis tersimpan" />
      </div>
      <Panel title="Frekuensi aktivasi rule" icon={GitBranch}>
        <div className="grid gap-1.5 grid-cols-1 md:grid-cols-2">
          {ruleUse.map((n, i) => (
            <div key={i} className="flex items-center gap-3 text-[12px]">
              <span className="tnum w-8" style={{ color: T.ter }}>{ruleId(i)}</span>
              <div className="flex-1 h-1.5 rounded-full" style={{ background: T.inner }}><div className="h-full rounded-full" style={{ width: `${(n / a.length) * 100}%`, background: OUT[RULES[i].out].color }} /></div>
              <span className="tnum w-12 text-right" style={{ color: T.sub }}>{n}/{a.length}</span>
            </div>
          ))}
        </div>
      </Panel>
    </div>
  );
}

/* ─── Ranking & Watchlist ─────────────────────────── */
export function RankingPage({ onNavigate, flash }: { onNavigate: Nav; flash: Flash }) {
  const ws = useWorkspace();
  const [q, setQ] = useState("");
  const [cat, setCat] = useState("all");
  const rows = ws.latestByTicker().sort((a, b) => b.score - a.score)
    .filter((a) => (cat === "all" || a.category === cat) && (a.ticker + a.companyName).toLowerCase().includes(q.toLowerCase()));
  if (!ws.analyses.length) return <NoAnalysis onNavigate={onNavigate} what="Ranking" />;
  const cols = "52px 90px 1.6fr 80px 130px 80px 120px 130px 90px";
  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center gap-3 flex-wrap">
        <h2 className="text-[14px] font-semibold">{tx("Ranking Berdasarkan Skor Model")}</h2>
        <div className="ml-auto relative"><Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2" style={{ color: T.ter }} />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder={L("Cari ticker / perusahaan")} className={inputCls + " !w-60 pl-8"} style={inputStyle} /></div>
        <Select value={cat} onChange={setCat} className="!w-auto"><option value="all">{tx("Semua kategori")}</option>{ZONES.map((z) => <option key={z.name} value={z.name}>{tx(z.name)}</option>)}</Select>
        <Btn icon={FileDown} disabled={rows.length === 0} onClick={() => exportAnalysesCsv("ranking", rows)}>Ekspor CSV</Btn>
      </div>
      <Panel pad={false}>
        <Table cols={cols} head={["Rank", "Ticker", "Perusahaan", "Skor Model", "Kategori", "Periode", "Verifikasi", "Tanggal Analisis", "Aksi"]} minWidth={1000}>
          {rows.length === 0 && <div className="px-4 py-6 text-[12px]" style={{ color: T.sub }}>{tx("Tidak ada emiten yang cocok dengan filter.")}</div>}
          {rows.map((a, i) => {
            const st = ws.analysisStatus(a.documentId);
            const watched = ws.watchlist.includes(a.ticker);
            return (
              <Row key={a.id} cols={cols}>
                <span className="tnum font-semibold" style={{ color: T.sub }}>{i + 1}</span>
                <span className="font-semibold flex items-center gap-1.5">{a.ticker}{a.demo && <DemoBadge />}</span>
                <span className="truncate" style={{ color: T.sub }}>{a.companyName}</span>
                <span className="tnum font-semibold" style={{ color: i === 0 ? T.teal : T.text }}>{a.score.toFixed(2)}</span>
                <CategoryBadge cat={a.category} />
                <span className="tnum" style={{ color: T.sub }}>{a.period.period} {a.period.fiscalYear}</span>
                <span><Badge tone={st === "calculated" ? "green" : "amber"}>{tx(st === "calculated" ? "9/9 Verified" : "Berubah")}</Badge></span>
                <span className="text-[11.5px] tnum" style={{ color: T.sub }}>{fmtDate(a.calculatedAt)}</span>
                <span className="flex gap-1">
                  <Btn kind="ghost" icon={Gauge} title="Lihat jejak skor" onClick={() => { ws.setFocusDoc(a.documentId); onNavigate("Skor & Defuzzifikasi"); }} />
                  <Btn kind="ghost" icon={watched ? BookmarkMinus : Bookmark} title={watched ? "Hapus dari watchlist" : "Pantau"}
                    onClick={() => { ws.toggleWatch(a.ticker); flash(L(watched ? "{t} dihapus dari watchlist" : "{t} ditambahkan ke watchlist", { t: a.ticker })); }} />
                </span>
              </Row>
            );
          })}
        </Table>
      </Panel>
      <div className="text-[11px]" style={{ color: T.ter }}>{tx("Urutan hanya mencerminkan Skor Model pada periode terbaru tiap emiten; bukan rekomendasi beli/jual.")}</div>
    </div>
  );
}

export function WatchlistPage({ onNavigate }: { onNavigate: Nav }) {
  const ws = useWorkspace();
  const [add, setAdd] = useState("");
  const known = [...new Set(ws.documents.map((d) => d.ticker))].filter((t) => !ws.watchlist.includes(t)).sort();
  const latest = ws.latestByTicker();
  const yearNow = new Date().getFullYear();
  const cols = "90px 1.6fr 90px 140px 90px 150px 170px 90px";
  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center gap-2 flex-wrap">
        <span className="text-[12px]" style={{ color: T.sub }}>{tx("Pantau emiten untuk melihat skor terbaru dan status laporan. Ini bukan portofolio.")}</span>
        <div className="ml-auto flex gap-2">
          <Select value={add} onChange={setAdd} className="!w-48"><option value="">{tx("Pilih emiten…")}</option>{known.map((t) => <option key={t}>{t}</option>)}</Select>
          <Btn kind="primary" icon={Bookmark} disabled={!add} onClick={() => { ws.toggleWatch(add); setAdd(""); }}>Pantau</Btn>
        </div>
      </div>
      <Panel pad={false}>
        {ws.watchlist.length === 0 ? (
          <EmptyState icon={Bookmark} title="Watchlist kosong" why="Tambahkan emiten dari pemilih di atas atau dari halaman Ranking." action={<Btn onClick={() => onNavigate("Ranking & Comparison")}>Buka Ranking</Btn>} />
        ) : (
          <Table cols={cols} head={["Ticker", "Perusahaan", "Skor", "Kategori", "Periode", "Kesegaran", "Status laporan terbaru", "Aksi"]} minWidth={960}>
            {ws.watchlist.map((t) => {
              const a = latest.find((x) => x.ticker === t);
              const docs = ws.documents.filter((d) => d.ticker === t).sort((x, y) => periodSort(y.period) - periodSort(x.period));
              const d = docs[0];
              const name = a?.companyName ?? d?.companyName ?? "—";
              const lag = a ? yearNow - a.period.fiscalYear : null;
              const p = d ? ws.progress(d.id) : null;
              return (
                <Row key={t} cols={cols}>
                  <span className="font-semibold flex items-center gap-1.5">{t}{(a?.demo || d?.demo) && <DemoBadge />}</span>
                  <span className="truncate" style={{ color: T.sub }}>{name}</span>
                  <span className="tnum font-semibold">{a ? a.score.toFixed(2) : "—"}</span>
                  {a ? <CategoryBadge cat={a.category} /> : <span style={{ color: T.ter }}>{tx("Belum dianalisis")}</span>}
                  <span className="tnum" style={{ color: T.sub }}>{a ? `${a.period.period} ${a.period.fiscalYear}` : "—"}</span>
                  <span>{lag == null ? <Badge>{tx("Tidak ada analisis")}</Badge> : lag <= 1 ? <Badge tone="green">{tx("Terkini")}</Badge> : <Badge tone="amber">{L("{n} tahun lalu", { n: lag })}</Badge>}</span>
                  <span className="text-[11.5px]" style={{ color: T.sub }}>{d && p ? `${docLabel(d)} · ${p.verified}/${p.total} ${L("Verified")}` : L("Belum ada laporan")}</span>
                  <span className="flex gap-1">
                    {a && <Btn kind="ghost" icon={Gauge} title="Lihat skor" onClick={() => { ws.setFocusDoc(a.documentId); onNavigate("Skor & Defuzzifikasi"); }} />}
                    <Btn kind="ghost" icon={BookmarkMinus} title="Berhenti memantau" onClick={() => ws.toggleWatch(t)} />
                  </span>
                </Row>
              );
            })}
          </Table>
        )}
      </Panel>
    </div>
  );
}

/* ─── Insight ─────────────────────────────────────── */
function useFocusAnalysis() {
  const ws = useWorkspace();
  const list = [...ws.analyses].sort((a, b) => a.ticker.localeCompare(b.ticker) || periodSort(b.period) - periodSort(a.period));
  const current = list.find((a) => a.documentId === ws.focusDoc) ?? list[0];
  const picker = current && (
    <Select value={current.documentId} onChange={ws.setFocusDoc} className="!w-auto min-w-[220px]">
      {list.map((a) => <option key={a.id} value={a.documentId}>{docLabel(a)}{a.demo ? " (DEMO)" : ""}</option>)}
    </Select>
  );
  return { ws, current, picker };
}

export function InsightLanding({ onNavigate }: { onNavigate: Nav }) {
  const ws = useWorkspace();
  const tickers = new Set(ws.analyses.map((a) => a.ticker)).size;
  return (
    <Landing onNavigate={onNavigate} items={[
      { icon: Table2, label: "Ringkasan Rasio & Skor", sub: `${ws.analyses.length} analisis`, desc: "Nilai 9 rasio, periode sebelumnya, perubahan, dan derajat keanggotaan." },
      { icon: CandlestickChart, label: "Harga Saham Real-Time", sub: "Sumber harga belum terhubung", desc: "Harga yang dipakai PER hanya input manual per laporan; tidak ada feed harga." },
      { icon: LineChart, label: "Tren Historis", sub: `${tickers} emiten`, desc: "Riwayat Skor Model dan rasio per periode. Periode kosong tetap kosong." },
      { icon: FileDown, label: "Export Laporan (PDF)", sub: "PDF jejak analisis", desc: "Laporan PDF berisi akun terverifikasi, rasio, rule aktif, defuzzifikasi, dan metodologi." },
    ]} />
  );
}

export function RingkasanPage({ onNavigate }: { onNavigate: Nav }) {
  const { ws, current, picker } = useFocusAnalysis();
  if (!current) return <NoAnalysis onNavigate={onNavigate} what="Ringkasan rasio" />;
  const prev = ws.previousOf(current);
  const cols = "70px 1.4fr 100px 100px 100px 1.2fr";
  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center gap-3 flex-wrap">{picker}{current.demo && <DemoBadge />}
        <span className="tnum font-semibold">{tx("Skor Model")} {current.score.toFixed(2)}</span><CategoryBadge cat={current.category} />
        {prev && <span className="text-[12px] tnum" style={{ color: T.sub }}>{tx("vs")} {prev.period.fiscalYear}: {prev.score.toFixed(2)} (<span style={{ color: current.score >= prev.score ? T.teal : T.red }}>{current.score >= prev.score ? "+" : ""}{(current.score - prev.score).toFixed(2)}</span>)</span>}
      </div>
      <Panel pad={false}>
        <Table cols={cols} head={["Rasio", "Nama", "Nilai", "Sebelumnya", "Perubahan", "Keanggotaan (μ)"]} minWidth={820}>
          {VAR_KEYS.map((k) => {
            const v = current.ratios[k]; const p = prev?.ratios[k]; const u = RATIO_DEFINITIONS[k].unit;
            return (
              <Row key={k} cols={cols}>
                <span className="font-semibold">{k}</span>
                <span style={{ color: T.sub }}>{tx(RATIO_DEFINITIONS[k].name)}</span>
                <span className="tnum font-semibold">{fmtNum(v)}{u}</span>
                <span className="tnum" style={{ color: T.sub }}>{p == null ? "—" : fmtNum(p) + u}</span>
                <span className="tnum" style={{ color: p == null ? T.ter : T.sub }}>{p == null ? L("Tidak ada periode sebelumnya") : (v - p >= 0 ? "+" : "") + fmtNum(v - p)}</span>
                <span className="text-[11.5px] tnum" style={{ color: T.sub }}>
                  {VAR_DEFS[k].sets.map((s) => `${L(s.name)} ${tri(v, s.pts).toFixed(2)}`).join(" · ")}
                </span>
              </Row>
            );
          })}
        </Table>
      </Panel>
    </div>
  );
}

export function HargaSahamPage({ onNavigate }: { onNavigate: Nav }) {
  const ws = useWorkspace();
  const rows = ws.market.filter((m) => m.sharePrice != null);
  return (
    <div className="flex flex-col gap-4">
      <Notice tone="amber" icon={Info}>
        Feed harga pasar belum dikonfigurasi. Super Stocks Intelligence tidak menampilkan harga real-time maupun tertunda. Harga di bawah adalah input manual per laporan yang dipakai hanya untuk PER (input pasar eksternal).
      </Notice>
      <Panel title="Harga saham yang dimasukkan" icon={CandlestickChart} pad={false}>
        {rows.length === 0 ? (
          <EmptyState icon={CandlestickChart} title="Belum ada harga saham" why="Masukkan harga per tanggal laporan di workspace Verifikasi agar PER dapat dihitung." action={<Btn onClick={() => onNavigate("Verifikasi Ekstraksi AI")}>Buka Verifikasi</Btn>} />
        ) : (
          <Table cols="1.2fr 120px 80px 120px 1.4fr" head={["Laporan", "Harga", "Mata uang", "Tanggal harga", "Sumber"]} minWidth={640}>
            {rows.map((m) => {
              const d = ws.documents.find((x) => x.id === m.documentId);
              return (
                <Row key={m.documentId} cols="1.2fr 120px 80px 120px 1.4fr">
                  <span className="font-semibold flex items-center gap-1.5">{d ? docLabel(d) : m.documentId}{d?.demo && <DemoBadge />}</span>
                  <span className="tnum">{fmtNum(m.sharePrice, 0)}</span><span style={{ color: T.sub }}>{m.currency}</span>
                  <span className="tnum" style={{ color: T.sub }}>{m.priceDate || "—"}</span><span style={{ color: T.sub }}>{m.source || "—"}</span>
                </Row>
              );
            })}
          </Table>
        )}
      </Panel>
      <ScoreVsPricePanel />
    </div>
  );
}

/* ─── Skor Model vs harga ─────────────────────────────────────────
   Compares the change in Skor Model with the change in the manually entered share price between an
   issuer's two latest FY analyses that both carry a price. Descriptive only — no causal claim. */
function ScoreVsPricePanel() {
  const ws = useWorkspace();
  const rows = useMemo(() => {
    const by = new Map<string, AnalysisRecord[]>();
    for (const a of ws.analyses) if (a.period.period === "FY" && a.sharePrice != null) by.set(a.ticker, [...(by.get(a.ticker) ?? []), a]);
    return [...by.entries()].map(([t, list]) => {
      const s = [...list].sort((a, b) => periodSort(a.period) - periodSort(b.period));
      const cur = s[s.length - 1], prev = s.length > 1 ? s[s.length - 2] : null;
      return {
        t, cur, prev,
        dScore: prev ? cur.score - prev.score : null,
        dPrice: prev && prev.sharePrice ? ((cur.sharePrice! - prev.sharePrice) / prev.sharePrice) * 100 : null,
      };
    }).sort((a, b) => b.cur.score - a.cur.score);
  }, [ws.analyses]);
  const pts = rows.filter((r) => r.dScore != null && r.dPrice != null);
  const aligned = pts.filter((r) => Math.sign(r.dScore!) === Math.sign(r.dPrice!)).length;

  const W = 560, H = 300, P = 40;
  const mx = Math.max(5, ...pts.map((r) => Math.abs(r.dScore!))) * 1.15;
  const my = Math.max(10, ...pts.map((r) => Math.abs(r.dPrice!))) * 1.15;
  const x = (v: number) => W / 2 + (v / mx) * (W / 2 - P);
  const y = (v: number) => H / 2 - (v / my) * (H / 2 - P);

  return (
    <Panel title="Skor Model vs Harga Saham" icon={Scale}>
      {rows.length === 0 ? (
        <EmptyState compact icon={Scale} title="Belum ada analisis FY dengan harga" why="Isi harga saham pada laporan FY lalu jalankan kalkulasi untuk melihat perbandingan skor dan harga." />
      ) : (
        <div className="grid grid-cols-1 xl:grid-cols-[1.1fr_1fr] gap-5">
          <div>
            {pts.length === 0 ? (
              <p className="text-[12px] py-10 text-center" style={{ color: T.ter }}>{tx("Perlu ≥2 tahun FY berharga per emiten untuk menghitung perubahan.")}</p>
            ) : (
              <svg viewBox={`0 0 ${W} ${H}`} className="w-full h-auto">
                <rect x={W / 2} y={P} width={W / 2 - P} height={H / 2 - P} fill={T.teal} opacity={0.06} />
                <rect x={P} y={H / 2} width={W / 2 - P} height={H / 2 - P} fill={T.teal} opacity={0.06} />
                <line x1={P} x2={W - P} y1={H / 2} y2={H / 2} stroke={T.line} />
                <line x1={W / 2} x2={W / 2} y1={P} y2={H - P} stroke={T.line} />
                <text x={W - P} y={H / 2 - 6} textAnchor="end" fontSize="10" fill={T.ter}>{L("Δ Skor →")}</text>
                <text x={W / 2 + 6} y={P + 10} fontSize="10" fill={T.ter}>{L("↑ Δ Harga %")}</text>
                <text x={W - P - 4} y={P + 14} textAnchor="end" fontSize="10" fill={T.sub}>{L("searah ↑")}</text>
                <text x={P + 4} y={H - P - 6} fontSize="10" fill={T.sub}>{L("searah ↓")}</text>
                {pts.map((r) => (
                  <g key={r.t}>
                    <circle cx={x(r.dScore!)} cy={y(r.dPrice!)} r={5} fill={CATEGORY_COLOR[r.cur.category]} stroke={T.card} strokeWidth={1.5} />
                    <text x={x(r.dScore!) + 8} y={y(r.dPrice!) + 3.5} fontSize="10.5" fontWeight={600} fill={T.text}>{r.t}</text>
                  </g>
                ))}
              </svg>
            )}
            {pts.length > 0 && (
              <p className="mt-2 text-[11.5px]" style={{ color: T.sub }}>
                <b className="tnum" style={{ color: T.text }}>{aligned}/{pts.length}</b> {tx("emiten bergerak searah (skor dan harga naik/turun bersama). Area berarsir = searah.")}
              </p>
            )}
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-[11.5px] tnum">
              <thead><tr className="text-[10.5px]" style={{ color: T.ter }}>
                <th className="text-left font-medium py-2">{tx("Emiten")}</th><th className="text-right font-medium">{tx("Skor")}</th><th className="text-right font-medium">{tx("Δ Skor")}</th>
                <th className="text-right font-medium">{tx("Harga")}</th><th className="text-right font-medium">{tx("Δ Harga")}</th>
              </tr></thead>
              <tbody>{rows.map((r) => (
                <tr key={r.t} style={{ borderTop: `1px solid ${T.line}` }}>
                  <td className="py-2"><div className="font-semibold">{r.t}</div><div className="text-[10.5px]" style={{ color: T.ter }}>FY{r.cur.period.fiscalYear}{r.prev ? ` vs FY${r.prev.period.fiscalYear}` : ""}</div></td>
                  <td className="text-right"><span className="font-semibold">{fmtNum(r.cur.score, 1)}</span> <CategoryBadge cat={r.cur.category} /></td>
                  <td className="text-right" style={{ color: r.dScore == null ? T.ter : r.dScore >= 0 ? T.teal : T.red }}>{r.dScore == null ? "—" : `${r.dScore >= 0 ? "+" : ""}${r.dScore.toFixed(1)}`}</td>
                  <td className="text-right">{fmtNum(r.cur.sharePrice, 0)}</td>
                  <td className="text-right" style={{ color: r.dPrice == null ? T.ter : r.dPrice >= 0 ? T.teal : T.red }}>{r.dPrice == null ? "—" : `${r.dPrice >= 0 ? "+" : ""}${r.dPrice.toFixed(1)}%`}</td>
                </tr>
              ))}</tbody>
            </table>
          </div>
        </div>
      )}
      <p className="mt-3 text-[11px] leading-relaxed" style={{ color: T.ter }}>
        {tx("Harga = input manual per tanggal laporan, bukan feed real-time. Perbandingan bersifat deskriptif: kesearahan skor dan harga tidak membuktikan hubungan sebab-akibat dan bukan rekomendasi beli/jual.")}
      </p>
    </Panel>
  );
}

function TrendChart({ years, series, max, unit }: { years: number[]; series: (number | null)[]; max: number; unit: string }) {
  const W = 720, H = 200, P = 32;
  const x = (i: number) => P + (years.length === 1 ? (W - 2 * P) / 2 : (i * (W - 2 * P)) / (years.length - 1));
  const y = (v: number) => H - P - (v / (max || 1)) * (H - 2 * P);
  const segs: string[] = []; let cur = "";
  series.forEach((v, i) => { if (v == null) { if (cur) segs.push(cur); cur = ""; } else cur += `${cur ? "L" : "M"}${x(i)},${y(v)} `; });
  if (cur) segs.push(cur);
  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="w-full h-auto">
      {[0, 0.5, 1].map((f) => <line key={f} x1={P} x2={W - P} y1={y(max * f)} y2={y(max * f)} stroke={T.line} />)}
      {segs.map((d, i) => <path key={i} d={d} fill="none" stroke={T.teal} strokeWidth={1.75} />)}
      {series.map((v, i) => v == null
        ? <text key={i} x={x(i)} y={H - P - 6} textAnchor="middle" fontSize="10" fill={T.ter}>{L("n/a")}</text>
        : <g key={i}><circle cx={x(i)} cy={y(v)} r={3} fill={T.teal} /><text x={x(i)} y={y(v) - 8} textAnchor="middle" fontSize="10" fill={T.sub}>{v.toFixed(1)}{unit}</text></g>)}
      {years.map((yr, i) => <text key={yr} x={x(i)} y={H - 10} textAnchor="middle" fontSize="10" fill={T.ter}>{yr}</text>)}
    </svg>
  );
}

export function TrenPage({ onNavigate }: { onNavigate: Nav }) {
  const ws = useWorkspace();
  const tickers = [...new Set(ws.analyses.map((a) => a.ticker))].sort();
  const [ticker, setTicker] = useState("");
  const [metric, setMetric] = useState<"score" | VarKey>("score");
  const t = ticker || tickers[0];
  const fy = ws.analyses.filter((a) => a.ticker === t && a.period.period === "FY");
  const interim = ws.analyses.filter((a) => a.ticker === t && a.period.period !== "FY").sort((a, b) => periodSort(b.period) - periodSort(a.period));
  if (!tickers.length) return <NoAnalysis onNavigate={onNavigate} what="Tren historis" />;
  const ys = fy.map((a) => a.period.fiscalYear);
  const years = ys.length ? Array.from({ length: Math.max(...ys) - Math.min(...ys) + 1 }, (_, i) => Math.min(...ys) + i) : [];
  const byYear = (yr: number) => fy.find((a) => a.period.fiscalYear === yr);
  const val = (a?: AnalysisRecord) => (a ? (metric === "score" ? a.score : a.ratios[metric]) : null);
  const series = years.map((yr) => val(byYear(yr)));
  const max = metric === "score" ? 100 : Math.max(...series.map((v) => v ?? 0)) * 1.2;
  const unit = metric === "score" ? "" : RATIO_DEFINITIONS[metric].unit;
  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center gap-3 flex-wrap">
        <Select value={t} onChange={setTicker} className="!w-auto">{tickers.map((x) => <option key={x}>{x}</option>)}</Select>
        <Select value={metric} onChange={(v) => setMetric(v as typeof metric)} className="!w-auto"><option value="score">{tx("Skor Model")}</option>{VAR_KEYS.map((k) => <option key={k} value={k}>{k}</option>)}</Select>
        <span className="text-[11px]" style={{ color: T.ter }}>{tx("Periode FY · tahun tanpa analisis ditandai n/a, tidak diinterpolasi")}</span>
      </div>
      <Panel title={`${t} — ${L(metric === "score" ? "Skor Model" : RATIO_DEFINITIONS[metric].name)}`} icon={LineChart}><TrendChart years={years} series={series} max={max} unit={unit} /></Panel>
      <Panel pad={false}>
        <Table cols="80px 100px 140px repeat(9, 70px)" head={["Tahun", "Skor", "Kategori", ...VAR_KEYS]} minWidth={1000}>
          {years.map((yr) => { const a = byYear(yr); return (
            <Row key={yr} cols="80px 100px 140px repeat(9, 70px)">
              <span className="tnum font-semibold">{yr}</span>
              {a ? <><span className="tnum">{a.score.toFixed(2)}</span><CategoryBadge cat={a.category} />{VAR_KEYS.map((k) => <span key={k} className="tnum text-[11.5px]" style={{ color: T.sub }}>{fmtNum(a.ratios[k])}</span>)}</>
                : <span className="col-span-11 text-[12px]" style={{ color: T.ter }}>{tx("Tidak ada analisis untuk periode ini.")}</span>}
            </Row>); })}
        </Table>
      </Panel>
      {interim.length > 0 && (
        <Panel title={`${t} — ${L("Periode interim (Q1–Q3 dan bulanan)")}`} icon={LineChart} pad={false}>
          <Table cols="120px 100px 140px repeat(9, 70px)" head={["Periode", "Skor", "Kategori", ...VAR_KEYS]} minWidth={1060}>
            {interim.map((a) => (
              <Row key={a.id} cols="120px 100px 140px repeat(9, 70px)">
                <span className="tnum font-semibold">{periodText(a.period)}</span>
                <span className="tnum">{a.score.toFixed(2)}</span>
                <CategoryBadge cat={a.category} />
                {VAR_KEYS.map((k) => <span key={k} className="tnum text-[11.5px]" style={{ color: T.sub }}>{fmtNum(a.ratios[k])}</span>)}
              </Row>
            ))}
          </Table>
          <p className="px-4 py-2.5 text-[11px]" style={{ color: T.ter, borderTop: `1px solid ${T.line}` }}>{L("Rasio kuartal bersifat kumulatif sejak awal tahun, jadi tidak dibandingkan langsung dengan FY.")}</p>
        </Panel>
      )}
    </div>
  );
}

function buildPdf(a: AnalysisRecord) {
  const pdf = new jsPDF({ unit: "mm", format: "a4" });
  let y = 16;
  const ML = 14, W = 182;
  const line = (txt: string, size = 9, bold = false) => {
    pdf.setFont("helvetica", bold ? "bold" : "normal"); pdf.setFontSize(size);
    for (const l of pdf.splitTextToSize(txt, W) as string[]) { if (y > 282) { pdf.addPage(); y = 16; } pdf.text(l, ML, y); y += size * 0.45; }
    y += 1;
  };
  const h = (t: string) => { y += 3; line(L(t), 11, true); };
  line(L("Super Stocks Intelligence —Laporan Analisis Skor Model"), 14, true);
  if (a.demo) line(L("DATA DEMO — angka ilustratif, bukan laporan emiten sebenarnya."), 9, true);
  line(`${a.companyName} (${a.ticker}) · ${L("Periode")} ${a.period.period} ${a.period.fiscalYear} · ${L("Model")} ${a.modelVersion}`);
  line(`${L("Dihitung:")} ${fmtDate(a.calculatedAt)} · ${L("Dicetak:")} ${fmtDate(new Date().toISOString())}`);
  h("Sumber data"); line(L(SOURCE_NOTICE));
  h("Akun terverifikasi");
  for (const k of REQUIRED_ACCOUNTS) { const ca = CANONICAL_ACCOUNTS[k]; const v = a.accounts[k];
    line(`${L(ca.labelId)} (${L(STATEMENT_LABEL[ca.statement])}): ${v == null ? L(NOT_FOUND_MESSAGE) : fmtNum(v, k === "basic_eps" ? 2 : 0)}`); }
  line(`${L("Harga saham (input pasar eksternal, untuk PER):")} ${a.sharePrice == null ? "—" : fmtNum(a.sharePrice, 0)}`);
  h("Rasio & input fuzzy");
  for (const k of VAR_KEYS) { const d = dominantSet(k, a.ratios[k]);
    line(`${k} = ${fmtNum(a.ratios[k])}${RATIO_DEFINITIONS[k].unit} · ${RATIO_DEFINITIONS[k].formula} · ${L("dominan:")} ${L(d.name)} (μ=${d.mu.toFixed(2)})`); }
  h("Rule aktif (α = min)");
  const fired = RULES.map((r, i) => ({ r, i, s: a.strengths[i] })).filter((x) => x.s > 0.005).sort((p, q) => q.s - p.s);
  if (!fired.length) line(L("Tidak ada rule aktif."));
  fired.forEach(({ r, i, s }) => line(`${ruleId(i)} α=${s.toFixed(3)} — ${r.text}`));
  h("Agregasi & defuzzifikasi");
  line(OUT.map((o, i) => `${L(o.name)}: ${a.classStrength[i].toFixed(3)}`).join(" · ") + ` ${L("(agregasi max)")}`);
  line(`${L("Centroid pada semesta 0–100 → Skor Model")} ${a.score.toFixed(2)}`);
  h("Hasil"); line(`${L("Skor Model")} ${a.score.toFixed(2)} — ${L("Kategori Kelayakan Berdasarkan Model:")} ${L(a.category)}`, 10, true);
  h("Metodologi"); line(L("Fuzzy Mamdani, 9 rasio, {n} rule, fungsi keanggotaan segitiga, AND = min, implikasi min, agregasi max, defuzzifikasi centroid. Kategori: <35 Tidak Layak, 35–65 Dipertimbangkan, ≥65 Layak.", { n: RULE_COUNT }));
  h("Disclaimer"); line(L("Dokumen ini dibuat untuk tujuan akademik. Skor Model bukan rekomendasi beli/jual dan tidak menjamin hasil investasi. Ekstraksi akun dapat keliru dan telah melewati verifikasi manusia; tanggung jawab keputusan ada pada pengguna."));
  pdf.save(`StockIntelligence_${a.ticker}_${a.period.period}${a.period.fiscalYear}.pdf`);
}

export function ExportPage({ onNavigate, flash }: { onNavigate: Nav; flash: Flash }) {
  const { ws, current, picker } = useFocusAnalysis();
  if (!current) return <NoAnalysis onNavigate={onNavigate} what="Export PDF" />;
  const st = ws.analysisStatus(current.documentId);
  return (
    <div className="flex flex-col gap-4 max-w-3xl">
      <div className="flex items-center gap-3 flex-wrap">{picker}{current.demo && <DemoBadge />}<Badge tone={ANALYSIS_META[st].tone}>{tx(ANALYSIS_META[st].label)}</Badge></div>
      {st === "outdated" && <Notice tone="amber" icon={Info}>Data berubah setelah analisis dihitung. PDF akan memuat hasil tersimpan terakhir; hitung ulang di halaman Skor bila perlu.</Notice>}
      <Panel title="Isi PDF" icon={FileDown}>
        <ul className="text-[12px] leading-[1.9]" style={{ color: T.sub }}>
          {["Identitas emiten, periode, versi model, timestamp", "Pernyataan sumber (P&L dan Statement of Financial Position)", "9 akun terverifikasi + harga saham eksternal", "9 rasio, formula, dan himpunan dominan", "Rule aktif beserta α", "Agregasi, centroid, Skor Model & kategori", "Metodologi dan disclaimer"].map((t) => <li key={t}>· {tx(t)}</li>)}
        </ul>
        <div className="mt-4"><Btn kind="primary" icon={FileDown} onClick={() => { buildPdf(current); flash(L("PDF diunduh")); }}>{L("Unduh PDF")} {docLabel(current)}</Btn></div>
      </Panel>
    </div>
  );
}

/* ─── Advisor ─────────────────────────────────────── */
export function AdvisorLanding({ onNavigate }: { onNavigate: Nav }) {
  return (
    <Landing onNavigate={onNavigate} items={[
      { icon: MessageSquare, label: "Tanya Advisor", sub: "Penjelasan berbasis data terverifikasi", desc: "Tanyakan skor, rasio, atau rule aktif suatu emiten. Jawaban hanya dari analisis tersimpan." },
      { icon: Globe2, label: "Macro & Banking Dashboard", sub: "Sumber data belum terhubung", desc: "Konteks makro dan perbankan. Bukan input model Fuzzy Mamdani." },
    ]} />
  );
}

function answer(q: string, list: AnalysisRecord[], previousOf: (a: AnalysisRecord) => AnalysisRecord | undefined): string {
  const up = q.toUpperCase();
  const tick = [...new Set(list.map((a) => a.ticker))].sort((a, b) => b.length - a.length).find((t) => up.includes(t));
  if (!tick) return list.length ? L("Sebutkan ticker yang sudah dianalisis: {list}. Data untuk emiten lain tidak tersedia.", { list: [...new Set(list.map((a) => a.ticker))].join(", ") }) : L("Belum ada analisis tersimpan, jadi tidak ada data yang bisa dijelaskan.");
  const yr = up.match(/20\d\d/)?.[0];
  const cands = list.filter((a) => a.ticker === tick && (!yr || String(a.period.fiscalYear) === yr)).sort((a, b) => periodSort(b.period) - periodSort(a.period));
  const a = cands[0];
  if (!a) return yr ? L("Analisis {t} untuk tahun {y} tidak tersedia.", { t: tick, y: yr }) : L("Analisis {t} tidak tersedia.", { t: tick });
  const head = L("{doc}: Skor Model {score}, Kategori Kelayakan Berdasarkan Model \"{cat}\".", { doc: `${docLabel(a)}${a.demo ? " (DEMO)" : ""}`, score: a.score.toFixed(2), cat: L(a.category) });
  const k = VAR_KEYS.find((x) => new RegExp(`\\b${x}\\b`).test(up));
  if (k) {
    const d = RATIO_DEFINITIONS[k]; const dom = dominantSet(k, a.ratios[k]);
    const inputs = d.requiredAccounts.map((x) => `${L(CANONICAL_ACCOUNTS[x].labelId)} = ${fmtNum(a.accounts[x], 0)}`).join(", ");
    return `${head}\n${k} (${L(d.name)}) = ${fmtNum(a.ratios[k])}${d.unit}, ${L("dihitung sebagai")} ${d.formula} ${L("dari")} ${inputs}${d.externalInputs.length ? `, ${L("harga saham")} ${fmtNum(a.sharePrice, 0)}` : ""}. ${L("Himpunan dominan:")} ${L(dom.name)} (μ=${dom.mu.toFixed(2)}).`;
  }
  const fired = RULES.map((r, i) => ({ r, i, s: a.strengths[i] })).filter((x) => x.s > 0.005).sort((p, q2) => q2.s - p.s).slice(0, 3);
  const prev = previousOf(a);
  return [head,
    `${L("Rule terkuat:")} ${fired.map(({ r, i, s }) => `${ruleId(i)} (α=${s.toFixed(2)}, → ${L(OUT[r.out].name)})`).join("; ") || L("tidak ada")}.`,
    `${L("Kekuatan agregasi:")} ${OUT.map((o, i) => `${L(o.name)} ${a.classStrength[i].toFixed(2)}`).join(", ")}.`,
    prev ? `${L("Dibanding")} ${prev.period.fiscalYear}: ${prev.score.toFixed(2)} → ${a.score.toFixed(2)}.` : L("Periode sebelumnya tidak tersedia."),
    L("Ini penjelasan hasil model, bukan rekomendasi beli/jual.")].join("\n");
}

const ADVISOR_LIMIT = 3;
const ADVISOR_KEY = "aurevia.advisor.v1";
const today = () => new Date().toLocaleDateString("en-CA");
const readUsed = () => {
  try { const v = JSON.parse(localStorage.getItem(ADVISOR_KEY) || "null"); return v?.date === today() ? Number(v.n) || 0 : 0; } catch { return 0; }
};

export function TanyaAdvisorPage() {
  const ws = useWorkspace();
  const [q, setQ] = useState("");
  const [log, setLog] = useState<{ q: string; a: string }[]>([]);
  const [used, setUsed] = useState(readUsed);
  const left = Math.max(0, ADVISOR_LIMIT - used);
  const ex = useMemo(() => { const t = ws.analyses[0]?.ticker; return t ? [L("Jelaskan skor {t}", { t }), L("Bagaimana BOPO {t}?", { t }), L("Kenapa {t} masuk kategori ini?", { t })] : []; }, [ws.analyses]);
  const ask = (text: string) => {
    if (!text.trim() || readUsed() >= ADVISOR_LIMIT) return;
    const n = readUsed() + 1;
    try { localStorage.setItem(ADVISOR_KEY, JSON.stringify({ date: today(), n })); } catch { /* quota */ }
    setUsed(n);
    track("advisor", "Tanya Advisor");
    setLog((l) => [...l, { q: text, a: answer(text, ws.analyses, ws.previousOf) }]); setQ("");
  };
  return (
    <div className="flex flex-col gap-4 max-w-4xl">
      <Notice icon={Sparkles}>Model bahasa (LLM) belum terhubung. Advisor menyusun jawaban secara deterministik hanya dari analisis tersimpan; pertanyaan di luar data dijawab "tidak tersedia".</Notice>
      <Notice tone="amber" icon={Info}>
        <div className="font-semibold mb-0.5">{tx("Kuota harian: maksimal 3 pertanyaan")}</div>
        <ul className="list-disc pl-4 flex flex-col gap-0.5">
          <li>{tx("Setiap pertanyaan yang dikirim, termasuk dari tombol contoh, mengurangi 1 kesempatan.")}</li>
          <li>{tx("Kuota diatur ulang setiap hari pada pukul 00.00 waktu perangkat Anda.")}</li>
          <li>{tx("Kuota dihitung per browser dan tidak dapat dipulihkan sebelum hari berikutnya.")}</li>
          <li>{tx("Gunakan pertanyaan yang spesifik, mis. satu ticker dan satu rasio atau skor.")}</li>
        </ul>
      </Notice>
      <Panel title="Percakapan" icon={MessageSquare} right={<Badge tone={left === 0 ? "red" : "teal"}>{translate(getLang(), "Sisa {n} dari {max} pertanyaan hari ini", { n: left, max: ADVISOR_LIMIT })}</Badge>}>
        <div className="flex flex-col gap-3 min-h-[220px]">
          {log.length === 0 && <div className="text-[12px]" style={{ color: T.ter }}>{tx("Belum ada pertanyaan.")}{ex.length > 0 && " " + L("Coba salah satu contoh di bawah.")}</div>}
          {log.map((m, i) => (
            <div key={i} className="flex flex-col gap-1.5">
              <div className="self-end max-w-[80%] px-3 py-2 rounded-[4px] text-[12.5px]" style={{ background: T.inner, border: `1px solid ${T.line}` }}>{m.q}</div>
              <div className="max-w-[90%] px-3 py-2 rounded-[4px] text-[12.5px] whitespace-pre-line leading-relaxed" style={{ background: T.tealMuted }}>{m.a}</div>
            </div>
          ))}
        </div>
        {left === 0 && <div className="mt-3"><Notice tone="amber" icon={Info}>Batas 3 pertanyaan per hari sudah tercapai. Coba lagi besok.</Notice></div>}
        {ex.length > 0 && left > 0 && <div className="flex gap-2 flex-wrap mt-3">{ex.map((e) => <Btn key={e} kind="ghost" icon={Lightbulb} onClick={() => ask(e)}>{e}</Btn>)}</div>}
        <form className="flex gap-2 mt-3" onSubmit={(e) => { e.preventDefault(); ask(q); }}>
          <input value={q} disabled={left === 0} onChange={(e) => setQ(e.target.value)} placeholder={L("Tanya tentang skor, rasio, atau rule suatu ticker…")} className={inputCls} style={inputStyle} />
          <Btn kind="primary" icon={Send} type="submit" disabled={!q.trim() || left === 0}>Kirim</Btn>
        </form>
      </Panel>
    </div>
  );
}

