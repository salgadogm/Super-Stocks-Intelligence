// Daftar Emiten: fixed bank registry + Mamdani score per fiscal year + share price context.
// Scores come only from verified analyses (ws.analyses); banks without a report show "Belum ada laporan".
import { useMemo, useState } from "react";
import { Search, Info } from "lucide-react";
import { getLang } from "../domain/preferences";
import { translate } from "../i18n";
import { ZONES } from "../domain/engine";
import { useWorkspace } from "../domain/store";
import { issuersFrom, registryWith, bankSegmentOf } from "../domain/issuers";
import { fyByYear, buildWindow } from "../domain/yearWindow";
import { valuationOf, pctRank, quadrant } from "../domain/valuation";
import { T, Panel, Badge, CategoryBadge, Notice, Table, Row, Select, inputCls, inputStyle, tx } from "../ui";

const L = (s: string) => translate(getLang(), s);
const sign = (v: number | null) => (v == null ? "—" : `${v > 0 ? "+" : ""}${v.toFixed(1)}`);

export default function DaftarEmitenPage({ onNavigate }: { onNavigate: (p: string) => void }) {
  const ws = useWorkspace();
  const [q, setQ] = useState("");
  const [cat, setCat] = useState("all");
  const [n, setN] = useState(3);
  const [endSel, setEndSel] = useState("");
  const lastFy = Math.max(0, ...ws.analyses.filter((a) => a.period.period === "FY").map((a) => a.period.fiscalYear));
  const endYear = +endSel || lastFy || new Date().getFullYear() - 1;
  const win = buildWindow(endYear, n);

  const rows = useMemo(() => registryWith(issuersFrom(ws.documents)).map((r) => {
    const m = fyByYear(ws, r.code);
    const first = m.get(win[0]), last = m.get(endYear);
    const pct = first?.sharePrice && last?.sharePrice ? ((last.sharePrice - first.sharePrice) / first.sharePrice) * 100 : null;
    const val = last ? valuationOf(last, last.sharePrice) : null;
    return { ...r, m, last, val, seg: bankSegmentOf(r.code), dScore: first && last ? last.score - first.score : null, dPrice: pct, quad: null as string | null };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }), [ws.documents, ws.analyses, endYear, n]);

  const priced = rows.filter((r) => r.last && r.val?.pbv != null);
  const scores = priced.map((r) => r.last!.score), pbvs = priced.map((r) => r.val!.pbv!);
  for (const r of priced) r.quad = quadrant(pctRank(r.last!.score, scores), pctRank(r.val!.pbv!, pbvs));

  const shown = rows
    .filter((r) => (cat === "all" || r.last?.category === cat) && (r.code + r.name).toLowerCase().includes(q.toLowerCase()))
    .sort((a, b) => (b.last?.score ?? -1) - (a.last?.score ?? -1));
  const scored = rows.filter((r) => r.last).length;
  const cols = `70px minmax(180px,1.6fr) 80px repeat(${n}, 64px) 140px 110px 80px 80px 60px 60px 80px 230px`;

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center gap-3 flex-wrap">
        <h2 className="text-[14px] font-semibold">{tx("Daftar Seluruh Emiten Bank")}</h2>
        <Badge tone="neutral">{rows.length} {tx("emiten")} · {scored} {tx("terskor")}</Badge>
        <div className="ml-auto flex gap-2 flex-wrap items-center">
          <div className="relative"><Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2" style={{ color: T.ter }} />
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder={L("Cari ticker / perusahaan")} className={inputCls + " !w-56 pl-8"} style={inputStyle} /></div>
          <Select value={cat} onChange={setCat} className="!w-auto"><option value="all">{tx("Semua kategori")}</option>{ZONES.map((z) => <option key={z.name} value={z.name}>{tx(z.name)}</option>)}</Select>
          <Select value={String(endYear)} onChange={setEndSel} className="!w-auto">
            {Array.from({ length: 6 }, (_, i) => (lastFy || endYear) + 1 - i).map((y) => <option key={y} value={y}>{L("Tahun akhir")} {y}</option>)}</Select>
          <Select value={String(n)} onChange={(v) => setN(+v)} className="!w-auto">{[2, 3, 4, 5].map((x) => <option key={x} value={x}>{x} {L("tahun")}</option>)}</Select>
        </div>
      </div>
      {scored === 0 && (
        <Notice icon={Info}>{tx("Belum ada skor. Skor hanya muncul untuk bank yang laporannya sudah diunggah dan diverifikasi, atau setelah Data Demo dimuat di Collections.")}{" "}
          <button className="underline" onClick={() => onNavigate("Collections")}>{tx("Buka Collections")}</button></Notice>
      )}
      <Panel pad={false}>
        <Table cols={cols} head={["Kode", "Perusahaan", "Segmen", ...win.map(String), "Kategori", `${tx("Harga")} FY${endYear}`, "Δ Skor", "Δ Harga", "PBV", "PER", "PBV wajar", "Kualitas vs Valuasi"]} minWidth={1180 + n * 64}>
          {shown.map((r) => (
            <Row key={r.code} cols={cols}>
              <span className="font-semibold">{r.code}</span>
              <span className="truncate" style={{ color: T.sub }}>{r.name}</span>
              <span style={{ color: T.ter }}>{r.seg ?? "—"}</span>
              {win.map((y) => <span key={y} className="tnum" style={{ color: r.m.has(y) ? T.text : T.ter }}>{r.m.has(y) ? r.m.get(y)!.score.toFixed(1) : "—"}</span>)}
              <span>{r.last ? <CategoryBadge cat={r.last.category} /> : <Badge tone="neutral">{tx("Belum ada laporan")}</Badge>}</span>
              <span className="tnum">{r.last?.sharePrice ? r.last.sharePrice.toLocaleString("id-ID") : "—"}</span>
              <span className="tnum">{sign(r.dScore)}</span>
              <span className="tnum">{r.dPrice == null ? "—" : `${sign(r.dPrice)}%`}</span>
              <span className="tnum">{r.val?.pbv?.toFixed(2) ?? "—"}</span>
              <span className="tnum">{r.val?.per?.toFixed(1) ?? "—"}</span>
              <span className="tnum">{r.val?.fairPbv?.toFixed(2) ?? "—"}</span>
              <span className="text-[11px]" style={{ color: T.sub }}>{r.quad ? tx(r.quad) : "—"}</span>
            </Row>
          ))}
          {shown.length === 0 && <div className="px-4 py-6 text-[12px]" style={{ color: T.sub }}>{tx("Tidak ada emiten yang cocok dengan filter.")}</div>}
        </Table>
      </Panel>
      <div className="text-[11px]" style={{ color: T.ter }}>{tx("Skor per tahun fiskal dihitung engine Mamdani dari 9 akun terverifikasi tahun itu. Harga saham hanya konteks (kecuali sebagai input PER). Δ dihitung dari tahun awal ke tahun akhir jendela bila keduanya tersedia. PBV = harga / nilai buku per saham; PBV wajar = (ROE - g) / (r - g) dengan asumsi g 6%, r 12% (asumsi ilustratif). Kuadran membandingkan peringkat skor dengan peringkat PBV antar bank terskor. Bukan rekomendasi beli/jual.")}</div>
    </div>
  );
}
