// News: the signed-in account is the admin and publishes structured articles (text + images).
// Non-admin (viewer) accounts may only read and comment. See the access model in domain/news.ts.
import { useRef, useState } from "react";
import {
  Newspaper, Plus, Trash2, MessageSquare, Send, ArrowLeft, ShieldCheck, X, ImagePlus, Heading2, Pilcrow, List, Quote,
  ChevronUp, ChevronDown, Eye, Pencil, Clock, AlertCircle,
} from "lucide-react";
import {
  NEWS_CATEGORIES, canPublishNews, imageToDataUrl, uid, useNews, type NewsArticle, type NewsBlock, type NewsCategory,
} from "../domain/news";
import { T, Panel, Btn, Badge, EmptyState, Notice, Field, inputCls, inputStyle, fmtDate, tx, type Tone } from "../ui";

const CAT_TONE: Record<NewsCategory, Tone> = { Emiten: "teal", Regulasi: "amber", "Perbankan & Moneter": "blue", Pasar: "neutral" };
const readMins = (a: NewsArticle) => {
  const words = a.blocks.reduce((n, b) => n + ("text" in b ? b.text.split(/\s+/).filter(Boolean).length : 0), 0);
  return Math.max(1, Math.round(words / 200));
};
const ink = "var(--c-ink)";

function Cover({ src, alt, className = "" }: { src: string | null; alt: string; className?: string }) {
  return (
    <div className={"relative overflow-hidden " + className} style={{ background: T.inner }}>
      {src ? <img src={src} alt={alt} className="absolute inset-0 w-full h-full object-cover" />
        : <div className="absolute inset-0 flex items-center justify-center"><Newspaper size={28} strokeWidth={1.25} style={{ color: T.ter }} /></div>}
    </div>
  );
}

/* ─── Article body renderer (shared by detail + preview) ─── */
function Blocks({ blocks }: { blocks: NewsBlock[] }) {
  return (
    <div className="flex flex-col gap-4">
      {blocks.map((b) => {
        switch (b.type) {
          case "heading": return <h2 key={b.id} className="text-[16px] font-semibold mt-3 pt-3" style={{ borderTop: `1px solid ${T.line}` }}>{b.text}</h2>;
          case "paragraph": return <p key={b.id} className="text-[14px] leading-[1.8] whitespace-pre-wrap" style={{ color: ink }}>{b.text}</p>;
          case "quote": return (
            <blockquote key={b.id} className="pl-4 py-1 text-[15px] leading-relaxed italic whitespace-pre-wrap" style={{ borderLeft: `2px solid ${T.teal}`, color: T.text }}>{b.text}</blockquote>);
          case "list": return (
            <ul key={b.id} className="flex flex-col gap-1.5 pl-1">
              {b.text.split("\n").filter((l) => l.trim()).map((l, i) => (
                <li key={i} className="flex gap-2.5 text-[14px] leading-relaxed" style={{ color: ink }}>
                  <span className="mt-[9px] w-1 h-1 rounded-full shrink-0" style={{ background: T.teal }} />{l}</li>))}
            </ul>);
          case "image": return (
            <figure key={b.id} className="flex flex-col gap-2">
              <img src={b.src} alt={b.caption || tx("Gambar berita")} className="w-full rounded-[4px]" style={{ border: `1px solid ${T.line}` }} />
              {b.caption && <figcaption className="text-[11.5px]" style={{ color: T.ter }}>{b.caption}</figcaption>}
            </figure>);
        }
      })}
    </div>
  );
}

/* ─── Composer (admin only) ─── */
const BLOCK_META = {
  heading: { label: "Subjudul", icon: Heading2 }, paragraph: { label: "Paragraf", icon: Pilcrow },
  list: { label: "Daftar poin", icon: List }, quote: { label: "Kutipan", icon: Quote }, image: { label: "Gambar", icon: ImagePlus },
} as const;

function Composer({ author, onClose, onPublished }: { author: string; onClose: () => void; onPublished: (id: string) => void }) {
  const { publish } = useNews();
  const [f, setF] = useState({ title: "", summary: "", category: "Emiten" as NewsCategory, ticker: "", source: "" });
  const [cover, setCover] = useState<string | null>(null);
  const [blocks, setBlocks] = useState<NewsBlock[]>([{ id: uid("b"), type: "paragraph", text: "" }]);
  const [preview, setPreview] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const coverRef = useRef<HTMLInputElement>(null);
  const setField = (k: keyof typeof f) => (v: string) => setF((s) => ({ ...s, [k]: v }));

  const clean = blocks.filter((b) => b.type === "image" ? !!b.src : b.text.trim());
  const ok = f.title.trim() && f.source.trim() && clean.length > 0;

  const add = async (type: NewsBlock["type"], file?: File) => {
    if (type === "image") {
      if (!file) return;
      try { const src = await imageToDataUrl(file); setBlocks((b) => [...b, { id: uid("b"), type: "image", src, caption: "" }]); }
      catch { setErr(tx("Gambar tidak dapat dibaca. Gunakan berkas JPG, PNG, atau WebP.")); }
    } else setBlocks((b) => [...b, { id: uid("b"), type, text: "" } as NewsBlock]);
  };
  const patch = (id: string, p: Partial<{ text: string; caption: string }>) =>
    setBlocks((bs) => bs.map((b) => b.id === id ? ({ ...b, ...p } as NewsBlock) : b));
  const move = (i: number, d: -1 | 1) => setBlocks((bs) => {
    const j = i + d; if (j < 0 || j >= bs.length) return bs;
    const n = [...bs]; [n[i], n[j]] = [n[j], n[i]]; return n;
  });
  const submit = () => {
    if (!ok) return;
    const firstText = clean.find((b) => b.type === "paragraph") as { text: string } | undefined;
    const id = publish({
      title: f.title.trim(), category: f.category, ticker: f.ticker.trim().toUpperCase(), source: f.source.trim(), author,
      summary: f.summary.trim() || (firstText?.text.trim().slice(0, 160) ?? ""), cover, blocks: clean,
    });
    if (!id) setErr(tx("Penyimpanan browser penuh. Kurangi jumlah atau ukuran gambar, atau hapus berita lama."));
    else onPublished(id);
  };

  const previewArticle: NewsArticle = { id: "preview", ...f, ticker: f.ticker.toUpperCase(), author, publishedAt: new Date().toISOString(), cover, blocks: clean, comments: [] };

  return (
    <Panel title="Terbitkan berita" icon={Pencil}
      right={<>
        <Btn kind={preview ? "primary" : "secondary"} icon={preview ? Pencil : Eye} onClick={() => setPreview((v) => !v)}>{preview ? "Edit" : "Pratinjau"}</Btn>
        <Btn kind="ghost" icon={X} onClick={onClose}>Tutup</Btn></>}>
      {err && <div className="mb-3"><Notice tone="red" icon={AlertCircle}>{err}</Notice></div>}
      {preview ? (
        <div className="max-w-[760px]">
          <ArticleHeader a={previewArticle} />
          <div className="mt-6"><Blocks blocks={clean} /></div>
        </div>
      ) : (
        <div className="grid gap-5">
          <section className="grid gap-3 md:grid-cols-2">
            <div className="md:col-span-2"><Field label="Judul berita">
              <input className={inputCls} style={inputStyle} value={f.title} onChange={(e) => setField("title")(e.target.value)} placeholder={tx("mis. BBCA mencatat kenaikan laba bersih semester I")} /></Field></div>
            <Field label="Kategori">
              <select className={inputCls} style={inputStyle} value={f.category} onChange={(e) => setField("category")(e.target.value)}>
                {NEWS_CATEGORIES.map((c) => <option key={c} value={c}>{tx(c)}</option>)}</select></Field>
            <Field label="Ticker terkait (opsional)">
              <input className={inputCls} style={inputStyle} value={f.ticker} onChange={(e) => setField("ticker")(e.target.value)} placeholder="BBCA" maxLength={6} /></Field>
            <div className="md:col-span-2"><Field label="Sumber" hint="Nama media, tautan, atau dokumen keterbukaan informasi.">
              <input className={inputCls} style={inputStyle} value={f.source} onChange={(e) => setField("source")(e.target.value)} placeholder={tx("Keterbukaan Informasi BEI")} /></Field></div>
            <div className="md:col-span-2"><Field label="Ringkasan (opsional)" hint="Jika kosong, diambil dari paragraf pertama.">
              <input className={inputCls} style={inputStyle} value={f.summary} onChange={(e) => setField("summary")(e.target.value)} maxLength={180} /></Field></div>
            <div className="md:col-span-2">
              <span className="text-[11px] font-medium" style={{ color: T.sub }}>{tx("Gambar sampul")}</span>
              <input ref={coverRef} type="file" accept="image/*" hidden onChange={async (e) => {
                const file = e.target.files?.[0]; e.target.value = "";
                if (file) try { setCover(await imageToDataUrl(file)); } catch { setErr(tx("Gambar sampul tidak dapat dibaca.")); }
              }} />
              {cover ? (
                <div className="mt-1.5 flex items-center gap-3">
                  <Cover src={cover} alt={tx("Sampul")} className="rounded-[4px] w-40 h-24 shrink-0" />
                  <div className="flex gap-2"><Btn onClick={() => coverRef.current?.click()}>Ganti</Btn><Btn kind="danger" icon={Trash2} onClick={() => setCover(null)}>Hapus</Btn></div>
                </div>
              ) : (
                <button onClick={() => coverRef.current?.click()} className="mt-1.5 w-full h-24 rounded-[4px] flex flex-col items-center justify-center gap-1.5 text-[12px] transition-colors hover:bg-[var(--c-row-hover)]"
                  style={{ border: `1px dashed ${T.input}`, color: T.sub }}>
                  <ImagePlus size={18} strokeWidth={1.5} />{tx("Unggah gambar sampul (rasio 16:9 disarankan)")}</button>
              )}
            </div>
          </section>

          <section>
            <div className="text-[11px] font-medium mb-2" style={{ color: T.sub }}>{tx("Isi berita")}</div>
            <div className="flex flex-col gap-2">
              {blocks.map((b, i) => {
                const M = BLOCK_META[b.type];
                return (
                  <div key={b.id} className="rounded-[4px] p-3" style={{ background: T.inner, border: `1px solid ${T.line}` }}>
                    <div className="flex items-center gap-1.5 mb-2 text-[11px] font-medium" style={{ color: T.ter }}>
                      <M.icon size={13} />{tx(M.label)}
                      <span className="ml-auto flex items-center gap-0.5">
                        <button aria-label={tx("Naikkan")} disabled={i === 0} onClick={() => move(i, -1)} className="p-1 disabled:opacity-30 hover:text-[var(--c-text)]"><ChevronUp size={14} /></button>
                        <button aria-label={tx("Turunkan")} disabled={i === blocks.length - 1} onClick={() => move(i, 1)} className="p-1 disabled:opacity-30 hover:text-[var(--c-text)]"><ChevronDown size={14} /></button>
                        <button aria-label={tx("Hapus blok")} onClick={() => setBlocks((bs) => bs.filter((x) => x.id !== b.id))} className="p-1 hover:opacity-80" style={{ color: T.red }}><Trash2 size={13} /></button>
                      </span>
                    </div>
                    {b.type === "image" ? (
                      <div className="flex flex-col gap-2">
                        <img src={b.src} alt="" className="max-h-52 rounded-[4px] object-contain self-start" />
                        <input className={inputCls} style={inputStyle} value={b.caption} onChange={(e) => patch(b.id, { caption: e.target.value })} placeholder={tx("Keterangan gambar (opsional)")} />
                      </div>
                    ) : b.type === "heading" ? (
                      <input className={inputCls + " font-semibold"} style={inputStyle} value={b.text} onChange={(e) => patch(b.id, { text: e.target.value })} placeholder={tx("Subjudul bagian")} />
                    ) : (
                      <textarea className={inputCls + " py-2 resize-y leading-relaxed " + (b.type === "paragraph" ? "h-28" : "h-20")} style={inputStyle} value={b.text}
                        onChange={(e) => patch(b.id, { text: e.target.value })}
                        placeholder={tx(b.type === "list" ? "Satu poin per baris" : b.type === "quote" ? "Teks kutipan" : "Tulis paragraf…")} />
                    )}
                  </div>
                );
              })}
            </div>
            <div className="flex flex-wrap gap-2 mt-3">
              {(["heading", "paragraph", "list", "quote"] as const).map((t) => {
                const M = BLOCK_META[t];
                return <Btn key={t} icon={M.icon} onClick={() => add(t)}>{M.label}</Btn>;
              })}
              <label className="inline-flex items-center justify-center gap-1.5 h-8 px-3 rounded-[4px] text-[12px] font-medium cursor-pointer transition-opacity hover:opacity-85"
                style={{ background: T.inner, color: T.text, border: `1px solid ${T.input}` }}>
                <ImagePlus size={14} strokeWidth={1.75} />{tx("Gambar")}
                <input type="file" accept="image/*" hidden onChange={(e) => { const file = e.target.files?.[0]; e.target.value = ""; if (file) add("image", file); }} />
              </label>
            </div>
          </section>
        </div>
      )}
      <div className="flex items-center justify-end gap-2 mt-5 pt-4" style={{ borderTop: `1px solid ${T.line}` }}>
        {!ok && <span className="text-[11.5px] mr-auto" style={{ color: T.ter }}>{tx("Judul, sumber, dan minimal satu blok isi wajib diisi.")}</span>}
        <Btn onClick={onClose}>Batal</Btn>
        <Btn kind="primary" icon={Send} disabled={!ok} onClick={submit}>Terbitkan</Btn>
      </div>
    </Panel>
  );
}

/* ─── Article header ─── */
function ArticleHeader({ a }: { a: NewsArticle }) {
  return (
    <header>
      <div className="flex items-center gap-2 flex-wrap">
        <Badge tone={CAT_TONE[a.category]}>{tx(a.category)}</Badge>
        {a.ticker && <Badge>{a.ticker}</Badge>}
        <span className="inline-flex items-center gap-1 text-[11px]" style={{ color: T.ter }}><Clock size={11} />{readMins(a)} {tx("menit baca")}</span>
      </div>
      <h1 className="text-[26px] font-semibold mt-3 leading-[1.25] tracking-[-0.01em]">{a.title || tx("Judul berita")}</h1>
      {a.summary && <p className="text-[14.5px] mt-3 leading-relaxed" style={{ color: T.sub }}>{a.summary}</p>}
      <div className="flex items-center gap-2 mt-4 pt-3 text-[11.5px] flex-wrap" style={{ borderTop: `1px solid ${T.line}`, color: T.ter }}>
        <span>{fmtDate(a.publishedAt)}</span><span>·</span><span>{tx("Oleh")} {a.author}</span><span>·</span><span>{tx("Sumber")}: {a.source || "—"}</span>
      </div>
      {a.cover && <Cover src={a.cover} alt={a.title} className="rounded-[6px] w-full aspect-[16/9] mt-5" />}
    </header>
  );
}

/* ─── Comments (open to everyone) ─── */
function Comments({ article, user, isAdmin }: { article: NewsArticle; user: string; isAdmin: boolean }) {
  const { comment, removeComment } = useNews();
  const [name, setName] = useState(user);
  const [text, setText] = useState("");
  const send = () => {
    if (!text.trim()) return;
    comment(article.id, name.trim() || tx("Anonim"), text.trim());
    setText("");
  };
  return (
    <Panel title={`${tx("Komentar")} (${article.comments.length})`} icon={MessageSquare}>
      {article.comments.length === 0 ? (
        <div className="text-[12px] pb-4" style={{ color: T.sub }}>{tx("Belum ada komentar. Jadilah yang pertama menanggapi berita ini.")}</div>
      ) : (
        <ul className="flex flex-col mb-4">
          {article.comments.map((c) => (
            <li key={c.id} className="py-3 flex gap-3" style={{ borderBottom: `1px solid ${T.line}` }}>
              <div className="shrink-0 flex items-center justify-center rounded-full text-[11px] font-semibold" style={{ width: 28, height: 28, background: T.tealMuted, color: T.teal }}>
                {c.author.slice(0, 1).toUpperCase()}</div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2 text-[12px]">
                  <span className="font-semibold">{c.author}</span><span style={{ color: T.ter }}>{fmtDate(c.at)}</span>
                  {isAdmin && <button onClick={() => removeComment(article.id, c.id)} aria-label={tx("Hapus komentar")} className="ml-auto hover:opacity-80" style={{ color: T.red }}><Trash2 size={13} /></button>}
                </div>
                <p className="text-[12.5px] mt-1 leading-relaxed whitespace-pre-wrap break-words" style={{ color: T.sub }}>{c.body}</p>
              </div>
            </li>
          ))}
        </ul>
      )}
      <div className="grid gap-2">
        <div className="max-w-[240px]"><Field label="Nama"><input className={inputCls} style={inputStyle} value={name} onChange={(e) => setName(e.target.value)} /></Field></div>
        <Field label="Komentar Anda">
          <textarea className={inputCls + " h-20 py-2 resize-y"} style={inputStyle} value={text} onChange={(e) => setText(e.target.value)}
            onKeyDown={(e) => { if ((e.metaKey || e.ctrlKey) && e.key === "Enter") send(); }} placeholder={tx("Tulis tanggapan Anda…")} /></Field>
        <div className="flex justify-end"><Btn kind="primary" icon={Send} disabled={!text.trim()} onClick={send}>Kirim komentar</Btn></div>
      </div>
    </Panel>
  );
}

function Detail({ article, user, isAdmin, onBack }: { article: NewsArticle; user: string; isAdmin: boolean; onBack: () => void }) {
  const { remove } = useNews();
  return (
    <div className="flex flex-col gap-4 max-w-[780px] mx-auto w-full">
      <div className="flex items-center">
        <Btn kind="ghost" icon={ArrowLeft} onClick={onBack}>Semua berita</Btn>
        {isAdmin && <Btn kind="danger" icon={Trash2} className="ml-auto" onClick={() => { if (confirm(tx("Hapus berita ini beserta komentarnya?"))) { remove(article.id); onBack(); } }}>Hapus berita</Btn>}
      </div>
      <Panel pad={false}>
        <div className="p-5 md:p-8">
          <ArticleHeader a={article} />
          <div className="mt-7"><Blocks blocks={article.blocks} /></div>
        </div>
      </Panel>
      <Comments article={article} user={user} isAdmin={isAdmin} />
    </div>
  );
}

/* ─── List ─── */
function Meta({ a }: { a: NewsArticle }) {
  return (
    <div className="flex items-center gap-1.5 text-[11.5px]" style={{ color: T.ter }}>
      <span className="truncate">{a.source}</span><span>·</span><span className="shrink-0">{fmtDate(a.publishedAt).split(",")[0]}</span>
      <span className="ml-auto inline-flex items-center gap-1 shrink-0"><MessageSquare size={12} />{a.comments.length}</span>
    </div>
  );
}

export default function NewsPage({ user }: { user: string }) {
  const { articles, role } = useNews();
  const [openId, setOpenId] = useState<string | null>(null);
  const [composing, setComposing] = useState(false);
  const [filter, setFilter] = useState<"Semua" | NewsCategory>("Semua");
  const isAdmin = canPublishNews(role);
  const open = articles.find((a) => a.id === openId);

  if (open) return <Detail article={open} user={user} isAdmin={isAdmin} onBack={() => setOpenId(null)} />;

  const shown = filter === "Semua" ? articles : articles.filter((a) => a.category === filter);
  const [lead, ...rest] = shown;
  const card = "text-left rounded-[6px] overflow-hidden cursor-pointer flex flex-col transition-colors hover:bg-[var(--c-row-hover)] outline-none focus-visible:border-[var(--c-teal)]";
  const cardStyle = { background: T.card, border: `1px solid ${T.line}` };

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center gap-3 flex-wrap">
        <div role="tablist" className="flex gap-1 flex-wrap">
          {(["Semua", ...NEWS_CATEGORIES] as const).map((c) => (
            <button key={c} role="tab" aria-selected={filter === c} onClick={() => setFilter(c)}
              className="h-7 px-2.5 rounded-[4px] text-[12px] font-medium transition-colors"
              style={{ background: filter === c ? T.tealMuted : "transparent", color: filter === c ? T.teal : T.sub, border: `1px solid ${filter === c ? T.tealBorder : T.line}` }}>{tx(c)}</button>
          ))}
        </div>
        <div className="ml-auto flex items-center gap-2">
          <span className="hidden md:inline-flex items-center gap-1.5 text-[11.5px]" style={{ color: T.ter }}><ShieldCheck size={13} />{tx("Akun admin")}</span>
          {isAdmin && !composing && <Btn kind="primary" icon={Plus} onClick={() => setComposing(true)}>Tulis berita</Btn>}
        </div>
      </div>

      {composing && isAdmin && <Composer author={user} onClose={() => setComposing(false)} onPublished={(id) => { setComposing(false); setOpenId(id); }} />}

      {shown.length === 0 ? (
        <Panel><EmptyState icon={Newspaper} title={articles.length ? "Tidak ada berita pada kategori ini" : "Belum ada berita"}
          why="Terbitkan berita pertama dengan teks dan gambar. Pembaca lain hanya dapat membaca dan berkomentar di bawah berita. Berita tidak memengaruhi Skor Model."
          action={isAdmin ? <Btn kind="primary" icon={Plus} onClick={() => setComposing(true)}>Tulis berita</Btn> : undefined} /></Panel>
      ) : (
        <>
          <article onClick={() => setOpenId(lead.id)} onKeyDown={(e) => { if (e.key === "Enter") setOpenId(lead.id); }} tabIndex={0} role="button"
            className={card + " lg:flex-row"} style={cardStyle}>
            <Cover src={lead.cover} alt={lead.title} className="w-full lg:w-[52%] aspect-[16/9] lg:aspect-auto lg:min-h-[280px] shrink-0" />
            <div className="p-5 lg:p-7 flex flex-col gap-3 justify-center min-w-0">
              <div className="flex items-center gap-2"><Badge tone={CAT_TONE[lead.category]}>{tx(lead.category)}</Badge>{lead.ticker && <Badge>{lead.ticker}</Badge>}
                <span className="text-[11px]" style={{ color: T.teal }}>{tx("Terbaru")}</span></div>
              <h2 className="text-[22px] font-semibold leading-[1.25] tracking-[-0.01em]">{lead.title}</h2>
              <p className="text-[13px] leading-relaxed line-clamp-3" style={{ color: T.sub }}>{lead.summary}</p>
              <Meta a={lead} />
            </div>
          </article>

          {rest.length > 0 && (
            <div className="grid gap-4 grid-cols-1 md:grid-cols-2 xl:grid-cols-3">
              {rest.map((a) => (
                <article key={a.id} onClick={() => setOpenId(a.id)} onKeyDown={(e) => { if (e.key === "Enter") setOpenId(a.id); }} tabIndex={0} role="button" className={card} style={cardStyle}>
                  <Cover src={a.cover} alt={a.title} className="w-full aspect-[16/9]" />
                  <div className="p-4 flex flex-col gap-2 flex-1">
                    <div className="flex items-center gap-2"><Badge tone={CAT_TONE[a.category]}>{tx(a.category)}</Badge>{a.ticker && <Badge>{a.ticker}</Badge>}</div>
                    <h3 className="text-[14.5px] font-semibold leading-snug">{a.title}</h3>
                    <p className="text-[12.5px] leading-relaxed line-clamp-2 flex-1" style={{ color: T.sub }}>{a.summary}</p>
                    <Meta a={a} />
                  </div>
                </article>
              ))}
            </div>
          )}
        </>
      )}
    </div>
  );
}
