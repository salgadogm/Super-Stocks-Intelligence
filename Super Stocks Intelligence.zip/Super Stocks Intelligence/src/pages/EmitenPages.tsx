// Issuer-centric views: Profil Emiten (one company, 5-year trend, price vs quality, peer position) and
// Perbandingan Emiten (several companies side by side). Every number is a stored analysis from a verified
// dataset; missing years stay empty and are never interpolated.
import { useMemo, useState } from "react";
import { AlertTriangle, Building2, LineChart, Scale, Grid3x3, ListOrdered, Gauge, GitCompareArrows, Upload, Library, Info, CircleDot, Sparkles } from "lucide-react";
import { VAR_KEYS, VAR_DEFS, ZONES, dominantSet, type VarKey } from "../domain/engine";
import { RATIO_DEFINITIONS, monthName } from "../domain/financial";
import { useWorkspace, type AnalysisRecord } from "../domain/store";
import { canManageCollection, getRole } from "../domain/news";
import { issuersFrom, coverageWindow, WINDOW_YEARS } from "../domain/issuers";
import { fyByYear, monthsByTicker, validateMonthly, validateComparison, endYearOptions, maxCommonYears, MIN_YEARS, MAX_YEARS } from "../domain/yearWindow";
import { YearDisclaimer } from "../components/YearDisclaimer";
import { T, Panel, Btn, Badge, CategoryBadge, EmptyState, Notice, Select, fmtNum, tx } from "../ui";
import ScoreGauge from "../components/ScoreGauge";
import WhatIfPanel from "../components/WhatIfPanel";
import { useT } from "../i18n";
import { buildNarrative } from "../domain/narrative";

type Nav = (p: string) => void;
type Metric = "score" | VarKey;

const SERIES = [T.teal, T.blue, T.amber, T.violet, T.pink];
const MAX_COMPARE = 5;

const metricOf = (a: AnalysisRecord | undefined, k: Metric) => (a ? (k === "score" ? a.score : a.ratios[k]) : null);
const metricLabel = (k: Metric, tr: (s: string) => string) => (k === "score" ? tr("Skor Model") : `${k} · ${tr(RATIO_DEFINITIONS[k].name)}`);
const metricUnit = (k: Metric) => (k === "score" ? "" : RATIO_DEFINITIONS[k].unit);

const Empty = ({ onNavigate, what }: { onNavigate: Nav; what: string }) => {
  const { t: tr } = useT();
  return (
    <Panel><EmptyState icon={Building2} title={tr("{x} belum tersedia", { x: tr(what) })}
      why="Emiten muncul setelah laporannya ada di koleksi, ditarik, diverifikasi, dan dihitung. Tidak ada daftar emiten bawaan."
      action={canManageCollection(getRole())
        ? <Btn kind="primary" icon={Upload} onClick={() => onNavigate("Upload Laporan")}>Upload Laporan</Btn>
        : <Btn kind="primary" icon={Library} onClick={() => onNavigate("Perpustakaan Laporan")}>Pilih laporan dari koleksi</Btn>} /></Panel>
  );
};

/* ─── Charts ─────────────────────────────────────── */
function LineChartSvg({ years, series, domain, unit, zones, height = 220 }: {
  years: number[]; series: { name: string; color: string; values: (number | null)[] }[];
  domain: [number, number]; unit: string; zones?: boolean; height?: number;
}) {
  const { t: tr } = useT();
  const W = 760, H = height, PL = 40, PR = 16, PT = 14, PB = 28;
  const x = (i: number) => PL + (years.length <= 1 ? (W - PL - PR) / 2 : (i * (W - PL - PR)) / (years.length - 1));
  const y = (v: number) => PT + (1 - (Math.min(Math.max(v, domain[0]), domain[1]) - domain[0]) / (domain[1] - domain[0] || 1)) * (H - PT - PB);
  const ticks = [0, 0.25, 0.5, 0.75, 1].map((f) => domain[0] + f * (domain[1] - domain[0]));
  const single = series.length === 1;
  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="w-full h-auto" role="img">
      {zones && ZONES.map((z) => (
        <g key={z.name}>
          <rect x={PL} width={W - PL - PR} y={y(z.to)} height={y(z.from) - y(z.to)} fill={z.color} opacity={0.045} />
          <text x={W - PR - 4} y={y(z.to) + 11} textAnchor="end" fontSize="9.5" fill={z.color} opacity={0.7}>{tr(z.name)}</text>
        </g>
      ))}
      {ticks.map((t) => (
        <g key={t}>
          <line x1={PL} x2={W - PR} y1={y(t)} y2={y(t)} stroke={T.line} />
          <text x={PL - 8} y={y(t) + 3} textAnchor="end" fontSize="9.5" fill={T.ter} className="tnum">{fmtNum(t, t % 1 ? 1 : 0)}</text>
        </g>
      ))}
      {years.map((yr, i) => <text key={yr} x={x(i)} y={H - 8} textAnchor="middle" fontSize="10" fill={T.ter} className="tnum">{yr}</text>)}
      {series.map((s) => {
        const segs: string[] = []; let cur = "";
        s.values.forEach((v, i) => { if (v == null) { if (cur) segs.push(cur); cur = ""; } else cur += `${cur ? "L" : "M"}${x(i)},${y(v)} `; });
        if (cur) segs.push(cur);
        return (
          <g key={s.name}>
            {segs.map((d, i) => <path key={i} d={d} fill="none" stroke={s.color} strokeWidth={2} strokeLinejoin="round" />)}
            {s.values.map((v, i) => v != null && (
              <g key={i}>
                <circle cx={x(i)} cy={y(v)} r={3.5} fill={T.card} stroke={s.color} strokeWidth={2}><title>{`${s.name} ${years[i]}: ${fmtNum(v)}${unit}`}</title></circle>
                {single && <text x={x(i)} y={y(v) - 10} textAnchor="middle" fontSize="10.5" fill={T.text} className="tnum">{fmtNum(v, 1)}{unit}</text>}
              </g>
            ))}
          </g>
        );
      })}
      {series.every((s) => s.values.every((v) => v == null)) && <text x={W / 2} y={H / 2} textAnchor="middle" fontSize="11" fill={T.ter}>{tr("Tidak ada data pada rentang ini")}</text>}
    </svg>
  );
}

function Spark({ values, color }: { values: (number | null)[]; color: string }) {
  const W = 120, H = 32;
  const nums = values.filter((v): v is number => v != null);
  const lo = Math.min(...nums), hi = Math.max(...nums);
  const x = (i: number) => (values.length <= 1 ? W / 2 : (i * W) / (values.length - 1));
  const y = (v: number) => H - 4 - ((v - lo) / (hi - lo || 1)) * (H - 8);
  let d = ""; values.forEach((v, i) => { if (v == null) { d += " "; return; } d += `${d && !d.endsWith(" ") ? "L" : "M"}${x(i)},${y(v)}`; });
  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="w-full h-8" preserveAspectRatio="none">
      <path d={d} fill="none" stroke={color} strokeWidth={1.5} vectorEffect="non-scaling-stroke" />
      {values.map((v, i) => v != null && i === values.length - 1 && <circle key={i} cx={x(i)} cy={y(v)} r={2.5} fill={color} />)}
    </svg>
  );
}

/** Valuation (PER, price-based) vs fundamental quality (Skor Model) for one fiscal year. */
function PriceQualityScatter({ points, highlight }: { points: { label: string; per: number; score: number; color: string }[]; highlight?: string }) {
  const { t: tr } = useT();
  const W = 760, H = 300, PL = 40, PR = 16, PT = 16, PB = 34, MAXX = VAR_DEFS.PER.domain[1];
  const x = (v: number) => PL + (Math.min(Math.max(v, 0), MAXX) / MAXX) * (W - PL - PR);
  const y = (v: number) => PT + (1 - v / 100) * (H - PT - PB);
  const bands = VAR_DEFS.PER.sets.map((s, i, arr) => ({ ...s, from: i === 0 ? 0 : (arr[i - 1].pts[2] + s.pts[0]) / 2, to: i === arr.length - 1 ? MAXX : (s.pts[2] + arr[i + 1].pts[0]) / 2 }));
  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="w-full h-auto" role="img">
      {ZONES.map((z) => <line key={z.name} x1={PL} x2={W - PR} y1={y(z.from)} y2={y(z.from)} stroke={T.line} strokeDasharray={z.from ? "3 4" : undefined} />)}
      {ZONES.map((z) => <text key={z.name} x={PL + 6} y={y(z.to) + 12} fontSize="9.5" fill={z.color} opacity={0.75}>{tr(z.name)}</text>)}
      {bands.map((b) => (
        <g key={b.name}>
          <line x1={x(b.from)} x2={x(b.from)} y1={PT} y2={H - PB} stroke={T.line} />
          <text x={(x(b.from) + x(b.to)) / 2} y={H - 18} textAnchor="middle" fontSize="9.5" fill={b.color} opacity={0.8}>PER {tr(b.name)}</text>
        </g>
      ))}
      {[0, 10, 20, 30, 40].map((t) => <text key={t} x={x(t)} y={H - 4} textAnchor="middle" fontSize="9.5" fill={T.ter} className="tnum">{t}{t === MAXX ? "x+" : "x"}</text>)}
      {[0, 35, 65, 100].map((t) => <text key={t} x={PL - 8} y={y(t) + 3} textAnchor="end" fontSize="9.5" fill={T.ter} className="tnum">{t}</text>)}
      {points.map((p) => {
        const on = !highlight || p.label === highlight;
        return (
          <g key={p.label} opacity={on ? 1 : 0.45}>
            <circle cx={x(p.per)} cy={y(p.score)} r={on && highlight ? 7 : 5.5} fill={p.color} fillOpacity={0.22} stroke={p.color} strokeWidth={1.75}>
              <title>{`${p.label}: PER ${fmtNum(p.per)}x · ${tr("Skor")} ${fmtNum(p.score)}`}</title>
            </circle>
            <text x={x(p.per) + 10} y={y(p.score) + 4} fontSize="11" fontWeight={600} fill={T.text}>{p.label}</text>
          </g>
        );
      })}
      <text x={W - PR} y={PT + 2} textAnchor="end" fontSize="9.5" fill={T.ter}>{tr("↑ kualitas fundamental · → harga relatif laba")}</text>
    </svg>
  );
}

/** Score and manually entered report-date price, normalized to 100 at the first FY so their direction is comparable. */
function ScorePriceIndexChart({ years, ticker, score, price }: { years: number[]; ticker: string; score: number[]; price: number[] }) {
  const { t: tr } = useT();
  if (price.some((v) => !Number.isFinite(v) || v <= 0)) {
    return (
      <div className="rounded-[6px] p-3 min-h-[180px] flex flex-col" style={{ background: T.inner, border: `1px solid ${T.line}` }}>
        <span className="font-semibold text-[12px]">{ticker}</span>
        <div className="flex-1 flex items-center justify-center text-[11px] text-center" style={{ color: T.ter }}>{tr("Harga belum lengkap pada jendela ini; grafik indeks tidak ditampilkan.")}</div>
      </div>
    );
  }
  const W = 420, H = 170, PL = 34, PR = 18, PT = 16, PB = 28;
  const index = (values: number[]) => {
    const base = values[0];
    return base > 0 ? values.map((v) => (v / base) * 100) : values.map(() => 0);
  };
  const scoreIndex = index(score), priceIndex = index(price);
  const all = [...scoreIndex, ...priceIndex].filter(Number.isFinite);
  const rawLo = Math.min(...all, 100), rawHi = Math.max(...all, 100);
  const pad = Math.max(5, (rawHi - rawLo) * 0.15);
  const lo = Math.max(0, rawLo - pad), hi = rawHi + pad;
  const x = (i: number) => PL + (years.length <= 1 ? (W - PL - PR) / 2 : (i * (W - PL - PR)) / (years.length - 1));
  const y = (v: number) => PT + (1 - (v - lo) / (hi - lo || 1)) * (H - PT - PB);
  const path = (values: number[]) => values.map((v, i) => `${i ? "L" : "M"}${x(i)},${y(v)}`).join(" ");
  const ticks = [lo, (lo + hi) / 2, hi];
  return (
    <div className="rounded-[6px] p-3" style={{ background: T.inner, border: `1px solid ${T.line}` }}>
      <div className="flex items-center gap-3 text-[11px] mb-2">
        <span className="font-semibold text-[12px]">{ticker}</span>
        <span className="inline-flex items-center gap-1.5" style={{ color: T.sub }}><span className="w-3 h-0.5 rounded" style={{ background: T.teal }} />{tr("Skor (indeks)")}</span>
        <span className="inline-flex items-center gap-1.5" style={{ color: T.sub }}><span className="w-3 h-0.5 rounded" style={{ background: T.amber }} />{tr("Harga (indeks)")}</span>
      </div>
      <svg viewBox={`0 0 ${W} ${H}`} className="w-full h-auto" role="img" aria-label={tr("Grafik indeks skor dan harga {ticker}", { ticker })}>
        {ticks.map((v) => <g key={v}>
          <line x1={PL} x2={W - PR} y1={y(v)} y2={y(v)} stroke={T.line} strokeDasharray={Math.abs(v - 100) < 0.01 ? "3 3" : undefined} />
          <text x={PL - 6} y={y(v) + 3} textAnchor="end" fontSize="9.5" fill={T.ter} className="tnum">{fmtNum(v, 0)}</text>
        </g>)}
        {years.map((yr, i) => <text key={yr} x={x(i)} y={H - 7} textAnchor="middle" fontSize="9.5" fill={T.ter} className="tnum">{yr}</text>)}
        <path d={path(scoreIndex)} fill="none" stroke={T.teal} strokeWidth={2} strokeLinejoin="round" />
        <path d={path(priceIndex)} fill="none" stroke={T.amber} strokeWidth={2} strokeLinejoin="round" />
        {scoreIndex.map((v, i) => <circle key={`s-${years[i]}`} cx={x(i)} cy={y(v)} r={3} fill={T.card} stroke={T.teal} strokeWidth={1.75}><title>{`${years[i]} · ${tr("Skor")} ${fmtNum(score[i], 1)} · ${tr("indeks")} ${fmtNum(v, 1)}`}</title></circle>)}
        {priceIndex.map((v, i) => <circle key={`p-${years[i]}`} cx={x(i)} cy={y(v)} r={3} fill={T.card} stroke={T.amber} strokeWidth={1.75}><title>{`${years[i]} · ${tr("Harga")} ${fmtNum(price[i], 0)} · ${tr("indeks")} ${fmtNum(v, 1)}`}</title></circle>)}
      </svg>
      <div className="grid grid-cols-2 gap-2 text-[10.5px] tnum mt-1" style={{ color: T.ter }}>
        <span>{tr("Δ Skor")}: {score.length > 1 ? `${score.at(-1)! >= score[0] ? "+" : ""}${fmtNum(score.at(-1)! - score[0], 1)}` : "—"}</span>
        <span className="text-right">{tr("Δ Harga")}: {price.length > 1 && price[0] ? `${price.at(-1)! >= price[0] ? "+" : ""}${fmtNum(((price.at(-1)! - price[0]) / price[0]) * 100, 1)}%` : "—"}</span>
      </div>
    </div>
  );
}

const CoverageChips = ({ years, window }: { years: number[]; window: number[] }) => (
  <div className="flex gap-1">
    {window.map((y) => {
      const ok = years.includes(y);
      return <span key={y} className="px-1.5 h-[22px] inline-flex items-center rounded-[3px] text-[10.5px] tnum font-medium"
        style={{ background: ok ? T.tealMuted : "transparent", color: ok ? T.teal : T.ter, border: `1px ${ok ? "solid" : "dashed"} ${ok ? T.tealBorder : T.input}` }}>{y}</span>;
    })}
  </div>
);

/* ─── Profil Emiten ──────────────────────────────── */
export function ProfilEmitenPage({ onNavigate, ticker: initial, onPick }: { onNavigate: Nav; ticker?: string; onPick?: (t: string) => void }) {
  const { t: tr } = useT();
  const ws = useWorkspace();
  const issuers = useMemo(() => issuersFrom(ws.documents), [ws.documents]);
  const scored = [...new Set(ws.analyses.filter((a) => a.period.period === "FY").map((a) => a.ticker))].sort();
  const [sel, setSel] = useState(initial ?? "");
  const t = sel && scored.includes(sel) ? sel : scored[0];
  if (!t) return <Empty onNavigate={onNavigate} what="Profil emiten" />;

  const by = fyByYear(ws, t);
  const issuer = issuers.find((i) => i.code === t);
  const years = [...by.keys()];
  const cov = coverageWindow(years);
  const window = cov.window;
  const latest = by.get(Math.max(...years))!;
  const prev = by.get(latest.period.fiscalYear - 1);
  const per = dominantSet("PER", latest.ratios.PER);
  const peers = ws.latestByTicker().filter((a) => a.period.period === "FY").sort((a, b) => b.score - a.score);
  const rank = peers.findIndex((a) => a.ticker === t) + 1;
  const docsMissing = cov.missing.filter((y) => ws.documents.some((d) => d.ticker === t && d.period.period === "FY" && d.period.fiscalYear === y));
  const pick = (v: string) => { setSel(v); onPick?.(v); };

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center gap-3 flex-wrap">
        <Select value={t} onChange={pick} className="!w-auto">{scored.map((x) => <option key={x} value={x}>{x} — {issuers.find((i) => i.code === x)?.name ?? ""}</option>)}</Select>
        <span className="text-[11px]" style={{ color: T.ter }}>{tr("Hanya emiten dengan analisis FY yang tampil di sini")}</span>
        <Btn className="ml-auto" icon={GitCompareArrows} onClick={() => onNavigate("Perbandingan Emiten")}>Bandingkan</Btn>
      </div>

      {/* Identity + verdict */}
      <section className="rounded-[6px] grid grid-cols-1 lg:grid-cols-[1.25fr_1fr] overflow-hidden" style={{ background: T.card, border: `1px solid ${T.line}` }}>
        <div className="p-5 flex flex-col gap-4">
          <div>
            <div className="flex items-baseline gap-3">
              <h2 className="text-[28px] font-semibold tracking-[-0.02em] leading-none">{t}</h2>
              <span className="text-[13px]" style={{ color: T.sub }}>{issuer?.name ?? latest.companyName}</span>
            </div>
            <div className="mt-2 text-[11px]" style={{ color: T.ter }}>{tr("Identitas dari laporan yang diunggah & dikonfirmasi · {n} dokumen", { n: issuer?.docs ?? 0 })}</div>
          </div>
          <div className="flex items-center gap-3 flex-wrap">
            <span className="text-[11px] uppercase tracking-[0.08em]" style={{ color: T.ter }}>{tr("Cakupan {n} FY", { n: WINDOW_YEARS })}</span>
            <CoverageChips years={years} window={window} />
            <Badge tone={cov.complete ? "green" : "amber"}>{tr("{n}/{m} tahun", { n: cov.have.length, m: WINDOW_YEARS })}</Badge>
          </div>
          {!cov.complete && (
            <Notice tone="amber" icon={Info}>
              {tr("Tren belum mencakup {n} tahun. FY {m} belum dianalisis", { n: WINDOW_YEARS, m: cov.missing.join(", ") })}{docsMissing.length ? ` (${tr("FY {m} sudah diunggah, menunggu verifikasi/kalkulasi", { m: docsMissing.join(", ") })})` : ""}. {tr("Skor tiap tahun tetap valid untuk periodenya, tetapi kesimpulan tren masih terbatas.")}
            </Notice>
          )}
        </div>
        <div className="p-5 flex flex-col gap-3" style={{ background: T.inner, borderLeft: `1px solid ${T.line}` }}>
          <div className="text-[11px] uppercase tracking-[0.08em]" style={{ color: T.ter }}>{tr("Kelayakan berdasarkan model")} · FY {latest.period.fiscalYear}</div>
          <div className="flex items-center gap-4 flex-wrap">
            <ScoreGauge score={latest.score} width={200} />
            <div className="flex flex-col gap-1.5">
              <CategoryBadge cat={latest.category} />
              {prev && <span className="text-[11px] tnum" style={{ color: latest.score >= prev.score ? T.teal : T.red }}>{latest.score >= prev.score ? "▲" : "▼"} {fmtNum(Math.abs(latest.score - prev.score), 1)} vs FY {prev.period.fiscalYear}</span>}
            </div>
          </div>
          <dl className="grid grid-cols-1 min-[420px]:grid-cols-3 gap-3 text-[12px] pt-1">
            <div><dt style={{ color: T.ter }} className="text-[10.5px]">{tr("Harga input")}</dt><dd className="tnum font-medium">{fmtNum(latest.sharePrice, 0)}</dd></div>
            <div><dt style={{ color: T.ter }} className="text-[10.5px]">PER</dt><dd className="tnum font-medium">{fmtNum(latest.ratios.PER, 1)}x <span style={{ color: T.sub }}>· {tr(per.name)}</span></dd></div>
            <div><dt style={{ color: T.ter }} className="text-[10.5px]">{tr("Peringkat")}</dt><dd className="tnum font-medium">{rank} <span style={{ color: T.sub }}>/ {peers.length}</span></dd></div>
          </dl>
          <p className="text-[11px] leading-relaxed" style={{ color: T.ter }}>{tr("Hasil model deterministik dari 9 rasio terverifikasi, bukan rekomendasi beli/jual. Peringkat dihitung terhadap emiten yang laporannya Anda unggah.")}</p>
          <div className="flex gap-2"><Btn icon={Gauge} onClick={() => onNavigate("Skor & Defuzzifikasi")}>Jejak perhitungan</Btn></div>
        </div>
      </section>

      <div className="grid grid-cols-1 xl:grid-cols-[1fr_1.4fr] gap-4 items-start">
        <Panel title="Ringkasan otomatis (berbasis aturan)" icon={Sparkles}>
          <ul className="flex flex-col gap-2 text-[12.5px] leading-relaxed">
            {buildNarrative({ latest, prev, rank, peers: peers.length, yearsHave: cov.have.length, yearsTotal: WINDOW_YEARS }).map((s, i) => (
              <li key={i} className="flex gap-2"><span className="mt-[7px] w-1 h-1 rounded-full shrink-0" style={{ background: T.teal }} />{tr(s)}</li>
            ))}
          </ul>
          <p className="text-[11px] mt-3 leading-relaxed" style={{ color: T.ter }}>{tx("Disusun dari template aturan dan analisis terverifikasi, bukan teks AI. Bukan rekomendasi beli/jual.")}</p>
        </Panel>
        <WhatIfPanel analysis={latest} onOpenFull={() => { ws.setFocusDoc(latest.documentId); onNavigate("Skor & Defuzzifikasi"); }} />
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-[1.5fr_1fr] gap-4">
        <Panel title={`${tr("Tren Skor Model")} · FY ${window[0]}–${window[window.length - 1]}`} icon={LineChart}>
          <LineChartSvg years={window} zones domain={[0, 100]} unit="" series={[{ name: t, color: T.teal, values: window.map((y) => metricOf(by.get(y), "score")) }]} />
        </Panel>
        <Panel title="Harga vs Kualitas Laporan" icon={Scale} pad={false}>
          <table className="w-full text-[12px] tnum">
            <thead><tr className="text-[10.5px]" style={{ color: T.ter }}>
              {["FY", "Harga", "PER", "Valuasi", "Skor"].map((h, i) => <th key={h} className={`font-medium py-2 ${i ? "text-right px-3" : "text-left px-4"}`}>{tr(h)}</th>)}
            </tr></thead>
            <tbody>{window.map((y) => { const a = by.get(y); const d = a && dominantSet("PER", a.ratios.PER); return (
              <tr key={y} style={{ borderTop: `1px solid ${T.line}` }}>
                <td className="px-4 py-2 font-semibold">{y}</td>
                {a ? <>
                  <td className="px-3 text-right">{fmtNum(a.sharePrice, 0)}</td>
                  <td className="px-3 text-right">{fmtNum(a.ratios.PER, 1)}x</td>
                  <td className="px-3 text-right" style={{ color: VAR_DEFS.PER.sets.find((s) => s.name === d?.name)?.color ?? T.sub }}>{d ? tr(d.name) : null}</td>
                  <td className="px-3 text-right font-medium">{fmtNum(a.score, 1)}</td>
                </> : <td colSpan={4} className="px-3 text-right" style={{ color: T.ter }}>n/a</td>}
              </tr>); })}</tbody>
          </table>
          <div className="px-4 py-2.5 text-[11px]" style={{ borderTop: `1px solid ${T.line}`, color: T.ter }}>{tr("Harga adalah input manual per tanggal laporan. PER = harga ÷ EPS, salah satu dari 9 input model.")}</div>
        </Panel>
      </div>

      <Panel title="9 Rasio · tren per tahun" icon={Grid3x3} pad={false}>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
          {VAR_KEYS.map((k) => {
            const vals = window.map((y) => metricOf(by.get(y), k));
            const dom = dominantSet(k, latest.ratios[k]);
            const color = VAR_DEFS[k].sets.find((s) => s.name === dom.name)?.color ?? T.sub;
            return (
              <div key={k} className="p-4 flex flex-col gap-2" style={{ borderRight: `1px solid ${T.line}`, borderBottom: `1px solid ${T.line}` }}>
                <div className="flex items-baseline gap-2">
                  <span className="text-[12px] font-semibold">{k}</span>
                  <span className="text-[10.5px] truncate" style={{ color: T.ter }}>{tr(VAR_DEFS[k].category)}</span>
                  <span className="ml-auto text-[15px] font-semibold tnum">{fmtNum(latest.ratios[k], k === "PER" || VAR_DEFS[k].unit === "x" ? 2 : 1)}{VAR_DEFS[k].unit}</span>
                </div>
                <Spark values={vals} color={color} />
                <div className="flex items-center justify-between text-[10.5px] tnum" style={{ color: T.ter }}>
                  <span>{window[0]}</span><span style={{ color }}>{tr(dom.name)} · μ {dom.mu.toFixed(2)}</span><span>{window[window.length - 1]}</span>
                </div>
              </div>
            );
          })}
        </div>
      </Panel>

      <Panel title="Posisi terhadap emiten lain (periode terbaru)" icon={ListOrdered}>
        <div className="flex flex-col gap-1.5">
          {peers.map((a) => (
            <button key={a.ticker} onClick={() => pick(a.ticker)} className="grid grid-cols-[48px_1fr_56px_96px] sm:grid-cols-[56px_1fr_64px_120px] items-center gap-2 sm:gap-3 text-left text-[12px] py-1 rounded-[3px] hover:bg-[var(--c-row-hover)]">
              <span className="font-semibold" style={{ color: a.ticker === t ? T.teal : T.text }}>{a.ticker}</span>
              <span className="h-2 rounded-full overflow-hidden" style={{ background: T.track }}>
                <span className="block h-full rounded-full" style={{ width: `${a.score}%`, background: a.ticker === t ? T.teal : T.lineHover }} />
              </span>
              <span className="tnum text-right">{fmtNum(a.score, 1)}</span>
              <span className="text-[11px] tnum" style={{ color: T.ter }}>FY {a.period.fiscalYear}</span>
            </button>
          ))}
        </div>
      </Panel>
    </div>
  );
}

/* ─── Perbandingan Emiten ────────────────────────── */
export function PerbandinganPage({ onNavigate }: { onNavigate: Nav }) {
  const { t: tr } = useT();
  const ws = useWorkspace();
  const issuers = useMemo(() => issuersFrom(ws.documents), [ws.documents]);
  const scored = useMemo(() => ws.latestByTicker().filter((a) => a.period.period === "FY").sort((a, b) => b.score - a.score).map((a) => a.ticker), [ws]);
  const [picked, setPicked] = useState<string[] | null>(null);
  const [metric, setMetric] = useState<Metric>("score");
  const [yearSel, setYearSel] = useState("");
  const [nSel, setNSel] = useState("3");
  const [endSel, setEndSel] = useState("");
  const sel = (picked ?? scored.slice(0, MAX_COMPARE)).filter((t) => scored.includes(t));
  if (scored.length === 0) return <Empty onNavigate={onNavigate} what="Perbandingan emiten" />;

  const maps = Object.fromEntries(sel.map((t) => [t, fyByYear(ws, t)]));
  const endOptions = endYearOptions(maps, sel);
  const endYear = endOptions.includes(Number(endSel)) ? Number(endSel) : endOptions[0] ?? 0;
  const n = Number(nSel);
  const check = validateComparison(maps, sel, endYear, n);
  const monthYear = endYear + 1;
  const monthMaps = Object.fromEntries(sel.map((t) => [t, monthsByTicker(ws, t, monthYear)]));
  const mCheck = validateMonthly(monthMaps, sel, monthYear);
  const allOk = check.ok && mCheck.ok;
  const reasons = [...check.reasons, ...mCheck.reasons];
  const window = check.window;
  const maxN = maxCommonYears(maps, sel, endYear);
  const color = (t: string) => SERIES[sel.indexOf(t) % SERIES.length];
  const series = sel.map((t) => ({ name: t, color: color(t), values: window.map((y) => metricOf(maps[t].get(y), metric)) }));
  const nums = series.flatMap((s) => s.values).filter((v): v is number => v != null);
  const domain: [number, number] = metric === "score" ? [0, 100] : [Math.min(VAR_DEFS[metric].domain[0], ...nums), Math.max(VAR_DEFS[metric].domain[1], ...nums) || 1];
  const yearOptions = [...window].sort((a, b) => b - a);
  const year = window.includes(Number(yearSel)) ? Number(yearSel) : endYear;
  const atYear = sel.map((t) => ({ t, a: maps[t].get(year) }));
  const toggle = (t: string) => setPicked(sel.includes(t) ? sel.filter((x) => x !== t) : sel.length >= MAX_COMPARE ? sel : [...sel, t]);

  return (
    <div className="flex flex-col gap-4">
      <Panel title="Emiten dibandingkan" icon={Building2} right={<span className="text-[11px] tnum" style={{ color: T.ter }}>{sel.length}/{MAX_COMPARE} {tr("dipilih")}</span>}>
        <div className="flex flex-wrap gap-2">
          {scored.map((t) => {
            const on = sel.includes(t);
            return (
              <button key={t} onClick={() => toggle(t)} disabled={!on && sel.length >= MAX_COMPARE}
                className="h-8 px-3 rounded-[4px] text-[12px] font-medium inline-flex items-center gap-2 disabled:opacity-40 transition-colors"
                style={{ background: on ? T.inner : "transparent", border: `1px solid ${on ? color(t) : T.input}`, color: on ? T.text : T.sub }}>
                <span className="w-2 h-2 rounded-full" style={{ background: on ? color(t) : T.ter }} />{t}
                <span className="text-[11px] font-normal hidden sm:inline" style={{ color: T.ter }}>{issuers.find((i) => i.code === t)?.name}</span>
              </button>
            );
          })}
        </div>
      </Panel>

      {sel.length > 0 && (
        <Panel title="Periode komparasi" icon={Scale}
          right={allOk ? <Badge tone="teal">Apple-to-apple · FY {window[0]}–{window[window.length - 1]}{mCheck.months.length > 0 && ` + ${monthName(1)}${mCheck.months.length > 1 ? `–${monthName(mCheck.months.length)}` : ""} ${monthYear}`}</Badge> : <Badge tone="red">Belum sebanding</Badge>}>
          <div className="flex flex-wrap items-end gap-4">
            <label className="flex flex-col gap-1 text-[11px]" style={{ color: T.ter }}>{tr("Jumlah tahun")}
              <Select value={nSel} onChange={setNSel} className="!w-auto !h-8">
                {Array.from({ length: MAX_YEARS - MIN_YEARS + 1 }, (_, i) => MIN_YEARS + i).map((k) => <option key={k} value={k}>{k} {tr("tahun")}</option>)}
              </Select>
            </label>
            <label className="flex flex-col gap-1 text-[11px]" style={{ color: T.ter }}>{tr("Tahun akhir")}
              <Select value={String(endYear)} onChange={setEndSel} className="!w-auto !h-8">
                {endOptions.map((y) => <option key={y} value={y}>FY {y}</option>)}
              </Select>
            </label>
            <span className="text-[11px] pb-2" style={{ color: T.ter }}>{tr("Rentang maksimal yang dimiliki semua emiten terpilih:")} <b className="tnum" style={{ color: T.text }}>{maxN} {tr("tahun")}</b></span>
          </div>
          <div className="mt-3"><YearDisclaimer /></div>
        </Panel>
      )}

      {sel.length === 0 ? <Panel><EmptyState compact icon={GitCompareArrows} title="Pilih minimal satu emiten" why="Klik emiten di atas untuk menambahkannya ke perbandingan." /></Panel>
      : !allOk ? (
        <div role="alert" className="rounded-[6px] p-4 flex flex-col gap-2" style={{ background: `color-mix(in srgb, ${T.red} 10%, transparent)`, border: `1px solid ${T.red}` }}>
          <span className="text-[13px] font-semibold inline-flex items-center gap-2" style={{ color: T.red }}><AlertTriangle size={15} />{tr("Komparasi belum bisa dilakukan")}</span>
          <p className="text-[12px] leading-relaxed" style={{ color: T.sub }}>{tr("Data tidak cukup atau jumlah/rentang tahun tidak sama antar emiten, sehingga hasilnya tidak apple-to-apple. Skor dan ranking disembunyikan sampai datanya disesuaikan.")}</p>
          <ul className="text-[12px] list-disc pl-5 tnum" style={{ color: T.text }}>{reasons.map((r) => <li key={r}>{r}</li>)}</ul>
          <div className="flex flex-wrap gap-2 pt-1">
            {maxN >= MIN_YEARS && n > maxN && <Btn kind="primary" onClick={() => setNSel(String(maxN))}>{tr("Gunakan {n} tahun", { n: maxN })}</Btn>}
            <Btn icon={Library} onClick={() => onNavigate("Folder Laporan")}>{tr("Lihat kelengkapan di Folder Laporan")}</Btn>
          </div>
        </div>
      ) : <>
        <Panel title={`${metricLabel(metric, tr)} · FY ${window[0]}–${window[window.length - 1]}`} icon={LineChart}
          right={<Select value={metric} onChange={(v) => setMetric(v as Metric)} className="!w-auto !h-8"><option value="score">{tr("Skor Model")}</option>{VAR_KEYS.map((k) => <option key={k} value={k}>{k}</option>)}</Select>}>
          <LineChartSvg years={window} series={series} domain={domain} unit={metricUnit(metric)} zones={metric === "score"} />
          <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-[11px]">
            {series.map((s) => <span key={s.name} className="inline-flex items-center gap-1.5" style={{ color: T.sub }}><span className="w-3 h-0.5 rounded" style={{ background: s.color }} />{s.name} <span className="tnum" style={{ color: T.ter }}>{s.values.filter((v) => v != null).length}/{n} FY</span></span>)}
            <span className="ml-auto" style={{ color: T.ter }}>{tr("Titik kosong = belum ada analisis FY, tidak diinterpolasi")}</span>
          </div>
        </Panel>

        <Panel title={tr("Skor vs Harga · indeks awal = 100")} icon={Scale}>
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-3">
            {sel.map((t) => {
              const records = window.map((y) => maps[t].get(y)!);
              return <ScorePriceIndexChart key={t} years={window} ticker={t} score={records.map((a) => a.score)} price={records.map((a) => a.sharePrice ?? 0)} />;
            })}
          </div>
          <p className="mt-3 text-[11px] leading-relaxed" style={{ color: T.ter }}>{tr("Skor dan harga dinormalisasi menjadi 100 pada FY awal agar arah perubahannya dapat dibandingkan. Harga adalah input manual per tanggal laporan, bukan feed real-time. Kesearahan tidak membuktikan sebab-akibat dan bukan rekomendasi beli/jual.")}</p>
        </Panel>

        <div className="flex items-center gap-3">
          <span className="text-[12px]" style={{ color: T.sub }}>{tr("Perbandingan pada tahun yang sama")}</span>
          <Select value={String(year)} onChange={setYearSel} className="!w-auto !h-8">{yearOptions.map((y) => <option key={y} value={y}>FY {y}</option>)}</Select>
        </div>

        <div className="grid grid-cols-1 2xl:grid-cols-[1fr_1fr] gap-4">
          <Panel title={`${tr("Harga vs Kualitas")} · FY ${year}`} icon={CircleDot}>
            <PriceQualityScatter points={atYear.filter((p) => p.a).map(({ t, a }) => ({ label: t, per: a!.ratios.PER, score: a!.score, color: color(t) }))} />
            <p className="mt-2 text-[11px] leading-relaxed" style={{ color: T.ter }}>{tr("Kiri-atas: kualitas laporan tinggi dengan PER rendah. Skor Model sudah memasukkan PER sebagai satu dari 9 input, jadi grafik ini membantu membaca, bukan menambah bobot.")}</p>
          </Panel>

          <Panel title={`${tr("Peta 9 Rasio")} · FY ${year}`} icon={Grid3x3} pad={false}>
            <div className="overflow-x-auto">
              <table className="w-full text-[11.5px] tnum">
                <thead><tr className="text-[10.5px]" style={{ color: T.ter }}>
                  <th className="text-left font-medium px-4 py-2">{tr("Emiten")}</th>
                  {VAR_KEYS.map((k) => <th key={k} className="font-medium px-1 py-2">{k}</th>)}
                  <th className="font-medium px-3 py-2 text-right">{tr("Skor")}</th>
                </tr></thead>
                <tbody>{atYear.map(({ t, a }) => (
                  <tr key={t} style={{ borderTop: `1px solid ${T.line}` }}>
                    <td className="px-4 py-2 font-semibold"><span className="inline-flex items-center gap-1.5"><span className="w-2 h-2 rounded-full" style={{ background: color(t) }} />{t}</span></td>
                    {a ? <>
                      {VAR_KEYS.map((k) => {
                        const d = dominantSet(k, a.ratios[k]); const c = VAR_DEFS[k].sets.find((s) => s.name === d.name)?.color ?? T.ter;
                        return <td key={k} className="px-0.5 py-1"><div className="h-8 rounded-[3px] flex items-center justify-center" title={`${k} ${fmtNum(a.ratios[k])}${VAR_DEFS[k].unit} · ${tr(d.name)}`}
                          style={{ background: `color-mix(in srgb, ${c} ${Math.round(8 + d.mu * 22)}%, transparent)`, color: T.text }}>{fmtNum(a.ratios[k], 1)}</div></td>;
                      })}
                      <td className="px-3 text-right font-semibold">{fmtNum(a.score, 1)}</td>
                    </> : <td colSpan={10} className="px-3 text-[11.5px]" style={{ color: T.ter }}>{tr("Tidak ada analisis FY {y}", { y: year })}</td>}
                  </tr>))}</tbody>
              </table>
            </div>
            <div className="px-4 py-2.5 text-[11px] flex gap-3 flex-wrap" style={{ borderTop: `1px solid ${T.line}`, color: T.ter }}>
              <span>{tr("Warna = himpunan fuzzy dominan, intensitas = derajat keanggotaan μ")}</span>
              <span className="inline-flex items-center gap-1"><span className="w-2 h-2 rounded-sm" style={{ background: T.teal }} />{tr("baik")}</span>
              <span className="inline-flex items-center gap-1"><span className="w-2 h-2 rounded-sm" style={{ background: T.yellow }} />{tr("sedang")}</span>
              <span className="inline-flex items-center gap-1"><span className="w-2 h-2 rounded-sm" style={{ background: T.red }} />{tr("lemah")}</span>
            </div>
          </Panel>
        </div>

        <Panel pad={false}>
          <div className="overflow-x-auto"><div className="grid" style={{ gridTemplateColumns: `repeat(${sel.length}, minmax(150px,1fr))`, minWidth: sel.length * 150 }}>
            {atYear.map(({ t, a }) => (
              <div key={t} className="p-4 flex flex-col gap-1.5" style={{ borderRight: `1px solid ${T.line}` }}>
                <span className="text-[11px] font-semibold inline-flex items-center gap-1.5"><span className="w-2 h-2 rounded-full" style={{ background: color(t) }} />{t} · FY {year}</span>
                {a ? <><span className="text-[22px] font-semibold tnum leading-none">{fmtNum(a.score, 1)}</span><CategoryBadge cat={a.category} /></>
                  : <span className="text-[12px]" style={{ color: T.ter }}>{tr("Belum dianalisis")}</span>}
              </div>
            ))}
          </div></div>
        </Panel>

        <CumulativePanel sel={sel} maps={maps} color={color} window={window} />
        {mCheck.months.length > 0 && <MonthlyPanel sel={sel} maps={monthMaps} color={color} year={monthYear} months={mCheck.months} />}
      </>}
    </div>
  );
}

/* ─── Current-year monthly reports (year-to-date) ─────────────────
   Raw cumulative ratios, not annualised and not scored by the Mamdani model: only comparable across issuers
   for the same month, never with FY values. */
function MonthlyPanel({ sel, maps, color, year, months }: { sel: string[]; maps: Record<string, Map<number, AnalysisRecord>>; color: (t: string) => string; year: number; months: number[] }) {
  const { t: tr } = useT();
  const [k, setK] = useState<VarKey>("ROE");
  return (
    <Panel title={`${tr("Laporan bulanan tahun berjalan (YTD)")} · ${monthName(months[0])}${months.length > 1 ? `–${monthName(months[months.length - 1])}` : ""} ${year}`} icon={Scale} pad={false}
      right={<Select value={k} onChange={(v) => setK(v as VarKey)} className="!w-auto !h-8">{VAR_KEYS.filter((x) => x !== "PER").map((x) => <option key={x} value={x}>{x}</option>)}</Select>}>
      <div className="overflow-x-auto">
        <table className="w-full text-[11.5px] tnum">
          <thead><tr className="text-[10.5px]" style={{ color: T.ter }}>
            <th className="text-left font-medium px-4 py-2">{tr("Emiten")}</th>
            {months.map((m) => <th key={m} className="font-medium px-3 py-2 text-right">{monthName(m)} {year}</th>)}
          </tr></thead>
          <tbody>{sel.map((t) => (
            <tr key={t} style={{ borderTop: `1px solid ${T.line}` }}>
              <td className="px-4 py-2 font-semibold"><span className="inline-flex items-center gap-1.5"><span className="w-2 h-2 rounded-full" style={{ background: color(t) }} />{t}</span></td>
              {months.map((m) => <td key={m} className="px-3 py-2 text-right">{fmtNum(maps[t].get(m)!.ratios[k], 2)}{VAR_DEFS[k].unit}</td>)}
            </tr>))}</tbody>
        </table>
      </div>
      <p className="px-4 py-2.5 text-[11px] leading-relaxed" style={{ borderTop: `1px solid ${T.line}`, color: T.ter }}>
        {tr("Rasio bulanan bersifat kumulatif sejak awal tahun (YTD), tidak dianualisasi, dan tidak diberi Skor Model. PER tidak ditampilkan karena laba YTD membuatnya terlalu besar. Bandingkan hanya antar emiten pada bulan yang sama, bukan dengan nilai FY.")}
      </p>
    </Panel>
  );
}

/* ─── Cumulative ratios across uneven year coverage ───────────────
   "intersect" averages only fiscal years every selected issuer has (fair, apples-to-apples);
   "all" averages each issuer over its own available years and shows the coverage it rests on. */
function CumulativePanel({ sel, maps, color, window }: { sel: string[]; maps: Record<string, Map<number, AnalysisRecord>>; color: (t: string) => string; window: number[] }) {
  const { t: tr } = useT();
  const yearsFor = (_t: string) => window;
  const avg = (xs: number[]) => (xs.length ? xs.reduce((s, v) => s + v, 0) / xs.length : null);
  const cagr = (t: string, k: VarKey) => {
    const ys = yearsFor(t); if (ys.length < 2) return null;
    const a = maps[t].get(ys[0])!.ratios[k], b = maps[t].get(ys[ys.length - 1])!.ratios[k];
    if (a <= 0 || b <= 0) return null;
    return (Math.pow(b / a, 1 / (ys[ys.length - 1] - ys[0])) - 1) * 100;
  };
  const rows = sel.map((t) => {
    const ys = yearsFor(t);
    const recs = ys.map((y) => maps[t].get(y)!);
    return { t, ys, score: avg(recs.map((r) => r.score)), vals: Object.fromEntries(VAR_KEYS.map((k) => [k, avg(recs.map((r) => r.ratios[k]))])) as Record<VarKey, number | null> };
  });

  return (
    <Panel title="Rasio Kumulatif (rata-rata multi-tahun)" icon={Scale} pad={false}
      right={<Badge tone="teal">FY {window[0]}–{window[window.length - 1]} · {window.length} {tr("tahun")}</Badge>}>
      <div className="px-4 py-2.5 text-[11.5px]" style={{ borderBottom: `1px solid ${T.line}`, color: T.sub }}>
        {tr("Semua emiten dirata-ratakan atas jendela tahun yang identik:")} <b className="tnum" style={{ color: T.text }}>{window.map((y) => `FY${y}`).join(", ")}</b>
      </div>
      {(
        <div className="overflow-x-auto">
          <table className="w-full text-[11.5px] tnum">
            <thead><tr className="text-[10.5px]" style={{ color: T.ter }}>
              <th className="text-left font-medium px-4 py-2">{tr("Emiten")}</th>
              <th className="font-medium px-2 py-2">{tr("Cakupan")}</th>
              {VAR_KEYS.map((k) => <th key={k} className="font-medium px-2 py-2 text-right">{k}</th>)}
              <th className="font-medium px-2 py-2 text-right">CAGR ROE</th>
              <th className="font-medium px-4 py-2 text-right">{tr("Skor rata²")}</th>
            </tr></thead>
            <tbody>{rows.map((r) => {
              const g = cagr(r.t, "ROE");
              return (
                <tr key={r.t} style={{ borderTop: `1px solid ${T.line}` }}>
                  <td className="px-4 py-2 font-semibold"><span className="inline-flex items-center gap-1.5"><span className="w-2 h-2 rounded-full" style={{ background: color(r.t) }} />{r.t}</span></td>
                  <td className="px-2 text-center" title={r.ys.map((y) => `FY${y}`).join(", ")}>
                    <Badge tone="teal">{r.ys.length}/{window.length} {tr("th")}</Badge>
                  </td>
                  {VAR_KEYS.map((k) => <td key={k} className="px-2 text-right">{r.vals[k] == null ? <span style={{ color: T.ter }}>—</span> : fmtNum(r.vals[k], 2)}</td>)}
                  <td className="px-2 text-right" style={{ color: g == null ? T.ter : g >= 0 ? T.teal : T.red }}>{g == null ? "—" : `${g >= 0 ? "+" : ""}${g.toFixed(1)}%`}</td>
                  <td className="px-4 text-right font-semibold">{fmtNum(r.score, 1)}</td>
                </tr>
              );
            })}</tbody>
          </table>
        </div>
      )}
      <div className="px-4 py-2.5 text-[11px] leading-relaxed" style={{ borderTop: `1px solid ${T.line}`, color: T.ter }}>
        {tr("Rata-rata aritmetika dari rasio FY terverifikasi; tahun kosong tidak diinterpolasi. CAGR hanya dihitung bila ≥2 tahun dan nilai awal/akhir positif. Skor rata² adalah rata-rata Skor Model per tahun, bukan hasil Mamdani atas rasio rata-rata.")}
      </div>
    </Panel>
  );
}
