import { useEffect, useMemo, useRef, useState } from "react";
import {
  Upload, CheckSquare, Library, FileText, ShieldAlert, Eye, Check, X, Ban, Pencil, Trash2, Search,
  FolderOpen, Calculator, Info, ImageOff, RefreshCw, ArrowRight, Database, AlertTriangle,
} from "lucide-react";
import {
  CANONICAL_ACCOUNTS, consistencyIssues, isMonthly, MONTH_PERIODS, monthName, periodText, REQUIRED_ACCOUNTS, STATEMENT_LABEL, NOT_FOUND_MESSAGE, isAllowedStatement, ratiosAffectedBy,
  type CanonicalAccountId, type Currency, type ReportingPeriod, type StatementType, type UnitScale, type VerificationStatus,
} from "../domain/financial";
import { useWorkspace, docLabel, hasAi, type DocRecord, type WorkingItem } from "../domain/store";
import { buildDemo } from "../domain/demo";
import { scanPdf, type TextScan } from "../domain/pdfScan";
import { issuersFrom, suggestIdentity, isSharia, coverageWindow, WINDOW_YEARS, type IdentitySuggestion, type StatementCoverage } from "../domain/issuers";
import { canManageCollection, getRole } from "../domain/news";
import { useT } from "../i18n";
import { usePull, YearMismatchDialog } from "../components/PullFlow";
import { YearDisclaimer } from "../components/YearDisclaimer";
import {
  T, Panel, Btn, Badge, DemoBadge, EmptyState, Notice, Stat, Field, Table, Row, Select, inputCls, inputStyle,
  VERIF_META, ANALYSIS_META, fmtDate, fmtNum,
  tx,
} from "../ui";

type Nav = (page: string) => void;
function ScanLine({ scan }: { scan: TextScan }) {
  const { t } = useT();
  if (scan.status === "reading")
    return <div className="text-[11px] mt-0.5 tnum" style={{ color: T.teal }}>{t("Mengonversi PDF → teks (tanpa AI)…")} {scan.total ? `${scan.progress}/${scan.total} ${t("hlm.")}` : ""}</div>;
  if (scan.status === "error")
    return <div className="text-[11px] mt-0.5" style={{ color: T.red }}>{t("Teks PDF tidak dapat dibaca (koneksi ke pustaka pdf.js atau file rusak). Isi manual di Verifikasi.")}</div>;
  if (scan.status === "scanned")
    return <div className="text-[11px] mt-0.5" style={{ color: T.amber }}>{t("PDF hasil scan (tidak ada lapisan teks). Butuh OCR atau AI vision; untuk sekarang isi manual di Verifikasi.")}</div>;
  const n = scan.matches?.length ?? 0, total = REQUIRED_ACCOUNTS.length;
  const pg = (xs: number[] = []) => (xs.length ? `${t("hlm.")} ${xs.join(", ")}` : t("tidak ketemu"));
  const saved = scan.tokensAll ? Math.round((1 - (scan.tokensRelevant ?? 0) / scan.tokensAll) * 100) : 0;
  return (
    <div className="text-[11px] mt-0.5 flex flex-wrap gap-x-3 tnum" style={{ color: T.sub }}>
      <span>P&L: {pg(scan.pages?.profit_loss)}</span>
      <span>SFP: {pg(scan.pages?.financial_position)}</span>
      <span style={{ color: n === total ? T.teal : n >= total - 2 ? T.amber : T.red }}>{t("Akun ketemu")} {n}/{total}</span>
      {scan.years?.length ? <span>{t("Kolom")}: {scan.years.join(" · ")}</span> : null}
      <span>{scan.unitFound ? t("Satuan terdeteksi") : t("Satuan belum terdeteksi")}</span>
      {scan.tokensAll ? <span style={{ color: T.ter }}>{t("≈{a} dari {b} token relevan (hemat {c}%)", { a: fmtNum(scan.tokensRelevant ?? 0, 0), b: fmtNum(scan.tokensAll, 0), c: saved })}</span> : null}
    </div>
  );
}

export const SOURCE_NOTICE = "Sistem hanya menggunakan Profit and Loss dan Statement of Financial Position sebagai sumber data analisis.";
const UNIT_LABEL: Record<UnitScale, string> = { unit: "Satuan penuh", thousands: "Ribuan", millions: "Jutaan", billions: "Miliaran" };
const fmtSize = (b: number) => (b ? (b > 1e6 ? `${(b / 1e6).toFixed(1)} MB` : `${Math.max(1, Math.round(b / 1e3))} KB`) : "—");

/* ─── Collections landing ────────────────────────── */
export function CollectionsLanding({ onNavigate }: { onNavigate: Nav }) {
  const { t } = useT();
  const ws = useWorkspace();
  const admin = canManageCollection(getRole());
  const docs = ws.documents;
  const queue = docs.filter((d) => d.status !== "verified");
  const counts = {
    total: docs.length,
    pending: queue.length,
    verified: docs.filter((d) => d.status === "verified").length,
    analysed: docs.filter((d) => ws.analysisStatus(d.id) === "calculated").length,
  };
  const open = (d: DocRecord, page: string) => { ws.setFocusDoc(d.id); onNavigate(page); };

  return (
    <div className="flex flex-col gap-4">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <Stat label="Dokumen tersimpan" value={counts.total} sub="Seluruh periode" />
        <Stat label="Antrian verifikasi" value={counts.pending} sub="Akun belum semuanya Verified" />
        <Stat label="Verified dataset" value={counts.verified} sub="9 akun wajib terverifikasi" />
        <Stat label="Analisis terkini" value={counts.analysed} sub="Skor Model up to date" accent={counts.analysed > 0} />
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
        <Panel title="Antrian Verifikasi" icon={CheckSquare} className="xl:col-span-2" pad={false}
          right={<Btn kind="ghost" onClick={() => onNavigate("Verifikasi Ekstraksi AI")}>{t("Buka workspace")} <ArrowRight size={13} /></Btn>}>
          {queue.length === 0 ? (
            <EmptyState compact icon={CheckSquare} title={docs.length ? "Tidak ada antrian verifikasi" : "Belum ada laporan"}
              why={docs.length ? "Seluruh dokumen sudah memiliki 9 akun wajib yang terverifikasi." : admin ? "Antrian akan terisi setelah Anda mengunggah laporan keuangan." : "Belum ada laporan di koleksi. Admin akan menambahkan laporan keuangan secara berkala."}
              action={!docs.length && (admin
                ? <Btn kind="primary" icon={Upload} onClick={() => onNavigate("Upload Laporan")}>Upload Laporan</Btn>
                : <Btn kind="primary" icon={Library} onClick={() => onNavigate("Perpustakaan Laporan")}>Pilih laporan dari koleksi</Btn>)} />
          ) : (
            <Table minWidth={560} cols="1.4fr 1fr 1.2fr 110px" head={["Dokumen", "Diunggah", "Progres verifikasi", ""]}>
              {queue.slice(0, 6).map((d) => {
                const p = ws.progress(d.id);
                return (
                  <Row key={d.id} cols="1.4fr 1fr 1.2fr 110px">
                    <div className="min-w-0"><div className="font-medium truncate">{docLabel(d)}</div><div className="text-[11px] truncate" style={{ color: T.ter }}>{d.companyName}</div></div>
                    <span style={{ color: T.sub }}>{fmtDate(d.uploadedAt)}</span>
                    <ProgressBar done={p.verified} total={p.total} flagged={p.flagged} />
                    <div className="text-right"><Btn kind="secondary" onClick={() => open(d, "Verifikasi Ekstraksi AI")}>Verifikasi</Btn></div>
                  </Row>
                );
              })}
            </Table>
          )}
        </Panel>

        <Panel title="Aksi Cepat" icon={FolderOpen}>
          <div className="flex flex-col gap-2">
            {[
              admin
                ? { icon: Upload, label: "Upload Laporan", sub: "PDF / JPG / PNG", page: "Upload Laporan" }
                : { icon: Library, label: "Pilih laporan dari koleksi", sub: "Analisis laporan yang sudah tersedia", page: "Perpustakaan Laporan" },
              { icon: CheckSquare, label: "Verifikasi Ekstraksi AI", sub: t("{n} dokumen menunggu", { n: counts.pending }), page: "Verifikasi Ekstraksi AI" },
              { icon: Library, label: "Perpustakaan Laporan", sub: t("{n} dokumen", { n: counts.total }), page: "Perpustakaan Laporan" },
            ].map((a) => (
              <button key={a.label} onClick={() => onNavigate(a.page)}
                className="flex items-center gap-3 px-3 h-12 rounded-[4px] text-left transition-colors hover:border-[var(--c-line-hover)]"
                style={{ background: T.inner, border: `1px solid ${T.line}` }}>
                <a.icon size={15} strokeWidth={1.75} style={{ color: T.sub }} />
                <span className="flex-1 min-w-0"><span className="block text-[12.5px] font-medium">{t(a.label)}</span><span className="block text-[11px]" style={{ color: T.ter }}>{t(a.sub)}</span></span>
                <ArrowRight size={13} style={{ color: T.ter }} />
              </button>
            ))}
            <div className="mt-2 pt-3 flex flex-col gap-2" style={{ borderTop: `1px solid ${T.line}` }}>
              <div className="text-[11px] leading-relaxed" style={{ color: T.ter }}>
                {t("Data demo memuat 3 emiten fiktif (DEMO-A/B/C) serta BBRI & BMRI dengan angka ilustratif untuk simulasi alur. Bukan laporan resmi emiten BEI.")}
              </div>
              <div className="flex gap-2">
                <Btn icon={Database} onClick={() => ws.seedDemo(buildDemo)}>Muat Data Demo</Btn>
                {docs.some((d) => d.demo) && <Btn kind="ghost" onClick={ws.clearDemo}>Hapus demo</Btn>}
              </div>
            </div>
          </div>
        </Panel>
      </div>

      <Panel title="Laporan Terbaru" icon={FileText} pad={false}
        right={<Btn kind="ghost" onClick={() => onNavigate("Perpustakaan Laporan")}>{t("Semua laporan")} <ArrowRight size={13} /></Btn>}>
        {docs.length === 0 ? (
          <EmptyState compact icon={FileText} title="Belum ada dokumen" why={admin ? "Unggah laporan keuangan (Profit and Loss dan Statement of Financial Position) untuk memulai pipeline analisis." : "Belum ada laporan di koleksi. Admin akan menambahkan laporan keuangan secara berkala."} />
        ) : (
          <Table minWidth={760} cols="1.4fr 1.4fr 130px 150px 140px" head={["Dokumen", "File", "Verifikasi", "Analisis", "Diunggah"]}>
            {docs.slice(0, 5).map((d) => {
              const a = ANALYSIS_META[ws.analysisStatus(d.id)];
              const p = ws.progress(d.id);
              return (
                <Row key={d.id} cols="1.4fr 1.4fr 130px 150px 140px">
                  <span className="flex items-center gap-2 min-w-0 font-medium"><span className="truncate">{docLabel(d)}</span>{d.demo && <DemoBadge />}</span>
                  <span className="truncate" style={{ color: T.sub }}>{d.fileName}</span>
                  <span className="tnum" style={{ color: T.sub }}>{p.verified}/{p.total} {t("Verified")}</span>
                  <span><Badge tone={a.tone}>{t(a.label)}</Badge></span>
                  <span style={{ color: T.sub }}>{fmtDate(d.uploadedAt)}</span>
                </Row>
              );
            })}
          </Table>
        )}
      </Panel>
    </div>
  );
}

function ProgressBar({ done, total, flagged }: { done: number; total: number; flagged: number }) {
  const { t } = useT();
  return (
    <div className="flex items-center gap-2 min-w-0">
      <div className="flex-1 h-1.5 rounded-full overflow-hidden" style={{ background: T.track }}>
        <div className="h-full" style={{ width: `${total ? (done / total) * 100 : 0}%`, background: T.teal }} />
      </div>
      <span className="text-[11px] tnum shrink-0" style={{ color: T.sub }}>{done}/{total}{flagged ? ` · ${flagged} ${t("flag")}` : ""}</span>
    </div>
  );
}

/* ─── Upload Laporan (batch) ─────────────────────── */
// Many files at once. Identity (ticker, company, year, statement) is only SUGGESTED; each file must be
// checked manually by the user before it is saved. Files of the same ticker + year + period are merged
// into one report, which must cover both Profit and Loss and Statement of Financial Position.
const ACCEPT: Record<string, DocRecord["fileType"]> = { "application/pdf": "pdf", "image/png": "png", "image/jpeg": "jpg" };
const MAX_BYTES = 50 * 1024 * 1024;
const COVER_LABEL: Record<StatementCoverage, string> = { profit_loss: "Profit and Loss", financial_position: "Statement of Financial Position", both: "Keduanya (laporan lengkap)" };
const MATCH_LABEL = { ticker: "kode", year: "tahun", period: "periode", statement: "jenis laporan" } as const;

interface Staged {
  id: string; file: File; ticker: string; companyName: string; fiscalYear: string; period: ReportingPeriod;
  statement: StatementCoverage; currency: Currency; unit: UnitScale; confirmed: boolean; matched: IdentitySuggestion["matched"];
  scan?: TextScan;
}

const groupKey = (r: Pick<Staged, "ticker" | "fiscalYear" | "period">) => `${r.ticker}|${r.fiscalYear}|${r.period}`;
const rowErrors = (r: Staged) => {
  const e: string[] = [];
  if (!/^[A-Z]{4}$/.test(r.ticker)) e.push("Kode saham BEI 4 huruf");
  else if (isSharia(r.ticker)) e.push("Bank syariah di luar cakupan (hanya bank umum konvensional)");
  if (!r.companyName.trim()) e.push("Nama perusahaan");
  if (!/^20\d{2}$/.test(r.fiscalYear)) e.push("Tahun fiskal");
  else if (isMonthly(r.period) && Number(r.fiscalYear) !== new Date().getFullYear()) e.push("Laporan bulanan hanya untuk tahun berjalan");
  return e;
};

export function UploadPage({ onNavigate }: { onNavigate: Nav }) {
  const { t } = useT();
  const ws = useWorkspace();
  const known = useMemo(() => issuersFrom(ws.documents), [ws.documents]);
  const [rows, setRows] = useState<Staged[]>([]);
  const [rejected, setRejected] = useState<string[]>([]);
  const [dragging, setDragging] = useState(false);
  const [saved, setSaved] = useState<{ ids: string[]; labels: string[] } | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const add = (list: FileList | null) => {
    if (!list?.length) return;
    const bad: string[] = []; const next: Staged[] = [];
    for (const f of Array.from(list)) {
      if (!ACCEPT[f.type]) { bad.push(`${f.name}: ${t("format tidak didukung (PDF, JPG, PNG)")}`); continue; }
      if (f.size > MAX_BYTES) { bad.push(`${f.name}: ${fmtSize(f.size)} ${t("melebihi 50 MB")}`); continue; }
      if (f.size === 0) { bad.push(`${f.name}: ${t("file kosong")}`); continue; }
      const s = suggestIdentity(f.name, known);
      const sibling = [...rows, ...next].find((r) => r.ticker && r.ticker === s.ticker);
      next.push({
        id: Math.random().toString(36).slice(2), file: f, ticker: s.ticker, companyName: s.companyName || sibling?.companyName || "",
        fiscalYear: s.fiscalYear, period: s.period, statement: s.statement, currency: sibling?.currency ?? "IDR", unit: sibling?.unit ?? "millions",
        confirmed: false, matched: s.matched,
      });
    }
    setRejected(bad); setSaved(null); setRows((r) => [...r, ...next]);
    for (const n of next) if (n.file.type === "application/pdf") runScan(n.id, n.file);
  };

  const setScan = (id: string, fn: (r: Staged) => Partial<Staged>) => setRows((rs) => rs.map((r) => (r.id === id ? { ...r, ...fn(r) } : r)));
  const runScan = (id: string, file: File) => {
    setScan(id, () => ({ scan: { status: "reading", progress: 0, total: 0 } }));
    scanPdf(file, (d, t) => setScan(id, (r) => ({ scan: { ...r.scan!, progress: d, total: t } })))
      .then(({ scan, unit }) => setScan(id, (r) => {
        const pl = !!scan.pages?.profit_loss.length, sfp = !!scan.pages?.financial_position.length;
        return {
          scan,
          ...(unit ? { unit: unit.unit, currency: unit.currency } : {}),
          ...(!r.fiscalYear && scan.years?.[0] ? { fiscalYear: String(scan.years[0]) } : {}),
          ...(pl && sfp ? { statement: "both" as const } : pl ? { statement: "profit_loss" as const } : sfp ? { statement: "financial_position" as const } : {}),
          confirmed: false,
        };
      }))
      .catch(() => setScan(id, (r) => ({ scan: { ...(r.scan ?? { progress: 0, total: 0 }), status: "error" } })));
  };

  const patch = (id: string, p: Partial<Staged>) => setRows((rs) => rs.map((r) => {
    if (r.id !== id) return r;
    const n = { ...r, ...p, confirmed: p.confirmed ?? false }; // any edit requires re-confirmation
    if (p.ticker !== undefined && !r.companyName) n.companyName = known.find((i) => i.code === p.ticker)?.name ?? rs.find((x) => x.id !== id && x.ticker === p.ticker)?.companyName ?? "";
    return n;
  }));

  /* group staged files into reports */
  const groups = useMemo(() => {
    const m = new Map<string, Staged[]>();
    for (const r of rows) if (!rowErrors(r).length) m.set(groupKey(r), [...(m.get(groupKey(r)) ?? []), r]);
    return [...m.entries()].map(([key, rs]) => {
      const pl = rs.some((r) => r.statement !== "financial_position"), sfp = rs.some((r) => r.statement !== "profit_loss");
      const problems: string[] = [];
      if (!pl) problems.push("Profit and Loss belum ada");
      if (!sfp) problems.push("Statement of Financial Position belum ada");
      if (new Set(rs.map((r) => r.companyName.trim().toLowerCase())).size > 1) problems.push("Nama perusahaan berbeda antar-file");
      if (new Set(rs.map((r) => `${r.currency}${r.unit}`)).size > 1) problems.push("Mata uang / satuan berbeda antar-file");
      return { key, rows: rs, problems, confirmed: rs.every((r) => r.confirmed), ready: !problems.length && rs.every((r) => r.confirmed) };
    });
  }, [rows]);
  const ready = groups.filter((g) => g.ready);
  const groupOf = (r: Staged) => groups.find((g) => g.key === groupKey(r));

  const save = () => {
    const ids: string[] = []; const labels: string[] = [];
    for (const g of ready) {
      const [h] = g.rows; const main = g.rows.find((r) => r.file.type === "application/pdf") ?? h;
      ids.push(ws.addDocument({
        ticker: h.ticker, companyName: h.companyName.trim(), period: { fiscalYear: Number(h.fiscalYear), period: h.period },
        fileName: g.rows.map((r) => r.file.name).join(" + "), fileType: ACCEPT[main.file.type], fileSize: g.rows.reduce((s, r) => s + r.file.size, 0),
        currency: h.currency, unit: h.unit, sources: g.rows.map((r) => ({ fileName: r.file.name, fileSize: r.file.size, statement: r.statement })),
      }, main.file));
      // prefill rule-based suggestions; they stay "needs_review" until confirmed in Verifikasi
      const docId = ids[ids.length - 1];
      const seen = new Set<string>();
      for (const m of g.rows.flatMap((r) => r.scan?.matches ?? [])) {
        if (seen.has(m.account)) continue; seen.add(m.account);
        ws.updateItem(docId, m.account, { rawLabel: m.label, rawValue: m.current, pageNumber: m.page, statementType: CANONICAL_ACCOUNTS[m.account].statement,
          note: `Diusulkan otomatis (rule-based, tanpa AI) dari teks PDF hlm. ${m.page}${m.prior ? ` · komparatif: ${m.prior}` : ""}. Wajib dicek.` });
      }
      labels.push(`${h.ticker} ${periodText({ fiscalYear: Number(h.fiscalYear), period: h.period })}`);
    }
    const done = new Set(ready.flatMap((g) => g.rows.map((r) => r.id)));
    setRows((rs) => rs.filter((r) => !done.has(r.id)));
    setSaved({ ids, labels });
  };

  /* coverage matrix: issuers × 5-year window */
  const matrix = useMemo(() => {
    const tickers = [...new Set([...known.map((i) => i.code), ...rows.filter((r) => /^[A-Z]{4}$/.test(r.ticker)).map((r) => r.ticker)])].sort();
    const allYears = [...ws.documents.filter((d) => d.period.period === "FY").map((d) => d.period.fiscalYear), ...rows.filter((r) => r.period === "FY" && /^20\d{2}$/.test(r.fiscalYear)).map((r) => Number(r.fiscalYear))];
    const { window } = coverageWindow(allYears);
    return { tickers, window };
  }, [known, rows, ws.documents]);
  const cell = (tk: string, y: number) => {
    const doc = ws.documents.find((d) => d.ticker === tk && d.period.period === "FY" && d.period.fiscalYear === y);
    if (doc) return { tone: doc.status === "verified" ? "green" : "teal", text: doc.status === "verified" ? t("Verified") : t("Tersimpan") } as const;
    const g = groups.find((x) => x.key === `${tk}|${y}|FY`);
    if (g) return g.problems.length ? { tone: "amber", text: g.problems.some((p) => p.includes("Profit")) ? t("SFP saja") : g.problems.some((p) => p.includes("Position")) ? t("P&L saja") : t("Cek") } as const
      : { tone: g.confirmed ? "blue" : "neutral", text: g.confirmed ? t("Siap") : t("Belum dicek") } as const;
    return null;
  };

  return (
    <div className="grid grid-cols-1 xl:grid-cols-[minmax(0,1fr)_380px] gap-4 items-start">
      <div className="flex flex-col gap-4">
        <Notice tone="teal" icon={ShieldAlert}><b>{t("Batasan sumber.")}</b> {t(SOURCE_NOTICE)} {t("Unggah keduanya untuk tiap tahun, boleh dalam satu file atau terpisah.")} {t("Untuk tren lengkap, siapkan {n} tahun FY.", { n: WINDOW_YEARS })}</Notice>
        <YearDisclaimer />

        <Panel title="File Laporan" icon={Upload} right={rows.length ? <span className="text-[11px] tnum" style={{ color: T.sub }}>{rows.length} {t("file")} · {rows.filter((r) => r.confirmed).length} {t("dicek")}</span> : undefined}>
          <input ref={inputRef} type="file" multiple accept=".pdf,.png,.jpg,.jpeg" className="hidden" onChange={(e) => { add(e.target.files); e.target.value = ""; }} />
          <div role="button" tabIndex={0} onClick={() => inputRef.current?.click()}
            onKeyDown={(e) => { if (e.key === "Enter") inputRef.current?.click(); }}
            onDragOver={(e) => { e.preventDefault(); setDragging(true); }} onDragLeave={() => setDragging(false)}
            onDrop={(e) => { e.preventDefault(); setDragging(false); add(e.dataTransfer.files); }}
            className="flex flex-col items-center justify-center gap-1.5 rounded-[4px] cursor-pointer h-[112px] transition-colors"
            style={{ border: `1px dashed ${dragging ? T.teal : T.input}`, background: dragging ? T.tealMuted : T.inner }}>
            <Upload size={20} style={{ color: dragging ? T.teal : T.ter }} />
            <div className="text-[12.5px]" style={{ color: T.sub }}>{t("Tarik & lepas beberapa file sekaligus, atau klik untuk memilih")}</div>
            <div className="text-[11px]" style={{ color: T.ter }}>{t("PDF, JPG, PNG · maks. 50 MB per file · beberapa emiten & tahun boleh dicampur")}</div>
          </div>
          {rejected.length > 0 && <ul className="mt-2 flex flex-col gap-0.5 text-[12px]" style={{ color: T.red }}>{rejected.map((e) => <li key={e} className="flex items-center gap-1.5"><AlertTriangle size={12} />{e}</li>)}</ul>}
          {rows.length > 0 && (
            <div className="mt-3"><Notice tone="amber" icon={Info}>
              {t("PDF digital dikonversi ke teks oleh kode di browser (tanpa AI): halaman SFP/P&L, satuan, tahun, dan 9 akun diusulkan otomatis. Identitas emiten diusulkan dari nama file dan emiten yang pernah dikonfirmasi.")} {t("Buka setiap file, cocokkan dengan sampul dan header laporan, lalu centang")} <b>{t("Sudah dicek manual")}</b>. {t("Mengubah isian membatalkan centang.")}
            </Notice></div>
          )}
        </Panel>

        {rows.map((r) => {
          const errs = rowErrors(r); const g = groupOf(r);
          return (
            <section key={r.id} className="rounded-[6px]" style={{ background: T.card, border: `1px solid ${r.confirmed ? T.tealBorder : T.line}` }}>
              <header className="flex items-center gap-3 px-4 py-2.5" style={{ borderBottom: `1px solid ${T.line}` }}>
                <FileText size={14} style={{ color: T.ter }} />
                <div className="flex-1 min-w-0">
                  <div className="text-[12.5px] font-medium truncate">{r.file.name}</div>
                  <div className="text-[11px] flex flex-wrap gap-x-2" style={{ color: T.ter }}>
                    <span>{fmtSize(r.file.size)}</span>
                    <span>{r.matched.length ? `${t("Terdeteksi")}: ${r.matched.map((m) => t(MATCH_LABEL[m])).join(", ")}` : t("Tidak ada yang terdeteksi, isi manual")}</span>
                  </div>
                  {r.scan && <ScanLine scan={r.scan} />}
                </div>
                <Btn kind="ghost" icon={Eye} onClick={() => window.open(URL.createObjectURL(r.file), "_blank")}>Buka</Btn>
                <Btn kind="ghost" icon={Trash2} title="Hapus dari antrean" onClick={() => setRows((rs) => rs.filter((x) => x.id !== r.id))} />
              </header>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3 p-4">
                <Field label="Kode Saham"><input className={inputCls + " tnum uppercase"} style={inputStyle} value={r.ticker} placeholder="XXXX"
                  onChange={(e) => patch(r.id, { ticker: e.target.value.toUpperCase().replace(/[^A-Z]/g, "").slice(0, 4) })} /></Field>
                <div className="col-span-2 md:col-span-3"><Field label="Nama Perusahaan"><input className={inputCls} style={inputStyle} value={r.companyName} placeholder="PT … Tbk"
                  onChange={(e) => patch(r.id, { companyName: e.target.value })} /></Field></div>
                <Field label="Tahun Fiskal"><input className={inputCls + " tnum"} style={inputStyle} value={r.fiscalYear} placeholder="2024" inputMode="numeric"
                  onChange={(e) => patch(r.id, { fiscalYear: e.target.value.replace(/\D/g, "").slice(0, 4) })} /></Field>
                <Field label="Periode"><Select value={r.period} onChange={(v) => patch(r.id, { period: v as ReportingPeriod })}>
                  <option value="FY">{t("FY (tahunan)")}</option><option value="Q1">Q1</option><option value="Q2">Q2</option><option value="Q3">Q3</option>
                  {MONTH_PERIODS.map((m, i) => <option key={m} value={m}>{t("Bulanan (YTD)")} · {monthName(i + 1)}</option>)}</Select></Field>
                <div className="col-span-2"><Field label="Isi File"><Select value={r.statement} onChange={(v) => patch(r.id, { statement: v as StatementCoverage })}>
                  {(Object.keys(COVER_LABEL) as StatementCoverage[]).map((k) => <option key={k} value={k}>{tx(COVER_LABEL[k])}</option>)}</Select></Field></div>
                <Field label="Mata Uang"><Select value={r.currency} onChange={(v) => patch(r.id, { currency: v as Currency })}><option>IDR</option><option>USD</option></Select></Field>
                <div className="col-span-1 md:col-span-3"><Field label="Satuan Angka" hint="Sesuai header laporan, mis. “dalam jutaan Rupiah”."><Select value={r.unit} onChange={(v) => patch(r.id, { unit: v as UnitScale })}>
                  {(Object.keys(UNIT_LABEL) as UnitScale[]).map((u) => <option key={u} value={u}>{t(UNIT_LABEL[u])}</option>)}</Select></Field></div>
              </div>
              <footer className="flex items-center gap-3 flex-wrap px-4 py-2.5" style={{ borderTop: `1px solid ${T.line}`, background: T.inner }}>
                <label className={`flex items-center gap-2 text-[12px] font-medium ${errs.length ? "opacity-40 cursor-not-allowed" : "cursor-pointer"}`}>
                  <input type="checkbox" className="accent-[var(--c-teal)] w-3.5 h-3.5" disabled={!!errs.length} checked={r.confirmed} onChange={(e) => patch(r.id, { confirmed: e.target.checked })} />
                  {t("Sudah dicek manual terhadap dokumen")}
                </label>
                <span className="ml-auto text-[11px]" style={{ color: errs.length ? T.red : g?.problems.length ? T.amber : T.sub }}>
                  {errs.length ? `${t("Lengkapi")}: ${errs.map((e) => t(e)).join(", ")}` : g?.problems.length ? `${r.ticker} ${r.period} ${r.fiscalYear}: ${g.problems.map((e) => t(e)).join(" · ")}` : t("Bagian dari laporan {x} ({n} file)", { x: `${r.ticker} ${r.period} ${r.fiscalYear}`, n: g?.rows.length ?? 0 })}
                </span>
              </footer>
            </section>
          );
        })}

        {(rows.length > 0 || saved) && (
          <Panel>
            <div className="flex items-center gap-3 flex-wrap">
              <Btn kind="primary" icon={Check} disabled={!ready.length} onClick={save}>{t("Simpan {n} laporan terkonfirmasi", { n: ready.length || "" })}</Btn>
              <span className="text-[11px]" style={{ color: T.ter }}>
                {groups.length - ready.length > 0 ? t("{n} laporan belum siap (belum dicek atau P&L/SFP belum lengkap) tetap di antrean.", { n: groups.length - ready.length }) : t("Hanya laporan yang seluruh filenya sudah dicek yang disimpan.")}
              </span>
            </div>
            {saved && saved.ids.length > 0 && (
              <div className="mt-3"><Notice tone="green" icon={Check}>
                <div className="flex items-center gap-3 flex-wrap">
                  <span>{saved.labels.join(", ")} {t("tersimpan sebagai")} <b>{t("Needs Verification")}</b>. {t("Langkah berikutnya: verifikasi 9 akun wajib per laporan.")}</span>
                  <Btn kind="primary" onClick={() => { ws.setFocusDoc(saved.ids[0]); onNavigate("Verifikasi Ekstraksi AI"); }}>{t("Lanjut ke Verifikasi")} <ArrowRight size={13} /></Btn>
                </div>
              </Notice></div>
            )}
          </Panel>
        )}
      </div>

      <div className="flex flex-col gap-4 xl:sticky xl:top-4">
        <Panel title={t("Kelengkapan {n} Tahun (FY)", { n: WINDOW_YEARS })} icon={Library} pad={false}>
          {matrix.tickers.length === 0 ? <EmptyState compact icon={Library} title="Belum ada emiten" why="Emiten muncul di sini setelah laporannya diunggah dan dikonfirmasi. Tidak ada daftar emiten bawaan." /> : (
            <div className="overflow-x-auto">
              <table className="w-full text-[11px] tnum">
                <thead><tr style={{ color: T.ter }}>
                  <th className="text-left font-medium px-4 py-2">{t("Emiten")}</th>
                  {matrix.window.map((y) => <th key={y} className="font-medium px-1 py-2">{y}</th>)}
                </tr></thead>
                <tbody>{matrix.tickers.map((tk) => (
                  <tr key={tk} style={{ borderTop: `1px solid ${T.line}` }}>
                    <td className="px-4 py-2 font-semibold text-[12px]">{tk}</td>
                    {matrix.window.map((y) => { const c = cell(tk, y); return (
                      <td key={y} className="px-1 py-2 text-center">{c ? <Badge tone={c.tone}>{c.text}</Badge> : <span style={{ color: T.ter }}>—</span>}</td>); })}
                  </tr>))}</tbody>
              </table>
            </div>
          )}
          <div className="px-4 py-2.5 text-[11px]" style={{ borderTop: `1px solid ${T.line}`, color: T.ter }}>{t("Satu laporan = P&L + SFP pada tahun yang sama. Tahun kosong tidak diestimasi.")}</div>
        </Panel>
        <Panel title="Status Pipeline" icon={Info}>
          <ol className="flex flex-col gap-2.5 text-[12px]">
            {[
              ["Upload banyak file", "Validasi format, kelompokkan per emiten & tahun", true],
              ["Usulan identitas", "Dari nama file dan emiten yang pernah dikonfirmasi", true],
              ["Cek manual identitas", "Wajib per file sebelum disimpan", true],
              ["Verifikasi 9 akun", "Wajib sebelum kalkulasi", true],
              ["Rasio → Fuzzy Mamdani", "Deterministik, bukan AI", true],
            ].map(([ti, s], i) => (
              <li key={i} className="flex items-start gap-2.5">
                <span className="flex items-center justify-center w-5 h-5 rounded-[3px] text-[10px] font-semibold shrink-0 tnum" style={{ background: T.inner, border: `1px solid ${T.line}`, color: T.sub }}>{i + 1}</span>
                <span className="flex-1"><span className="block font-medium">{t(ti as string)}</span><span className="block text-[11px]" style={{ color: T.ter }}>{t(s as string)}</span></span>
              </li>
            ))}
          </ol>
        </Panel>
      </div>
    </div>
  );
}


/* ─── Verifikasi Ekstraksi AI ────────────────────── */
const STATEMENT_OPTIONS: StatementType[] = ["profit_loss", "financial_position", "cash_flows", "changes_in_equity", "notes", "other"];

export function VerifikasiPage({ onNavigate, flash, user }: { onNavigate: Nav; flash: (m: string) => void; user: string }) {
  const { t } = useT();
  const ws = useWorkspace();
  const candidates = ws.documents;
  const docId = ws.focusDoc && candidates.some((d) => d.id === ws.focusDoc) ? ws.focusDoc : (candidates.find((d) => d.status !== "verified") ?? candidates[0])?.id;
  const doc = candidates.find((d) => d.id === docId);
  const [viewPage, setViewPage] = useState(1);
  const [editing, setEditing] = useState<{ acc: CanonicalAccountId; mode: "mapping" | "value" } | null>(null);
  const [runError, setRunError] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const admin = canManageCollection(getRole());
  const hasFile = docId ? !!ws.files[docId] : true;
  const isDemoDoc = !!doc?.demo;
  useEffect(() => {
    if (docId && !hasFile && !isDemoDoc) void ws.openFile(docId);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [docId, hasFile, isDemoDoc]);

  if (!doc) {
    return (
      <Panel><EmptyState icon={CheckSquare} title="Belum ada dokumen untuk diverifikasi"
        why={admin ? "Workspace verifikasi membutuhkan dokumen laporan keuangan. Unggah laporan terlebih dahulu, atau muat data demo dari Collections." : "Belum ada laporan di koleksi. Admin akan menambahkan laporan keuangan secara berkala."}
        action={admin
          ? <><Btn kind="primary" icon={Upload} onClick={() => onNavigate("Upload Laporan")}>Upload Laporan</Btn><Btn onClick={() => onNavigate("Collections")}>Collections</Btn></>
          : <Btn kind="primary" icon={Library} onClick={() => onNavigate("Perpustakaan Laporan")}>Pilih laporan dari koleksi</Btn>} /></Panel>
    );
  }

  const items = REQUIRED_ACCOUNTS.map((a) => ws.items.find((i) => i.documentId === doc.id && i.canonicalAccount === a)).filter(Boolean) as WorkingItem[];
  const consistency = consistencyIssues(Object.fromEntries(items.map((i) => [i.canonicalAccount, i.normalizedValue])));
  const original = (acc: CanonicalAccountId) => ws.extractions.find((e) => e.documentId === doc.id && e.canonicalAccount === acc);
  const p = ws.progress(doc.id);
  const market = ws.market.find((m) => m.documentId === doc.id);
  const fileUrl = ws.files[doc.id];
  const wrongYear = ws.extractions.find((e) => e.documentId === doc.id && e.columnYear && e.columnYear !== doc.period.fiscalYear)?.columnYear;
  const yearBlocked = !!wrongYear && !doc.demo;
  const allVerified = p.verified === p.total && p.total > 0 && !yearBlocked;

  const act = (acc: CanonicalAccountId, st: VerificationStatus) => {
    const msg = ws.setStatus(doc.id, acc, st, user);
    if (msg) flash(msg);
    setEditing(null);
  };
  const acceptable = items.filter((i) => i.rawValue.trim() !== "" && i.pageNumber != null && i.statementType != null && i.status !== "verified" && i.status !== "rejected");
  const acceptAll = () => {
    let n = 0;
    for (const it of acceptable) { if (!ws.setStatus(doc.id, it.canonicalAccount, "verified", user)) n++; }
    setEditing(null);
    flash(t("{n} akun diterima sebagai Verified", { n }));
  };
  const run = () => {
    const err = ws.runAnalysis(doc.id);
    setRunError(err);
    if (!err) { flash(t("Analisis {d} selesai dihitung", { d: docLabel(doc) })); onNavigate("Skor & Defuzzifikasi"); }
  };
  const cols = "minmax(150px,1.3fr) minmax(130px,1.2fr) minmax(120px,1fr) 52px 150px 70px 104px 132px";

  return (
    <div className="flex flex-col gap-4">
      {/* Document bar */}
      <div className="flex items-center gap-3 flex-wrap px-4 py-3 rounded-[6px]" style={{ background: T.card, border: `1px solid ${T.line}` }}>
        <Select value={doc.id} onChange={(v) => { ws.setFocusDoc(v); setEditing(null); setRunError(null); setViewPage(1); }} className="!w-auto min-w-[260px]">
          {candidates.map((d) => <option key={d.id} value={d.id}>{docLabel(d)} — v{d.version}{d.demo ? " (DEMO)" : ""}</option>)}
        </Select>
        <span className="text-[12px]" style={{ color: T.sub }}>{doc.companyName}</span>
        {doc.demo && <DemoBadge />}
        <span className="text-[11px]" style={{ color: T.ter }}>{doc.currency} · {t(UNIT_LABEL[doc.unit])}</span>
        <div className="ml-auto flex items-center gap-3 min-w-[220px]"><ProgressBar done={p.verified} total={p.total} flagged={p.flagged} /></div>
      </div>

      {!doc.demo && (
        <Notice tone="neutral" icon={Info}>
          <b>{t("Angka diisi otomatis dari laporan di koleksi.")}</b> {t("Periksa setiap angka terhadap PDF asli sebelum konfirmasi; AI hanya mengusulkan, Anda yang memverifikasi. Akun yang tidak tercantum pada dua statement yang diizinkan ditandai")} <b>{t("Not Found")}</b>.
        </Notice>
      )}
      {!hasAi() && !doc.demo && (
        <Notice tone="amber" icon={Info}>{t("Hanya pencocokan otomatis (rule-based) yang aktif; akun yang tidak ketemu diisi manual.")}</Notice>
      )}

      <div className="grid grid-cols-1 2xl:grid-cols-[minmax(0,5fr)_minmax(0,8fr)] gap-4 items-start">
        {/* Viewer */}
        <Panel title="Dokumen Sumber" icon={FileText} pad={false}
          right={fileUrl && doc.fileType === "pdf" && (
            <div className="flex items-center gap-1.5 text-[11px]" style={{ color: T.sub }}>{t("Hal.")}
              <input type="number" min={1} value={viewPage} onChange={(e) => setViewPage(Math.max(1, Number(e.target.value) || 1))} className="w-14 h-7 px-2 rounded-[4px] text-[12px] outline-none tnum" style={inputStyle} />
            </div>
          )}>
          <input ref={fileRef} type="file" accept=".pdf,.png,.jpg,.jpeg" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) ws.attachFile(doc.id, f); e.target.value = ""; }} />
          {fileUrl ? (
            doc.fileType === "pdf"
              ? <iframe key={`${fileUrl}-${viewPage}`} title={t("Pratinjau dokumen")} src={`${fileUrl}#page=${viewPage}`} className="w-full block" style={{ height: 640, border: 0, background: "#fff" }} />
              : <div className="overflow-auto" style={{ maxHeight: 640 }}><img src={fileUrl} alt={doc.fileName} className="w-full block" /></div>
          ) : (
            <EmptyState icon={ImageOff} title={doc.demo ? "Dokumen demo tidak memiliki file" : "Pratinjau file tidak tersedia"}
              why={doc.demo ? "Data demo hanya berisi akun terverifikasi ilustratif, tanpa PDF sumber." : "File sumber tidak ditemukan di penyimpanan browser ini. Koleksi hanya tersimpan di perangkat yang sama; minta admin menambahkan ulang laporan."}
              action={admin && !doc.demo ? <Btn icon={RefreshCw} onClick={() => fileRef.current?.click()}>Pilih ulang file</Btn> : undefined} />
          )}
        </Panel>

        {/* Extraction table */}
        <div className="flex flex-col gap-4 min-w-0">
          {yearBlocked && (
            <Notice tone="red" icon={AlertTriangle}>
              <b>{t("Proses dibekukan: tahun tidak cocok.")}</b> {t("Dokumen ini terdaftar sebagai FY {e}, tetapi ekstraksi membaca kolom {f}. Sesuaikan data (hapus dan unggah ulang dengan tahun yang benar) sebelum diverifikasi dan dihitung.", { e: doc.period.fiscalYear, f: wrongYear })}
            </Notice>
          )}
          {consistency.length > 0 && (
            <Notice tone="amber" icon={AlertTriangle}>
              <b>{t("Cek konsistensi angka:")}</b>
              <ul className="list-disc pl-4 mt-1">{consistency.map((m) => <li key={m}>{t(m)}</li>)}</ul>
            </Notice>
          )}
          <Panel title="Tabel Ekstraksi & Verifikasi" icon={CheckSquare} pad={false}
            right={<div className="flex items-center gap-3">
              <span className="text-[11px] hidden xl:inline" style={{ color: T.ter }}>{t("Ekstraksi asli & hasil verifikasi disimpan terpisah")}</span>
              <Btn kind="secondary" icon={Check} disabled={doc.demo || yearBlocked || acceptable.length === 0} onClick={acceptAll}>Terima semua angka yang terisi</Btn>
            </div>}>
            <Table cols={cols} minWidth={1000} head={["Akun Wajib", "Label Akun (raw)", "Nilai", "Hal.", "Jenis Statement", "Conf.", "Status", "Aksi"]}>
              {items.map((it) => {
                const ca = CANONICAL_ACCOUNTS[it.canonicalAccount];
                const orig = original(it.canonicalAccount);
                const meta = VERIF_META[it.status];
                const isEdit = editing?.acc === it.canonicalAccount;
                const locked = doc.demo || yearBlocked;
                const stOk = it.statementType == null || isAllowedStatement(it.statementType);
                const src = parseSource(it.note);
                return (
                  <Row key={it.canonicalAccount} cols={cols}>
                    <div className="min-w-0">
                      <div className="font-medium truncate">{t(ca.labelId)}</div>
                      <div className="text-[10.5px] truncate" style={{ color: T.ter }}>{t(STATEMENT_LABEL[ca.statement])} · {ratiosAffectedBy(it.canonicalAccount).join(", ")}</div>
                    </div>
                    <div className="min-w-0">
                      {isEdit && editing.mode === "mapping"
                        ? <input autoFocus className={inputCls + " !h-7"} style={inputStyle} value={it.rawLabel} placeholder={ca.aliases[0]} onChange={(e) => ws.updateItem(doc.id, it.canonicalAccount, { rawLabel: e.target.value })} />
                        : <span className="truncate block" style={{ color: it.rawLabel ? T.text : T.ter }}>{it.rawLabel || "—"}</span>}
                      {orig && <span className="text-[10.5px] block truncate" style={{ color: T.ter }}>AI: {orig.rawLabel}</span>}
                      {src && (
                        <span className="flex items-start gap-1.5 mt-0.5">
                          <Badge tone={src.kind === "ai" ? "teal" : "blue"}>{src.kind === "ai" ? "AI" : "Rule"}</Badge>
                          {src.text && <span className="text-[10.5px] leading-snug" style={{ color: T.ter }} title={src.text}>{src.text}</span>}
                        </span>
                      )}
                      {it.pageNumber && fileUrl && doc.fileType === "pdf" && (
                        <button type="button" onClick={() => setViewPage(it.pageNumber ?? 1)} className="text-[10.5px] underline mt-0.5 text-left" style={{ color: T.teal }}>{t("Bandingkan dengan laporan asli")} ({t("hlm.")} {it.pageNumber})</button>
                      )}
                    </div>
                    <div className="min-w-0">
                      {isEdit && editing.mode === "value"
                        ? <input autoFocus className={inputCls + " !h-7 tnum"} style={inputStyle} value={it.rawValue} placeholder="1.234.567" onChange={(e) => ws.updateItem(doc.id, it.canonicalAccount, { rawValue: e.target.value })} />
                        : it.status === "not_found"
                          ? <span className="text-[11px]" style={{ color: T.ter }}>{t(NOT_FOUND_MESSAGE)}</span>
                          : <span className="tnum block truncate">{it.rawValue || <span style={{ color: T.ter }}>—</span>}</span>}
                      <span className="text-[10.5px] block truncate tnum" style={{ color: it.rawValue && it.parsedValue == null ? T.red : T.ter }}>
                        {it.rawValue && it.parsedValue == null ? t("Bukan angka valid") : it.normalizedValue != null ? `= ${fmtNum(it.normalizedValue, 0)} ${doc.currency}${it.canonicalAccount === "basic_eps" ? t("/saham") : ""}` : ""}
                      </span>
                    </div>
                    <div>
                      {isEdit && editing.mode === "mapping"
                        ? <input type="number" min={1} className={inputCls + " !h-7 !px-1.5 tnum"} style={inputStyle} value={it.pageNumber ?? ""} onChange={(e) => ws.updateItem(doc.id, it.canonicalAccount, { pageNumber: e.target.value ? Number(e.target.value) : null })} />
                        : <span className="tnum" style={{ color: T.sub }}>{it.pageNumber ?? "—"}</span>}
                    </div>
                    <div className="min-w-0">
                      {isEdit && editing.mode === "mapping"
                        ? <select className={inputCls + " !h-7"} style={inputStyle} value={it.statementType ?? ""} onChange={(e) => ws.updateItem(doc.id, it.canonicalAccount, { statementType: (e.target.value || null) as StatementType | null })}>
                            <option value="">{t("Pilih…")}</option>{STATEMENT_OPTIONS.map((s) => <option key={s} value={s}>{t(STATEMENT_LABEL[s])}</option>)}
                          </select>
                        : <span className="text-[11.5px] truncate block" style={{ color: stOk ? T.sub : T.red }}>{it.statementType ? t(STATEMENT_LABEL[it.statementType]) : "—"}</span>}
                    </div>
                    <span className="tnum text-[11.5px]" style={{ color: T.ter }} title={t("Confidence hanya tersedia jika engine ekstraksi mengembalikannya")}>{orig?.confidence != null ? `${Math.round(orig.confidence * 100)}%` : "—"}</span>
                    <span><Badge tone={meta.tone}>{t(meta.label)}</Badge></span>
                    <div className="flex items-center gap-0.5">
                      <IconAct icon={Eye} label="View Source" disabled={!it.pageNumber || !fileUrl} onClick={() => setViewPage(it.pageNumber ?? 1)} />
                      <IconAct icon={Pencil} label="Edit Mapping (label, halaman, statement)" disabled={locked} active={isEdit && editing.mode === "mapping"} onClick={() => setEditing(isEdit && editing.mode === "mapping" ? null : { acc: it.canonicalAccount, mode: "mapping" })} />
                      <IconAct icon={Calculator} label="Edit Value" disabled={locked} active={isEdit && editing.mode === "value"} onClick={() => setEditing(isEdit && editing.mode === "value" ? null : { acc: it.canonicalAccount, mode: "value" })} />
                      <IconAct icon={Check} label="Verify" tone="green" disabled={locked || it.status === "verified"} onClick={() => act(it.canonicalAccount, "verified")} />
                      <IconAct icon={X} label="Reject" tone="red" disabled={locked || it.status === "rejected"} onClick={() => act(it.canonicalAccount, "rejected")} />
                      <IconAct icon={Ban} label="Mark Not Found" disabled={locked || it.status === "not_found"} onClick={() => act(it.canonicalAccount, "not_found")} />
                    </div>
                  </Row>
                );
              })}
            </Table>
          </Panel>

          <Panel title="Input Pasar Eksternal — khusus PER" icon={Info}>
            <div className="text-[11.5px] mb-3 leading-relaxed" style={{ color: T.sub }}>
              {t("PER = Harga Saham / Laba per Saham Dasar. Harga saham")} <b>{t("tidak terdapat")}</b> {t("pada Profit and Loss maupun Statement of Financial Position, sehingga dicatat terpisah sebagai")} <i>external market input</i> {t("beserta tanggal dan sumbernya. Tanpa input ini PER — dan Skor Model — tidak dihitung.")}
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <Field label="Harga saham penutupan">
                <input type="number" min={0} disabled={doc.demo} className={inputCls + " tnum"} style={inputStyle} value={market?.sharePrice ?? ""} onChange={(e) => ws.setMarket(doc.id, { sharePrice: e.target.value === "" ? null : Number(e.target.value) })} />
              </Field>
              <Field label="Mata uang"><Select value={market?.currency ?? doc.currency} onChange={(v) => ws.setMarket(doc.id, { currency: v as Currency })}><option>IDR</option><option>USD</option></Select></Field>
              <Field label="Tanggal harga"><input type="date" disabled={doc.demo} className={inputCls} style={inputStyle} value={market?.priceDate ?? ""} onChange={(e) => ws.setMarket(doc.id, { priceDate: e.target.value })} /></Field>
              <Field label="Sumber"><input disabled={doc.demo} className={inputCls} style={inputStyle} value={market?.source ?? ""} placeholder={t("mis. IDX, ringkasan perdagangan")} onChange={(e) => ws.setMarket(doc.id, { source: e.target.value })} /></Field>
            </div>
            {market && market.currency !== doc.currency && <div className="mt-2 text-[11.5px]" style={{ color: T.amber }}>{t("Mata uang harga ({a}) berbeda dengan mata uang laporan ({b}). Konversi kurs tidak dilakukan otomatis, PER tidak akan dihitung.", { a: market.currency, b: doc.currency })}</div>}
          </Panel>

          <div className="flex items-center gap-3 flex-wrap px-4 py-3 rounded-[6px]" style={{ background: T.card, border: `1px solid ${T.line}` }}>
            <div className="text-[12px] flex-1 min-w-[240px]" style={{ color: T.sub }}>
              {allVerified ? t("Seluruh 9 akun wajib Verified. Verified dataset siap dihitung secara deterministik.") : t("{n} akun belum Verified. Kalkulasi rasio diblokir sampai seluruh akun wajib terverifikasi.", { n: p.total - p.verified })}
            </div>
            <Btn kind="primary" icon={Calculator} disabled={!allVerified} onClick={run}>Simpan Verified Dataset & Hitung</Btn>
          </div>
          {runError && <Notice tone="red" icon={AlertTriangle}>{t(runError)}</Notice>}
        </div>
      </div>
    </div>
  );
}

/** Splits the "[rule]" / "[ai]" source prefix from an item note. */
function parseSource(note?: string): { kind: "rule" | "ai"; text: string } | null {
  const m = note?.match(/^\[(rule|ai)\]\s*(.*)$/s);
  if (m) return { kind: m[1] as "rule" | "ai", text: m[2] };
  return null;
}

function IconAct({ icon: Icon, label, onClick, disabled, tone, active }: { icon: typeof Eye; label: string; onClick: () => void; disabled?: boolean; tone?: "green" | "red"; active?: boolean }) {
  const c = tone === "green" ? T.green : tone === "red" ? T.red : T.sub;
  return (
    <button type="button" title={tx(label)} aria-label={tx(label)} disabled={disabled} onClick={onClick}
      className="flex items-center justify-center w-6 h-6 rounded-[3px] transition-colors hover:bg-[var(--c-hover)] disabled:opacity-25 disabled:cursor-not-allowed"
      style={{ color: c, background: active ? T.tealMuted : undefined }}>
      <Icon size={13} strokeWidth={1.9} />
    </button>
  );
}

/* ─── Perpustakaan Laporan ───────────────────────── */
const PULL_STAGES = ["reading", "extracting", "filling"] as const;
const PULL_LABEL: Record<string, string> = { reading: "Membaca PDF", extracting: "Membaca angka", filling: "Mengisi form" };

export function PullProgress({ stage, done, total }: { stage: string; done?: number; total?: number }) {
  const { t } = useT();
  const idx = Math.max(0, PULL_STAGES.indexOf(stage as typeof PULL_STAGES[number]));
  return (
    <div className="flex items-center gap-2 text-[11.5px] tnum" style={{ color: T.teal }} role="status">
      <RefreshCw size={12} className="animate-spin" />
      <span>{idx + 1}/3 {t(PULL_LABEL[PULL_STAGES[idx]])}{total ? ` ${done ?? 0}/${total}` : ""}…</span>
    </div>
  );
}

export function PerpustakaanPage({ onNavigate, user }: { onNavigate: Nav; user?: string }) {
  const { t } = useT();
  const ws = useWorkspace();
  const admin = canManageCollection(getRole());
  const userKey = user || "user";
  const { pulling, pullError, mismatch, closeMismatch, run } = usePull(onNavigate, userKey);
  const pull = (d: DocRecord) => run([d]);
  const [q, setQ] = useState("");
  const [vf, setVf] = useState("all");
  const [af, setAf] = useState("all");
  const [confirmDel, setConfirmDel] = useState<string | null>(null);

  const rows = useMemo(() => ws.documents.filter((d) => {
    const s = q.trim().toLowerCase();
    if (s && !`${d.ticker} ${d.companyName} ${d.fileName} ${d.period.fiscalYear}`.toLowerCase().includes(s)) return false;
    if (vf !== "all" && (vf === "verified") !== (d.status === "verified")) return false;
    if (af !== "all" && ws.analysisStatus(d.id) !== af) return false;
    return true;
  }), [ws, q, vf, af]);

  const go = (d: DocRecord, page: string) => { ws.setFocusDoc(d.id); onNavigate(page); };
  const cols = "minmax(160px,1.4fr) 90px minmax(140px,1.3fr) 130px 150px 150px 130px 330px";

  return (
    <div className="flex flex-col gap-3">
      {!hasAi() && ws.documents.length > 0 && (
        <Notice tone="amber" icon={Info}>{t("Hanya pencocokan otomatis (rule-based) yang aktif; akun yang tidak ketemu diisi manual.")}</Notice>
      )}
      {pullError && <Notice tone="red" icon={AlertTriangle}>{pullError}</Notice>}
      {mismatch && <YearMismatchDialog doc={mismatch.doc} err={mismatch.err} onClose={closeMismatch} onNavigate={onNavigate} />}
      <div className="flex items-center gap-2 flex-wrap px-3 py-2.5 rounded-[6px]" style={{ background: T.card, border: `1px solid ${T.line}` }}>
        <div className="flex items-center gap-2 h-8 px-2.5 rounded-[4px] flex-1 min-w-[220px]" style={inputStyle}>
          <Search size={13} style={{ color: T.ter }} />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder={t("Cari kode, perusahaan, file, tahun…")} className="bg-transparent outline-none text-[12px] w-full" />
        </div>
        <Select value={vf} onChange={setVf} className="!w-auto !h-8"><option value="all">{t("Semua verifikasi")}</option><option value="verified">{t("Verified")}</option><option value="pending">{t("Needs Verification")}</option></Select>
        <Select value={af} onChange={setAf} className="!w-auto !h-8"><option value="all">{t("Semua analisis")}</option>{Object.entries(ANALYSIS_META).map(([k, v]) => <option key={k} value={k}>{t(v.label)}</option>)}</Select>
        <span className="text-[11px] ml-auto tnum" style={{ color: T.ter }}>{t("{a} dari {b} dokumen", { a: rows.length, b: ws.documents.length })}</span>
      </div>

      <Panel pad={false}>
        {ws.documents.length === 0 ? (
          <EmptyState icon={Library} title="Perpustakaan masih kosong"
            why={admin ? "Belum ada laporan yang diunggah. Setiap dokumen yang disimpan akan tercatat di sini beserta status ekstraksi, verifikasi, dan analisisnya." : "Belum ada laporan di koleksi. Admin akan menambahkan laporan keuangan secara berkala."}
            action={admin ? <><Btn kind="primary" icon={Upload} onClick={() => onNavigate("Upload Laporan")}>Upload Laporan</Btn><Btn icon={Database} onClick={() => ws.seedDemo(buildDemo)}>Muat Data Demo</Btn></> : undefined} />
        ) : rows.length === 0 ? (
          <EmptyState compact icon={Search} title="Tidak ada dokumen yang cocok" why="Ubah kata kunci atau filter status." action={<Btn onClick={() => { setQ(""); setVf("all"); setAf("all"); }}>Reset filter</Btn>} />
        ) : (
          <Table cols={cols} minWidth={1320} head={["Emiten", "Periode", "File", "Ekstraksi", "Verifikasi", "Analisis", "Diunggah", "Aksi"]}>
            {rows.map((d) => {
              const p = ws.progress(d.id);
              const a = ANALYSIS_META[ws.analysisStatus(d.id)];
              return (
                <Row key={d.id} cols={cols}>
                  <div className="min-w-0"><div className="font-semibold flex items-center gap-2">{d.ticker} {d.demo && <DemoBadge />}</div><div className="text-[11px] truncate" style={{ color: T.ter }}>{d.companyName}</div></div>
                  <span className="tnum">{periodText(d.period)}</span>
                  <div className="min-w-0"><div className="truncate" style={{ color: T.sub }}>{d.fileName}</div><div className="text-[10.5px]" style={{ color: T.ter }}>v{d.version} · {fmtSize(d.fileSize)} · {d.currency}</div></div>
                  <span>{d.demo ? <Badge tone="blue">{t("Demo")}</Badge> : hasAi() ? <Badge tone="teal">AI</Badge> : <Badge tone="neutral" >{t("Manual")}</Badge>}</span>
                  <span className="flex items-center gap-1.5"><Badge tone={d.status === "verified" ? "green" : "amber"}>{d.status === "verified" ? t("Verified") : t("Needs Review")}</Badge><span className="text-[11px] tnum" style={{ color: T.ter }}>{p.verified}/{p.total}</span></span>
                  <span><Badge tone={a.tone}>{t(a.label)}</Badge></span>
                  <span className="text-[11.5px]" style={{ color: T.sub }}>{fmtDate(d.uploadedAt)}</span>
                  <div className="flex items-center gap-1 flex-wrap">
                    {confirmDel === d.id && admin ? (
                      <><Btn kind="danger" onClick={() => { ws.removeDocument(d.id); setConfirmDel(null); }}>Hapus?</Btn><Btn kind="ghost" onClick={() => setConfirmDel(null)}>Batal</Btn></>
                    ) : pulling?.id === d.id ? (
                      <PullProgress stage={pulling.stage} done={pulling.done} total={pulling.total} />
                    ) : (
                      <>
                        <Btn kind="primary" icon={Calculator} disabled={!!pulling} onClick={() => pull(d)}>Analisis laporan ini</Btn>
                        <Btn kind="ghost" onClick={() => go(d, "Verifikasi Ekstraksi AI")}>Verifikasi</Btn>
                        <Btn kind="ghost" disabled={a.label === ANALYSIS_META.not_started.label} onClick={() => go(d, "Skor & Defuzzifikasi")}>Analisis</Btn>
                        {admin && <IconAct icon={Trash2} label="Hapus dokumen" tone="red" onClick={() => setConfirmDel(d.id)} />}
                      </>
                    )}
                  </div>
                </Row>
              );
            })}
          </Table>
        )}
      </Panel>
    </div>
  );
}
