// Simulasi End-to-End — scripted walkthrough of the full SSI pipeline on illustrative BBRI & BMRI reports:
// library → PDF to TXT → DeepSeek (server-side, key hidden) → 9-account verification → Mamdani → score → apple-to-apple comparison.
import { Fragment, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import {
  Library, FileText, Cpu, ClipboardCheck, Sigma, Gauge, GitCompare, Play, Pause, SkipForward, RotateCcw, Lock, ShieldCheck,
  AlertTriangle, Info, CheckCircle2, XCircle, Server, FileWarning, Ban, Calculator, X, Bell,
} from "lucide-react";
import { T, Panel, Btn, Badge, Notice, Stat, Table, Row, Select, CategoryBadge, fmtNum, inputCls, inputStyle, tx, type Tone } from "../ui";
import { alpha } from "../theme";
import { CANONICAL_ACCOUNTS, MODEL_VERSION, RATIO_DEFINITIONS, type CanonicalAccountId } from "../domain/financial";
import { VAR_KEYS, VAR_DEFS, RULES, OUT, RULE_COUNT, ruleId, categoryOf, CATEGORY_COLOR, dominantSet, type VarKey } from "../domain/engine";
import { validateComparison, MIN_YEARS } from "../domain/yearWindow";
import type { AnalysisRecord } from "../domain/store";
import { SIM_BANKS, SIM_DOCS, TRAP, simAccounts, simPrice, simScore, simTxt, simExtraction, simYears, type SimTicker } from "../domain/simulation";
import ScoreGauge from "../components/ScoreGauge";
import { YearDisclaimer } from "../components/YearDisclaimer";

const STAGES = [
  { label: "Perpustakaan", icon: Library },
  { label: "PDF → TXT", icon: FileText },
  { label: "Analisis DeepSeek", icon: Cpu },
  { label: "Verifikasi 9 Akun", icon: ClipboardCheck },
  { label: "Mamdani", icon: Sigma },
  { label: "Hasil Skor", icon: Gauge },
  { label: "Perbandingan", icon: GitCompare },
] as const;

const PICK: { ticker: SimTicker; year: number }[] = [{ ticker: "BBRI", year: 2024 }, { ticker: "BMRI", year: 2024 }];
const TICKERS: SimTicker[] = ["BBRI", "BMRI"];
const LEVEL: Record<string, string> = { Layak: "Tinggi", Dipertimbangkan: "Sedang", "Tidak Layak": "Rendah" };
const DONE_MSG: [Tone, string][] = [
  ["teal", "2 laporan ditarik dari Koleksi (BBRI FY2024, BMRI FY2024)."],
  ["green", "Konversi PDF → TXT selesai. Halaman Laba Rugi & Posisi Keuangan ditemukan."],
  ["amber", "DeepSeek mengusulkan 8/9 akun. 1 usulan ditolak validator, DPK perlu input manual."],
  ["green", "Semua akun terverifikasi. Skor dihitung secara deterministik."],
  ["green", "Inferensi Mamdani selesai: 24 rule dievaluasi, defuzzifikasi centroid."],
  ["teal", "Skor Model tersedia untuk 2 emiten."],
  ["neutral", "Simulasi selesai."],
];

type Toast = { id: number; tone: Tone; text: string };
const mono = { fontFamily: "ui-monospace, SFMono-Regular, Menlo, monospace" };
const idr = (v: number) => v.toLocaleString("id-ID");
const tr = (s: string) => tx(s) as string;
const trTerms = (s: string) => s.replace(/\b(Tinggi|Sedang|Rendah|Efisien|Murah|Wajar|Ideal|Boros|Mahal|Layak|Dipertimbangkan)\b/g, (term) => tr(term));

/* ─── Small building blocks ─────────────────────── */
function Bar({ pct, color = T.teal }: { pct: number; color?: string }) {
  return <div className="h-1.5 rounded-full overflow-hidden" style={{ background: T.track }}>
    <div className="h-full rounded-full transition-[width] duration-300" style={{ width: `${Math.min(100, Math.max(0, pct))}%`, background: color }} /></div>;
}

function StepLine({ done, active, children }: { done: boolean; active: boolean; children: ReactNode }) {
  const Icon = done ? CheckCircle2 : active ? Cpu : Info;
  return <div className="flex items-start gap-2 text-[12px] transition-opacity duration-300" style={{ opacity: done || active ? 1 : 0.4, color: done ? T.text : T.sub }}>
    <Icon size={13} className={"shrink-0 mt-[2px] " + (active && !done ? "animate-pulse" : "")} style={{ color: done ? T.green : T.sub }} />{children}</div>;
}

function Highlight({ text }: { text: string }) {
  const parts = text.split(/(\d{1,3}(?:\.\d{3})+(?:,\d+)?|\d+,\d{2})/g);
  return <>{parts.map((p, i) => i % 2 ? <mark key={i} className="rounded-[2px] px-0.5" style={{ background: alpha(T.amber, 18), color: T.text }}>{p}</mark> : <span key={i}>{p}</span>)}</>;
}

function MembershipChart({ k, v }: { k: VarKey; v: number }) {
  const d = VAR_DEFS[k], [lo, hi] = d.domain, W = 220, H = 70;
  const x = (u: number) => ((Math.min(hi, Math.max(lo, u)) - lo) / (hi - lo)) * W;
  const y = (m: number) => H - 6 - m * (H - 14);
  const dom = dominantSet(k, v);
  return (
    <div className="rounded-[8px] p-3" style={{ background: T.inner, border: `1px solid ${T.line}` }}>
      <div className="flex items-center justify-between gap-2 mb-1">
        <span className="text-[12px] font-semibold">{k}</span>
        <span className="text-[12px] tnum font-semibold">{fmtNum(v)}{d.unit}</span>
      </div>
      <svg viewBox={`0 0 ${W} ${H}`} className="w-full" style={{ height: H }} aria-label={`${k} ${fmtNum(v)}`}>
        <line x1={0} x2={W} y1={y(0)} y2={y(0)} stroke={T.line} />
        {d.sets.map((s) => <polyline key={s.name} fill="none" stroke={s.color} strokeWidth={1.5}
          points={`${x(s.pts[0])},${y(s.pts[0] === s.pts[1] ? 1 : 0)} ${x(s.pts[1])},${y(1)} ${x(s.pts[2])},${y(s.pts[1] === s.pts[2] ? 1 : 0)}`} />)}
        <line x1={x(v)} x2={x(v)} y1={4} y2={y(0)} stroke={T.text} strokeDasharray="2 2" />
        {d.sets.map((s, i) => dom.all[i] > 0 && <circle key={s.name} cx={x(v)} cy={y(dom.all[i])} r={3} fill={s.color} />)}
      </svg>
      <div className="flex flex-wrap gap-x-2 gap-y-0.5 mt-1 text-[10.5px] tnum">
        {d.sets.map((s, i) => <span key={s.name} style={{ color: dom.all[i] > 0 ? T.text : T.ter }}>
          <span className="inline-block w-1.5 h-1.5 rounded-full mr-1 align-middle" style={{ background: s.color }} />{tr(s.name)} {fmtNum(dom.all[i])}</span>)}
      </div>
    </div>
  );
}

function OutputChart({ agg, score }: { agg: number[]; score: number }) {
  const W = 520, H = 150, x = (u: number) => (u / 100) * W, y = (m: number) => H - 18 - m * (H - 30);
  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="w-full" style={{ maxHeight: 180 }} aria-label={`Kurva agregasi output, centroid ${fmtNum(score)}`}>
      {[0, 25, 50, 75, 100].map((u) => <g key={u}><line x1={x(u)} x2={x(u)} y1={8} y2={y(0)} stroke={T.line} strokeDasharray="2 3" />
        <text x={x(u)} y={H - 4} fontSize={10} textAnchor="middle" fill={T.ter}>{u}</text></g>)}
      {OUT.map((s) => <polyline key={s.name} fill="none" stroke={s.color} strokeOpacity={0.45} strokeWidth={1}
        points={`${x(s.pts[0])},${y(s.pts[0] === s.pts[1] ? 1 : 0)} ${x(s.pts[1])},${y(1)} ${x(s.pts[2])},${y(s.pts[1] === s.pts[2] ? 1 : 0)}`} />)}
      <polyline fill="none" stroke={T.text} strokeWidth={2} points={agg.map((m, i) => `${x(i)},${y(m)}`).join(" ")} />
      <line x1={x(score)} x2={x(score)} y1={8} y2={y(0)} stroke={T.teal} strokeWidth={1.5} />
      <text x={x(score) + 4} y={18} fontSize={11} fill={T.teal} fontWeight={600}>centroid {fmtNum(score)}</text>
    </svg>
  );
}

function TrendChart({ series, window }: { series: Record<string, number[]>; window: number[] }) {
  const W = 520, H = 170, pad = 28;
  const x = (i: number) => pad + (window.length < 2 ? 0 : (i / (window.length - 1)) * (W - pad * 2));
  const y = (s: number) => H - 22 - (s / 100) * (H - 36);
  const colors = [T.teal, T.blue];
  return (
    <div>
      <svg viewBox={`0 0 ${W} ${H}`} className="w-full" style={{ maxHeight: 200 }} aria-label="Tren Skor Model">
        {[35, 65].map((s) => <g key={s}><line x1={pad} x2={W - pad} y1={y(s)} y2={y(s)} stroke={T.line} strokeDasharray="3 3" />
          <text x={W - pad + 4} y={y(s) + 3} fontSize={9.5} fill={T.ter}>{s}</text></g>)}
        {window.map((yr, i) => <text key={yr} x={x(i)} y={H - 6} fontSize={10} textAnchor="middle" fill={T.ter}>{yr}</text>)}
        {Object.entries(series).map(([t, vals], si) => <g key={t}>
          <polyline fill="none" stroke={colors[si]} strokeWidth={2} points={vals.map((v, i) => `${x(i)},${y(v)}`).join(" ")} />
          {vals.map((v, i) => <circle key={i} cx={x(i)} cy={y(v)} r={3} fill={colors[si]} />)}
          <text x={x(vals.length - 1) + 6} y={y(vals[vals.length - 1]) + 4} fontSize={11} fontWeight={600} fill={colors[si]}>{t}</text>
        </g>)}
      </svg>
      <div className="flex gap-3 text-[11px]" style={{ color: T.sub }}>
        {Object.keys(series).map((t, i) => <span key={t}><span className="inline-block w-2 h-2 rounded-full mr-1.5 align-middle" style={{ background: colors[i] }} />{t}</span>)}
        <span className="ml-auto" style={{ color: T.ter }}>{tr("Garis putus: batas 35 / 65")}</span>
      </div>
    </div>
  );
}

function Tabs({ value, onChange }: { value: SimTicker; onChange: (t: SimTicker) => void }) {
  return <div className="inline-flex rounded-[6px] p-0.5" style={{ background: T.inner, border: `1px solid ${T.line}` }}>
    {TICKERS.map((t) => <button key={t} onClick={() => onChange(t)} className="h-7 px-3 rounded-[4px] text-[12px] font-semibold transition-colors"
      style={{ background: value === t ? T.card : "transparent", color: value === t ? T.text : T.sub, border: value === t ? `1px solid ${T.line}` : "1px solid transparent" }}>{t}</button>)}
  </div>;
}

/* ─── Page ──────────────────────────────────────── */
export default function SimulasiPage() {
  const [stage, setStage] = useState(0);
  const [prog, setProg] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [tab, setTab] = useState<SimTicker>("BBRI");
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [verified, setVerified] = useState<Record<string, boolean>>({});
  const [manual, setManual] = useState<Record<string, string>>({});
  const [computed, setComputed] = useState(false);
  const [confirm, setConfirm] = useState(false);
  const [trapOpen, setTrapOpen] = useState(false);
  const [endYear, setEndYear] = useState(2024);
  const [n, setN] = useState(5);
  const tid = useRef(0);

  const toast = (tone: Tone, text: string) => {
    const id = ++tid.current;
    setToasts((l) => [...l.slice(-3), { id, tone, text }]);
    setTimeout(() => setToasts((l) => l.filter((x) => x.id !== id)), 5200);
  };

  const ready = prog >= 100;
  const gate = stage === 3 && !computed;

  // Progress animation inside a stage; autoplay advances except at the verification gate.
  useEffect(() => {
    if (ready) return;
    const h = setInterval(() => setProg((p) => Math.min(100, p + (stage === 0 ? 4 : 2))), 55);
    return () => clearInterval(h);
  }, [stage, ready]);
  useEffect(() => {
    if (!ready) return;
    if (stage !== 3) toast(DONE_MSG[stage][0], tr(DONE_MSG[stage][1]));
    if (!playing || stage >= STAGES.length - 1) return;
    if (gate) { toast("amber", tr("Autoplay dijeda: verifikasi wajib dilakukan pengguna sebelum skor dihitung.")); setPlaying(false); return; }
    const h = setTimeout(() => go(stage + 1), 1400);
    return () => clearTimeout(h);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ready, stage, playing]);

  const go = (s: number) => {
    if (s > 3 && !computed) { toast("red", tr("Tahap terkunci: verifikasi 9 akun dan hitung skor terlebih dahulu.")); setStage(3); setProg(100); return; }
    setStage(Math.max(0, Math.min(STAGES.length - 1, s))); setProg(0);
  };
  const reset = () => { setStage(0); setProg(0); setPlaying(false); setVerified({}); setManual({}); setComputed(false); setToasts([]); };

  return (
    <div className="flex flex-col gap-4">
      <Notice tone="blue" icon={FileWarning}>
        <b>{tr("Mode simulasi.")}</b> {tr("Laporan BBRI & BMRI di sini adalah data ilustratif yang mendekati skala publikasi, bukan laporan resmi. Tidak ada panggilan AI atau backend sungguhan. Skor tetap dihitung oleh engine Mamdani asli.")} ({MODEL_VERSION}).
      </Notice>

      {/* Stepper & controls */}
      <section className="rounded-[10px] p-3 flex flex-col gap-3" style={{ background: T.card, border: `1px solid ${T.line}` }}>
        <div className="flex flex-wrap items-center gap-2">
          <Btn kind="primary" icon={playing ? Pause : Play} onClick={() => setPlaying((p) => !p)} disabled={stage === STAGES.length - 1 && ready}>{playing ? tr("Jeda") : tr("Putar otomatis")}</Btn>
          <Btn icon={SkipForward} onClick={() => go(stage + 1)} disabled={!ready || stage === STAGES.length - 1 || gate}>Tahap berikutnya</Btn>
          <Btn kind="ghost" icon={RotateCcw} onClick={reset}>Ulangi</Btn>
          <span className="ml-auto text-[11px] tnum" style={{ color: T.ter }}>{tr("Tahap")} {stage + 1}/{STAGES.length} · {Math.round(prog)}%</span>
        </div>
        <ol className="flex gap-1.5 overflow-x-auto">
          {STAGES.map((s, i) => {
            const done = i < stage || (i === stage && ready), cur = i === stage, locked = i > 3 && !computed;
            const Icon = locked ? Lock : s.icon;
            return <li key={s.label} className="min-w-[88px] flex-1">
              <button onClick={() => i <= stage || (ready && i === stage + 1) ? go(i) : toast("neutral", tr("Selesaikan tahap sebelumnya terlebih dahulu."))}
                className="w-full text-left rounded-[8px] px-2.5 py-2 transition-colors" style={{ background: cur ? T.inner : "transparent", border: `1px solid ${cur ? T.lineHover : T.line}` }}>
                <div className="flex items-center gap-1.5 text-[11px] font-semibold" style={{ color: cur || done ? T.text : T.ter }}>
                  <Icon size={13} style={{ color: done ? T.green : T.sub }} /><span className="truncate">{tr(s.label)}</span></div>
                <div className="mt-1.5"><Bar pct={i < stage ? 100 : cur ? prog : 0} color={done ? T.green : T.teal} /></div>
              </button>
            </li>;
          })}
        </ol>
      </section>

      {stage === 0 && <StageLibrary prog={prog} />}
      {stage === 1 && <StageTxt prog={prog} tab={tab} setTab={setTab} />}
      {stage === 2 && <StageAi prog={prog} tab={tab} setTab={setTab} />}
      {stage === 3 && <StageVerify tab={tab} setTab={setTab} verified={verified} setVerified={setVerified} manual={manual} setManual={setManual}
        computed={computed} onCompute={() => setConfirm(true)} toast={toast} />}
      {stage === 4 && <StageMamdani prog={prog} tab={tab} setTab={setTab} />}
      {stage === 5 && <StageResult prog={prog} />}
      {stage === 6 && <StageCompare endYear={endYear} setEndYear={setEndYear} n={n} setN={setN} onTrap={() => setTrapOpen(true)} toast={toast} />}

      {confirm && <Modal tone="teal" icon={Calculator} title="Hitung Skor Model?" onClose={() => setConfirm(false)}
        body={tr('Angka yang Anda verifikasi akan dipakai apa adanya oleh engine deterministik. AI tidak terlibat dalam perhitungan. Perubahan angka setelah ini membuat skor berstatus "Perlu dihitung ulang".')}
        actions={<><Btn onClick={() => setConfirm(false)}>Batal</Btn>
          <Btn kind="primary" icon={Calculator} onClick={() => { setConfirm(false); setComputed(true); toast("green", tr(DONE_MSG[3][1])); setStage(4); setProg(0); }}>Ya, hitung skor</Btn></>} />}

      {trapOpen && <Modal tone="red" icon={AlertTriangle} title="Proses dihentikan: tahun laporan tidak cocok" onClose={() => setTrapOpen(false)}
        body={<>
          <p>{TRAP.ticker} FY{TRAP.year}: {tr("AI membaca kolom tahun")} <b>{TRAP.found}</b>, {tr("tetapi dokumen ini terdaftar sebagai")} <b>FY {TRAP.year}</b> ({tr("kolom pertama di TXT adalah tahun pembanding")}).
          </p>
          <p className="mt-2 rounded-[6px] px-3 py-2" style={{ background: T.inner }}>{tr("Tidak ada angka yang diisi. Komparasi hanya valid bila data tiap tahun benar-benar sesuai. Admin perlu mengunggah ulang atau mengoreksi metadata, lalu analisis dijalankan lagi.")}</p>
        </>}
        actions={<Btn onClick={() => setTrapOpen(false)}>Tutup</Btn>} />}

      {/* Toast stack */}
      <div className="fixed bottom-4 right-4 z-[90] flex flex-col gap-2 w-[min(360px,calc(100vw-32px))]" aria-live="polite">
        {toasts.map((t) => {
          const c = t.tone === "neutral" ? T.sub : t.tone === "red" ? T.red : t.tone === "amber" ? T.amber : t.tone === "green" ? T.green : t.tone === "blue" ? T.blue : T.teal;
          const Icon = t.tone === "red" ? XCircle : t.tone === "amber" ? AlertTriangle : t.tone === "green" ? CheckCircle2 : Bell;
          return <div key={t.id} className="toast-in flex items-start gap-2.5 rounded-[8px] px-3 py-2.5 text-[12px] leading-relaxed"
            style={{ background: T.card, border: `1px solid ${alpha(c, 40)}`, boxShadow: "0 6px 20px rgba(0,0,0,0.25)" }}>
            <Icon size={14} className="shrink-0 mt-[2px]" style={{ color: c }} />
            <span className="flex-1">{t.text}</span>
            <button aria-label="Tutup" onClick={() => setToasts((l) => l.filter((x) => x.id !== t.id))} style={{ color: T.ter }}><X size={13} /></button>
          </div>;
        })}
      </div>
    </div>
  );
}

function Modal({ tone, icon: Icon, title, body, actions, onClose }: { tone: "teal" | "red"; icon: typeof Info; title: string; body: ReactNode; actions: ReactNode; onClose: () => void }) {
  const c = tone === "red" ? T.red : T.teal;
  return <div className="fixed inset-0 z-[100] flex items-center justify-center p-4" style={{ background: "rgba(0,0,0,0.66)" }}>
    <div role="alertdialog" aria-modal="true" className="w-full max-w-[480px] rounded-[10px] p-5 flex flex-col gap-3" style={{ background: T.card, border: `1px solid ${c}` }}>
      <div className="flex items-start gap-3">
        <Icon size={20} className="shrink-0 mt-0.5" style={{ color: c }} />
        <div className="flex-1 min-w-0"><h2 className="text-[14px] font-semibold">{tr(title)}</h2>
          <div className="text-[12px] mt-1 leading-relaxed" style={{ color: T.sub }}>{body}</div></div>
        <button onClick={onClose} aria-label="Tutup" className="p-1" style={{ color: T.ter }}><X size={16} /></button>
      </div>
      <div className="flex flex-wrap gap-2 justify-end">{actions}</div>
    </div>
  </div>;
}

/* ─── Stage 1: library ──────────────────────────── */
function StageLibrary({ prog }: { prog: number }) {
  return (
    <div className="grid grid-cols-1 xl:grid-cols-[minmax(0,1fr)_320px] gap-4 items-start">
      <Panel title="Koleksi Laporan · Folder Laporan" icon={Library} right={<Badge tone="neutral">{SIM_DOCS.length} PDF</Badge>}>
        <div className="flex flex-col gap-4">
          {TICKERS.map((t) => (
            <div key={t}>
              <div className="flex items-baseline gap-2 mb-2"><span className="text-[13px] font-semibold">{t}</span><span className="text-[11px]" style={{ color: T.ter }}>{SIM_BANKS[t].name}</span></div>
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
                {SIM_DOCS.filter((d) => d.ticker === t).map((d) => {
                  const sel = PICK.some((p) => p.ticker === t && p.year === d.year);
                  return <div key={d.id} className="rounded-[8px] p-2.5 transition-colors" style={{ background: sel ? T.tealMuted : T.inner, border: `1px solid ${sel ? T.tealBorder : T.line}` }}>
                    <div className="flex items-center justify-between"><span className="text-[13px] font-semibold tnum">FY{d.year}</span>
                      {sel ? <CheckCircle2 size={13} style={{ color: T.teal }} /> : d.trap ? <AlertTriangle size={13} style={{ color: T.amber }} /> : null}</div>
                    <div className="text-[10.5px] mt-1 truncate" style={{ color: T.ter }}>{d.pages} {tr("Hlm")} · {d.sizeMb} MB</div>
                    {d.trap && <div className="mt-1"><Badge tone="amber">Cek tahun</Badge></div>}
                  </div>;
                })}
              </div>
            </div>
          ))}
        </div>
      </Panel>
      <Panel title="Menarik laporan" icon={ShieldCheck}>
        <div className="flex flex-col gap-3">
          {PICK.map((p, i) => <div key={p.ticker}>
            <div className="flex justify-between text-[12px] mb-1"><span>{p.ticker}_LK_Konsolidasian_FY{p.year}.pdf</span><span className="tnum" style={{ color: T.ter }}>{Math.round(Math.min(100, Math.max(0, prog * 2 - i * 60)))}%</span></div>
            <Bar pct={prog * 2 - i * 60} />
          </div>)}
          <StepLine done={prog > 30} active={prog <= 30}>{tr("Membaca berkas dari IndexedDB (ssi-files)")}</StepLine>
          <StepLine done={prog > 70} active={prog > 30 && prog <= 70}>{tr("Memeriksa sektor: bank umum konvensional (G Financials)")}</StepLine>
          <StepLine done={prog >= 100} active={prog > 70 && prog < 100}>{tr("Membuat salinan kerja milik pengguna")}</StepLine>
          <Notice icon={Info}>Pengguna hanya menarik laporan yang sudah diunggah admin. Unggah dan hapus laporan khusus admin.</Notice>
        </div>
      </Panel>
    </div>
  );
}

/* ─── Stage 2: PDF → TXT ───────────────────────── */
function StageTxt({ prog, tab, setTab }: { prog: number; tab: SimTicker; setTab: (t: SimTicker) => void }) {
  const pages = simTxt(tab, 2024);
  const all = pages.flatMap((p) => [`=== HALAMAN ${p.page} · ${p.title} ===`, ...p.lines, ""]);
  const shown = Math.ceil((all.length * prog) / 100);
  const chars = all.join("\n").length;
  const doc = SIM_DOCS.find((d) => d.id === `${tab}-2024`)!;
  return (
    <div className="grid grid-cols-1 xl:grid-cols-[320px_minmax(0,1fr)] gap-4 items-start">
      <div className="flex flex-col gap-4">
        <Panel title="Konversi pdf.js" icon={FileText} right={<Tabs value={tab} onChange={setTab} />}>
          <div className="flex flex-col gap-3">
            <div className="grid grid-cols-2 gap-2">
              <Stat label="Halaman dibaca" value={<span className="tnum">{Math.round((doc.pages * prog) / 100)}/{doc.pages}</span>} />
              <Stat label="Karakter TXT" value={<span className="tnum">{idr(Math.round(chars * 41 * prog / 100))}</span>} />
              <Stat label="Halaman laporan" value={prog > 60 ? "2" : "…"} sub="dikirim ke AI" />
              <Stat label="Estimasi token" value={<span className="tnum">{prog > 60 ? idr(Math.round(chars / 4)) : "…"}</span>} sub="panjang / 4" />
            </div>
            <Bar pct={prog} />
            <StepLine done={prog > 35} active={prog <= 35}>{tr("Ekstraksi teks per halaman (lapisan teks, bukan OCR)")}</StepLine>
            <StepLine done={prog > 60} active={prog > 35 && prog <= 60}>{tr("Mencari judul laporan yang diizinkan")}</StepLine>
            <StepLine done={prog > 85} active={prog > 60 && prog <= 85}>{tr("Deteksi satuan: jutaan Rupiah · tahun:")} {tab === TRAP.ticker ? "2024, 2023" : "2024, 2023"}</StepLine>
            <div className="flex flex-wrap gap-1.5">
              <Badge tone={prog > 60 ? "green" : "neutral"}>{tr("Laba Rugi · hlm")} {pages[1].page}</Badge>
              <Badge tone={prog > 60 ? "green" : "neutral"}>{tr("Posisi Keuangan · hlm")} {pages[0].page}</Badge>
              <Badge tone="red">Arus Kas · dilarang</Badge>
              <Badge tone="red">Catatan · dilarang</Badge>
            </div>
          </div>
        </Panel>
        <Notice tone="amber" icon={AlertTriangle}>Konversi ke TXT dapat menghilangkan tata letak tabel. Kolom dipisah tanda &quot;|&quot;. PDF hasil scan (rata-rata &lt; 40 karakter/halaman) ditolak karena DeepSeek hanya membaca teks.</Notice>
      </div>
      <Panel title={`TXT · ${doc.file.replace(".pdf", ".txt")}`} icon={FileText} right={<Badge tone="amber">angka disorot</Badge>} pad={false}>
        <pre className="text-[11.5px] leading-[1.7] p-4 overflow-x-auto max-h-[460px]" style={{ ...mono, color: T.sub, background: T.inner }}>
          {all.slice(0, shown).map((l, i) => <div key={i} style={{ color: l.startsWith("===") ? T.text : undefined }}><Highlight text={l} /></div>)}
          {prog < 100 && <span className="animate-pulse" style={{ color: T.teal }}>▍</span>}
        </pre>
      </Panel>
    </div>
  );
}

/* ─── Stage 3: DeepSeek ────────────────────────── */
function StageAi({ prog, tab, setTab }: { prog: number; tab: SimTicker; setTab: (t: SimTicker) => void }) {
  const { proposals, dropped } = simExtraction(tab, 2024);
  const shown = Math.floor((proposals.length * Math.min(prog, 80)) / 80);
  const tokens = Math.round(simTxt(tab, 2024).flatMap((p) => p.lines).join("\n").length / 4) + 610;
  return (
    <div className="grid grid-cols-1 xl:grid-cols-[320px_minmax(0,1fr)] gap-4 items-start">
      <div className="flex flex-col gap-4">
        <Panel title="Permintaan AI" icon={Server} right={<Tabs value={tab} onChange={setTab} />}>
          <div className="flex flex-col gap-2 text-[12px]">
            <div className="flex items-center gap-2 rounded-[6px] px-2.5 py-2" style={{ background: T.inner, border: `1px solid ${T.line}` }}>
              <Lock size={13} style={{ color: T.green }} /><span className="font-semibold">DeepSeek</span><span style={{ color: T.ter }}>· {tr("dikelola di server · key tersembunyi")}</span>
            </div>
            {[["Endpoint", "POST /api/ai-extract (server)"], ["Model", "deepseek-chat"], ["Mode", "teks saja, JSON"], ["Temperature", "0"], ["Token masuk", idr(tokens)], ["Token keluar", prog > 80 ? "412" : "…"], ["API key", "tidak pernah dikirim ke browser"]].map(([k, v]) =>
              <div key={k} className="flex justify-between gap-3"><span style={{ color: T.ter }}>{tr(k)}</span><span className="text-right tnum" style={mono}>{tr(v)}</span></div>)}
            <div className="mt-1"><Bar pct={prog} /></div>
            <StepLine done={prog > 10} active={prog <= 10}>{tr("Mengirim TXT 2 halaman ke proxy server")}</StepLine>
            <StepLine done={prog > 80} active={prog > 10 && prog <= 80}>{tr("DeepSeek membaca teks dan mengusulkan angka")}</StepLine>
            <StepLine done={prog >= 100} active={prog > 80 && prog < 100}>{tr("Validasi: angka harus muncul di halaman · kolom tahun = FY")}</StepLine>
          </div>
        </Panel>
        <Notice tone="blue" icon={Info}>AI hanya mengusulkan angka. AI tidak menghitung rasio atau skor dan tidak melihat gambar, grafik, atau tanda tangan di PDF.</Notice>
      </div>
      <div className="flex flex-col gap-4">
        <Panel title="Usulan akun" icon={Cpu} right={<span className="text-[11px] tnum" style={{ color: T.ter }}>{shown}/{proposals.length}</span>} pad={false}>
          <Table cols="minmax(160px,1.4fr) minmax(130px,1fr) 90px 60px 70px" head={["Akun", "Nilai (Rp juta)", "Sumber", "Hlm", "Conf."]} minWidth={560}>
            {proposals.slice(0, shown).map((p) => <div key={p.account} className="toast-in"><Row cols="minmax(160px,1.4fr) minmax(130px,1fr) 90px 60px 70px">
              <span className="truncate">{tr(CANONICAL_ACCOUNTS[p.account].labelId)}</span>
              <span className="tnum" style={mono}>{p.value == null ? <span style={{ color: T.amber }}>{tr("tidak ditemukan")}</span> : idr(p.value)}</span>
              <span>{p.source === "rule" ? <Badge>Rule</Badge> : p.source === "deepseek" ? <Badge tone="blue">DeepSeek</Badge> : <Badge tone="amber">Manual</Badge>}</span>
              <span className="tnum">{p.page}</span>
              <span className="tnum" style={{ color: p.confidence ? T.text : T.ter }}>{p.confidence ? `${Math.round(p.confidence * 100)}%` : "—"}</span>
            </Row></div>)}
            {prog < 80 && <div className="px-4 py-3 text-[12px] animate-pulse" style={{ color: T.ter }}>{tr("Menunggu respons…")}</div>}
          </Table>
        </Panel>
        {prog >= 90 && <>
          {dropped.map((d) => <Notice key={d.account} tone="red" icon={XCircle}><b>{tr("Ditolak validator:")}</b> {tr(CANONICAL_ACCOUNTS[d.account].labelId)} = {idr(d.value)}. {tr(d.reason)}</Notice>)}
          <Notice tone="green" icon={CheckCircle2}>Cek tahun lolos: columnYear 2024 = FY 2024 terdaftar.</Notice>
          <Notice tone="amber" icon={AlertTriangle}>Dana Pihak Ketiga tidak ditemukan sebagai satu baris. Wajib diisi manual di tahap verifikasi. Harga saham untuk PER juga input manual (data pasar eksternal).</Notice>
        </>}
      </div>
    </div>
  );
}

/* ─── Stage 4: verification dialog ─────────────── */
function StageVerify({ tab, setTab, verified, setVerified, manual, setManual, computed, onCompute, toast }: {
  tab: SimTicker; setTab: (t: SimTicker) => void; verified: Record<string, boolean>; setVerified: (v: Record<string, boolean>) => void;
  manual: Record<string, string>; setManual: (v: Record<string, string>) => void; computed: boolean; onCompute: () => void; toast: (tone: Tone, t: string) => void;
}) {
  const { proposals } = simExtraction(tab, 2024);
  const acc = simAccounts(tab, 2024);
  const key = (id: string, t: SimTicker = tab) => `${t}:${id}`;
  const rowsOk = (t: SimTicker) => simExtraction(t, 2024).proposals.every((p) => verified[key(p.account, t)])
    && !!manual[key("third_party_funds", t)] && !!manual[key("share_price", t)] && verified[key("share_price", t)];
  const allOk = TICKERS.every(rowsOk);
  const fillDpk = () => {
    setManual({ ...manual, [key("third_party_funds")]: String(acc.third_party_funds) });
    toast("neutral", `${tr("DPK")} ${tab} = ${tr("Giro + Tabungan + Deposito dari halaman")} ${proposals[8].page}.`);
  };
  const verifyAll = () => {
    const v = { ...verified };
    proposals.forEach((p) => { if (p.value != null || manual[key(p.account)]) v[key(p.account)] = true; });
    if (manual[key("share_price")]) v[key("share_price")] = true;
    setVerified(v);
  };
  const cols = "28px minmax(170px,1.3fr) minmax(150px,1fr) 100px 54px";
  return (
    <div className="grid grid-cols-1 xl:grid-cols-[minmax(0,1fr)_300px] gap-4 items-start">
      <Panel title={`Dialog 9 Akun · ${tab} FY2024`} icon={ClipboardCheck} right={<Tabs value={tab} onChange={setTab} />} pad={false}>
        <Table cols={cols} head={["", "Akun", "Nilai (Rp juta)", "Sumber", "Hlm"]} minWidth={560}>
          {proposals.map((p) => {
            const k = key(p.account), isManual = p.value == null;
            const val = isManual ? manual[k] ?? "" : String(p.value);
            return <Row key={k} cols={cols}>
              <input type="checkbox" aria-label={`${tr("Verifikasi")} ${tr(CANONICAL_ACCOUNTS[p.account].labelId)}`} disabled={computed || (isManual && !val)} checked={!!verified[k]}
                onChange={(e) => setVerified({ ...verified, [k]: e.target.checked })} className="accent-[var(--c-teal)]" />
              <span className="min-w-0"><span className="block truncate">{tr(CANONICAL_ACCOUNTS[p.account].labelId)}</span>
                <span className="text-[10.5px]" style={{ color: T.ter }}>{tr(CANONICAL_ACCOUNTS[p.account].statement === "profit_loss" ? "Laba Rugi" : "Posisi Keuangan")}</span></span>
              {isManual
                ? <div className="flex gap-1.5"><input className={inputCls + " h-8 tnum"} style={{ ...inputStyle, borderColor: val ? T.input : T.amber }} placeholder={tr("Isi manual")} value={val} disabled={computed}
                    onChange={(e) => setManual({ ...manual, [k]: e.target.value.replace(/\D/g, "") })} />
                    {!val && <Btn kind="ghost" onClick={fillDpk}>Jumlahkan</Btn>}</div>
                : <span className="tnum" style={mono}>{idr(p.value!)}</span>}
              <span>{p.source === "rule" ? <Badge>Rule</Badge> : p.source === "deepseek" ? <Badge tone="blue">DeepSeek</Badge> : <Badge tone="amber">Manual</Badge>}</span>
              <span className="tnum">{p.page}</span>
            </Row>;
          })}
          <Row cols={cols}>
            <input type="checkbox" aria-label="Verifikasi harga saham" disabled={computed || !manual[key("share_price")]} checked={!!verified[key("share_price")]}
              onChange={(e) => setVerified({ ...verified, [key("share_price")]: e.target.checked })} className="accent-[var(--c-teal)]" />
            <span><span className="block">{tr("Harga saham (PER)")}</span><span className="text-[10.5px]" style={{ color: T.ter }}>{tr("Input eksternal, bukan dari laporan")}</span></span>
            <div className="flex gap-1.5"><input className={inputCls + " h-8 tnum"} style={inputStyle} placeholder={tr("Rp per lembar")} disabled={computed} value={manual[key("share_price")] ?? ""}
              onChange={(e) => setManual({ ...manual, [key("share_price")]: e.target.value.replace(/\D/g, "") })} />
              {!manual[key("share_price")] && <Btn kind="ghost" onClick={() => setManual({ ...manual, [key("share_price")]: String(simPrice(tab, 2024)) })}>Penutupan 30/12</Btn>}</div>
            <Badge tone="amber">Manual</Badge><span>—</span>
          </Row>
        </Table>
        <div className="flex flex-wrap items-center gap-2 p-3">
          <Btn icon={CheckCircle2} onClick={verifyAll} disabled={computed}>{tr("Tandai semua terverifikasi")} ({tab})</Btn>
          <span className="text-[11px]" style={{ color: T.ter }}>{tr("Cocokkan tiap angka dengan TXT/halaman sumber sebelum dicentang.")}</span>
        </div>
      </Panel>
      <div className="flex flex-col gap-3">
        <Panel title="Status verifikasi" icon={ShieldCheck}>
          <div className="flex flex-col gap-2.5">
            {TICKERS.map((t) => {
              const n = simExtraction(t, 2024).proposals.filter((p) => verified[key(p.account, t)]).length + (verified[key("share_price", t)] ? 1 : 0);
              return <div key={t}><div className="flex justify-between text-[12px] mb-1"><span className="font-semibold">{t}</span><span className="tnum">{n}/10</span></div>
                <Bar pct={n * 10} color={n === 10 ? T.green : T.amber} /></div>;
            })}
            <Btn kind="primary" icon={Calculator} disabled={!allOk || computed} onClick={onCompute}>{computed ? "Skor sudah dihitung" : "Hitung Skor Model"}</Btn>
          </div>
        </Panel>
        {!allOk && <Notice tone="amber" icon={Lock}>Skor terkunci sampai 9 akun + harga saham kedua emiten terverifikasi.</Notice>}
        <Notice icon={Info}>Pemeriksaan konsistensi: Jumlah Beban Operasional &lt; Jumlah Pendapatan Operasional, Kredit &lt; Jumlah Aset. Tidak ada peringatan.</Notice>
      </div>
    </div>
  );
}

/* ─── Stage 5: Mamdani ─────────────────────────── */
function StageMamdani({ prog, tab, setTab }: { prog: number; tab: SimTicker; setTab: (t: SimTicker) => void }) {
  const res = useMemo(() => simScore(tab, 2024), [tab]);
  const fired = res.strengths.map((s, i) => ({ s, i })).filter((r) => r.s > 0).sort((a, b) => b.s - a.s);
  const k = Math.min(1, prog / 70);
  return (
    <div className="flex flex-col gap-4">
      <Panel title={`1 · ${tr("Fuzzifikasi 9 rasio")} · ${tab} FY2024`} icon={Sigma} right={<Tabs value={tab} onChange={setTab} />}>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
          {VAR_KEYS.map((v, i) => <div key={v} className="transition-opacity duration-500" style={{ opacity: prog > i * 6 ? 1 : 0.15 }}>
            <MembershipChart k={v} v={res.ratios[v]} /><div className="text-[10.5px] mt-1 px-1 truncate" style={{ color: T.ter }}>{RATIO_DEFINITIONS[v].formula}</div></div>)}
        </div>
      </Panel>
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4 items-start">
        <Panel title={`2 · ${tr("Inferensi (implikasi min)")}`} icon={Cpu} right={<Badge tone="teal">{fired.length}/{RULE_COUNT} {tr("rule aktif")}</Badge>}>
          <div className="flex flex-col gap-2">
            {fired.map(({ s, i }) => <div key={i} className="grid grid-cols-[38px_minmax(0,1fr)_44px] items-center gap-2 text-[12px]">
              <span className="tnum font-semibold" style={{ color: T.ter }}>{ruleId(i)}</span>
              <div className="min-w-0"><div className="truncate">{trTerms(RULES[i].text)}</div><div className="mt-1"><Bar pct={s * 100 * k} color={OUT[RULES[i].out].color} /></div></div>
              <span className="tnum text-right">{fmtNum(s * k)}</span>
            </div>)}
            <p className="text-[11px] mt-1" style={{ color: T.ter }}>{RULE_COUNT - fired.length} {tr("rule lain bernilai 0 (salah satu anteseden tidak aktif).")}</p>
          </div>
        </Panel>
        <Panel title={`3 · ${tr("Agregasi (max) & defuzzifikasi centroid")}`} icon={Gauge}>
          <OutputChart agg={res.agg.map((m) => m * k)} score={prog >= 70 ? res.score : 0} />
          <div className="grid grid-cols-1 min-[420px]:grid-cols-3 gap-2 mt-3">
            {OUT.map((o, i) => <Stat key={o.name} label={`α ${tr(o.name)}`} value={<span className="tnum" style={{ color: o.color }}>{fmtNum(res.classStrength[i] * k)}</span>} />)}
          </div>
          <p className="text-[11px] mt-3" style={{ ...mono, color: T.ter }}>z* = Σ z·μ(z) / Σ μ(z) = {prog >= 70 ? fmtNum(res.score) : "…"}</p>
        </Panel>
      </div>
    </div>
  );
}

/* ─── Stage 6: results ─────────────────────────── */
function StageResult({ prog }: { prog: number }) {
  const res = TICKERS.map((t) => ({ t, ...simScore(t, 2024) }));
  const k = Math.min(1, prog / 60);
  return (
    <div className="flex flex-col gap-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {res.map((r) => {
          const cat = categoryOf(r.score);
          return <Panel key={r.t} title={`${r.t} · ${SIM_BANKS[r.t].short} · FY2024`} icon={Gauge} right={<CategoryBadge cat={cat} />}>
            <div className="flex flex-col sm:flex-row items-center gap-4">
              <ScoreGauge score={r.score * k} width={210} />
              <div className="flex-1 grid grid-cols-2 gap-2 w-full">
                <Stat label="Skor Model" value={<span className="tnum">{fmtNum(r.score * k)}</span>} accent sub="skala 0–100" />
                <Stat label="Tingkat" value={<span style={{ color: CATEGORY_COLOR[cat] }}>{tr(LEVEL[cat])}</span>} sub={cat} />
                <Stat label="Rule aktif" value={<span className="tnum">{r.strengths.filter((s) => s > 0).length}/{RULE_COUNT}</span>} />
                <Stat label="Model" value={<span className="text-[13px]">{MODEL_VERSION}</span>} />
              </div>
            </div>
          </Panel>;
        })}
      </div>
      <Panel title="Rasio & tingkat (Rendah / Sedang / Tinggi)" icon={Sigma} pad={false}>
        <Table cols="70px minmax(150px,1fr) minmax(170px,1.4fr) minmax(170px,1.4fr)" head={["Rasio", "Nama", "BBRI", "BMRI"]} minWidth={640}>
          {VAR_KEYS.map((v) => {
            const d = VAR_DEFS[v];
            return <Row key={v} cols="70px minmax(150px,1fr) minmax(170px,1.4fr) minmax(170px,1.4fr)">
              <span className="font-semibold">{v}</span><span className="truncate" style={{ color: T.sub }}>{d.label}</span>
              {res.map((r) => {
                const val = r.ratios[v], dom = dominantSet(v, val), set = d.sets.find((s) => s.name === dom.name);
                return <div key={r.t} className="grid grid-cols-[64px_minmax(0,1fr)_64px] items-center gap-2">
                  <span className="tnum">{fmtNum(val)}{d.unit}</span>
                  <Bar pct={((val - d.domain[0]) / (d.domain[1] - d.domain[0])) * 100 * k} color={set?.color ?? T.sub} />
                  <span className="text-[11px] font-semibold" style={{ color: set?.color ?? T.ter }}>{tr(dom.name)}</span>
                </div>;
              })}
            </Row>;
          })}
        </Table>
      </Panel>
      <Notice tone="amber" icon={AlertTriangle}>Skor Model adalah hasil model akademik atas rasio keuangan, bukan rekomendasi beli/jual. Data pasar hanya konteks dan tidak masuk ke model. Keputusan investasi sepenuhnya tanggung jawab pengguna.</Notice>
    </div>
  );
}

/* ─── Stage 7: comparison ──────────────────────── */
function StageCompare({ endYear, setEndYear, n, setN, onTrap, toast }: {
  endYear: number; setEndYear: (y: number) => void; n: number; setN: (n: number) => void; onTrap: () => void; toast: (tone: Tone, t: string) => void;
}) {
  // BMRI FY2025 is frozen by the year mismatch, so it never becomes an analysis.
  const maps = useMemo(() => Object.fromEntries(TICKERS.map((t) => [t, new Map(simYears(t)
    .filter((y) => !(t === TRAP.ticker && y === TRAP.year)).map((y) => [y, {} as AnalysisRecord]))])), []);
  const check = validateComparison(maps, TICKERS, endYear, n);
  const reasons = check.perTicker.filter((p) => p.missing.length).map((p) =>
    `${p.ticker}: ${p.have.length} ${tr("dari")} ${n} ${tr("tahun tersedia, belum ada FY")} ${p.missing.join(", ")}`);
  const prev = useRef("");
  useEffect(() => {
    const sig = `${endYear}-${n}-${check.ok}`;
    if (prev.current && prev.current !== sig) toast(check.ok ? "green" : "red", check.ok ? `${tr("Apple-to-apple")}: ${check.window[0]}–${endYear} ${tr("lengkap untuk kedua emiten.")}` : `${tr("Komparasi diblokir:")} ${reasons.join("; ")}.`);
    prev.current = sig;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [endYear, n]);
  const series = Object.fromEntries(TICKERS.map((t) => [t, check.window.map((y) => maps[t].has(y) ? simScore(t, y).score : 0)]));
  const latest = TICKERS.map((t) => ({ t, s: simScore(t, endYear).score })).sort((a, b) => b.s - a.s);
  return (
    <div className="flex flex-col gap-4">
      <Panel title="Jendela komparasi BBRI vs BMRI" icon={GitCompare} right={check.ok ? <Badge tone="green">Apple-to-apple</Badge> : <Badge tone="red">Belum sebanding</Badge>}>
        <div className="flex flex-wrap items-end gap-3">
          <label className="flex flex-col gap-1 text-[11px]" style={{ color: T.sub }}>{tr("Tahun akhir")}
            <Select value={String(endYear)} onChange={(v) => setEndYear(+v)} className="w-28">{[2025, 2024, 2023].map((y) => <option key={y}>{y}</option>)}</Select></label>
          <label className="flex flex-col gap-1 text-[11px]" style={{ color: T.sub }}>{tr("Jumlah tahun (N)")}
            <Select value={String(n)} onChange={(v) => setN(+v)} className="w-28">{Array.from({ length: 5 }, (_, i) => i + MIN_YEARS).map((x) => <option key={x} value={x}>{x} {tr("tahun")}</option>)}</Select></label>
          <span className="text-[12px] tnum" style={{ color: T.sub }}>{tr("Jendela: FY")} {check.window[0]}–{check.window[check.window.length - 1]}</span>
          <Btn kind="danger" icon={AlertTriangle} className="ml-auto" onClick={onTrap}>Coba tarik BMRI FY2025</Btn>
        </div>
        <div className="mt-3 overflow-x-auto">
          <div className="grid gap-1 min-w-[420px]" style={{ gridTemplateColumns: `60px repeat(${check.window.length}, minmax(48px,1fr))` }}>
            <span />{check.window.map((y) => <span key={y} className="text-[10.5px] text-center tnum" style={{ color: T.ter }}>{y}</span>)}
            {check.perTicker.map((p) => <Fragment key={p.ticker}>
              <span className="text-[12px] font-semibold">{p.ticker}</span>
              {check.window.map((y) => {
                const ok = p.have.includes(y), trap = p.ticker === TRAP.ticker && y === TRAP.year;
                return <span key={p.ticker + y} title={tr(trap ? "Dibekukan: tahun tidak cocok" : ok ? "Tersedia" : "Tidak ada laporan")} className="h-7 rounded-[4px] flex items-center justify-center"
                  style={{ background: ok ? alpha(T.green, 14) : alpha(T.red, 12), border: `1px solid ${ok ? alpha(T.green, 30) : alpha(T.red, 30)}` }}>
                  {ok ? <CheckCircle2 size={12} style={{ color: T.green }} /> : trap ? <Lock size={12} style={{ color: T.red }} /> : <X size={12} style={{ color: T.red }} />}
                </span>;
              })}
            </Fragment>)}
          </div>
        </div>
      </Panel>
      <YearDisclaimer />
      {!check.ok ? (
        <>
          <Notice tone="red" icon={Ban}><b>{tr("Skor dan ranking disembunyikan.")}</b> {tr("Tidak apple-to-apple:")} {reasons.join("; ")}. {tr('Tidak ada fallback "tahun yang sama saja". Pilih jendela yang lengkap untuk kedua emiten.')}</Notice>
          <Panel title="Ranking" icon={Lock}><div className="py-8 text-center text-[12px]" style={{ color: T.ter }}>{tr("Terkunci sampai jendela tahun identik dan lengkap.")}</div></Panel>
        </>
      ) : (
        <div className="grid grid-cols-1 xl:grid-cols-[minmax(0,1fr)_320px] gap-4 items-start">
          <Panel title={`${tr("Tren Skor Model FY")} ${check.window[0]}–${endYear}`} icon={Gauge}><TrendChart series={series} window={check.window} /></Panel>
          <Panel title={`Ranking FY${endYear}`} icon={GitCompare}>
            <div className="flex flex-col gap-2">
              {latest.map((r, i) => { const cat = categoryOf(r.s); return (
                <div key={r.t} className="flex items-center gap-3 rounded-[8px] px-3 py-2.5" style={{ background: T.inner, border: `1px solid ${T.line}` }}>
                  <span className="text-[18px] font-semibold tnum w-6" style={{ color: T.ter }}>{i + 1}</span>
                  <div className="flex-1 min-w-0"><div className="text-[13px] font-semibold">{r.t}</div><div className="text-[11px]" style={{ color: T.ter }}>{SIM_BANKS[r.t].short}</div></div>
                  <div className="text-right"><div className="text-[18px] font-semibold tnum" style={{ color: T.teal }}>{fmtNum(r.s)}</div><CategoryBadge cat={cat} /></div>
                </div>); })}
              <p className="text-[11px]" style={{ color: T.ter }}>{tr("Rata-rata")} {check.window.length} {tr("tahun")}: {TICKERS.map((t) => `${t} ${fmtNum(series[t].reduce((a, b) => a + b, 0) / series[t].length)}`).join(" · ")}</p>
            </div>
          </Panel>
        </div>
      )}
    </div>
  );
}
