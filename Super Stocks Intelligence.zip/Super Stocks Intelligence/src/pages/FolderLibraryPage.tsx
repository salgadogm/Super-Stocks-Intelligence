// Koleksi Laporan as folders: emiten → tahun → dokumen. Gaps between a bank's first and last year are shown as
// empty folders so completeness is visible before anyone tries to compare several years.
import { useMemo, useState } from "react";
import { ChevronRight, Folder, FolderOpen, FolderX, Library, Trash2, Upload, Calculator, AlertTriangle, Info } from "lucide-react";
import { useWorkspace, type DocRecord } from "../domain/store";
import { isMonthly, monthName, monthOf } from "../domain/financial";
import { canManageCollection, getRole } from "../domain/news";
import { useT } from "../i18n";
import { usePull, YearMismatchDialog } from "../components/PullFlow";
import { YearDisclaimer } from "../components/YearDisclaimer";
import { PullProgress } from "./CollectionsPages";
import { T, Panel, Btn, Badge, EmptyState, Notice, ANALYSIS_META, fmtDate } from "../ui";

type Nav = (p: string) => void;
type Bank = { ticker: string; name: string; years: number[]; byYear: Map<number, DocRecord[]>; missing: number[] };

export default function FolderLibraryPage({ onNavigate, user }: { onNavigate: Nav; user?: string }) {
  const { t } = useT();
  const ws = useWorkspace();
  const admin = canManageCollection(getRole());
  const { pulling, pullError, mismatch, closeMismatch, run } = usePull(onNavigate, user || "user");
  const [open, setOpen] = useState<string | null>(null);
  const [picked, setPicked] = useState<number[]>([]);
  const [confirmDel, setConfirmDel] = useState<string | null>(null);

  const banks = useMemo<Bank[]>(() => {
    const m = new Map<string, Bank>();
    for (const d of ws.documents) {
      const b = m.get(d.ticker) ?? { ticker: d.ticker, name: d.companyName, years: [], byYear: new Map(), missing: [] };
      b.byYear.set(d.period.fiscalYear, [...(b.byYear.get(d.period.fiscalYear) ?? []), d]);
      m.set(d.ticker, b);
    }
    return [...m.values()].map((b) => {
      b.years = [...b.byYear.keys()].sort((a, c) => a - c);
      const lo = b.years[0], hi = b.years[b.years.length - 1];
      b.missing = Array.from({ length: hi - lo + 1 }, (_, i) => lo + i).filter((y) => !b.byYear.has(y));
      return b;
    }).sort((a, b) => a.ticker.localeCompare(b.ticker));
  }, [ws.documents]);

  const bank = banks.find((b) => b.ticker === open);
  const goBank = (tk: string | null) => { setOpen(tk); setPicked([]); setConfirmDel(null); };

  const sortedPick = [...picked].sort((a, b) => a - b);
  const gaps = sortedPick.length > 1 ? Array.from({ length: sortedPick[sortedPick.length - 1] - sortedPick[0] + 1 }, (_, i) => sortedPick[0] + i).filter((y) => !sortedPick.includes(y)) : [];
  const pickOk = sortedPick.length >= 2 && gaps.length === 0;

  if (ws.documents.length === 0) {
    return (
      <Panel><EmptyState icon={Library} title="Folder laporan masih kosong"
        why={admin ? "Belum ada laporan. Unggah laporan beberapa tahun per emiten; folder emiten dan tahun terbentuk otomatis." : "Belum ada laporan di koleksi. Admin akan menambahkan laporan keuangan secara berkala."}
        action={admin ? <Btn kind="primary" icon={Upload} onClick={() => onNavigate("Upload Laporan")}>Upload Laporan</Btn> : undefined} /></Panel>
    );
  }

  return (
    <div className="flex flex-col gap-4">
      {pullError && <Notice tone="red" icon={AlertTriangle}>{pullError}</Notice>}
      {mismatch && <YearMismatchDialog doc={mismatch.doc} err={mismatch.err} onClose={closeMismatch} onNavigate={onNavigate} />}
      <YearDisclaimer />

      <nav aria-label="breadcrumb" className="flex items-center gap-1.5 text-[12px]" style={{ color: T.sub }}>
        <button onClick={() => goBank(null)} className="hover:underline" style={{ color: bank ? T.teal : T.text }}>{t("Koleksi")}</button>
        {bank && <><ChevronRight size={12} style={{ color: T.ter }} /><span className="font-semibold" style={{ color: T.text }}>{bank.ticker}</span></>}
      </nav>

      {!bank ? (
        <div className="grid gap-3 grid-cols-1 sm:grid-cols-2 xl:grid-cols-3">
          {banks.map((b) => {
            const span = b.years[b.years.length - 1] - b.years[0] + 1;
            const complete = b.missing.length === 0;
            return (
              <button key={b.ticker} onClick={() => goBank(b.ticker)} className="text-left rounded-[6px] p-4 flex flex-col gap-3 transition-colors"
                style={{ background: T.card, border: `1px solid ${complete ? T.line : T.amber}` }}>
                <div className="flex items-start gap-3">
                  <Folder size={22} style={{ color: T.teal }} className="shrink-0" />
                  <div className="min-w-0 flex-1">
                    <div className="text-[14px] font-semibold">{b.ticker}</div>
                    <div className="text-[11.5px] truncate" style={{ color: T.ter }}>{b.name}</div>
                  </div>
                  <Badge tone={complete ? "green" : "amber"}>{b.years.length}/{span} {t("tahun")}</Badge>
                </div>
                <div className="text-[11.5px] tnum" style={{ color: T.sub }}>
                  FY {b.years[0]}{span > 1 ? `–${b.years[b.years.length - 1]}` : ""}
                  {!complete && <span style={{ color: T.amber }}> · {t("kosong")}: {b.missing.join(", ")}</span>}
                </div>
              </button>
            );
          })}
        </div>
      ) : (
        <>
          <Panel title={`${bank.ticker} · ${bank.name}`} icon={FolderOpen}
            right={<Btn kind="primary" icon={Calculator} disabled={!pickOk || !!pulling}
              onClick={() => run(sortedPick.flatMap((y) => bank.byYear.get(y) ?? []))}>
              {pickOk ? t("Analisis {n} tahun terpilih", { n: sortedPick.length }) : t("Pilih ≥2 tahun berurutan")}
            </Btn>} pad={false}>
            {(gaps.length > 0 || bank.missing.length > 0) && (
              <div className="p-3" style={{ borderBottom: `1px solid ${T.line}` }}>
                <Notice tone="amber" icon={Info}>
                  {gaps.length > 0
                    ? t("Tahun terpilih tidak berurutan: FY {y} belum dipilih atau tidak ada. Komparasi hanya valid untuk rentang tahun yang lengkap.", { y: gaps.join(", ") })
                    : t("Folder tahun yang kosong (FY {y}) menghalangi komparasi yang melewati tahun tersebut. Minta admin melengkapinya.", { y: bank.missing.join(", ") })}
                </Notice>
              </div>
            )}
            <ul>
              {Array.from({ length: bank.years[bank.years.length - 1] - bank.years[0] + 1 }, (_, i) => bank.years[0] + i).map((y) => {
                const docs = bank.byYear.get(y);
                if (!docs) return (
                  <li key={y} className="flex items-center gap-3 px-4 py-3 text-[12.5px]" style={{ borderTop: `1px solid ${T.line}`, color: T.ter }}>
                    <span className="w-3.5" /><FolderX size={16} /><span className="tnum font-semibold">FY {y}</span><Badge tone="red">{t("Kosong")}</Badge>
                  </li>
                );
                return (
                  <li key={y} className="px-4 py-3 flex flex-col gap-2" style={{ borderTop: `1px solid ${T.line}` }}>
                    <label className="flex items-center gap-3 text-[12.5px] cursor-pointer">
                      <input type="checkbox" className="accent-[var(--c-teal)] w-3.5 h-3.5" checked={picked.includes(y)}
                        onChange={(e) => setPicked(e.target.checked ? [...picked, y] : picked.filter((x) => x !== y))} />
                      <Folder size={16} style={{ color: T.teal }} /><span className="tnum font-semibold">FY {y}</span>
                      <span className="text-[11px]" style={{ color: T.ter }}>{docs.length} {t("dokumen")}</span>
                    </label>
                    <ul className="flex flex-col gap-1 pl-10">
                      {docs.map((d) => {
                        const a = ANALYSIS_META[ws.analysisStatus(d.id)];
                        return (
                          <li key={d.id} className="flex items-center gap-2 flex-wrap text-[12px]">
                            <span className="tnum w-12" style={{ color: T.sub }}>{isMonthly(d.period.period) ? monthName(monthOf(d.period.period)) : d.period.period}</span>
                            <span className="truncate min-w-0 flex-1 basis-40" style={{ color: T.sub }}>{d.fileName}</span>
                            <Badge tone={d.status === "verified" ? "green" : "amber"}>{d.status === "verified" ? t("Verified") : t("Needs Review")}</Badge>
                            <Badge tone={a.tone}>{t(a.label)}</Badge>
                            <span className="text-[11px] hidden md:inline" style={{ color: T.ter }}>{fmtDate(d.uploadedAt)}</span>
                            {pulling?.id === d.id ? <PullProgress stage={pulling.stage} done={pulling.done} total={pulling.total} />
                              : confirmDel === d.id && admin ? <><Btn kind="danger" onClick={() => { ws.removeDocument(d.id); setConfirmDel(null); }}>Hapus?</Btn><Btn kind="ghost" onClick={() => setConfirmDel(null)}>Batal</Btn></>
                              : <>
                                <Btn kind="ghost" icon={Calculator} disabled={!!pulling} onClick={() => run([d])}>{t("Analisis")}</Btn>
                                {admin && <button type="button" aria-label={t("Hapus dokumen")} title={t("Hapus dokumen")} onClick={() => setConfirmDel(d.id)} className="p-1.5" style={{ color: T.red }}><Trash2 size={14} /></button>}
                              </>}
                          </li>
                        );
                      })}
                    </ul>
                  </li>
                );
              })}
            </ul>
          </Panel>
        </>
      )}
    </div>
  );
}
