import { useMemo, useState } from "react";
import { Users, Activity, UserPlus, Repeat, MousePointerClick, CalendarCheck, Download, RotateCcw, Database, Trash2, ShieldAlert, Info } from "lucide-react";
import { Panel, Btn, Stat, Select, Table, Row, Badge, Notice, EmptyState, T, tx, fmtNum, fmtDate } from "../ui";
import { alpha } from "../theme";
import { getRole, canViewUserAmounts } from "../domain/news";
import { downloadCsv, stamp } from "../domain/exporters";
import {
  aggregate, useUsageEvents, seedDemo, clearDemo, hasDemo, DEFAULT_FILTER,
  type UsageFilter, type UsageType, type Range, type Source, type Segment, type Aggregate,
} from "../domain/usage";

const RANGES: { v: Range; l: string }[] = [{ v: 7, l: "7 Hari" }, { v: 30, l: "30 Hari" }, { v: 90, l: "90 Hari" }, { v: 0, l: "Semua" }];
const TYPES: { v: UsageType | "all"; l: string }[] = [
  { v: "all", l: "Semua aktivitas" }, { v: "login", l: "Login" }, { v: "page_view", l: "Kunjungan halaman" },
  { v: "upload", l: "Upload" }, { v: "calculate", l: "Kalkulasi" }, { v: "export", l: "Ekspor" }, { v: "advisor", l: "Advisor" },
  { v: "pick_report", l: "Tarik laporan" }, { v: "extract", l: "Ekstraksi angka" },
];
const TYPE_LABEL = Object.fromEntries(TYPES.map((t) => [t.v, t.l])) as Record<string, string>;
const DAYS = ["Sen", "Sel", "Rab", "Kam", "Jum", "Sab", "Min"];

function Seg<V extends string | number>({ value, onChange, options, label }: { value: V; onChange: (v: V) => void; options: { v: V; l: string }[]; label: string }) {
  return (
    <div role="group" aria-label={tx(label)} className="inline-flex rounded-[4px] overflow-hidden" style={{ border: `1px solid ${T.input}` }}>
      {options.map((o) => {
        const on = o.v === value;
        return (
          <button key={String(o.v)} type="button" aria-pressed={on} onClick={() => onChange(o.v)}
            className="h-8 px-3 text-[12px] font-medium whitespace-nowrap transition-colors"
            style={{ background: on ? T.tealMuted : T.inner, color: on ? T.teal : T.sub, boxShadow: on ? `inset 0 0 0 1px ${T.tealBorder}` : "none" }}>
            {tx(o.l)}
          </button>
        );
      })}
    </div>
  );
}

const delta = (cur: number, prev: number, on: boolean) => {
  if (!on) return null;
  if (!prev) return cur ? "baru vs periode lalu" : "—";
  const p = ((cur - prev) / prev) * 100;
  return `${p >= 0 ? "▲" : "▼"} ${Math.abs(p).toFixed(0)}% ${tx("vs periode lalu")}`;
};

/* ─── Charts (hand-built SVG, matching the app's scatter chart style) ─── */
function TrendChart({ daily }: { daily: Aggregate["daily"] }) {
  const [hover, setHover] = useState<number | null>(null);
  const W = 760, H = 240, L = 36, R = 12, TP = 12, B = 26;
  const max = Math.max(4, ...daily.map((d) => d.active));
  const ceil = Math.ceil(max / 4) * 4;
  const x = (i: number) => L + (daily.length <= 1 ? 0 : (i / (daily.length - 1)) * (W - L - R));
  const y = (v: number) => TP + (1 - v / ceil) * (H - TP - B);
  const line = daily.map((d, i) => `${i ? "L" : "M"}${x(i).toFixed(1)},${y(d.active).toFixed(1)}`).join(" ");
  const area = `${line} L${x(daily.length - 1)},${y(0)} L${x(0)},${y(0)} Z`;
  const step = Math.max(1, Math.ceil(daily.length / 8));
  const h = hover != null ? daily[hover] : null;
  return (
    <div className="relative">
      <svg viewBox={`0 0 ${W} ${H}`} className="w-full h-auto" role="img" aria-label={tx("Grafik pengguna aktif per hari")}
        onMouseLeave={() => setHover(null)}
        onMouseMove={(e) => {
          const r = e.currentTarget.getBoundingClientRect();
          const px = ((e.clientX - r.left) / r.width) * W;
          setHover(Math.max(0, Math.min(daily.length - 1, Math.round(((px - L) / (W - L - R)) * (daily.length - 1)))));
        }}>
        {[0, 1, 2, 3, 4].map((g) => {
          const v = (ceil / 4) * g;
          return <g key={g}><line x1={L} x2={W - R} y1={y(v)} y2={y(v)} stroke={T.line} strokeDasharray="3 4" />
            <text x={L - 6} y={y(v) + 3} textAnchor="end" fontSize="10" fill={T.ter}>{v}</text></g>;
        })}
        <path d={area} fill={alpha(T.teal, 14)} />
        <path d={line} fill="none" stroke={T.teal} strokeWidth="2" strokeLinejoin="round" />
        {daily.map((d, i) => i % step === 0 && (
          <text key={d.key} x={x(i)} y={H - 8} textAnchor="middle" fontSize="10" fill={T.ter}>
            {new Date(d.ts).toLocaleDateString("id-ID", { day: "2-digit", month: "short" })}
          </text>
        ))}
        {h && hover != null && <g><line x1={x(hover)} x2={x(hover)} y1={TP} y2={y(0)} stroke={T.lineHover} /><circle cx={x(hover)} cy={y(h.active)} r="4" fill={T.teal} stroke={T.card} strokeWidth="2" /></g>}
      </svg>
      {h && hover != null && (
        <div className="absolute pointer-events-none px-2.5 py-1.5 rounded-[4px] text-[11px] tnum"
          style={{ left: `${(x(hover) / W) * 100}%`, top: 0, transform: `translateX(${hover > daily.length / 2 ? "-105%" : "5%"})`, background: T.inner, border: `1px solid ${T.input}` }}>
          <div style={{ color: T.sub }}>{new Date(h.ts).toLocaleDateString("id-ID", { weekday: "long", day: "2-digit", month: "short", year: "numeric" })}</div>
          <div><b>{h.active}</b> {tx("pengguna aktif")} · <b>{h.actions}</b> {tx("aktivitas")}</div>
        </div>
      )}
    </div>
  );
}

function HBars({ rows, color, fmt }: { rows: { label: string; count: number }[]; color: string; fmt?: (l: string) => string }) {
  const max = Math.max(1, ...rows.map((r) => r.count));
  if (!rows.length) return <div className="text-[12px] py-6 text-center" style={{ color: T.ter }}>{tx("Belum ada data untuk filter ini.")}</div>;
  return (
    <ul className="flex flex-col gap-2.5">
      {rows.map((r) => (
        <li key={r.label} className="flex items-center gap-3 text-[12px]">
          <span className="w-[42%] truncate" title={tx(fmt ? fmt(r.label) : r.label)}>{tx(fmt ? fmt(r.label) : r.label)}</span>
          <div className="flex-1 h-2 rounded-full" style={{ background: T.track }}>
            <div className="h-2 rounded-full" style={{ width: `${(r.count / max) * 100}%`, background: color }} />
          </div>
          <span className="w-10 text-right tnum" style={{ color: T.sub }}>{r.count}</span>
        </li>
      ))}
    </ul>
  );
}

function FreqBars({ rows }: { rows: Aggregate["freq"] }) {
  const max = Math.max(1, ...rows.map((r) => r.count));
  return (
    <div className="flex items-end gap-4 h-[170px] px-2">
      {rows.map((r) => (
        <div key={r.label} className="flex-1 flex flex-col items-center justify-end gap-1.5 h-full">
          <span className="text-[12px] font-semibold tnum">{r.count}</span>
          <div className="w-full rounded-t-[3px]" style={{ height: `${Math.max(2, (r.count / max) * 100)}%`, background: T.blue, minHeight: 3 }} />
          <span className="text-[11px] text-center" style={{ color: T.sub }}>{tx(r.label)}</span>
        </div>
      ))}
    </div>
  );
}

function Heatmap({ heat }: { heat: number[][] }) {
  const max = Math.max(1, ...heat.flat());
  return (
    <div className="overflow-x-auto">
      <div style={{ minWidth: 520 }}>
        <div className="grid gap-[3px]" style={{ gridTemplateColumns: "28px repeat(24, 1fr)" }}>
          <span />
          {Array.from({ length: 24 }, (_, h) => <span key={h} className="text-[9.5px] text-center" style={{ color: T.ter }}>{h % 3 === 0 ? h : ""}</span>)}
          {heat.map((row, d) => (
            <div key={d} className="contents">
              <span className="text-[10.5px] flex items-center" style={{ color: T.sub }}>{DAYS[d]}</span>
              {row.map((v, h) => (
                <div key={h} title={`${DAYS[d]} ${String(h).padStart(2, "0")}:00 — ${v} ${tx("aktivitas")}`} className="rounded-[2px]"
                  style={{ height: 20, background: v ? alpha(T.violet, 12 + (v / max) * 83) : T.track }} />
              ))}
            </div>
          ))}
        </div>
        <div className="flex items-center gap-2 mt-3 text-[10.5px]" style={{ color: T.ter }}>
          {tx("Sedikit")}
          {[0, 25, 50, 75, 100].map((p) => <span key={p} className="w-4 h-3 rounded-[2px]" style={{ background: p ? alpha(T.violet, 12 + p * 0.83) : T.track }} />)}
          {tx("Banyak")}
        </div>
      </div>
    </div>
  );
}

function Donut({ a, b }: { a: number; b: number }) {
  const tot = a + b, r = 52, c = 2 * Math.PI * r, pa = tot ? a / tot : 0;
  return (
    <div className="flex items-center gap-6 justify-center py-2">
      <svg width="140" height="140" viewBox="0 0 140 140" role="img" aria-label={tx("Pengguna baru vs kembali")}>
        <circle cx="70" cy="70" r={r} fill="none" stroke={T.track} strokeWidth="16" />
        {tot > 0 && <>
          <circle cx="70" cy="70" r={r} fill="none" stroke={T.teal} strokeWidth="16" strokeDasharray={`${pa * c} ${c}`} transform="rotate(-90 70 70)" />
          <circle cx="70" cy="70" r={r} fill="none" stroke={T.amber} strokeWidth="16" strokeDasharray={`${(1 - pa) * c} ${c}`} strokeDashoffset={-pa * c} transform="rotate(-90 70 70)" />
        </>}
        <text x="70" y="68" textAnchor="middle" fontSize="20" fontWeight="600" fill={T.text}>{tot}</text>
        <text x="70" y="84" textAnchor="middle" fontSize="10" fill={T.ter}>{tx("pengguna")}</text>
      </svg>
      <ul className="text-[12px] flex flex-col gap-2">
        <li className="flex items-center gap-2"><span className="w-2.5 h-2.5 rounded-full" style={{ background: T.teal }} />{tx("Baru")} <b className="tnum">{a}</b> <span style={{ color: T.ter }}>({tot ? Math.round(pa * 100) : 0}%)</span></li>
        <li className="flex items-center gap-2"><span className="w-2.5 h-2.5 rounded-full" style={{ background: T.amber }} />{tx("Pengguna kembali")} <b className="tnum">{b}</b> <span style={{ color: T.ter }}>({tot ? Math.round((1 - pa) * 100) : 0}%)</span></li>
      </ul>
    </div>
  );
}

/* ─── Page ─── */
export default function UserAmountsPage() {
  const events = useUsageEvents();
  const [f, setF] = useState<UsageFilter>(DEFAULT_FILTER);
  const [sort, setSort] = useState<"actions" | "sessions" | "last" | "active">("actions");
  const agg = useMemo(() => aggregate(events, f), [events, f]);
  const set = <K extends keyof UsageFilter>(k: K, v: UsageFilter[K]) => setF((s) => ({ ...s, [k]: v }));

  if (!canViewUserAmounts(getRole())) {
    return <Panel><EmptyState icon={ShieldAlert} title="Akses ditolak" why="Halaman Data Analytics hanya tersedia untuk akun admin." /></Panel>;
  }

  const cmp = f.range > 0;
  const users = [...agg.users].sort((a, b) => b[sort] - a[sort]).slice(0, 10);
  const dirty = JSON.stringify(f) !== JSON.stringify(DEFAULT_FILTER);
  const demoOn = hasDemo();
  const rows = agg.users;

  return (
    <div className="flex flex-col gap-4">
      <Notice tone="blue" icon={Info}>
        Data bersumber dari aktivitas di browser ini (localStorage). Data berlabel DEMO adalah contoh ilustratif dan dapat dimuat atau dihapus kapan saja; pengguna lintas perangkat memerlukan backend.
      </Notice>

      {/* Filter bar */}
      <Panel pad={false}>
        <div className="flex flex-wrap items-center gap-3 p-3">
          <Seg label="Rentang waktu" value={f.range} onChange={(v) => set("range", v)} options={RANGES} />
          <div className="w-[190px]"><Select value={f.type} onChange={(v) => set("type", v as UsageFilter["type"])}>
            {TYPES.map((o) => <option key={o.v} value={o.v}>{tx(o.l)}</option>)}</Select></div>
          <div className="w-[150px]"><Select value={f.segment} onChange={(v) => set("segment", v as Segment)}>
            <option value="all">{tx("Semua pengguna")}</option><option value="new">{tx("Pengguna baru")}</option><option value="returning">{tx("Pengguna kembali")}</option></Select></div>
          <Seg label="Sumber data" value={f.source} onChange={(v) => set("source", v as Source)}
            options={[{ v: "all", l: "Semua" }, { v: "real", l: "Nyata" }, { v: "demo", l: "Demo" }]} />
          <div className="ml-auto flex items-center gap-2">
            <Btn kind="ghost" icon={RotateCcw} disabled={!dirty} onClick={() => setF(DEFAULT_FILTER)}>Reset filter</Btn>
            <Btn icon={Download} disabled={!rows.length} onClick={() => downloadCsv<(typeof rows)[number]>(`data-analytics-${stamp()}.csv`, rows, [
              { header: "Nama", value: (r) => r.name }, { header: "Email", value: (r) => r.user },
              { header: "Hari aktif", value: (r) => r.active }, { header: "Sesi", value: (r) => r.sessions },
              { header: "Aktivitas", value: (r) => r.actions }, { header: "Terakhir aktif", value: (r) => new Date(r.last).toISOString() },
              { header: "Halaman favorit", value: (r) => r.topPage }, { header: "Sumber", value: (r) => (r.demo ? "demo" : "nyata") },
            ])}>Ekspor CSV</Btn>
            {demoOn
              ? <Btn kind="danger" icon={Trash2} onClick={clearDemo}>Hapus data demo</Btn>
              : <Btn icon={Database} onClick={seedDemo}>Muat data demo</Btn>}
          </div>
        </div>
      </Panel>

      {!events.length ? (
        <Panel><EmptyState icon={Users} title="Belum ada aktivitas tercatat"
          why="Aktivitas akan tercatat otomatis saat Anda menjelajahi aplikasi. Muat data demo untuk melihat contoh tampilan dashboard."
          action={<Btn kind="primary" icon={Database} onClick={seedDemo}>Muat data demo</Btn>} /></Panel>
      ) : (
        <>
          <div className="grid gap-3" style={{ gridTemplateColumns: "repeat(auto-fit, minmax(170px, 1fr))" }}>
            <Stat label="Total pengguna" value={agg.totalUsers} accent sub={delta(agg.totalUsers, agg.prev.totalUsers, cmp) ?? "Seluruh periode"} />
            <Stat label="Aktif hari ini (DAU)" value={agg.dau} sub="Pengguna unik hari ini" />
            <Stat label="Aktif 7 hari (WAU)" value={agg.wau} sub="Pengguna unik 7 hari" />
            <Stat label="Pengguna baru" value={agg.newUsers} sub={delta(agg.newUsers, agg.prev.newUsers, cmp) ?? "Seluruh periode"} />
            <Stat label="Sesi / pengguna" value={fmtNum(agg.sessionsPerUser, 1)} sub={delta(agg.sessionsPerUser, agg.prev.sessionsPerUser, cmp) ?? "Rata-rata login"} />
            <Stat label="Total aktivitas" value={agg.totalActions.toLocaleString("id-ID")} sub={delta(agg.totalActions, agg.prev.totalActions, cmp) ?? "Semua aksi"} />
          </div>

          <Panel title="Pengguna aktif per hari" icon={Activity}
            right={<span className="text-[11px]" style={{ color: T.ter }}>{tx(TYPE_LABEL[f.type])}</span>}>
            <TrendChart daily={agg.daily} />
          </Panel>

          <div className="grid gap-4 lg:grid-cols-2">
            <Panel title="Frekuensi penggunaan" icon={CalendarCheck}
              right={<span className="text-[11px]" style={{ color: T.ter }}>{tx("jumlah pengguna per rentang hari aktif")}</span>}>
              <FreqBars rows={agg.freq} />
            </Panel>
            <Panel title="Pengguna baru vs kembali" icon={Repeat}><Donut a={agg.newUsers} b={agg.returning} /></Panel>
            <Panel title="Halaman terpopuler" icon={MousePointerClick}><HBars rows={agg.pages} color={T.teal} /></Panel>
            <Panel title="Jenis aktivitas" icon={Activity}><HBars rows={agg.types} color={T.blue} fmt={(l) => TYPE_LABEL[l] ?? l} /></Panel>
          </div>

          <Panel title="Jam sibuk (hari × jam)" icon={UserPlus}><Heatmap heat={agg.heat} /></Panel>

          <Panel title="Pengguna teratas" icon={Users} pad={false}
            right={<div className="w-[170px]"><Select value={sort} onChange={(v) => setSort(v as typeof sort)}>
              <option value="actions">{tx("Urut: aktivitas")}</option><option value="sessions">{tx("Urut: sesi")}</option>
              <option value="active">{tx("Urut: hari aktif")}</option><option value="last">{tx("Urut: terakhir aktif")}</option></Select></div>}>
            {users.length === 0 ? <EmptyState compact icon={Users} title="Tidak ada pengguna" why="Tidak ada pengguna yang cocok dengan filter saat ini." /> : (
              <Table cols="minmax(160px,1.6fr) 80px 70px 90px minmax(150px,1fr) minmax(150px,1.2fr)" minWidth={760}
                head={["Pengguna", "Hari aktif", "Sesi", "Aktivitas", "Terakhir aktif", "Halaman favorit"]}>
                {users.map((u) => (
                  <Row key={u.user} cols="minmax(160px,1.6fr) 80px 70px 90px minmax(150px,1fr) minmax(150px,1.2fr)">
                    <span className="min-w-0 flex items-center gap-2"><span className="truncate"><span className="font-medium">{u.name}</span>
                      <span className="block text-[11px] truncate" style={{ color: T.ter }}>{u.user}</span></span>{u.demo && <Badge tone="blue">DEMO</Badge>}</span>
                    <span className="tnum">{u.active}</span><span className="tnum">{u.sessions}</span><span className="tnum">{u.actions}</span>
                    <span style={{ color: T.sub }}>{fmtDate(new Date(u.last).toISOString())}</span>
                    <span className="truncate" style={{ color: T.sub }}>{tx(u.topPage)}</span>
                  </Row>
                ))}
              </Table>
            )}
          </Panel>
        </>
      )}
    </div>
  );
}
