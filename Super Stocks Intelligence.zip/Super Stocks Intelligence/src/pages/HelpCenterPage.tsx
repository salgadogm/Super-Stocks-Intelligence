import { useState, useMemo } from "react";
import { Search, ChevronDown, CheckCircle, Upload, FlaskConical, Gauge, BookOpen, Send } from "lucide-react";

import { palette as C, alpha } from "../theme";
import { useT } from "../i18n";

type FaqCat = "Umum" | "Upload & Verifikasi" | "Scoring" | "Teknis";

interface FaqItem { id: string; cat: FaqCat; q: string; a: string }

const FAQS: FaqItem[] = [
  // Umum
  { id:"f01", cat:"Umum", q:"Apa itu Super Stocks Intelligence?", a:"Super Stocks Intelligence adalah sistem pendukung keputusan (DSS) investasi saham berbasis model Fuzzy Mamdani. Sistem ini menganalisis laporan keuangan emiten perbankan yang terdaftar di BEI dan menghasilkan skor kelayakan investasi dari 0–100." },
  { id:"f02", cat:"Umum", q:"Apakah Super Stocks Intelligence bisa digunakan untuk membuat keputusan investasi secara langsung?", a:"Tidak. Super Stocks Intelligence adalah alat bantu analisis akademik. Skor yang dihasilkan bukan merupakan rekomendasi atau nasihat investasi. Selalu konsultasikan keputusan investasi Anda dengan profesional keuangan berlisensi." },
  { id:"f03", cat:"Umum", q:"Sektor saham apa yang dicakup oleh sistem ini?", a:"Cakupan adalah Sektor G Financials (IDXFINANCE) menurut IDX-IC, subsektor Banks (Perbankan): BBCA, BBRI, BMRI, BBNI, BBTN, BNGA, BDMN, PNBN, MEGA, dan bank umum konvensional lain. Perusahaan pembiayaan, asuransi, dan sekuritas juga tidak dicakup. Seluruh laporan harus berbasis konsolidasian dan periode yang sama. Data hanya tersedia untuk laporan yang sudah ada di koleksi (diisi admin) dan yang Anda tarik serta verifikasi di workspace." },
  { id:"f04", cat:"Umum", q:"Berapa sering data emiten diperbarui?", a:"Data hanya berubah ketika admin menambahkan laporan baru ke koleksi dan Anda menariknya serta memverifikasi angkanya. Feed harga saham belum terhubung; harga untuk PER dimasukkan manual per tanggal laporan." },
  { id:"f05", cat:"Umum", q:"Bagaimana cara menyimpan emiten favorit saya?", a:"Gunakan fitur Watchlist Saya. Di halaman Ranking & Comparison, klik ikon bookmark di samping nama emiten untuk menambahkan atau menghapusnya dari watchlist. Emiten yang disimpan dapat dipantau secara terpusat di menu Watchlist Saya." },

  // Upload & Verifikasi
  { id:"f06", cat:"Upload & Verifikasi", q:"Format file apa yang didukung untuk upload laporan keuangan?", a:"User tidak mengunggah PDF sendiri. Admin mengisi koleksi laporan (PDF, JPG, PNG, maksimal 50 MB per file) secara berkala, dan Anda memilih laporan dari Perpustakaan Laporan lalu menekan Analisis laporan ini. Yang dipakai hanya Profit and Loss dan Statement of Financial Position; arus kas, perubahan ekuitas, CALK, dan narasi tidak dipakai. Untuk tiap emiten dan tahun, kedua laporan wajib ada, boleh dalam satu file atau terpisah." },
  { id:"f07", cat:"Upload & Verifikasi", q:"Berapa lama proses ekstraksi AI berlangsung setelah upload?", a:"Untuk PDF digital, konversi PDF → teks berjalan langsung di browser dengan kode (tanpa AI), biasanya beberapa detik per laporan. Progres (membaca PDF, membaca angka, mengisi form) ditampilkan saat Anda menekan Analisis laporan ini. Usulan 9 akun langsung terisi di halaman Verifikasi Ekstraksi AI dan tetap wajib dicek manual." },
  { id:"f07b", cat:"Upload & Verifikasi", q:"Kenapa PDF diubah ke teks dulu, bukan langsung dibaca AI?", a:"Membaca PDF langsung dengan AI memproses tiap halaman sebagai gambar dan seluruh laporan tahunan (150–300 halaman), sehingga boros token. Super Stocks Intelligence mengubah PDF ke teks dengan kode, lalu hanya memakai 2–4 halaman SFP dan P&L. Biayanya nol untuk PDF digital, dan hasilnya konsisten setiap kali dijalankan. AI hanya disiapkan sebagai cadangan untuk akun yang tidak ditemukan, dan tidak pernah menghitung rasio atau skor." },
  { id:"f08", cat:"Upload & Verifikasi", q:"Apa yang harus dilakukan jika AI salah mengidentifikasi nilai suatu akun?", a:"Buka halaman Verifikasi Ekstraksi AI, temukan laporan yang bersangkutan, dan klik tombol Review. Anda dapat melihat nilai yang diidentifikasi AI per variabel rasio dan mengonfirmasi atau menolak hasilnya. Jika ditolak, perbaiki angkanya dari PDF asli atau tarik ulang laporan dari koleksi." },
  { id:"f09", cat:"Upload & Verifikasi", q:"Mengapa laporan saya berstatus 'Ditolak'?", a:"Status Ditolak terjadi ketika reviewer manual menilai hasil ekstraksi AI tidak akurat — misalnya AI tidak dapat membaca tabel keuangan karena kualitas scan PDF yang buruk, atau format laporan tidak standar. Solusi: gunakan PDF digital (teksnya bisa diblok/disalin), bukan scan fisik. PDF scan tidak memiliki lapisan teks sehingga tidak dapat dikonversi otomatis." },
  { id:"f10", cat:"Upload & Verifikasi", q:"Bisakah saya mengupload laporan keuangan tengah tahun (interim)?", a:"Bisa. Periode Q1, Q2, dan Q3 dapat ditambahkan admin ke koleksi lalu dihitung. Tren 5 tahun, Profil Emiten, dan Perbandingan Emiten memakai periode FY (tahunan) agar antar-tahun dan antar-emiten setara." },

  // Scoring
  { id:"f11", cat:"Scoring", q:"Apa saja 9 variabel rasio yang digunakan dalam model Fuzzy Mamdani?", a:"Model menggunakan 9 variabel: (1) Profitabilitas: ROE, ROA, NIM, NPM — (2) Efisiensi: BOPO — (3) Likuiditas: LDR — (4) Permodalan: EQA — (5) Intermediasi: LTA — (6) Valuasi: PER. Setiap variabel difuzzifikasi menggunakan fungsi keanggotaan segitiga dan diproses melalui rule base Mamdani (lihat Rule Base Viewer)." },
  { id:"f12", cat:"Scoring", q:"Apa arti kategori Layak, Dipertimbangkan, dan Tidak Layak?", a:"Skor Model (0–100) dibagi 3 Kategori Kelayakan Berdasarkan Model: Layak (≥65), Dipertimbangkan (35–65), Tidak Layak (<35). Kategori ini mencerminkan kondisi fundamental keuangan emiten berdasarkan analisis multivariabel — bukan prediksi harga saham." },
  { id:"f13", cat:"Scoring", q:"Bagaimana cara menggunakan mode simulasi di Skor & Defuzzifikasi?", a:"Pilih emiten dan tahun laporan di halaman Skor & Defuzzifikasi. Nilai aktual dari laporan akan otomatis terisi. Anda bisa menggeser slider tiap variabel untuk mensimulasikan kondisi berbeda. Sistem otomatis menampilkan badge 'Mode Simulasi'. Klik 'Reset ke Nilai Aktual' untuk kembali ke data asli, atau 'Simpan sebagai Skor Resmi' jika ingin mengonfirmasi skor." },
  { id:"f14", cat:"Scoring", q:"Mengapa skor dua emiten berbeda padahal nilai ROE-nya sama?", a:"Model Fuzzy Mamdani bersifat multivariabel — skor ditetapkan berdasarkan kombinasi semua 9 variabel secara bersamaan melalui rule base Mamdani (lihat Rule Base Viewer). Dua emiten dengan ROE sama dapat menghasilkan skor yang sangat berbeda jika variabel lain (misalnya BOPO atau EQA) berbeda signifikan." },
  { id:"f15", cat:"Scoring", q:"Apakah skor bisa diekspor?", a:"Ya. Gunakan menu Export Laporan (PDF) di bagian Insight untuk mengunduh laporan gabungan yang mencakup skor, breakdown variabel rasio, tren historis, dan ringkasan analisis. Format PDF tersedia dalam versi ringkas (2 halaman) dan detail (full report)." },

  // Teknis
  { id:"f16", cat:"Teknis", q:"Browser apa yang didukung?", a:"Super Stocks Intelligence dioptimalkan untuk Chrome 120+, Firefox 121+, Edge 120+, dan Safari 17+. Beberapa fitur visual (grafik, animasi) mungkin tidak bekerja optimal di browser versi lama. Mobile view belum dioptimalkan — gunakan layar minimal 1280px untuk pengalaman terbaik." },
  { id:"f17", cat:"Teknis", q:"Data saya aman? Di mana laporan keuangan yang saya upload disimpan?", a:"Saat ini belum ada server. Metadata, nilai terverifikasi, dan hasil analisis tersimpan di localStorage browser Anda. File PDF koleksi disimpan di browser (IndexedDB) pada perangkat ini dan tidak dikirim ke mana pun, sehingga hanya terlihat di perangkat yang sama." },
  { id:"f18", cat:"Teknis", q:"Apa yang harus dilakukan jika dashboard terasa lambat atau tidak merespons?", a:"Coba langkah berikut: (1) Hard refresh halaman dengan Ctrl+Shift+R (Windows) atau Cmd+Shift+R (Mac), (2) Bersihkan cache browser, (3) Pastikan koneksi internet stabil. Jika masalah berlanjut, hubungi dukungan melalui formulir di bawah ini dengan menyertakan screenshot error." },
  { id:"f19", cat:"Teknis", q:"Apakah ada API untuk mengintegrasikan data Super Stocks Intelligence dengan platform lain?", a:"API publik belum tersedia pada versi ini. Fitur API akan dihadirkan pada rilis berikutnya (Q1 2027) dengan dokumentasi OpenAPI. Untuk kebutuhan integrasi segera, gunakan fitur Export Laporan (PDF) sebagai alternatif." },
  { id:"f20", cat:"Teknis", q:"Bagaimana cara mengganti bahasa antarmuka?", a:"Antarmuka Super Stocks Intelligence saat ini tersedia dalam Bahasa Indonesia. Dukungan bahasa Inggris (EN) sedang dalam pengembangan dan direncanakan hadir pada versi 2.0. Untuk keperluan akademik internasional, gunakan fitur Export Laporan yang tersedia dalam format bilingual (ID/EN)." },
];

const FAQ_CATS: FaqCat[] = ["Umum", "Upload & Verifikasi", "Scoring", "Teknis"];

const QUICK_LINKS = [
  { icon: Upload,       label: "Perpustakaan Laporan",   sub: "Pilih laporan dari koleksi" },
  { icon: FlaskConical, label: "Verifikasi Ekstraksi AI", sub: "Periksa hasil identifikasi AI" },
  { icon: Gauge,        label: "Skor & Defuzzifikasi",   sub: "Hitung skor kelayakan emiten" },
  { icon: BookOpen,     label: "User Guidelines",        sub: "Panduan lengkap penggunaan" },
];

export default function HelpCenterPage({ flash, onNavigate }: {
  flash: (m: string) => void;
  onNavigate?: (page: string) => void;
}) {
  const { t } = useT();
  const [faqQuery, setFaqQuery] = useState("");
  const [faqCat, setFaqCat] = useState<FaqCat | "Semua">("Semua");
  const [expandedId, setExpandedId] = useState<string | null>(null);

  // Form state
  const [formName, setFormName] = useState("");
  const [formEmail, setFormEmail] = useState("");
  const [formCat, setFormCat] = useState("");
  const [formMsg, setFormMsg] = useState("");

  const filteredFaqs = useMemo(() => {
    return FAQS.filter((f) => {
      if (faqCat !== "Semua" && f.cat !== faqCat) return false;
      if (faqQuery.trim()) {
        const q = faqQuery.toLowerCase();
        return t(f.q).toLowerCase().includes(q) || t(f.a).toLowerCase().includes(q);
      }
      return true;
    });
  }, [faqCat, faqQuery, t]);

  const handleSubmit = () => {
    if (!formName.trim() || !formEmail.trim() || !formMsg.trim()) {
      flash(t("Lengkapi semua field yang wajib diisi"));
      return;
    }
    flash(t("Layanan tiket belum terhubung ke backend — permintaan tidak terkirim"));
    setFormName(""); setFormEmail(""); setFormCat(""); setFormMsg("");
  };

  return (
    <div className="flex flex-col gap-5">
      {/* System status */}
      <div className="flex items-center gap-3 px-5 py-3 rounded-[8px]"
        style={{ background: alpha(C.lime, 8), border: `1px solid ${alpha(C.lime, 20)}` }}>
        <CheckCircle size={18} style={{ color: C.lime, flexShrink: 0 }} />
        <div>
          <span className="text-[13px] font-semibold" style={{ color: C.lime }}>{t("Semua sistem berjalan normal")}</span>
          <span className="text-[12px] ml-3" style={{ color: C.sub }}>{t("Terakhir dicek: 08 Sep 2026 · 09:14 WIB")}</span>
        </div>
        <div className="ml-auto flex items-center gap-4 text-[11px]" style={{ color: C.sub }}>
          {["API Scoring","AI Extractor","Database","BEI Feed"].map((s) => (
            <span key={s} className="flex items-center gap-1.5">
              <span style={{ width: 6, height: 6, borderRadius: "50%", background: C.lime, display: "inline-block" }} />
              {t(s)}
            </span>
          ))}
        </div>
      </div>

      {/* Quick links */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {QUICK_LINKS.map((l) => (
          <div key={l.label}
            className="flex items-center gap-3 p-4 rounded-[8px] cursor-pointer transition-colors"
            style={{ background: C.card, border: `1px solid ${C.cardBorder}` }}
            onClick={() => { onNavigate?.(l.label); flash(t("Membuka {label}…", { label: t(l.label) })); }}
            onMouseEnter={(e) => (e.currentTarget.style.borderColor = C.borderHover)}
            onMouseLeave={(e) => (e.currentTarget.style.borderColor = C.cardBorder)}>
            <div className="flex items-center justify-center rounded-[6px] shrink-0"
              style={{ width: 40, height: 40, background: C.inner }}>
              <l.icon size={18} strokeWidth={1.5} style={{ color: C.text }} />
            </div>
            <div className="min-w-0">
              <div className="text-[12px] font-semibold leading-snug">{t(l.label)}</div>
              <div className="text-[11px] mt-0.5 truncate" style={{ color: C.ter }}>{t(l.sub)}</div>
            </div>
          </div>
        ))}
      </div>

      <div className="grid gap-5 grid-cols-1 lg:grid-cols-[1fr_340px]">
        {/* FAQ section */}
        <div className="flex flex-col gap-4">
          {/* FAQ filter bar */}
          <div className="flex items-center gap-3 p-3 rounded-[8px]"
            style={{ background: C.card, border: `1px solid ${C.cardBorder}` }}>
            <div className="flex items-center gap-2 h-9 rounded-[6px] px-3 flex-1"
              style={{ background: C.inner, border: `1px solid ${C.inputBorder}` }}>
              <Search size={13} style={{ color: C.ter, flexShrink: 0 }} />
              <input value={faqQuery} onChange={(e) => setFaqQuery(e.target.value)}
                placeholder={t("Cari pertanyaan atau kata kunci…")}
                className="bg-transparent outline-none text-[12px] w-full" style={{ color: C.text }} />
            </div>
            <div className="flex items-center gap-1.5">
              {(["Semua", ...FAQ_CATS] as const).map((cat) => (
                <button key={cat} onClick={() => setFaqCat(cat)}
                  className="h-8 px-3 rounded-[4px] text-[11px] font-medium whitespace-nowrap"
                  style={{
                    background: faqCat === cat ? C.accentMuted : C.inner,
                    color: faqCat === cat ? C.teal : C.sub,
                    border: faqCat === cat ? `1px solid ${C.teal}` : `1px solid ${C.inputBorder}`,
                  }}>{t(cat)}</button>
              ))}
            </div>
            <span className="text-[11px] shrink-0" style={{ color: C.ter }}>{filteredFaqs.length} FAQ</span>
          </div>

          {/* FAQ accordion */}
          <div className="rounded-[8px] overflow-hidden" style={{ background: C.card, border: `1px solid ${C.cardBorder}` }}>
            {filteredFaqs.length === 0 && (
              <div className="py-10 text-center text-[13px]" style={{ color: C.sub }}>
                {t("Tidak ada FAQ cocok dengan pencarian.")}
              </div>
            )}
            {filteredFaqs.map((faq, i) => {
              const isOpen = expandedId === faq.id;
              return (
                <div key={faq.id} style={{ borderBottom: i < filteredFaqs.length - 1 ? `1px solid ${C.cardBorder}` : "none" }}>
                  <div
                    className="flex items-start gap-3 px-5 py-4 cursor-pointer transition-colors"
                    onClick={() => setExpandedId(isOpen ? null : faq.id)}
                    onMouseEnter={(e) => (e.currentTarget.style.background = C.rowHover)}
                    onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-0.5">
                        <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded-[4px]"
                          style={{
                            background: alpha(faq.cat === "Umum" ? C.teal : faq.cat === "Upload & Verifikasi" ? C.lime : faq.cat === "Scoring" ? C.yellow : C.amber, 12),
                            color: faq.cat === "Umum" ? C.teal : faq.cat === "Upload & Verifikasi" ? C.lime : faq.cat === "Scoring" ? C.yellow : C.amber,
                          }}>
                          {t(faq.cat)}
                        </span>
                      </div>
                      <div className="text-[13px] font-semibold leading-snug" style={{ color: C.text }}>{t(faq.q)}</div>
                    </div>
                    <ChevronDown size={16} style={{
                      color: C.ter, flexShrink: 0, marginTop: 2,
                      transform: isOpen ? "rotate(180deg)" : "none",
                      transition: "transform 0.2s",
                    }} />
                  </div>
                  {isOpen && (
                    <div className="px-5 pb-5" style={{ background: C.inner }}>
                      <div className="pt-3 text-[13px] leading-relaxed" style={{ color: C.sub, borderTop: `1px solid ${C.cardBorder}` }}>
                        {t(faq.a)}
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Contact form */}
        <div className="rounded-[10px] p-5 flex flex-col gap-4 h-fit"
          style={{ background: C.card, border: `1px solid ${C.cardBorder}` }}>
          <div>
            <div className="text-[14px] font-semibold">{t("Kirim Permintaan Bantuan")}</div>
            <div className="text-[12px] mt-1" style={{ color: C.sub }}>{t("Pengiriman tiket belum terhubung ke backend")}</div>
          </div>

          <div className="flex flex-col gap-3">
            <div>
              <label className="text-[11px] mb-1.5 block" style={{ color: C.ter }}>{t("Nama Lengkap *")}</label>
              <input value={formName} onChange={(e) => setFormName(e.target.value)}
                placeholder={t("Masukkan nama lengkap")}
                className="w-full h-10 px-3 rounded-[6px] text-[13px] outline-none"
                style={{ background: C.inner, border: `1px solid ${C.inputBorder}`, color: C.text }} />
            </div>

            <div>
              <label className="text-[11px] mb-1.5 block" style={{ color: C.ter }}>{t("Email *")}</label>
              <input value={formEmail} onChange={(e) => setFormEmail(e.target.value)}
                type="email" placeholder="email@institusi.ac.id"
                className="w-full h-10 px-3 rounded-[6px] text-[13px] outline-none"
                style={{ background: C.inner, border: `1px solid ${C.inputBorder}`, color: C.text }} />
            </div>

            <div>
              <label className="text-[11px] mb-1.5 block" style={{ color: C.ter }}>{t("Kategori Masalah")}</label>
              <select value={formCat} onChange={(e) => setFormCat(e.target.value)}
                className="w-full h-10 px-3 rounded-[6px] text-[13px] outline-none"
                style={{ background: C.inner, border: `1px solid ${C.inputBorder}`, color: formCat ? C.text : C.ter }}>
                <option value="">{t("Pilih kategori…")}</option>
                <option value="Bug atau Error">{t("Bug atau Error")}</option>
                <option value="Upload & Verifikasi">{t("Upload & Verifikasi")}</option>
                <option value="Hasil Scoring">{t("Hasil Scoring")}</option>
                <option value="Akun & Akses">{t("Akun & Akses")}</option>
                <option value="Permintaan Fitur">{t("Permintaan Fitur")}</option>
                <option value="Lainnya">{t("Lainnya")}</option>
              </select>
            </div>

            <div>
              <label className="text-[11px] mb-1.5 block" style={{ color: C.ter }}>{t("Pesan *")}</label>
              <textarea value={formMsg} onChange={(e) => setFormMsg(e.target.value)}
                placeholder={t("Deskripsikan masalah atau pertanyaan Anda secara detail. Sertakan screenshot jika ada.")}
                rows={5}
                className="w-full px-3 py-2.5 rounded-[6px] text-[13px] outline-none resize-none"
                style={{ background: C.inner, border: `1px solid ${C.inputBorder}`, color: C.text }} />
            </div>
          </div>

          <button onClick={handleSubmit}
            className="flex items-center justify-center gap-2 h-11 rounded-[6px] text-[13px] font-semibold transition-opacity hover:opacity-85"
            style={{ background: C.teal, color: C.onAccent }}>
            <Send size={15} /> {t("Kirim Permintaan")}
          </button>

          <div className="text-center text-[11px] leading-relaxed" style={{ color: C.ter }}>
            {t("Atau email langsung ke")}{" "}
            <span style={{ color: C.teal }}>support@aurevia.id</span>
          </div>
        </div>
      </div>
    </div>
  );
}
