// Akun Saya — each signed-in account edits its own profile. Email is the account identity and is read-only.
import { useState } from "react";
import { UserRound, Palette, Check, RotateCcw, Mail, ShieldCheck, Sun, Moon, Monitor, Languages, Trash2, KeyRound, Lock } from "lucide-react";
import { PROVIDERS, AI_SERVER_PROVIDER, keySource, setKey, useKeysVersion, type Provider } from "../domain/apiKeys";
import { getRole, canManageCollection } from "../domain/news";
import Avatar, { AVATARS, ProfileBanner } from "../components/Avatar";
import { useTheme, useLang } from "../domain/preferences";
import { useT } from "../i18n";
import { BIO_MAX, type Profile } from "../domain/profile";
import { T, Panel, Btn, Badge, Field, inputCls, inputStyle } from "../ui";

function ApiKeysPanel() {
  useKeysVersion();
  const { t } = useT();
  const [draft, setDraft] = useState<Partial<Record<Provider, string>>>({});
  const admin = canManageCollection(getRole());
  return (
    <Panel title="Sumber Data & API Key" icon={KeyRound} right={<span className="text-[11px]" style={{ color: T.ter }}>Opsional · konteks Overview, bukan input model</span>}>
      <p className="text-[12px] leading-relaxed mb-3" style={{ color: T.sub }}>
        {t("Daftar gratis di tiap penyedia, lalu tempel key-nya di sini (tersimpan di browser ini) atau isi di")} <code>.env</code> (<code>VITE_*</code>). {t("Respons di-cache agar tetap dalam kuota gratis.")}
      </p>
      <div className="flex flex-col gap-2.5">
        <div className="grid gap-2 md:grid-cols-[220px_1fr_auto] items-center rounded-[6px] p-2.5" style={{ background: T.inner, border: `1px solid ${T.line}` }}>
          <div className="min-w-0">
            <div className="text-[12.5px] font-semibold flex items-center gap-1.5">{AI_SERVER_PROVIDER.name}<Badge tone="green">{t("Server")}</Badge></div>
            <div className="text-[11px] truncate" style={{ color: T.ter }}>{t(AI_SERVER_PROVIDER.what)}</div>
          </div>
          <div className="flex items-center gap-1.5 text-[12px]" style={{ color: T.sub }}><Lock size={13} />{t("Dikelola di backend, tidak ditampilkan di browser")}</div>
          <span />
        </div>
        {!admin && <p className="text-[11px]" style={{ color: T.ter }}>{t("Hanya admin yang dapat mengubah API key open-source/gratis di bawah ini.")}</p>}
        {PROVIDERS.map((p) => {
          const src = keySource(p.id);
          return (
            <div key={p.id} className="grid gap-2 md:grid-cols-[220px_1fr_auto] items-center">
              <div className="min-w-0">
                <div className="text-[12.5px] font-semibold flex items-center gap-1.5">{p.name}
                  {src ? <Badge tone="green">{src === "env" ? ".env" : t("Tersimpan")}</Badge> : <Badge>Kosong</Badge>}</div>
                <div className="text-[11px] truncate" style={{ color: T.ter }}>{t(p.what)} · {t(p.quota)} · <a href={p.signup} target="_blank" rel="noreferrer" className="hover:underline" style={{ color: T.teal }}>{t("Daftar")}</a></div>
              </div>
              <input type="password" autoComplete="off" disabled={!admin} placeholder={src ? t("•••••••• (ganti)") : t("Tempel API key")} className={inputCls} style={inputStyle}
                value={draft[p.id] ?? ""} onChange={(e) => setDraft({ ...draft, [p.id]: e.target.value })} />
              <div className="flex gap-1.5">
                <Btn disabled={!admin || !draft[p.id]} onClick={() => { setKey(p.id, draft[p.id] ?? ""); setDraft({ ...draft, [p.id]: "" }); }}>Simpan</Btn>
                {src === "device" && admin && <Btn kind="ghost" icon={Trash2} onClick={() => setKey(p.id, "")}>Hapus</Btn>}
              </div>
            </div>
          );
        })}
      </div>
    </Panel>
  );
}

export default function AkunPage({ profile, email, onSave }: { profile: Profile; email: string; onSave: (p: Profile) => void }) {
  const theme = useTheme();
  const { lang, setLang } = useLang();
  const { t } = useT();
  const [draft, setDraft] = useState<Profile>(profile);
  const dirty = JSON.stringify(draft) !== JSON.stringify(profile);
  const nameOk = draft.name.trim().length >= 2;
  const set = (p: Partial<Profile>) => setDraft((d) => ({ ...d, ...p }));

  return (
    <div className="grid grid-cols-1 xl:grid-cols-[minmax(0,1fr)_340px] gap-4 items-start">
      <div className="flex flex-col gap-4">
        <Panel title="Profil" icon={UserRound}>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <Field label="Nama tampilan" hint={!nameOk ? <span style={{ color: T.red }}>Minimal 2 karakter</span> : undefined}>
              <input className={inputCls} style={inputStyle} value={draft.name} maxLength={60} onChange={(e) => set({ name: e.target.value })} />
            </Field>
            <Field label="Peran / jabatan"><input className={inputCls} style={inputStyle} value={draft.headline} maxLength={60} placeholder={t("mis. Analis Ekuitas, Mahasiswa Akuntansi")} onChange={(e) => set({ headline: e.target.value })} /></Field>
            <Field label="Institusi"><input className={inputCls} style={inputStyle} value={draft.organization} maxLength={80} placeholder={t("Universitas / perusahaan")} onChange={(e) => set({ organization: e.target.value })} /></Field>
            <Field label="Lokasi"><input className={inputCls} style={inputStyle} value={draft.location} maxLength={60} placeholder={t("Kota")} onChange={(e) => set({ location: e.target.value })} /></Field>
            <div className="md:col-span-2">
              <Field label="Deskripsi" hint={<span className="tnum">{draft.bio.length}/{BIO_MAX}</span>}>
                <textarea className={inputCls + " !h-28 py-2 resize-none leading-relaxed"} style={inputStyle} value={draft.bio} maxLength={BIO_MAX}
                  placeholder={t("Ceritakan fokus analisis Anda, mis. emiten bank besar dan bank digital di BEI.")} onChange={(e) => set({ bio: e.target.value })} />
              </Field>
            </div>
          </div>
        </Panel>

        <Panel title="Avatar" icon={Palette} right={<span className="text-[11px] tnum" style={{ color: T.ter }}>{AVATARS.length} {t("pilihan + inisial")}</span>}>
          <div className="grid grid-cols-4 sm:grid-cols-7 gap-2.5">
            {[{ id: "", name: "Inisial" }, ...AVATARS].map((a) => {
              const on = draft.avatar === a.id;
              return (
                <button key={a.id || "mono"} onClick={() => set({ avatar: a.id })} aria-pressed={on}
                  className="group flex flex-col items-center gap-1.5 py-3 rounded-[6px] transition-colors"
                  style={{ background: on ? T.inner : "transparent", border: `1px solid ${on ? T.teal : T.line}` }}>
                  <span className="relative">
                    <Avatar id={a.id} name={draft.name} size={48} />
                    {on && <span className="absolute -right-1 -bottom-1 w-4 h-4 rounded-full flex items-center justify-center" style={{ background: T.teal, color: T.onAccent }}><Check size={10} strokeWidth={3} /></span>}
                  </span>
                  <span className="text-[10.5px]" style={{ color: on ? T.text : T.sub }}>{t(a.name)}</span>
                </button>
              );
            })}
          </div>
        </Panel>

        <Panel title="Tampilan" icon={Sun} right={<span className="text-[11px]" style={{ color: T.ter }}>{t("Berlaku langsung di perangkat ini")}</span>}>
          <div role="radiogroup" aria-label={t("Tema")} className="grid grid-cols-1 min-[420px]:grid-cols-3 gap-2.5 max-w-md">
            {([["dark", "Gelap", Moon], ["light", "Terang", Sun], ["system", "Sistem", Monitor]] as const).map(([v, label, Icon]) => {
              const on = theme.pref === v;
              return (
                <button key={v} role="radio" aria-checked={on} onClick={() => theme.setPref(v)}
                  className="flex items-center justify-center gap-2 h-10 rounded-[6px] text-[12.5px] font-medium transition-colors"
                  style={{ background: on ? T.tealMuted : "transparent", color: on ? T.teal : T.sub, border: `1px solid ${on ? T.teal : T.line}` }}>
                  <Icon size={14} strokeWidth={1.75} />{t(label)}
                </button>
              );
            })}
          </div>
        </Panel>

        <Panel title="Bahasa" icon={Languages} right={<span className="text-[11px]" style={{ color: T.ter }}>{t("Berlaku langsung di perangkat ini")}</span>}>
          <div role="radiogroup" aria-label={t("Bahasa")} className="grid grid-cols-2 gap-2.5 max-w-md">
            {([["id", "Bahasa Indonesia"], ["en", "English"]] as const).map(([v, label]) => {
              const on = lang === v;
              return (
                <button key={v} role="radio" aria-checked={on} onClick={() => setLang(v)}
                  className="flex items-center justify-center h-10 rounded-[6px] text-[12.5px] font-medium transition-colors"
                  style={{ background: on ? T.tealMuted : "transparent", color: on ? T.teal : T.sub, border: `1px solid ${on ? T.teal : T.line}` }}>
                  {label}
                </button>
              );
            })}
          </div>
        </Panel>

        <ApiKeysPanel />

        <div className="flex items-center gap-2">
          <Btn kind="primary" icon={Check} disabled={!dirty || !nameOk} onClick={() => onSave({ ...draft, name: draft.name.trim() })}>Simpan perubahan</Btn>
          <Btn icon={RotateCcw} disabled={!dirty} onClick={() => setDraft(profile)}>Batalkan</Btn>
          <span className="text-[11px]" style={{ color: T.ter }}>{t("Tersimpan di browser ini untuk akun")} {email || t("ini")}.</span>
        </div>
      </div>

      {/* Live preview of the profile card */}
      <div className="flex flex-col gap-4 xl:sticky xl:top-4">
        <section className="rounded-[6px] overflow-hidden" style={{ background: T.card, border: `1px solid ${T.line}` }}>
          <ProfileBanner id={draft.avatar} height={96} />
          <div className="px-5 pb-5 -mt-9 flex flex-col gap-3 relative">
            <span className="rounded-full p-1 self-start" style={{ background: T.card }}><Avatar id={draft.avatar} name={draft.name} size={64} /></span>
            <div>
              <div className="text-[16px] font-semibold">{draft.name.trim() || "—"}</div>
              {(draft.headline || draft.organization) && <div className="text-[12px]" style={{ color: T.sub }}>{[draft.headline, draft.organization].filter(Boolean).join(" · ")}</div>}
              {draft.location && <div className="text-[11px]" style={{ color: T.ter }}>{draft.location}</div>}
            </div>
            <p className="text-[12px] leading-relaxed whitespace-pre-wrap" style={{ color: draft.bio ? T.sub : T.ter }}>{draft.bio || t("Belum ada deskripsi.")}</p>
            <div className="flex flex-col gap-1.5 pt-3 text-[11.5px]" style={{ borderTop: `1px solid ${T.line}`, color: T.sub }}>
              <span className="flex items-center gap-2"><Mail size={13} style={{ color: T.ter }} />{email || "—"}</span>
              <span className="flex items-center gap-2"><ShieldCheck size={13} style={{ color: T.ter }} />{t("Peran sistem")} <Badge tone="teal">Admin</Badge></span>
            </div>
          </div>
        </section>
        <p className="text-[11px] leading-relaxed" style={{ color: T.ter }}>{t("Email adalah identitas akun dan tidak dapat diubah di sini. Nama dipakai di header dan komentar News; avatar tampil di header.")}</p>
      </div>
    </div>
  );
}
