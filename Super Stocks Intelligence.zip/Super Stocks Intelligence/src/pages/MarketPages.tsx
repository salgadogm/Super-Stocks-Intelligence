// Market context (free, public, keyless sources only): USD/IDR, Indonesian macro (World Bank) and micro/sector factors from uploaded reports.
// Context only — none of these values feed the Fuzzy Mamdani model.
import { useMemo, type ReactNode } from "react";
import { Globe2, Landmark, Plug, RefreshCw, TrendingUp, TrendingDown, Scale, Newspaper } from "lucide-react";
import { useUsdIdr, useMacro, useQuotes, useSectorNews, WB_INDICATORS, type MacroSeries, type Point, type Quote, type SourceState } from "../domain/market";
import { useKeysVersion } from "../domain/apiKeys";
import { bankSegmentOf } from "../domain/issuers";
import { useWorkspace } from "../domain/store";
import { VAR_KEYS, VAR_DEFS, dominantSet } from "../domain/engine";
import { T, Panel, Badge, Notice, fmtNum, tx } from "../ui";

const Spark = ({ pts, color = T.teal, h = 36 }: { pts: Point[]; color?: string; h?: number }) => {
  if (pts.length < 2) return <div style={{ height: h }} />;
  const W = 160, vs = pts.map((p) => p.v), lo = Math.min(...vs), hi = Math.max(...vs);
  const d = pts.map((p, i) => `${i ? "L" : "M"}${(i / (pts.length - 1)) * W},${h - 3 - ((p.v - lo) / (hi - lo || 1)) * (h - 6)}`).join("");
  return (
    <svg viewBox={`0 0 ${W} ${h}`} preserveAspectRatio="none" className="w-full" style={{ height: h }}>
      <path d={`${d}L${W},${h}L0,${h}Z`} fill={color} opacity={0.08} />
      <path d={d} fill="none" stroke={color} strokeWidth={1.5} vectorEffect="non-scaling-stroke" />
    </svg>
  );
};

const delta = (pts: Point[]) => (pts.length > 1 ? pts[pts.length - 1].v - pts[pts.length - 2].v : null);
const Change = ({ v, unit = "", digits = 2 }: { v: number | null; unit?: string; digits?: number }) =>
  v == null ? null : (
    <span className="inline-flex items-center gap-0.5 text-[11px] tnum" style={{ color: v >= 0 ? T.teal : T.red }}>
      {v >= 0 ? <TrendingUp size={11} /> : <TrendingDown size={11} />}{v >= 0 ? "+" : ""}{fmtNum(v, digits)}{unit}
    </span>
  );

function Tile({ label, value, change, foot, pts, color, off }: {
  label: string; value: ReactNode; change?: ReactNode; foot: string; pts?: Point[]; color?: string; off?: boolean;
}) {
  return (
    <div className="rounded-[6px] p-4 flex flex-col gap-2 min-w-0" style={{ background: T.card, border: `1px ${off ? "dashed" : "solid"} ${off ? T.input : T.line}` }}>
      <div className="flex items-center gap-2">
        <span className="text-[11px] uppercase tracking-[0.08em]" style={{ color: T.ter }}>{tx(label)}</span>
        <span className="ml-auto">{change}</span>
      </div>
      <div className="text-[22px] font-semibold tnum leading-none tracking-[-0.02em]" style={{ color: off ? T.ter : T.text }}>{value}</div>
      {pts ? <Spark pts={pts} color={color} h={28} /> : <div className="h-7" />}
      <div className="text-[10.5px] truncate" style={{ color: T.ter }}>{tx(foot)}</div>
    </div>
  );
}

/* ─── Overview strip ─────────────────────────────── */
const WB_PLACEHOLDER: MacroSeries[] = WB_INDICATORS.map((i) => ({ ...i, source: "World Bank", points: [] }));

export function MarketStrip({ onOpen, onKeys }: { onOpen: () => void; onKeys: () => void }) {
  const fx = useUsdIdr(), ihsg = useQuotes(["^JKSE"]), macro = useMacro();
  const pts = fx.data ?? [];
  const l = pts[pts.length - 1];
  const jk = ihsg.data?.["^JKSE"];
  const offFoot = (s: SourceState, src: string) => (s === "nokey" ? `${tx("Butuh API key")} ${src}` : s === "loading" ? tx("Memuat…") : s === "error" ? tx("Gagal memuat") : src);
  return (
    <Panel title="Pita Pasar" icon={Landmark}
      right={<><span className="text-[11px]" style={{ color: T.ter }}>{tx("Konteks · bukan input Skor Model")}</span>
        <button onClick={onKeys} className="text-[11.5px] hover:underline" style={{ color: T.sub }}>{tx("API key")}</button>
        <button onClick={onOpen} className="text-[11.5px] hover:underline" style={{ color: T.teal }}>{tx("Dashboard →")}</button></>}>
      <div className="grid gap-3 grid-cols-2 md:grid-cols-3 xl:grid-cols-5">
        <Tile label="USD / IDR" value={l ? fmtNum(l.v, 0) : "—"} change={<Change v={delta(pts)} digits={0} />} pts={pts.slice(-30)} color={T.amber}
          foot={l ? `ECB · ${l.t}` : fx.loading ? tx("Memuat…") : tx("Gagal memuat kurs")} off={!l} />
        <Tile label="IHSG" value={jk ? fmtNum(jk.price, 0) : "—"} change={jk && <Change v={jk.changePct} unit="%" />} pts={jk?.history.slice(-30)}
          foot={jk ? jk.source : offFoot(ihsg.state, "FMP / Twelve Data")} off={!jk} />
        {(macro.data ?? WB_PLACEHOLDER).map((m) => {
          const lp = m.points[m.points.length - 1];
          return <Tile key={m.id} label={m.label} value={lp ? `${fmtNum(lp.v, 2)}${m.unit}` : "—"}
            change={lp && <Change v={delta(m.points)} unit=" pp" />} pts={m.points.length > 1 ? m.points : undefined}
            foot={lp ? `World Bank · ${lp.t}` : macro.loading ? tx("Memuat…") : tx("Gagal memuat")} off={!lp} />;
        })}
      </div>
    </Panel>
  );
}

const STATE_META: Record<SourceState, { tone: "green" | "neutral" | "red" | "amber"; label: string }> = {
  live: { tone: "green", label: "Live" }, nokey: { tone: "neutral", label: "Tanpa key" }, error: { tone: "red", label: "Error" }, loading: { tone: "amber", label: "Memuat" },
};

/** Health chips for every context source shown on Overview. */
export function SourceHealth({ onKeys }: { onKeys: () => void }) {
  useKeysVersion();
  const fx = useUsdIdr(), q = useQuotes(["^JKSE"]), n = useSectorNews();
  const rows: [string, SourceState][] = [
    ["ECB kurs", fx.loading ? "loading" : fx.error ? "error" : "live"],
    ["Saham IDX", q.state], ["Berita", n.state],
  ];
  return (
    <div className="flex items-center gap-1.5 flex-wrap">
      {rows.map(([k, s]) => <Badge key={k} tone={STATE_META[s].tone} title={`${tx(k)}: ${tx(STATE_META[s].label)}`}>{tx(k)} · {tx(STATE_META[s].label)}</Badge>)}
      {rows.some(([, s]) => s === "nokey") && <button onClick={onKeys} className="text-[11px] hover:underline" style={{ color: T.teal }}>{tx("Atur API key →")}</button>}
    </div>
  );
}

/** Uploaded issuers grouped by bank segment (BUMN / Swasta / Lainnya). Static mapping, context only. */
export function BankSegments({ tickers }: { tickers: string[] }) {
  const groups = (["BUMN", "Swasta", "Lainnya"] as const).map((seg) => ({
    seg, list: [...new Set(tickers)].filter((t) => (bankSegmentOf(t) ?? "Lainnya") === seg).sort(),
  })).filter((g) => g.list.length);
  return (
    <Panel title="Segmen bank" icon={Landmark} right={<span className="text-[11px]" style={{ color: T.ter }}>{tx("Pemetaan statis")}</span>}>
      {groups.length === 0 ? <div className="text-[12px]" style={{ color: T.ter }}>{tx("Belum ada emiten terskor yang terpetakan ke segmen bank.")}</div> : (
        <div className="flex flex-col gap-2">
          {groups.map(({ seg, list }) => (
            <div key={seg} className="flex items-center gap-2 text-[12px]">
              <span className="font-semibold w-16" style={{ color: T.sub }}>{tx(seg)}</span>
              <div className="flex gap-1.5 flex-wrap">
                {list.map((t) => (
                  <span key={t} className="inline-flex items-center px-2 h-6 rounded-[4px] font-semibold" style={{ background: T.inner, border: `1px solid ${T.line}` }}>{t}</span>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </Panel>
  );
}

/** Divergence between Model Score and 3-month price trend. Context, not a recommendation. */
export function ScoreVsMarket({ rows }: { rows: { ticker: string; score: number; category: string; quote?: Quote }[] }) {
  const items = rows.filter((r) => r.quote && r.quote.history.length > 20).map((r) => {
    const h = r.quote!.history, ret = ((h[h.length - 1].v - h[0].v) / h[0].v) * 100;
    const div = (r.category === "Layak" && ret < -5) ? "Skor tinggi, harga turun" : (r.category === "Tidak Layak" && ret > 5) ? "Skor rendah, harga naik" : null;
    return { ...r, ret, div };
  });
  return (
    <Panel title="Skor Model vs tren harga 3 bulan" icon={Scale} right={<span className="text-[11px]" style={{ color: T.ter }}>{tx("Konteks, bukan rekomendasi")}</span>}>
      {items.length === 0 ? <div className="text-[12px]" style={{ color: T.ter }}>{tx("Butuh key FMP atau Twelve Data untuk membandingkan skor dengan harga.")}</div> : (
        <div className="flex flex-col gap-2">
          {items.sort((a, b) => Number(!!b.div) - Number(!!a.div)).slice(0, 6).map((r) => (
            <div key={r.ticker} className="grid grid-cols-[48px_48px_1fr_auto] sm:grid-cols-[56px_56px_1fr_auto] items-center gap-2 text-[12px]">
              <span className="font-semibold">{r.ticker}</span>
              <span className="tnum">{r.score.toFixed(1)}</span>
              <Spark pts={r.quote!.history} color={r.ret >= 0 ? T.teal : T.red} h={22} />
              <span className="flex items-center gap-2"><Change v={r.ret} unit="%" digits={1} />{r.div && <Badge tone="amber">{tx(r.div)}</Badge>}</span>
            </div>
          ))}
        </div>
      )}
    </Panel>
  );
}

export function SectorNews() {
  const n = useSectorNews();
  return (
    <Panel title="Berita pasar & sektor" icon={Newspaper} right={<span className="text-[11px]" style={{ color: T.ter }}>{tx("Finnhub · terpisah dari News internal")}</span>}>
      {n.state === "nokey" ? <div className="text-[12px]" style={{ color: T.ter }}>{tx("Tambahkan key Finnhub untuk menampilkan berita pasar.")}</div>
        : n.state === "loading" ? <div className="text-[12px]" style={{ color: T.ter }}>{tx("Memuat…")}</div>
        : n.state === "error" ? <div className="text-[12px]" style={{ color: T.red }}>{tx("Gagal memuat berita.")}</div> : (
          <div className="flex flex-col gap-2.5">
            {(n.data ?? []).map((x) => (
              <a key={x.url} href={x.url} target="_blank" rel="noreferrer" className="text-[12px] hover:underline">
                <div className="line-clamp-2">{x.headline}</div>
                <div className="text-[10.5px]" style={{ color: T.ter }}>{x.source} · {fmtNum(Math.max(0, (Date.now() - +new Date(x.at)) / 36e5), 0)} {tx("jam lalu")}</div>
              </a>
            ))}
          </div>
        )}
    </Panel>
  );
}

/* ─── Full dashboard ─────────────────────────────── */
const SOURCES = [
  { name: "World Bank Indicators API", what: "Inflasi, pertumbuhan PDB, suku bunga kredit Indonesia (tahunan)", url: "api.worldbank.org" },
  { name: "Frankfurter (ECB reference rates)", what: "Kurs USD/IDR harian, hari kerja", url: "api.frankfurter.app" },
];

function LineArea({ pts, color, height = 180, unit = "" }: { pts: Point[]; color: string; height?: number; unit?: string }) {
  if (pts.length < 2) return <div className="flex items-center justify-center text-[12px]" style={{ height, color: T.ter }}>{tx("Data belum tersedia")}</div>;
  const W = 760, H = height, PL = 48, PB = 22, vs = pts.map((p) => p.v), lo = Math.min(...vs), hi = Math.max(...vs), pad = (hi - lo) * 0.1 || 1;
  const x = (i: number) => PL + (i / (pts.length - 1)) * (W - PL - 8);
  const y = (v: number) => 8 + (1 - (v - lo + pad) / (hi - lo + 2 * pad)) * (H - 8 - PB);
  const d = pts.map((p, i) => `${i ? "L" : "M"}${x(i)},${y(p.v)}`).join("");
  const ticks = [lo, (lo + hi) / 2, hi];
  const labels = [0, Math.floor(pts.length / 2), pts.length - 1];
  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="w-full h-auto">
      {ticks.map((t) => <g key={t}><line x1={PL} x2={W - 8} y1={y(t)} y2={y(t)} stroke={T.line} /><text x={PL - 8} y={y(t) + 3} textAnchor="end" fontSize="9.5" fill={T.ter} className="tnum">{fmtNum(t, t > 100 ? 0 : 2)}{unit}</text></g>)}
      <path d={`${d}L${x(pts.length - 1)},${H - PB}L${PL},${H - PB}Z`} fill={color} opacity={0.08} />
      <path d={d} fill="none" stroke={color} strokeWidth={1.75} />
      {labels.map((i) => <text key={i} x={x(i)} y={H - 6} textAnchor={i === 0 ? "start" : i === pts.length - 1 ? "end" : "middle"} fontSize="9.5" fill={T.ter} className="tnum">{pts[i].t}</text>)}
    </svg>
  );
}

const median = (xs: number[]) => { const s = [...xs].sort((a, b) => a - b); const m = s.length >> 1; return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2; };

export function MacroPage() {
  const ws = useWorkspace();
  const fx = useUsdIdr(), macro = useMacro();
  const fxPts = fx.data ?? [];

  // Micro / sector factors: medians across the latest FY analysis of every uploaded issuer.
  const sector = useMemo(() => {
    const latest = ws.latestByTicker().filter((a) => a.period.period === "FY");
    return { n: latest.length, years: [...new Set(latest.map((a) => a.period.fiscalYear))].sort(), med: VAR_KEYS.map((k) => ({ k, v: latest.length ? median(latest.map((a) => a.ratios[k])) : null })) };
  }, [ws]);

  return (
    <div className="flex flex-col gap-4">
      <Notice tone="teal" icon={Globe2}>{tx("Semua data di halaman ini adalah")} <b>{tx("konteks")}</b>{tx(". Hanya sumber gratis dan publik yang dipakai. Tidak ada nilai makro maupun kurs yang masuk ke 9 input Fuzzy Mamdani atau mengubah Skor Model.")}</Notice>

      <Panel title="USD / IDR · 60 hari" icon={Landmark} right={fxPts.length ? <Badge tone="green">{tx("Live")}</Badge> : undefined}>
          <div className="flex items-baseline gap-3 mb-2">
            <span className="text-[26px] font-semibold tnum leading-none">{fxPts.length ? fmtNum(fxPts[fxPts.length - 1].v, 0) : "—"}</span>
            <Change v={delta(fxPts)} digits={0} />
          </div>
          <LineArea pts={fxPts} color={T.amber} height={150} />
          <p className="mt-2 text-[11px]" style={{ color: T.ter }}>{tx("Relevan bagi bank dengan eksposur valas dan pendanaan USD. Kurs tidak dipakai untuk konversi angka laporan.")}</p>
        </Panel>

      <Panel title="Makroekonomi Indonesia" icon={Globe2} right={<span className="text-[11px]" style={{ color: T.ter }}>{tx("World Bank · tahunan")}</span>} pad={false}>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
          {(macro.data ?? []).map((m) => {
            const l = m.points[m.points.length - 1];
            return (
              <div key={m.id} className="p-4 flex flex-col gap-2" style={{ borderRight: `1px solid ${T.line}`, borderBottom: `1px solid ${T.line}` }}>
                <div className="flex items-baseline gap-2">
                  <span className="text-[12px] font-medium">{tx(m.label)}</span>
                  <span className="ml-auto text-[18px] font-semibold tnum">{l ? `${fmtNum(l.v, 2)}${m.unit}` : "—"}</span>
                </div>
                <Spark pts={m.points} color="var(--c-blue)" h={40} />
                <div className="flex justify-between text-[10.5px] tnum" style={{ color: T.ter }}>
                  <span>{m.points[0]?.t ?? ""}</span><Change v={delta(m.points)} unit=" pp" /><span>{l?.t ?? tx("tidak tersedia")}</span>
                </div>
              </div>
            );
          })}
          {macro.loading && <div className="p-6 text-[12px] flex items-center gap-2" style={{ color: T.ter }}><RefreshCw size={13} className="animate-spin" />{tx("Memuat indikator…")}</div>}
          {macro.error && <div className="p-6 text-[12px]" style={{ color: T.red }}>{tx("Gagal memuat World Bank API")} ({macro.error}).</div>}
        </div>
      </Panel>

        <Panel title="Faktor Mikro · Perbankan (IDX-IC Financials)" icon={Landmark}
          right={<span className="text-[11px] tnum" style={{ color: T.ter }}>{tx("median")} {sector.n} {tx("emiten terunggah")}{sector.years.length ? ` · FY ${sector.years.join(", ")}` : ""}</span>} pad={false}>
          {sector.n === 0 ? <div className="p-4 text-[12px]" style={{ color: T.ter }}>{tx("Belum ada analisis FY. Faktor mikro dihitung dari laporan yang Anda unggah, bukan dari data pihak ketiga.")}</div> : (
            <div className="grid grid-cols-3 sm:grid-cols-5 lg:grid-cols-9">
              {sector.med.map(({ k, v }) => {
                const d = v == null ? null : dominantSet(k, v); const c = VAR_DEFS[k].sets.find((s) => s.name === d?.name)?.color ?? T.ter;
                return (
                  <div key={k} className="p-3 flex flex-col gap-1" style={{ borderRight: `1px solid ${T.line}`, borderBottom: `1px solid ${T.line}` }}>
                    <span className="text-[10.5px]" style={{ color: T.ter }}>{k}</span>
                    <span className="text-[15px] font-semibold tnum">{fmtNum(v, 1)}{VAR_DEFS[k].unit}</span>
                    <span className="text-[10.5px]" style={{ color: c }}>{d?.name ? tx(d.name) : d?.name}</span>
                  </div>
                );
              })}
            </div>
          )}
          <div className="px-4 py-2.5 text-[11px]" style={{ color: T.ter }}>{tx("Median sektor berguna sebagai pembanding di Profil Emiten. Profitabilitas, likuiditas, solvabilitas, aktivitas, dan valuasi ditampilkan dari 9 rasio model.")}</div>
        </Panel>


      <Panel title="Sumber Data" icon={Plug} pad={false}>
        <div className="overflow-x-auto">
          <table className="w-full text-[12px] min-w-[560px]">
            <thead><tr className="text-[10.5px] text-left" style={{ color: T.ter }}>{["Penyedia", "Data", "Endpoint", "Akses"].map((h) => <th key={h} className="font-medium px-4 py-2">{tx(h)}</th>)}</tr></thead>
            <tbody>{SOURCES.map((s) => (
              <tr key={s.name} style={{ borderTop: `1px solid ${T.line}` }}>
                <td className="px-4 py-2.5 font-medium">{tx(s.name)}</td><td className="px-4" style={{ color: T.sub }}>{tx(s.what)}</td>
                <td className="px-4 tnum" style={{ color: T.sub }}>{s.url}</td><td className="px-4"><Badge tone="green">{tx("Gratis · tanpa key")}</Badge></td>
              </tr>))}</tbody>
          </table>
        </div>
      </Panel>
    </div>
  );
}
