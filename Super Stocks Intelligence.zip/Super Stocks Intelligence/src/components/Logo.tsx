import inkLight from "../assets/logo-dark-ink.png";
import inkDark from "../assets/logo-light-ink.png";

// Both sources are 1774×887 with transparent padding; boxes below are the visible mark (x, y, w, h).
const ART = { w: 1774 };
const ON_DARK = { src: inkDark, x: 75, y: 205, w: 1635, h: 520, cls: "logo-for-dark" };
const ON_LIGHT = { src: inkLight, x: 95, y: 185, w: 1620, h: 510, cls: "logo-for-light" };

export default function Logo({ size = 32 }: { size?: number; withWordmark?: boolean; wordSize?: number }) {
  const ratio = ON_DARK.w / ON_DARK.h;
  return (
    <span className="logo-full relative inline-block shrink-0" style={{ height: size, width: size * ratio }} role="img" aria-label="Super Stocks Intelligence">
      {[ON_DARK, ON_LIGHT].map((v) => (
        <span key={v.cls} className={`${v.cls} absolute inset-0 overflow-hidden`}>
          <img
            src={v.src}
            alt=""
            draggable={false}
            className="absolute max-w-none"
            style={{
              width: `${(ART.w / v.w) * 100}%`,
              left: `${(-v.x / v.w) * 100}%`,
              top: `${(-v.y / v.h) * 100}%`,
            }}
          />
        </span>
      ))}
    </span>
  );
}
