import { useEffect, useRef, useState } from "react";
import { Share2, Link2, Mail, Check, Smartphone } from "lucide-react";
import { palette as C } from "../theme";
import { useT } from "../i18n";

// Shares only the app link and page title, never workspace data.
export default function ShareMenu({ title, onCopied }: { title: string; onCopied?: (msg: string) => void }) {
  const { t } = useT();
  const [open, setOpen] = useState(false);
  const [copied, setCopied] = useState(false);
  const box = useRef<HTMLDivElement>(null);
  const url = typeof location !== "undefined" ? location.origin + location.pathname : "";
  const text = `Super Stocks Intelligence — ${title}`;
  const canNative = typeof navigator !== "undefined" && typeof navigator.share === "function";

  useEffect(() => {
    const away = (e: MouseEvent) => { if (!box.current?.contains(e.target as Node)) setOpen(false); };
    const esc = (e: KeyboardEvent) => { if (e.key === "Escape") setOpen(false); };
    document.addEventListener("mousedown", away);
    window.addEventListener("keydown", esc);
    return () => { document.removeEventListener("mousedown", away); window.removeEventListener("keydown", esc); };
  }, []);

  const enc = encodeURIComponent;
  const targets = [
    { name: "WhatsApp", mark: "W", bg: "#25D366", href: `https://wa.me/?text=${enc(text + " " + url)}` },
    { name: "Telegram", mark: "T", bg: "#27A7E7", href: `https://t.me/share/url?url=${enc(url)}&text=${enc(text)}` },
    { name: "X", mark: "X", bg: "#111", href: `https://twitter.com/intent/tweet?url=${enc(url)}&text=${enc(text)}` },
    { name: "Facebook", mark: "f", bg: "#1877F2", href: `https://www.facebook.com/sharer/sharer.php?u=${enc(url)}` },
    { name: "LinkedIn", mark: "in", bg: "#0A66C2", href: `https://www.linkedin.com/sharing/share-offsite/?url=${enc(url)}` },
    { name: "Email", mark: "@", bg: "#6B7280", href: `mailto:?subject=${enc(text)}&body=${enc(text + "\n" + url)}` },
  ];

  const copy = async () => {
    try { await navigator.clipboard.writeText(url); } catch {
      const ta = document.createElement("textarea"); ta.value = url; document.body.appendChild(ta); ta.select(); document.execCommand("copy"); ta.remove();
    }
    setCopied(true); onCopied?.(t("Tautan disalin")); window.setTimeout(() => setCopied(false), 1800);
  };
  const native = async () => { try { await navigator.share({ title: text, text, url }); setOpen(false); } catch { /* cancelled */ } };

  const row = "flex items-center gap-2.5 w-full px-3 py-2 text-[12.5px] text-left cursor-pointer";
  return (
    <div ref={box} className="relative">
      <button type="button" aria-label={t("Bagikan")} aria-haspopup="menu" aria-expanded={open} title={t("Bagikan")} onClick={() => setOpen((v) => !v)}
        className="flex items-center justify-center rounded-[6px] cursor-pointer shrink-0 active:scale-95"
        style={{ width: 36, height: 36, background: open ? C.border : C.inner, border: `1px solid ${C.border}`, color: C.text }}>
        <Share2 size={16} strokeWidth={1.75} />
      </button>
      {open && (
        <div role="menu" className="absolute right-0 top-[42px] z-50 w-56 py-1 rounded-[6px] shadow-xl" style={{ background: C.card, border: `1px solid ${C.border}` }}>
          <div className="px-3 pt-2 pb-1 text-[10px] uppercase tracking-[0.08em]" style={{ color: C.ter }}>{t("Bagikan")}</div>
          {canNative && (
            <button type="button" role="menuitem" className={row} style={{ color: C.text }} onClick={native}>
              <Smartphone size={15} strokeWidth={1.75} style={{ color: C.ter }} />{t("Aplikasi lain…")}
            </button>
          )}
          {targets.map((s) => (
            <a key={s.name} role="menuitem" href={s.href} target="_blank" rel="noopener noreferrer" className={row} style={{ color: C.text }} onClick={() => setOpen(false)}>
              <span className="w-[18px] h-[18px] rounded-[4px] flex items-center justify-center text-[10px] font-bold leading-none shrink-0" style={{ background: s.bg, color: "#fff" }}>{s.mark}</span>{s.name}
            </a>
          ))}
          <button type="button" role="menuitem" className={row} style={{ color: C.text, borderTop: `1px solid ${C.border}` }} onClick={copy}>
            {copied ? <Check size={15} strokeWidth={2} style={{ color: C.teal }} /> : <Link2 size={15} strokeWidth={1.75} style={{ color: C.ter }} />}
            {copied ? t("Tautan disalin") : t("Salin tautan")}
          </button>
          <p className="px-3 py-2 text-[10.5px] leading-snug" style={{ color: C.ter }}>{t("Hanya tautan aplikasi yang dibagikan, bukan data workspace Anda.")}</p>
        </div>
      )}
    </div>
  );
}
