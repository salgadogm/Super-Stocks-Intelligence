import { Info } from "lucide-react";
import { Notice } from "../ui";
import { useT } from "../i18n";

export function YearDisclaimer() {
  const { t: tr } = useT();
  return (
    <Notice tone="amber" icon={Info}>
      {tr("Masukkan laporan keuangan dengan jumlah dan rentang tahun yang sama untuk setiap emiten (mis. 2020–2024 vs 2020–2024). Laporan bulanan tahun berjalan boleh ditambahkan (mis. 2021–2025 + Jan 2026) asalkan minimal 2 emiten memiliki bulan, tanggal, dan jumlah laporan yang identik. Rentang berbeda seperti 3 tahun vs 4 tahun, atau 2015–2020 vs 2020–2025, tidak apple-to-apple dan komparasinya akan diblokir.")}
    </Notice>
  );
}
