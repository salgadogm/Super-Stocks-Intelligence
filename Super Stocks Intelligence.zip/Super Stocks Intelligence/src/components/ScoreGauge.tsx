// Half-circle gauge for the 0-100 Model Score, zoned by the three output categories (cut points 35 and 65).
import { ZONES, CATEGORY_COLOR, categoryOf } from "../domain/engine";
import { palette as C } from "../theme";
import { fmtNum, tx } from "../ui";
import { getLang } from "../domain/preferences";
import { translate } from "../i18n";

const CX = 100, CY = 100, R = 78;
const pt = (s: number, r = R) => {
  const th = Math.PI * (1 - Math.min(100, Math.max(0, s)) / 100);
  return [CX + r * Math.cos(th), CY - r * Math.sin(th)] as const;
};
const arc = (from: number, to: number) => {
  const [x1, y1] = pt(from), [x2, y2] = pt(to);
  return `M${x1.toFixed(2)} ${y1.toFixed(2)} A${R} ${R} 0 0 1 ${x2.toFixed(2)} ${y2.toFixed(2)}`;
};

export default function ScoreGauge({ score, width = 220, label = "Skor Model", showCategory = true }: {
  score: number; width?: number; label?: string; showCategory?: boolean;
}) {
  const cat = categoryOf(score);
  const color = CATEGORY_COLOR[cat];
  const name = translate(getLang(), cat);
  return (
    <figure className="m-0 flex flex-col items-center" style={{ width }}
      role="img" aria-label={`${translate(getLang(), label)} ${fmtNum(score)}, ${name}`}>
      <svg viewBox="0 0 200 116" width={width} aria-hidden>
        <path d={arc(0, 100)} fill="none" stroke={C.inner} strokeWidth={14} strokeLinecap="round" />
        {ZONES.map((z) => (
          <path key={z.name} d={arc(z.from + 0.6, z.to - 0.6)} fill="none" stroke={z.color} strokeWidth={14}
            opacity={z.name === cat ? 1 : 0.28} />
        ))}
        {[35, 65].map((s) => {
          const [x, y] = pt(s, R + 14);
          return <text key={s} x={x} y={y + 3} textAnchor="middle" fontSize="8" fill={C.ter}>{s}</text>;
        })}
        <g style={{ transform: `rotate(${(score / 100) * 180}deg)`, transformOrigin: `${CX}px ${CY}px`, transition: "transform 700ms cubic-bezier(.2,.8,.2,1)" }}>
          <line x1={CX - 54} y1={CY} x2={CX - 20} y2={CY} stroke={C.text} strokeWidth={2.5} strokeLinecap="round" />
        </g>
        <circle cx={CX} cy={CY} r={5} fill={C.text} />
        <circle cx={CX} cy={CY} r={2} fill={C.card} />
      </svg>
      <figcaption className="-mt-2 flex flex-col items-center gap-0.5">
        <span className="text-[28px] font-semibold tnum leading-none" style={{ color }}>{fmtNum(score)}</span>
        <span className="text-[11px]" style={{ color: C.ter }}>{tx(label)}</span>
        {showCategory && <span className="text-[12px] font-semibold mt-1" style={{ color }}>{name}</span>}
      </figcaption>
    </figure>
  );
}
