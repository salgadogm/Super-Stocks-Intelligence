import { useState } from "react";
import { Check, X, Upload, Library, ShieldCheck, Gauge } from "lucide-react";
import { canManageCollection, getRole } from "../domain/news";
import { useWorkspace } from "../domain/store";
import { T, Panel, Btn } from "../ui";
import { useT } from "../i18n";

const KEY = "aurevia.onboarding.v1";

export default function GettingStarted({ onNavigate }: { onNavigate: (p: string) => void }) {
  const ws = useWorkspace();
  const { t } = useT();
  const [hidden, setHidden] = useState(() => { try { return localStorage.getItem(KEY) === "done"; } catch { return false; } });

  const admin = canManageCollection(getRole());
  const uploaded = ws.documents.some((d) => !(d as { demo?: boolean }).demo);
  const verified = ws.documents.some((d) => { const p = ws.progress(d.id); return p.total > 0 && p.verified >= p.total; });
  const scored = ws.analyses.some((a) => !a.demo);
  const steps = [
    admin
      ? { done: uploaded, icon: Upload, title: "Unggah laporan keuangan", why: "P&L dan Posisi Keuangan; identitas emiten wajib dicek manual.", cta: "Upload Laporan" }
      : { done: uploaded, icon: Library, title: "Pilih laporan dari koleksi", why: "Admin mengisi koleksi secara berkala; Anda menarik laporan dan angkanya diisi otomatis.", cta: "Perpustakaan Laporan" },
    { done: verified, icon: ShieldCheck, title: "Verifikasi 9 akun", why: "Setiap angka yang diusulkan otomatis dicek terhadap halaman sumber.", cta: "Verifikasi Ekstraksi AI" },
    { done: scored, icon: Gauge, title: "Hitung Skor Model", why: "Rasio dan Fuzzy Mamdani dihitung deterministik dari akun terverifikasi.", cta: "Skor & Defuzzifikasi" },
  ];
  if (hidden || steps.every((s) => s.done)) return null;
  const next = steps.findIndex((s) => !s.done);
  const dismiss = () => { try { localStorage.setItem(KEY, "done"); } catch { /* ignore */ } setHidden(true); };

  return (
    <Panel title="Mulai dalam 3 langkah" right={<button type="button" aria-label={t("Tutup panduan")} onClick={dismiss} style={{ color: T.ter }}><X size={14} /></button>}>
      <ol className="grid grid-cols-1 md:grid-cols-3 gap-3">
        {steps.map((s, i) => {
          const Icon = s.icon;
          return (
            <li key={s.title} className="flex flex-col gap-2 p-3 rounded-[6px]"
              style={{ background: T.inner, border: `1px solid ${i === next ? T.teal : T.line}` }}>
              <div className="flex items-center gap-2 text-[13px] font-semibold">
                <span className="w-5 h-5 rounded-full flex items-center justify-center shrink-0"
                  style={{ background: s.done ? T.teal : "transparent", border: `1px solid ${s.done ? T.teal : T.input}`, color: T.onAccent }}>
                  {s.done ? <Check size={12} strokeWidth={2.5} /> : <span className="text-[10px]" style={{ color: T.sub }}>{i + 1}</span>}
                </span>
                <Icon size={14} strokeWidth={1.75} style={{ color: T.sub }} />{t(s.title)}
              </div>
              <p className="text-[12px] leading-relaxed" style={{ color: T.ter }}>{t(s.why)}</p>
              {i === next && <Btn kind="primary" className="self-start" onClick={() => onNavigate(s.cta)}>{s.cta === "Upload Laporan" ? "Mulai upload" : s.cta === "Perpustakaan Laporan" ? "Pilih laporan" : "Lanjutkan"}</Btn>}
            </li>
          );
        })}
      </ol>
    </Panel>
  );
}
