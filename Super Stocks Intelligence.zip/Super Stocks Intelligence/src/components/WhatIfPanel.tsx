// Quick what-if: nudge the most influential ratios and see the engine's score. Never persisted to the workspace.
import { useEffect, useMemo, useState } from "react";
import { FlaskConical, RotateCcw, Plus, X, ArrowRight } from "lucide-react";
import { VAR_KEYS, VAR_DEFS, computeFuzzy, categoryOf, type VarKey } from "../domain/engine";
import type { AnalysisRecord } from "../domain/store";
import { T, Panel, Btn, Badge, CategoryBadge, fmtNum } from "../ui";
import { useT } from "../i18n";
import ScoreGauge from "./ScoreGauge";
import Term from "./Term";

type Vals = Record<VarKey, number>;
interface Scenario { id: number; vals: Vals; score: number }
const MAX_SCENARIOS = 3;

export default function WhatIfPanel({ analysis, onOpenFull }: { analysis: AnalysisRecord; onOpenFull?: () => void }) {
  const { t } = useT();
  const base = analysis.ratios as Vals;
  const [vals, setVals] = useState<Vals>({ ...base });
  const [saved, setSaved] = useState<Scenario[]>([]);
  const [seq, setSeq] = useState(1);
  useEffect(() => { setVals({ ...base }); setSaved([]); }, [analysis.id]);

  const live = useMemo(() => computeFuzzy(vals).score, [vals]);
  const baseScore = analysis.score;
  const changed = VAR_KEYS.filter((k) => Math.abs(vals[k] - base[k]) > 1e-9);
  const top = useMemo(() => VAR_KEYS.map((k) => {
    const [lo, hi] = VAR_DEFS[k].domain;
    const moved = { ...base, [k]: Math.min(hi, Math.max(lo, base[k] + 0.2 * (hi - lo))) };
    return { k, sens: Math.abs(computeFuzzy(moved).score - baseScore) };
  }).sort((a, b) => b.sens - a.sens).slice(0, 3).map((x) => x.k), [analysis.id]);

  const shown = [...new Set([...top, ...changed])];
  const delta = live - baseScore;
  const catChanged = categoryOf(live) !== analysis.category;
  const save = () => {
    if (!changed.length || saved.length >= MAX_SCENARIOS) return;
    setSaved((s) => [...s, { id: seq, vals: { ...vals }, score: live }]);
    setSeq((n) => n + 1);
  };

  return (
    <Panel title="Simulasi cepat (what-if)" icon={FlaskConical}
      right={changed.length ? <Badge tone="amber">Simulasi — tidak disimpan</Badge> : <Badge tone="teal">Nilai aktual</Badge>}>
      <div className="grid grid-cols-1 md:grid-cols-[auto_1fr] gap-5 items-center">
        <div className="flex justify-center"><ScoreGauge score={live} width={190} label={changed.length ? "Skor simulasi" : "Skor Model"} /></div>
        <div className="flex flex-col gap-3 min-w-0">
          {shown.map((k) => {
            const [lo, hi] = VAR_DEFS[k].domain;
            const dirty = Math.abs(vals[k] - base[k]) > 1e-9;
            return (
              <label key={k} className="flex flex-col gap-1">
                <span className="flex items-baseline justify-between text-[12px]">
                  <span><span className="font-semibold"><Term term={k} /></span> <span style={{ color: T.ter }}>{VAR_DEFS[k].label}</span></span>
                  <span className="tnum" style={{ color: dirty ? T.amber : T.sub }}>
                    {dirty && <span style={{ color: T.ter }}>{fmtNum(base[k], 1)} → </span>}{fmtNum(vals[k], 1)}{VAR_DEFS[k].unit}
                  </span>
                </span>
                <input type="range" min={lo} max={hi} step={(hi - lo) / 200} value={Math.min(hi, Math.max(lo, vals[k]))}
                  onChange={(e) => setVals((v) => ({ ...v, [k]: Number(e.target.value) }))}
                  aria-label={`${k} ${VAR_DEFS[k].label}`} className="w-full" style={{ accentColor: "var(--c-teal)" }} />
              </label>
            );
          })}
          <div className="flex items-center gap-2 flex-wrap text-[12px]">
            <span className="tnum" style={{ color: delta === 0 ? T.sub : delta > 0 ? T.teal : T.red }}>
              {delta > 0 ? "▲" : delta < 0 ? "▼" : "•"} {fmtNum(Math.abs(delta), 1)} {t("poin")}
            </span>
            {catChanged && <span className="flex items-center gap-1.5"><CategoryBadge cat={analysis.category} /><ArrowRight size={12} style={{ color: T.ter }} /><CategoryBadge cat={categoryOf(live)} /></span>}
            <span className="ml-auto flex gap-2">
              <Btn icon={Plus} disabled={!changed.length || saved.length >= MAX_SCENARIOS} onClick={save}>Simpan skenario</Btn>
              <Btn icon={RotateCcw} disabled={!changed.length} onClick={() => setVals({ ...base })}>Reset</Btn>
            </span>
          </div>
        </div>
      </div>

      {saved.length > 0 && (
        <div className="mt-4 pt-3" style={{ borderTop: `1px solid ${T.line}` }}>
          <div className="text-[10.5px] uppercase mb-2" style={{ color: T.ter }}>{t("Skenario tersimpan sementara")} ({saved.length}/{MAX_SCENARIOS})</div>
          <div className="flex flex-col gap-1.5">
            {saved.map((s, i) => {
              const d = s.score - baseScore;
              const diff = VAR_KEYS.filter((k) => Math.abs(s.vals[k] - base[k]) > 1e-9).map((k) => `${k} ${fmtNum(s.vals[k], 1)}${VAR_DEFS[k].unit}`).join(" · ");
              return (
                <div key={s.id} className="flex items-center gap-3 text-[12px] px-3 py-2 rounded-[4px]" style={{ background: T.inner, border: `1px solid ${T.line}` }}>
                  <span className="font-semibold">{t("Skenario")} {i + 1}</span>
                  <span className="truncate flex-1" style={{ color: T.sub }}>{diff}</span>
                  <span className="tnum font-semibold">{fmtNum(s.score, 1)}</span>
                  <span className="tnum w-14 text-right" style={{ color: d >= 0 ? T.teal : T.red }}>{d >= 0 ? "▲" : "▼"} {fmtNum(Math.abs(d), 1)}</span>
                  <CategoryBadge cat={categoryOf(s.score)} />
                  <button type="button" aria-label={t("Hapus skenario")} onClick={() => setSaved((x) => x.filter((y) => y.id !== s.id))} style={{ color: T.ter }}><X size={13} /></button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      <div className="flex items-center gap-3 mt-3 flex-wrap">
        <span className="text-[11px] leading-relaxed" style={{ color: T.ter }}>{t("Hanya 3 rasio paling berpengaruh yang ditampilkan. Simulasi dihitung ulang oleh mesin Fuzzy Mamdani dan tidak mengubah hasil tersimpan.")}</span>
        {onOpenFull && <Btn kind="ghost" className="ml-auto" onClick={onOpenFull}>{t("Buka simulasi penuh")} <ArrowRight size={13} /></Btn>}
      </div>
    </Panel>
  );
}
