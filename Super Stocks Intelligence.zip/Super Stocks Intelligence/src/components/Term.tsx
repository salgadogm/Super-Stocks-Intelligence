import { useId, useState, type ReactNode } from "react";
import { GLOSSARY } from "../domain/glossary";
import { palette as C } from "../theme";
import { useT } from "../i18n";

export default function Term({ term, children }: { term: string; children?: ReactNode }) {
  const { t } = useT();
  const [open, setOpen] = useState(false);
  const id = useId();
  const def = GLOSSARY[term];
  if (!def) return <>{children ?? term}</>;
  return (
    <span className="relative inline-block" onMouseEnter={() => setOpen(true)} onMouseLeave={() => setOpen(false)}>
      <span tabIndex={0} aria-describedby={open ? id : undefined} onFocus={() => setOpen(true)} onBlur={() => setOpen(false)}
        onKeyDown={(e) => { if (e.key === "Escape") setOpen(false); }}
        style={{ borderBottom: `1px dotted ${C.ter}`, cursor: "help" }}>{children ?? term}</span>
      {open && (
        <span id={id} role="tooltip" className="absolute left-0 top-full mt-1 z-50 w-64 px-3 py-2 rounded-[6px] text-[11.5px] leading-relaxed font-normal normal-case tracking-normal shadow-xl"
          style={{ background: C.card, border: `1px solid ${C.border}`, color: C.text }}>{t(def)}</span>
      )}
    </span>
  );
}
