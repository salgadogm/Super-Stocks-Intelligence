import { Component, type ReactNode } from "react";
import { AlertTriangle } from "lucide-react";
import { palette as C, alpha } from "../theme";
import { translate } from "../i18n";
import { getLang } from "../domain/preferences";

type Props = { children: ReactNode; scope?: "page" | "root" };
type State = { error: Error | null };

export default class ErrorBoundary extends Component<Props, State> {
  state: State = { error: null };

  static getDerivedStateFromError(error: Error): State {
    return { error };
  }

  componentDidCatch(error: Error) {
    console.error("[SSI] render error:", error);
  }

  render() {
    const { error } = this.state;
    if (!error) return this.props.children;
    const L = (s: string) => translate(getLang(), s);
    return (
      <div
        className="flex items-start gap-3 rounded-[8px] px-5 py-4 max-w-2xl"
        style={{ background: alpha(C.red, 8), border: `1px solid ${alpha(C.red, 30)}`, color: C.text }}
        role="alert"
      >
        <AlertTriangle size={18} strokeWidth={1.75} style={{ color: C.red, flexShrink: 0, marginTop: 1 }} />
        <div className="flex flex-col gap-2">
          <div className="text-[13px] font-bold">{L("Halaman ini gagal ditampilkan")}</div>
          <div className="text-[12px] leading-relaxed" style={{ color: C.sub }}>
            {L("Terjadi kesalahan tak terduga. Data Anda tidak hilang. Coba muat ulang, atau pindah ke halaman lain.")}
          </div>
          <code className="text-[11px] break-words" style={{ color: C.ter }}>{error.message}</code>
          <button
            onClick={() => (this.props.scope === "root" ? window.location.reload() : this.setState({ error: null }))}
            className="self-start h-8 px-3 rounded-[4px] text-[12px] font-medium"
            style={{ background: C.inner, border: `1px solid ${C.input}`, color: C.text }}
          >
            {L(this.props.scope === "root" ? "Muat ulang" : "Coba lagi")}
          </button>
        </div>
      </div>
    );
  }
}
