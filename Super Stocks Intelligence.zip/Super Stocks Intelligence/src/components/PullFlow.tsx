import { useState } from "react";
import { AlertTriangle, Library, Upload, X } from "lucide-react";
import { useWorkspace, docLabel, YearMismatchError, type DocRecord } from "../domain/store";
import { monthName } from "../domain/financial";
import { canManageCollection, getRole } from "../domain/news";
import { useT } from "../i18n";
import { T, Btn } from "../ui";

export type Pulling = { id: string; stage: string; done?: number; total?: number };

/** Shared pull flow: runs the stored-PDF extraction for one or more documents and freezes on a year mismatch. */
export function usePull(onNavigate: (p: string) => void, userKey: string) {
  const { t } = useT();
  const ws = useWorkspace();
  const [pulling, setPulling] = useState<Pulling | null>(null);
  const [pullError, setPullError] = useState<string | null>(null);
  const [mismatch, setMismatch] = useState<{ doc: DocRecord; err: YearMismatchError } | null>(null);

  const run = async (docs: DocRecord[]) => {
    if (pulling || !docs.length) return;
    setPullError(null);
    for (const d of docs) {
      setPulling({ id: d.id, stage: "reading" });
      try {
        await ws.pullFromCollection(d.id, userKey, (p) => setPulling({ id: d.id, stage: p.stage, done: p.done, total: p.total }));
      } catch (e) {
        setPulling(null);
        if (e instanceof YearMismatchError) setMismatch({ doc: d, err: e });
        else setPullError(`${docLabel(d)}: ${e instanceof Error ? e.message : t("Laporan gagal dianalisis. Coba lagi atau isi manual di Verifikasi.")}`);
        return;
      }
    }
    setPulling(null);
    ws.setFocusDoc(docs[0].id);
    onNavigate("Verifikasi Ekstraksi AI");
  };

  return { pulling, pullError, setPullError, mismatch, closeMismatch: () => setMismatch(null), run };
}

/** Blocking dialog: nothing behind it is clickable and there is no "continue" action until the data is fixed. */
export function YearMismatchDialog({ doc, err, onClose, onNavigate }: { doc: DocRecord; err: YearMismatchError; onClose: () => void; onNavigate: (p: string) => void }) {
  const { t } = useT();
  const admin = canManageCollection(getRole());
  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4" style={{ background: "rgba(0,0,0,0.66)" }}>
      <div role="alertdialog" aria-modal="true" aria-labelledby="ym-title" className="w-full max-w-[480px] rounded-[8px] p-5 flex flex-col gap-3"
        style={{ background: T.card, border: `1px solid ${T.red}` }}>
        <div className="flex items-start gap-3">
          <AlertTriangle size={20} style={{ color: T.red }} className="shrink-0 mt-0.5" />
          <div className="flex-1 min-w-0">
            <h2 id="ym-title" className="text-[14px] font-semibold">{t("Proses dihentikan: tahun laporan tidak cocok")}</h2>
            <p className="text-[12px] mt-1 leading-relaxed" style={{ color: T.sub }}>{docLabel(doc)}: {err.months ? t("Teks PDF menunjukkan periode {f}, tetapi dokumen ini terdaftar sebagai periode {e}.", { f: `${monthName(err.months.found)} ${err.found}`, e: `${monthName(err.months.expected)} ${err.expected}` }) : t(err.source === "ai" ? "AI membaca kolom tahun {f}, tetapi dokumen ini terdaftar sebagai FY {e}." : "Teks PDF menunjukkan tahun {f}, tetapi dokumen ini terdaftar sebagai FY {e}.", { f: err.found, e: err.expected })}</p>
          </div>
          <button onClick={onClose} aria-label={t("Tutup")} className="p-1" style={{ color: T.ter }}><X size={16} /></button>
        </div>
        <p className="text-[12px] leading-relaxed rounded-[4px] px-3 py-2" style={{ background: T.inner, color: T.sub }}>
          {t("Tidak ada angka yang diisi. Komparasi hanya valid bila data tiap tahun benar-benar sesuai. Sesuaikan data terlebih dahulu, lalu jalankan analisis lagi.")}
        </p>
        <div className="flex flex-wrap gap-2 justify-end">
          {admin
            ? <Btn kind="primary" icon={Upload} onClick={() => { onClose(); onNavigate("Upload Laporan"); }}>{t("Sesuaikan data (Upload Laporan)")}</Btn>
            : <Btn kind="primary" icon={Library} onClick={() => { onClose(); onNavigate("Folder Laporan"); }}>{t("Sesuaikan data (Folder Laporan)")}</Btn>}
          <Btn onClick={onClose}>{t("Tutup")}</Btn>
        </div>
      </div>
    </div>
  );
}
