// SSI avatar set — 12 geometric marks drawn from banking and finance.
// Each is a 40×40 SVG on a tinted tile; strokes stay thin to match the terminal UI.
import type { ReactNode } from "react";

export interface AvatarDef { id: string; name: string; fg: string; bg: string; draw: ReactNode }

const s = { fill: "none", strokeWidth: 1.8, strokeLinecap: "round", strokeLinejoin: "round" } as const;

export const AVATARS: AvatarDef[] = [
  { id: "bank", name: "Bank", fg: "#5B9BFF", bg: "#12203A", draw: <g {...s} stroke="currentColor">
    <path d="M6 15L20 7l14 8z" fill="currentColor" fillOpacity=".2" /><path d="M10 18v11M17 18v11M23 18v11M30 18v11" /><path d="M7 32h26M9 29h22" /></g> },
  { id: "vault", name: "Brankas", fg: "#4FD1C5", bg: "#0F2A2A", draw: <g {...s} stroke="currentColor">
    <rect x="7" y="8" width="26" height="24" rx="3" /><circle cx="20" cy="20" r="6.5" /><path d="M20 16v8M16 20h8" opacity=".55" /><path d="M12 32v2M28 32v2" /></g> },
  { id: "coin", name: "Koin", fg: "#F0B93E", bg: "#2C2210", draw: <g {...s} stroke="currentColor">
    <circle cx="20" cy="20" r="12" fill="currentColor" fillOpacity=".15" /><circle cx="20" cy="20" r="8" opacity=".5" /><path d="M20 14v12M17 17.5c0-2.5 6-2.5 6 0s-6 2-6 4.5 6 2.5 6 0" /></g> },
  { id: "card", name: "Kartu", fg: "#6FA8FF", bg: "#14203A", draw: <g {...s} stroke="currentColor">
    <rect x="6" y="10" width="28" height="20" rx="3" /><path d="M6 16h28" strokeWidth="4" opacity=".5" /><path d="M11 24h7M11 27h4" /><circle cx="28" cy="25" r="2" fill="currentColor" fillOpacity=".4" /></g> },
  { id: "rate", name: "Kurva Suku Bunga", fg: "#3FBF8A", bg: "#0F2A20", draw: <g {...s} stroke="currentColor">
    <path d="M7 8v24h26" opacity=".55" /><path d="M9 28c6 0 6-14 12-14s6 8 11 8" /><circle cx="32" cy="22" r="2" fill="currentColor" /></g> },
  { id: "shield", name: "Perisai Risiko", fg: "#3DB9D3", bg: "#0F2630", draw: <g {...s} stroke="currentColor">
    <path d="M20 7l11 4v8c0 7-5 12-11 14-6-2-11-7-11-14v-8z" fill="currentColor" fillOpacity=".12" /><path d="M14 20l4 4 8-8" /></g> },
  { id: "tower", name: "Gedung Kantor", fg: "#8CB4E8", bg: "#161F2E", draw: <g {...s} stroke="currentColor">
    <path d="M10 33V14h10v19M20 33V8h10v25" /><path d="M5 33h30" /><path d="M13 18h4M13 23h4M13 28h4M23 13h4M23 18h4M23 23h4M23 28h4" opacity=".55" /></g> },
  { id: "credit", name: "Tren Kredit", fg: "#58C98B", bg: "#10291D", draw: <g {...s} stroke="currentColor">
    <path d="M9 31v-6M17 31v-11M25 31v-8M33 31V13" strokeWidth="3.2" opacity=".6" /><path d="M7 20l9-6 7 3 10-9" /><path d="M28 8h5v5" /></g> },
  { id: "network", name: "Jaring Transaksi", fg: "#4FC7C0", bg: "#0F2829", draw: <g {...s} stroke="currentColor">
    <path d="M20 12L9 27M20 12l11 15M9 27h22M20 12v7M20 19L9 27M20 19l11 8" opacity=".55" /><circle cx="20" cy="11" r="3.2" fill="currentColor" fillOpacity=".3" /><circle cx="9" cy="28" r="3.2" fill="currentColor" fillOpacity=".3" /><circle cx="31" cy="28" r="3.2" fill="currentColor" fillOpacity=".3" /></g> },
  { id: "bell", name: "Lonceng Pasar", fg: "#F2C14E", bg: "#2A2210", draw: <g {...s} stroke="currentColor">
    <path d="M10 28c2-2 3-5 3-9a7 7 0 0 1 14 0c0 4 1 7 3 9z" fill="currentColor" fillOpacity=".15" /><path d="M20 8v4M17 31a3 3 0 0 0 6 0" /></g> },
  { id: "ledger", name: "Neraca", fg: "#63D6A5", bg: "#0F2A22", draw: <g {...s} stroke="currentColor">
    <path d="M9 8h20a2 2 0 0 1 2 2v22H11a2 2 0 0 1-2-2z" /><path d="M20 8v24" opacity=".55" /><path d="M13 14h4M13 19h4M13 24h4M24 14h4M24 19h4M24 24h4" opacity=".7" /></g> },
  { id: "bear", name: "Timbangan", fg: "#E3B65B", bg: "#2A2212", draw: <g {...s} stroke="currentColor">
    <path d="M20 8v24M12 32h16M8 14h24" /><path d="M8 14l-3 8h6zM32 14l-3 8h6z" /><path d="M5 22a3 3 0 0 0 6 0M29 22a3 3 0 0 0 6 0" /></g> },
];

/** Old mining-era ids keep resolving to a banking equivalent. */
const LEGACY_ALIAS: Record<string, string> = {
  crystal: "network", gold: "coin", copper: "rate", mine: "tower", tin: "vault",
  silver: "card", diamond: "shield", ore: "credit", pickaxe: "bell", platinum: "bank",
};

export const avatarById = (id: string) => {
  const key = LEGACY_ALIAS[id] ?? id;
  return AVATARS.find((a) => a.id === key);
};

export default function Avatar({ id, name, size = 28 }: { id?: string; name: string; size?: number }) {
  const a = id ? avatarById(id) : undefined;
  if (a) return (
    <span className="inline-flex items-center justify-center rounded-full shrink-0 overflow-hidden"
      style={{ width: size, height: size, background: `color-mix(in srgb, ${a.fg} 16%, var(--c-card))`, color: `color-mix(in srgb, ${a.fg} 72%, var(--c-text))`, boxShadow: `inset 0 0 0 1px color-mix(in srgb, ${a.fg} 30%, transparent)` }}>
      <svg viewBox="0 0 40 40" width={size * 0.78} height={size * 0.78} aria-hidden>{a.draw}</svg>
    </span>
  );
  const initials = name.trim().split(/\s+/).map((w) => w[0]).slice(0, 2).join("").toUpperCase() || "IN";
  return (
    <span className="inline-flex items-center justify-center rounded-full shrink-0 font-semibold"
      style={{ width: size, height: size, background: "var(--c-inner)", border: "1px solid var(--c-line)", color: "var(--c-sub)", fontSize: size * 0.39 }}>{initials}</span>
  );
}

/* Profile banner: a wide motif matching each avatar, tinted by the avatar colour and theme-aware. */
const ln = { fill: "none", stroke: "currentColor", strokeWidth: 1.4, strokeLinecap: "round", strokeLinejoin: "round" } as const;
const range = (n: number) => Array.from({ length: n }, (_, i) => i);

const MOTIFS: Record<string, ReactNode> = {
  bank: <g {...ln}><path d="M250 40 L330 14 L410 40z" fill="currentColor" fillOpacity=".14" opacity=".7" />
    {range(5).map((i) => <path key={i} d={`M${266 + i * 30} 44 V84`} strokeWidth={3} opacity=".35" />)}<path d="M244 90H416M252 84H408" opacity=".5" />
    {range(6).map((i) => <path key={`g${i}`} d={`M${i * 40} 0 V96`} opacity=".08" />)}</g>,
  vault: <g {...ln}>{range(6).map((i) => <circle key={i} cx="320" cy="48" r={10 + i * 16} opacity={0.45 - i * 0.06} strokeDasharray={i % 2 ? "4 6" : undefined} />)}
    {range(8).map((i) => <path key={`s${i}`} d={`M320 48 L${320 + Math.cos(i * Math.PI / 4) * 36} ${48 + Math.sin(i * Math.PI / 4) * 36}`} opacity=".4" />)}<circle cx="320" cy="48" r="4" fill="currentColor" /></g>,
  coin: <g {...ln}>{range(5).map((i) => <ellipse key={i} cx={250 + i * 30} cy={78 - i * 10} rx="34" ry="9" fill="currentColor" fillOpacity={0.06 + i * 0.03} opacity=".6" />)}
    <circle cx="340" cy="30" r="18" opacity=".5" /><circle cx="340" cy="30" r="12" opacity=".3" /></g>,
  card: <g {...ln}><rect x="230" y="18" width="130" height="80" rx="10" transform="rotate(-10 295 58)" fill="currentColor" fillOpacity=".1" opacity=".6" />
    <rect x="260" y="10" width="130" height="80" rx="10" transform="rotate(8 325 50)" opacity=".5" /><path d="M262 34 H386" strokeWidth={9} opacity=".2" transform="rotate(8 325 50)" />
    {range(4).map((i) => <path key={`g${i}`} d={`M0 ${i * 28 + 10} H400`} opacity=".08" />)}</g>,
  rate: <g {...ln}>{range(5).map((i) => <path key={i} d={`M0 ${16 + i * 18} H400`} opacity=".1" />)}
    <path d="M0 80 C60 80 80 30 150 32 S230 70 290 50 S360 20 400 22" strokeWidth={2} opacity=".7" />
    <path d="M0 88 C70 86 100 52 160 52 S250 80 310 66 S370 40 400 42" opacity=".3" /><circle cx="290" cy="50" r="4" fill="currentColor" /></g>,
  shield: <g {...ln}><path d="M320 6l56 20v34c0 26-24 40-56 48-32-8-56-22-56-48V26z" fill="currentColor" fillOpacity=".1" opacity=".7" />
    <path d="M320 24l38 14v22c0 16-16 26-38 32-22-6-38-16-38-32V38z" opacity=".4" /><path d="M300 52l14 14 26-26" strokeWidth={2.2} opacity=".7" /></g>,
  tower: <g {...ln}>{[[20, 60, 40], [70, 36, 36], [116, 52, 30], [190, 24, 44], [244, 44, 34], [292, 14, 46], [346, 40, 38]].map(([x, y, w], i) => <g key={i}>
      <path d={`M${x} 96 V${y} h${w} V96`} fill="currentColor" fillOpacity={0.05 + (i % 3) * 0.04} opacity=".6" />
      {range(Math.floor((96 - y) / 14)).map((j) => <path key={j} d={`M${x + 6} ${y + 10 + j * 14} h${w - 12}`} opacity=".18" />)}</g>)}</g>,
  credit: <g {...ln}>{range(10).map((i) => <path key={i} d={`M${30 + i * 38} 96 V${80 - i * 5 - (i % 2) * 8}`} strokeWidth={14} opacity={0.08 + i * 0.012} />)}
    <path d="M0 78 L60 66 L120 70 L190 44 L250 50 L320 24 L400 8" strokeWidth={2} opacity=".7" /><path d="M370 6h30v22" opacity=".5" /></g>,
  network: <g {...ln}>{[[240, 20], [300, 60], [360, 18], [390, 70], [270, 84], [330, 40], [210, 62]].map(([x, y], i, a) => <g key={i}>
      {a.slice(i + 1).filter((_, k) => (i + k) % 2 === 0).map(([x2, y2], k) => <path key={k} d={`M${x} ${y} L${x2} ${y2}`} opacity=".3" />)}
      <circle cx={x} cy={y} r={i % 3 === 0 ? 6 : 4} fill="currentColor" fillOpacity=".3" opacity=".7" /></g>)}</g>,
  bell: <g {...ln}>{range(6).map((i) => <path key={i} d={`M${300 - i * 4} ${84} C${296 - i * 4} 30 ${322 + i * 4} 30 ${340 + i * 4} 84z`} opacity={0.4 - i * 0.05} />)}
    <path d="M320 12 v10" opacity=".5" /><circle cx="320" cy="90" r="4" fill="currentColor" fillOpacity=".5" />
    {range(4).map((i) => <path key={`g${i}`} d={`M0 ${i * 28 + 10} H400`} opacity=".08" />)}</g>,
  ledger: <g {...ln}>{range(6).map((i) => <path key={i} d={`M0 ${14 + i * 15} H400`} opacity=".14" />)}{range(4).map((i) => <path key={i} d={`M${90 + i * 100} 0 V96`} opacity=".1" />)}
    <path d="M20 80 L110 64 L200 70 L300 36 L390 28" strokeWidth={2} opacity=".6" /></g>,
  bear: <g {...ln}><path d="M200 18 V92M140 92 H260M80 30 H320" opacity=".5" />
    <path d="M80 30 l-26 46 h52z M320 30 l-26 46 h52z" fill="currentColor" fillOpacity=".1" opacity=".6" />
    <path d="M54 76a26 8 0 0 0 52 0M294 76a26 8 0 0 0 52 0" opacity=".5" /><circle cx="200" cy="18" r="4" fill="currentColor" /></g>,
  "": <g {...ln}>{range(10).map((i) => <path key={i} d={`M${i * 44} 0 V96`} opacity=".1" />)}{range(3).map((i) => <path key={i} d={`M0 ${i * 32 + 16} H400`} opacity=".1" />)}</g>,
};

export function ProfileBanner({ id, className = "", height = 96 }: { id?: string; className?: string; height?: number }) {
  const a = id ? avatarById(id) : undefined;
  const fg = a?.fg ?? "var(--c-teal)";
  return (
    <div className={"relative overflow-hidden " + className} aria-hidden
      style={{ height, color: `color-mix(in srgb, ${fg} 70%, var(--c-text))`,
        background: `radial-gradient(120% 140% at 85% 0%, color-mix(in srgb, ${fg} 26%, transparent), transparent 60%), linear-gradient(120deg, color-mix(in srgb, ${fg} 14%, var(--c-card)), var(--c-card))` }}>
      <svg viewBox="0 0 400 96" preserveAspectRatio="xMidYMid slice" width="100%" height="100%" className="absolute inset-0">{MOTIFS[a?.id ?? ""]}</svg>
      <div className="absolute inset-x-0 bottom-0 h-8" style={{ background: "linear-gradient(to top, var(--c-card), transparent)" }} />
    </div>
  );
}
