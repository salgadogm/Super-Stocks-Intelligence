import { useEffect, useRef, useState } from "react";
import { useT } from "../i18n";

const A = "#20D5C2";
const A2 = "#13B8AD";
const DOWN = "#F87171";

// S-ribbon: offset cubic paths flowing bottom-left → top-right through center
const RIBBON = [
  { d: "M-40 760 C 180 700, 420 640, 430 470 C 440 300, 200 260, 330 140 C 420 60, 560 40, 760 -20", w: 1.4, o: 0.9 },
  { d: "M-40 790 C 200 730, 460 660, 465 480 C 470 310, 240 270, 365 150 C 455 70, 590 55, 760 10", w: 1, o: 0.6, dash: true },
  { d: "M-40 720 C 160 670, 385 615, 395 460 C 405 290, 165 250, 295 130 C 385 50, 530 25, 760 -50", w: 0.9, o: 0.55 },
  { d: "M-40 830 C 230 770, 505 690, 505 495 C 505 330, 285 290, 405 165 C 490 85, 620 70, 760 40", w: 0.7, o: 0.35, dash: true },
  { d: "M-40 680 C 140 640, 345 590, 360 450 C 375 285, 130 240, 260 120 C 350 40, 500 10, 760 -80", w: 0.6, o: 0.3 },
];

const RUNNERS = [
  { i: 0, dur: 7, delay: 0 },
  { i: 2, dur: 9, delay: 2.5 },
  { i: 4, dur: 6, delay: 4.5 },
];

const NODES = [
  [430, 470], [330, 140], [465, 480], [200, 700], [560, 52], [365, 150],
];

// deterministic pseudo-random for particles and candles
const rnd = (i: number) => {
  const x = Math.sin(i * 9301 + 49297) * 233280;
  return x - Math.floor(x);
};

const PARTICLES = Array.from({ length: 22 }, (_, i) => [rnd(i) * 700, rnd(i + 50) * 800, 0.4 + rnd(i + 99) * 0.9]);

const CANDLES = (() => {
  let p = 640;
  return Array.from({ length: 30 }, (_, i) => {
    const o = p;
    const c = p - 8 + rnd(i + 7) * 2 - 14 * rnd(i + 3) + 6;
    p = c;
    const hi = Math.min(o, c) - 4 - rnd(i + 11) * 10;
    const lo = Math.max(o, c) + 4 + rnd(i + 13) * 10;
    return { x: 300 + i * 13.5, o, c, hi, lo };
  });
})();

function Spark({ pts }: { pts: string }) {
  return (
    <svg width="64" height="22" viewBox="0 0 64 22" fill="none" aria-hidden>
      <polyline points={pts} stroke={A} strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round" opacity="0.85" />
    </svg>
  );
}

const reducedMotion = () => typeof window !== "undefined" && window.matchMedia("(prefers-reduced-motion: reduce)").matches;

function useTween(target: number[], ms = 700) {
  const [shown, setShown] = useState(target);
  const cur = useRef(target);
  useEffect(() => {
    const from = cur.current;
    const t0 = performance.now();
    let raf = 0;
    const tick = (now: number) => {
      const k = Math.min(1, (now - t0) / ms);
      const e = 1 - Math.pow(1 - k, 3);
      cur.current = target.map((v, i) => (from[i] ?? v) + (v - (from[i] ?? v)) * e);
      setShown(cur.current);
      if (k < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [target, ms]);
  return shown;
}

type LiveCfg = { start: number[]; every: number; step: number; min: number; max: number };

function useLive({ start, every, step, min, max }: LiveCfg) {
  const [series, setSeries] = useState(start);
  const [flash, setFlash] = useState(0);
  useEffect(() => {
    if (reducedMotion()) return;
    const mid = (min + max) / 2;
    let last = start[start.length - 1];
    let buf = start;
    let ft = 0;
    const id = setInterval(() => {
      let d = (Math.random() - 0.5) * 2 * step + (mid - last) * 0.12;
      if (Math.abs(d) < step * 0.25) d = (d < 0 ? -1 : 1) * step * 0.25;
      last = Math.min(max, Math.max(min, last + d));
      buf = [...buf.slice(1), last];
      setSeries(buf);
      setFlash(d > 0 ? 1 : -1);
      clearTimeout(ft);
      ft = window.setTimeout(() => setFlash(0), 900);
    }, every);
    return () => {
      clearInterval(id);
      clearTimeout(ft);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  const shown = useTween(series);
  const value = shown[shown.length - 1];
  const pct = (value / shown[0] - 1) * 100;
  const color = pct >= 0 ? A : DOWN;
  return { shown, value, pct, color, flash };
}

const pctLabel = (pct: number, signed: boolean) =>
  `${pct >= 0 ? "↑" : "↓"} ${signed ? (pct >= 0 ? "+" : "-") : ""}${Math.abs(pct).toFixed(1)}%`;

function LiveSpark({ series, color, width = 64, height = 22 }: { series: number[]; color: string; width?: number; height?: number }) {
  const lo = Math.min(...series);
  const span = Math.max(...series) - lo || 1;
  const pts = series.map((v, i) => `${(2 + (i * 60) / (series.length - 1)).toFixed(1)},${(20 - ((v - lo) / span) * 16).toFixed(1)}`).join(" ");
  return (
    <svg width={width} height={height} viewBox="0 0 64 22" fill="none" aria-hidden>
      <polyline points={pts} stroke={color} strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" opacity="0.9" style={{ transition: "stroke 600ms" }} />
    </svg>
  );
}

const numStyle = (flash: number) => ({ color: flash > 0 ? A : flash < 0 ? DOWN : "#F3F4F6", transition: "color 600ms" });

const BBCA_CFG: LiveCfg = { start: [73.4, 76.4, 75.2, 79, 78.6, 81, 82.4], every: 2600, step: 2, min: 74, max: 90 };
const BMRI_CFG: LiveCfg = { start: [68.9, 71, 70.4, 72.9, 72.2, 73.6, 74.8], every: 3400, step: 2.2, min: 66, max: 80 };
const KSBW_CFG: LiveCfg = { start: [59.1, 60, 59.6, 60.9, 60.6, 61.2, 61.5], every: 2100, step: 0.9, min: 56, max: 66 };

const AMBER = "#FBBF24";

const BADGE_SIZE = {
  lg: "min-w-[46px] px-2 py-0.5 text-[10px]",
  md: "min-w-[40px] px-1.5 py-px text-[9px]",
  sm: "min-w-[34px] px-1 py-px text-[8px]",
};

function LevelBadge({ value, size = "md" }: { value: number; size?: keyof typeof BADGE_SIZE }) {
  const { t } = useT();
  const [label, color] = value >= 75 ? ["Tinggi", A] : value >= 62 ? ["Sedang", AMBER] : ["Rendah", DOWN];
  return (
    <span
      className={`inline-block rounded-[4px] text-center font-medium leading-tight ${BADGE_SIZE[size]}`}
      style={{ color, background: `${color}18`, border: `1px solid ${color}40`, transition: "color 600ms, background-color 600ms, border-color 600ms" }}
    >
      {t(label)}
    </span>
  );
}

function Card({ className, delay, children }: { className: string; delay: string; children: React.ReactNode }) {
  return (
    <div
      className={`absolute ssi-float rounded-[12px] px-3.5 py-3 backdrop-blur-md ${className}`}
      style={{
        animationDelay: delay,
        background: "rgba(12,14,20,0.62)",
        border: `1px solid ${A}2e`,
        boxShadow: `0 0 24px -8px ${A}40, 0 12px 32px -12px rgba(0,0,0,0.6)`,
      }}
    >
      {children}
    </div>
  );
}

export default function AuthHeroVisual() {
  const { t } = useT();
  const bbca = useLive(BBCA_CFG);
  const bmri = useLive(BMRI_CFG);
  const ksbw = useLive(KSBW_CFG);
  return (
    <div className="pointer-events-none absolute inset-0 select-none" aria-hidden>
      {/* Layer 2: perspective grid */}
      <div
        className="absolute inset-x-[-20%] bottom-[-10%] h-[70%] origin-bottom"
        style={{
          transform: "perspective(700px) rotateX(58deg)",
          background: `linear-gradient(to right, ${A}14 1px, transparent 1px) 0 0 / 56px 56px, linear-gradient(to bottom, ${A}14 1px, transparent 1px) 0 0 / 56px 56px`,
          maskImage: "linear-gradient(to top, black 10%, transparent 85%)",
          WebkitMaskImage: "linear-gradient(to top, black 10%, transparent 85%)",
        }}
      />
      <div
        className="absolute inset-0"
        style={{
          background: `linear-gradient(to right, rgba(148,163,184,0.045) 1px, transparent 1px) 0 0 / 64px 64px, linear-gradient(to bottom, rgba(148,163,184,0.045) 1px, transparent 1px) 0 0 / 64px 64px`,
          maskImage: "radial-gradient(ellipse 70% 60% at 60% 40%, black, transparent 80%)",
          WebkitMaskImage: "radial-gradient(ellipse 70% 60% at 60% 40%, black, transparent 80%)",
        }}
      />

      <svg className="absolute inset-0 h-full w-full" viewBox="0 0 700 800" preserveAspectRatio="xMidYMid slice" fill="none">
        <defs>
          <linearGradient id="ssi-rib" x1="0" y1="800" x2="700" y2="0" gradientUnits="userSpaceOnUse">
            <stop offset="0" stopColor={A2} stopOpacity="0" />
            <stop offset="0.3" stopColor={A2} stopOpacity="0.7" />
            <stop offset="0.65" stopColor={A} />
            <stop offset="1" stopColor={A} stopOpacity="0.1" />
          </linearGradient>
          <radialGradient id="ssi-node">
            <stop offset="0" stopColor={A} stopOpacity="0.55" />
            <stop offset="1" stopColor={A} stopOpacity="0" />
          </radialGradient>
          <filter id="ssi-blur" x="-10%" y="-10%" width="120%" height="120%">
            <feGaussianBlur stdDeviation="3" />
          </filter>
          <linearGradient id="ssi-candle-fade" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0" stopColor="#fff" stopOpacity="0" />
            <stop offset="0.35" stopColor="#fff" stopOpacity="1" />
          </linearGradient>
          <mask id="ssi-candle-mask">
            <rect x="0" y="0" width="700" height="800" fill="url(#ssi-candle-fade)" />
          </mask>
        </defs>

        {/* technical guide lines + ticks */}
        <g stroke="rgba(148,163,184,0.08)" strokeWidth="1">
          <line x1="560" y1="0" x2="560" y2="800" strokeDasharray="2 6" />
          <line x1="0" y1="560" x2="700" y2="560" strokeDasharray="2 6" />
          <line x1="640" y1="0" x2="640" y2="800" />
        </g>
        <g fill="rgba(148,163,184,0.35)" fontSize="9" fontFamily="Inter, sans-serif">
          <text x="648" y="282">78.1</text>
          <text x="648" y="432">65.3</text>
          <text x="648" y="492">49.7</text>
        </g>

        {/* Layer 3: S ribbon */}
        <path d={RIBBON[0].d} stroke={A} strokeWidth="6" opacity="0.18" filter="url(#ssi-blur)" strokeLinecap="round" />
        {RIBBON.map((r, i) => (
          <path
            key={i}
            d={r.d}
            stroke="url(#ssi-rib)"
            strokeWidth={r.w}
            opacity={r.o}
            strokeLinecap="round"
            strokeDasharray={r.dash ? "3 9" : undefined}
            className={r.dash ? "ssi-dash" : undefined}
          />
        ))}

        {/* single fast light dot per solid ribbon line, each with its own timing */}
        {RUNNERS.map((r) => {
          const timing = { animationDuration: `${r.dur}s`, animationDelay: `${r.delay}s` };
          return (
            <g key={r.i}>
              <path d={RIBBON[r.i].d} pathLength={100} stroke={A} strokeWidth="5" strokeLinecap="round" strokeDasharray="1.5 200" filter="url(#ssi-blur)" className="ssi-runner" style={timing} />
              <path d={RIBBON[r.i].d} pathLength={100} stroke="#E8FFFC" strokeWidth="2" strokeLinecap="round" strokeDasharray="1.5 200" className="ssi-runner" style={timing} />
            </g>
          );
        })}

        {/* Layer 4: market chart — right-center to right-bottom */}
        <g mask="url(#ssi-candle-mask)" className="ssi-reveal">
          {CANDLES.map((k, i) => {
            const up = k.c < k.o;
            return (
              <g key={i} opacity={0.18 + (i / CANDLES.length) * 0.3}>
                <line x1={k.x} y1={k.hi} x2={k.x} y2={k.lo} stroke={A2} strokeWidth="0.8" />
                <rect
                  x={k.x - 3}
                  y={Math.min(k.o, k.c)}
                  width="6"
                  height={Math.max(2, Math.abs(k.o - k.c))}
                  rx="1"
                  fill={up ? A : "transparent"}
                  stroke={A2}
                  strokeWidth="0.8"
                />
              </g>
            );
          })}
          <polyline
            points={CANDLES.map((k) => `${k.x},${k.c + 26}`).join(" ")}
            stroke={A}
            strokeWidth="1"
            opacity="0.35"
            strokeDasharray="1 4"
            strokeLinecap="round"
          />
        </g>

        {/* particles */}
        {PARTICLES.map(([x, y, r], i) => (
          <circle key={i} cx={x} cy={y} r={r} fill={A} opacity={0.12 + (i % 4) * 0.06} />
        ))}

        {/* nodes */}
        {NODES.map(([x, y], i) => (
          <g key={i}>
            <circle cx={x} cy={y} r="10" fill="url(#ssi-node)" className="ssi-pulse" style={{ animationDelay: `${i * 0.9}s` }} />
            <circle cx={x} cy={y} r="2" fill={A} />
          </g>
        ))}
      </svg>

      {/* calm zone behind headline */}
      <div
        className="absolute inset-0"
        style={{ background: "radial-gradient(ellipse 55% 45% at 22% 50%, rgba(9,10,15,0.92), rgba(9,10,15,0.5) 55%, transparent 80%)" }}
      />
      <div className="absolute inset-0" style={{ background: "linear-gradient(to top, rgba(9,10,15,0.85), transparent 22%)" }} />

      {/* Layer 5: floating insight cards */}
      <Card className="right-[8%] top-[11%] w-[150px]" delay="0s">
        <div className="flex items-center justify-between">
          <span className="text-[12px] font-semibold text-[#F3F4F6]">BBCA</span>
          <LevelBadge value={bbca.value} size="lg" />
        </div>
        <div className="text-[9.5px] text-[#94A3B8]">{t("Skor Kelayakan")}</div>
        <div className="mt-1 flex items-end justify-between">
          <span className="text-[22px] font-semibold tabular-nums leading-none" style={numStyle(bbca.flash)}>{bbca.value.toFixed(1)}</span>
          <LiveSpark series={bbca.shown} color={bbca.color} />
        </div>
        <div className="mt-1.5 inline-flex rounded-[5px] px-1.5 py-0.5 text-[9.5px] font-medium tabular-nums" style={{ color: bbca.color, background: `${bbca.color}18`, transition: "color 600ms, background-color 600ms" }}>
          {pctLabel(bbca.pct, true)}
        </div>
      </Card>
      <Card className="right-[3%] top-[47%] w-[118px]" delay="-2.5s">
        <div className="flex items-center justify-between">
          <span className="text-[12px] font-semibold text-[#F3F4F6]">BMRI</span>
          <LevelBadge value={bmri.value} />
        </div>
        <div className="text-[9.5px] text-[#94A3B8]">{t("Skor Kelayakan")}</div>
        <div className="mt-1 flex items-end justify-between gap-1">
          <span className="text-[16px] font-semibold tabular-nums leading-none" style={numStyle(bmri.flash)}>{bmri.value.toFixed(1)}</span>
          <LiveSpark series={bmri.shown} color={bmri.color} />
        </div>
      </Card>
      <Card className="right-[7%] top-[63%] w-[124px] !px-3 !py-2.5" delay="-1.5s">
        <div className="flex items-center justify-between gap-2">
          <span className="text-[11px] font-semibold text-[#F3F4F6]">KSBW</span>
          <LevelBadge value={ksbw.value} size="sm" />
        </div>
        <div className="whitespace-nowrap text-[9px] text-[#94A3B8]">{t("Skor Kelayakan")}</div>
        <div className="mt-1 flex items-end justify-between gap-1">
          <span className="text-[14px] font-semibold tabular-nums leading-none" style={numStyle(ksbw.flash)}>{ksbw.value.toFixed(1)}</span>
          <LiveSpark series={ksbw.shown} color={ksbw.color} width={40} height={14} />
        </div>
        <div className="mt-1 text-[9px] font-medium tabular-nums" style={{ color: ksbw.color, transition: "color 600ms" }}>{pctLabel(ksbw.pct, false)}</div>
      </Card>
      <Card className="right-[28%] top-[66%] hidden w-[128px] xl:block" delay="-4.5s">
        <div className="text-[12px] font-semibold text-[#F3F4F6]">BBRI</div>
        <div className="text-[9.5px] text-[#94A3B8]">{t("Tingkat Risiko")}</div>
        <div className="mt-1 flex items-end justify-between gap-1">
          <span className="text-[15px] font-semibold leading-none text-[#F3F4F6]">{t("Sedang")}</span>
          <Spark pts="2,17 12,13 22,15 34,8 44,11 62,5" />
        </div>
      </Card>
    </div>
  );
}
