// Global search: issuers, pages, rules and ratios. Navigation keys stay Indonesian; only display text is translated.
import { useEffect, useId, useMemo, useRef, useState, type RefObject } from "react";
import { Search, Building2, FileText, ListChecks, Percent } from "lucide-react";
import { RULES } from "../domain/engine";
import { RATIO_DEFINITIONS } from "../domain/financial";
import { useWorkspace } from "../domain/store";
import { palette as C } from "../theme";
import { useT } from "../i18n";

interface Item { group: "Emiten" | "Halaman" | "Rule" | "Rasio"; id: string; title: string; hint?: string; page: string; ticker?: string; score: number }
const GROUP_ICON = { Emiten: Building2, Halaman: FileText, Rule: ListChecks, Rasio: Percent } as const;
const GROUP_LABEL = { Emiten: "Emiten", Halaman: "Halaman", Rule: "Rule", Rasio: "Rasio" } as const;

const rank = (hay: string, q: string) => {
  const h = hay.toLowerCase();
  if (h === q) return 100;
  if (h.startsWith(q)) return 80;
  if (h.split(/[\s/&·-]+/).some((w) => w.startsWith(q))) return 60;
  return h.includes(q) ? 40 : 0;
};

export default function SearchBox({ inputRef, pages, onGo, placeholder }: {
  inputRef: RefObject<HTMLInputElement | null>;
  pages: string[];
  onGo: (page: string, ticker?: string) => void;
  placeholder: string;
}) {
  const { t } = useT();
  const ws = useWorkspace();
  const [q, setQ] = useState("");
  const [open, setOpen] = useState(false);
  const [cursor, setCursor] = useState(0);
  const box = useRef<HTMLDivElement>(null);
  const listId = useId();

  const issuers = useMemo(() => {
    const m = new Map<string, string>();
    ws.analyses.forEach((a) => m.set(a.ticker, a.companyName));
    ws.documents.forEach((d: any) => { if (d.ticker && !m.has(d.ticker)) m.set(d.ticker, d.companyName ?? ""); });
    return [...m.entries()];
  }, [ws.analyses, ws.documents]);

  const results = useMemo(() => {
    const s = q.trim().toLowerCase();
    if (!s) return [] as Item[];
    const all: Item[] = [];
    issuers.forEach(([tk, name]) => {
      const sc = Math.max(rank(tk, s), rank(name, s) - 10);
      if (sc > 0) all.push({ group: "Emiten", id: "e" + tk, title: tk, hint: name, page: "Profil Emiten", ticker: tk, score: sc + 20 });
    });
    pages.forEach((p) => {
      const sc = Math.max(rank(p, s), rank(t(p), s));
      if (sc > 0) all.push({ group: "Halaman", id: "p" + p, title: t(p), page: p, score: sc });
    });
    RULES.forEach((r, i) => {
      const code = "R" + (i + 1);
      const sc = Math.max(rank(code, s), rank(r.text, s) - 15);
      if (sc > 0) all.push({ group: "Rule", id: "r" + i, title: code, hint: r.text, page: "Rule Base Viewer", score: sc });
    });
    Object.values(RATIO_DEFINITIONS).forEach((d) => {
      const sc = Math.max(rank(d.key, s), rank(d.name, s) - 5);
      if (sc > 0) all.push({ group: "Rasio", id: "d" + d.key, title: d.key, hint: d.name, page: "Ringkasan Rasio & Skor", score: sc });
    });
    return all.sort((a, b) => b.score - a.score).slice(0, 8);
  }, [q, issuers, pages, t]);

  useEffect(() => setCursor(0), [q]);
  useEffect(() => {
    const away = (e: MouseEvent) => { if (!box.current?.contains(e.target as Node)) setOpen(false); };
    const key = (e: KeyboardEvent) => {
      const typing = /INPUT|TEXTAREA|SELECT/.test((e.target as HTMLElement)?.tagName ?? "") || (e.target as HTMLElement)?.isContentEditable;
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") { e.preventDefault(); inputRef.current?.focus(); setOpen(true); }
      else if (e.key === "/" && !typing && !e.metaKey && !e.ctrlKey) { e.preventDefault(); inputRef.current?.focus(); setOpen(true); }
    };
    document.addEventListener("mousedown", away);
    window.addEventListener("keydown", key);
    return () => { document.removeEventListener("mousedown", away); window.removeEventListener("keydown", key); };
  }, [inputRef]);

  const pick = (it: Item) => { onGo(it.page, it.ticker); setQ(""); setOpen(false); inputRef.current?.blur(); };
  const showList = open && q.trim().length > 0;

  return (
    <div ref={box} className="relative hidden md:block">
      <div className="flex items-center gap-2.5 h-9 rounded-[6px] px-4" style={{ width: 300, background: C.inner, border: `1px solid ${C.border}` }}>
        <Search size={15} strokeWidth={1.75} style={{ color: C.ter }} />
        <input ref={inputRef} value={q} placeholder={placeholder}
          role="combobox" aria-expanded={showList} aria-controls={listId} aria-autocomplete="list"
          aria-activedescendant={showList && results[cursor] ? `${listId}-${cursor}` : undefined}
          onChange={(e) => { setQ(e.target.value); setOpen(true); }}
          onFocus={() => setOpen(true)}
          onKeyDown={(e) => {
            if (e.key === "ArrowDown") { e.preventDefault(); setCursor((c) => Math.min(results.length - 1, c + 1)); }
            else if (e.key === "ArrowUp") { e.preventDefault(); setCursor((c) => Math.max(0, c - 1)); }
            else if (e.key === "Enter" && results[cursor]) { e.preventDefault(); pick(results[cursor]); }
            else if (e.key === "Escape") { setOpen(false); setQ(""); inputRef.current?.blur(); }
          }}
          className="bg-transparent outline-none text-[13px] w-full" style={{ color: C.text }} />
        <kbd className="flex items-center gap-0.5 px-1.5 h-5 rounded-md text-[10px] font-semibold shrink-0"
          style={{ background: C.inner, border: `1px solid ${C.inputBorder}`, color: C.ter }}>⌘K</kbd>
      </div>
      {showList && (
        <ul id={listId} role="listbox" className="absolute left-0 top-[42px] z-50 w-[360px] max-w-[calc(100vw-1.5rem)] max-h-[360px] overflow-auto rounded-[6px] py-1 shadow-xl"
          style={{ background: C.card, border: `1px solid ${C.border}` }}>
          {results.length === 0 && <li className="px-3 py-3 text-[12px]" style={{ color: C.ter }}>{t("Tidak ada hasil")}</li>}
          {results.map((it, i) => {
            const Icon = GROUP_ICON[it.group];
            const first = i === 0 || results[i - 1].group !== it.group;
            return (
              <li key={it.id} role="presentation">
                {first && <div className="px-3 pt-2 pb-1 text-[10px] uppercase tracking-[0.08em]" style={{ color: C.ter }}>{t(GROUP_LABEL[it.group])}</div>}
                <div id={`${listId}-${i}`} role="option" aria-selected={i === cursor}
                  onMouseEnter={() => setCursor(i)} onMouseDown={(e) => e.preventDefault()} onClick={() => pick(it)}
                  className="flex items-center gap-2.5 px-3 py-1.5 cursor-pointer text-[12.5px]"
                  style={{ background: i === cursor ? C.inner : "transparent", color: C.text }}>
                  <Icon size={14} strokeWidth={1.75} style={{ color: C.ter }} />
                  <span className="font-semibold shrink-0">{it.title}</span>
                  {it.hint && <span className="truncate" style={{ color: C.ter }}>{it.hint}</span>}
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}
